System.register(["@angular/core", "@angular/router", "./maxAppContext.service", "./site-search.service", "./document_factory.service", './document_loader.service', "./user_profiles.service", "./DfObjectId", "./df_uuid_gen", "./basic_medical_saver.service", "@angular/common"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, router_1, maxAppContext_service_1, site_search_service_1, document_factory_service_1, document_loader_service_1, user_profiles_service_1, DfObjectId_1, df_uuid_gen_1, basic_medical_saver_service_1, common_1, core_2;
    var hiddenPipe, DocumentsComponent;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
                core_2 = core_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (maxAppContext_service_1_1) {
                maxAppContext_service_1 = maxAppContext_service_1_1;
            },
            function (site_search_service_1_1) {
                site_search_service_1 = site_search_service_1_1;
            },
            function (document_factory_service_1_1) {
                document_factory_service_1 = document_factory_service_1_1;
            },
            function (document_loader_service_1_1) {
                document_loader_service_1 = document_loader_service_1_1;
            },
            function (user_profiles_service_1_1) {
                user_profiles_service_1 = user_profiles_service_1_1;
            },
            function (DfObjectId_1_1) {
                DfObjectId_1 = DfObjectId_1_1;
            },
            function (df_uuid_gen_1_1) {
                df_uuid_gen_1 = df_uuid_gen_1_1;
            },
            function (basic_medical_saver_service_1_1) {
                basic_medical_saver_service_1 = basic_medical_saver_service_1_1;
            },
            function (common_1_1) {
                common_1 = common_1_1;
            }],
        execute: function() {
            hiddenPipe = (function () {
                function hiddenPipe() {
                }
                hiddenPipe.prototype.transform = function (value, args) {
                    if (!value) {
                        return value;
                    }
                    var keys = [];
                    _.each(value, function (data) {
                        if ((data.hidden != true || data.hidden != 1) && (data.hidden == undefined)) {
                            keys.push(data);
                        }
                    });
                    if (keys.length == 0) {
                        console.log(keys);
                        return keys[0] = [{ data: 'notfound' }];
                    }
                    else {
                        return keys;
                    }
                };
                hiddenPipe = __decorate([
                    core_2.Pipe({ name: 'hiddencheck' }), 
                    __metadata('design:paramtypes', [])
                ], hiddenPipe);
                return hiddenPipe;
            }());
            exports_1("hiddenPipe", hiddenPipe);
            DocumentsComponent = (function () {
                function DocumentsComponent(_router, _route, _ctx, _documents, _docLoader, _changeSaver, _userProfiles, datepipe) {
                    var _this = this;
                    this._router = _router;
                    this._route = _route;
                    this._ctx = _ctx;
                    this._documents = _documents;
                    this._docLoader = _docLoader;
                    this._changeSaver = _changeSaver;
                    this._userProfiles = _userProfiles;
                    this.datepipe = datepipe;
                    this.isShowDocumentGif = false;
                    this._amrId = "";
                    this.logoMedia = {};
                    this.frontLogoImageUrl = "";
                    this.chkResult = new core_1.EventEmitter();
                    this._orgLogoUploadStateChange = function (s, f, r) { return _this.orgLogoUploadStateChanged(s, f, r); };
                }
                Object.defineProperty(DocumentsComponent.prototype, "documentData", {
                    set: function (data) {
                        console.log(data);
                        var groupedDocs = _.filter(data, function (d) {
                            if (d.type !== undefined && d.type === "Media") {
                                return d;
                            }
                        });
                        this.teamDocumentmediaData = groupedDocs;
                        this.teamDocumentmediaData.reverse();
                        var checkhideninmedia = _.filter(this.teamDocumentmediaData, function (d) {
                            if (d.hidden == true) {
                                return d;
                            }
                        });
                        var groupeotherdDocs = _.filter(data, function (d) {
                            if (d.type !== "Media") {
                                return d;
                            }
                        });
                        var sortotherdDocs = _.sortBy(groupeotherdDocs, function (od) {
                            if (od.createdDate !== undefined) {
                                var d = new Date(od.createdDate);
                                var n = d.getDate();
                                return n;
                            }
                        });
                        var sortotherdDocsreverse = sortotherdDocs.reverse();
                        this.teamDocumentotherData = _.groupBy(sortotherdDocsreverse, function (od) {
                            if (od.createdDate !== undefined) {
                                var d = new Date(od.createdDate);
                                var n = d.getFullYear();
                                return n;
                            }
                        });
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(DocumentsComponent.prototype, "userProfile", {
                    set: function (data) {
                        this._amrId = data.amrId;
                    },
                    enumerable: true,
                    configurable: true
                });
                DocumentsComponent.prototype.ngOnInit = function () {
                    var _this = this;
                    var uuid = df_uuid_gen_1.DfUuidGen.newUuid();
                    var logoMedia = {};
                    var mediaId = uuid;
                    var params = this._route.snapshot.params;
                    this.profileId = params['id'];
                    var loadProfile = this._userProfiles.getProfile(this.profileId).single().toPromise();
                    // console.log(this._amrId);
                    this.logoUploadSettings = {
                        getFileParams: function (file) {
                            _this.isShowDocumentGif = true;
                            var fileId = df_uuid_gen_1.DfUuidGen.newUuid();
                            var uuid = df_uuid_gen_1.DfUuidGen.newUuid();
                            var mediaId = uuid;
                            var createdDate = _this.datepipe.transform(new Date(), 'MM/dd/yyyy');
                            logoMedia = {
                                _id: (new DfObjectId_1.DfObjectId()).toString(),
                                type: 'Media',
                                documentStableId: (new DfObjectId_1.DfObjectId()).toString(),
                                name: "Picture",
                                createdDate: (new Date()).toISOString(),
                                subjects: [
                                    {
                                        amrId: _this._amrId
                                    }
                                ],
                                media: [
                                    {
                                        contentType: file.type,
                                        mediaId: mediaId
                                    }
                                ],
                                lastModifiedDate: (new Date()).toISOString()
                            };
                            _this.logoMedia = logoMedia;
                            //console.log(this.logoMedia);
                            return _this._changeSaver.update(_this.logoMedia).single().toPromise()
                                .then(function (data) {
                                //  this.isShowDocumentGif = false;
                                return {
                                    paramsUrl: "/training/api/documents/" + _this.logoMedia._id + "/media/" + encodeURIComponent(mediaId)
                                };
                                // return logoMedia;
                            });
                        },
                        dfUploadTag: mediaId,
                        uploaderSettings: {
                            filters: {
                                max_file_size: '10mb',
                                mime_types: [
                                    { title: "Image files", extensions: "jpeg,jpg,gif,png" }
                                ]
                            },
                            resize: {
                                width: 600,
                                height: 600
                            }
                        },
                    };
                };
                DocumentsComponent.prototype.removeDocumentImage = function () {
                };
                DocumentsComponent.prototype.onPrint = function (documentStableId) {
                    var _this = this;
                    this.printing = true;
                    this.errorMessage = '';
                    if (documentStableId.length < 1) {
                        this.printing = false;
                        this.errorMessage = 'The selected athlete(s) have not filled out any of the selected forms.';
                        return;
                    }
                    this._docLoader.openPdf(documentStableId, window).then(function () {
                        _this.printing = false;
                        // console.log('success');
                    }).catch(function (error) {
                        _this.printing = false;
                        console.error(error);
                        _this.errorMessage = 'We encountered an error printing.  Please try again.';
                    });
                };
                DocumentsComponent.prototype.refreshdatadocument = function () {
                    var _this = this;
                    this._userProfiles.getTeamUserDocument(this.profileId).single().toPromise()
                        .then(function (data) {
                        _this.isShowDocumentGif = false;
                        var groupedDocs = _.filter(data, function (d) {
                            if (d.type !== undefined && d.type === "Media") {
                                return d;
                            }
                        });
                        _this.teamDocumentmediaData = groupedDocs;
                        _this.teamDocumentmediaData.reverse();
                        _this.chkResult.emit({
                            value: true
                        });
                    })
                        .catch(function (e) {
                        _this.isShowDocumentGif = false;
                        throw e;
                    });
                };
                DocumentsComponent.prototype.orgLogoUploadStateChanged = function (state, fromUploaderEvent, resultUrl) {
                    var _this = this;
                    this.isShowDocumentGif = true;
                    if (state === plupload.DONE) {
                        console.log(this.logoMedia);
                        this._changeSaver.getLogoUrldocumentmedia(this.logoMedia).single().toPromise()
                            .then(function (url) {
                            _this.frontLogoImageUrl = url;
                        })
                            .catch(function (e) {
                            console.log('Logo error - ' + e.message);
                            _this.errorMessage = 'An error was encountered showing the image.';
                            // this.logoUploading = false;
                        });
                        this.refreshdatadocument();
                    }
                    else if (state === plupload.FAILED) {
                        // this.logoUploading = false;
                        this.errorMessage = 'An error was encountered while uploading your image.  Refresh the page and try again.';
                    }
                    else {
                    }
                };
                ;
                __decorate([
                    core_1.Output(), 
                    __metadata('design:type', core_1.EventEmitter)
                ], DocumentsComponent.prototype, "chkResult", void 0);
                __decorate([
                    core_1.Input('documentData'), 
                    __metadata('design:type', site_search_service_1.SiteSearch), 
                    __metadata('design:paramtypes', [site_search_service_1.SiteSearch])
                ], DocumentsComponent.prototype, "documentData", null);
                __decorate([
                    core_1.Input('userProfile'), 
                    __metadata('design:type', Object), 
                    __metadata('design:paramtypes', [Object])
                ], DocumentsComponent.prototype, "userProfile", null);
                DocumentsComponent = __decorate([
                    core_1.Component({
                        selector: 'document-data',
                        providers: [document_loader_service_1.DocumentLoader],
                        template: "\n        <div class=\"row\">\n            <div class=\"col-xs-12 col-sm-12 col-md-6 text-left pull-right\">\n                <ul class=\"doument-list\">\n                    <span *ngFor=\"let otherdocument of teamDocumentotherData | keys; let i=index;\">\n                        <h4 class=\"doument-group\">{{otherdocument?.key}}</h4>\n                        <li  *ngFor=\"let otherdocument of otherdocument.value | hiddencheck\">\n                            <span  *ngIf=\"otherdocument.data  != 'notfound'\" class=\"doument-icon\"></span> <a  *ngIf=\"otherdocument.data  != 'notfound'\" href=\"javascript:void(0)\" (click)=\"onPrint(otherdocument.documentStableId)\" class=\"dropdown-item\">{{otherdocument?.name}}</a><i *ngIf=\"otherdocument.data  != 'notfound'\" class=\"doument-date\" >{{otherdocument.createdDate | date: 'MM/dd/yyyy'}}</i>\n                            <div *ngIf=\"otherdocument.data  == 'notfound'\" class=\"alert alert-info\" style=\"text-align: center\">\n                               No documents on file\n                 </div> \n                        </li>\n                        </span>   \n            </ul>\n                 <div *ngIf=\"(teamDocumentotherData | json) == '{}'\" class=\"alert alert-info\" style=\"text-align: center\">\n                               No documents on file\n                 </div> \n            </div>\n            <div class=\"col-xs-12 col-sm-12 col-md-6 doument-img pull-left\">\n            <div>\n             <button  [disabled]=\"isShowDocumentGif\" type=\"button\" df-pl-upload-host class=\"btn btn-primary\" [uploadSettings]=\"logoUploadSettings\" [uploadStateChanged]=\"_orgLogoUploadStateChange\"><span class=\"glyphicon glyphicon-plus\"></span> Upload</button>\n             <span *ngIf=\"isShowDocumentGif\">Uploading image...</span>\n             </div>\n             \n              <div *ngIf=\"isShowDocumentGif\" style=\"text-align: center\">\n                            <img style=\"max-width:30px; max-height:30px; width:30px\" src=\"/maxweb/app/media/ajax-loader.gif\" /> \n             </div>\n             <div *ngIf=\"!isShowDocumentGif\" style=\"padding-top:22px;\"> <documentlist-media style=\"position: relative;\" (chkResult)=\"refreshdatadocument()\" *ngFor=\"let document of teamDocumentmediaData | hiddencheck; let i=index;\" [documentmedia]=\"document\"></documentlist-media></div>\n            \n                <div *ngIf=\"teamDocumentmediaData.length == 0\" class=\"alert alert-info\" style=\"text-align: center\">\n                           No media found\n                 </div> \n             </div>  \n        </div>"
                    }), 
                    __metadata('design:paramtypes', [router_1.Router, router_1.ActivatedRoute, maxAppContext_service_1.MaxAppContext, document_factory_service_1.Documents, document_loader_service_1.DocumentLoader, basic_medical_saver_service_1.BasicMedicalSaver, user_profiles_service_1.UserProfiles, common_1.DatePipe])
                ], DocumentsComponent);
                return DocumentsComponent;
            }());
            exports_1("DocumentsComponent", DocumentsComponent);
        }
    }
});
//# sourceMappingURL=documents.component.js.map