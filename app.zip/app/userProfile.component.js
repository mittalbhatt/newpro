System.register(["@angular/core", "./user_profiles.service", "@angular/router", "./assignments.service", "./df_uuid_gen", "./organizations.service", "./relatedProfilesList.component", "./maxAppContext.service", "./confirmProfileDelete", "./intercomRouterTracker.service", 'angular2-modal/plugins/bootstrap'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, user_profiles_service_1, router_1, assignments_service_1, df_uuid_gen_1, organizations_service_1, relatedProfilesList_component_1, maxAppContext_service_1, confirmProfileDelete_1, intercomRouterTracker_service_1, bootstrap_1;
    var UserProfileComponent;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (user_profiles_service_1_1) {
                user_profiles_service_1 = user_profiles_service_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (assignments_service_1_1) {
                assignments_service_1 = assignments_service_1_1;
            },
            function (df_uuid_gen_1_1) {
                df_uuid_gen_1 = df_uuid_gen_1_1;
            },
            function (organizations_service_1_1) {
                organizations_service_1 = organizations_service_1_1;
            },
            function (relatedProfilesList_component_1_1) {
                relatedProfilesList_component_1 = relatedProfilesList_component_1_1;
            },
            function (maxAppContext_service_1_1) {
                maxAppContext_service_1 = maxAppContext_service_1_1;
            },
            function (confirmProfileDelete_1_1) {
                confirmProfileDelete_1 = confirmProfileDelete_1_1;
            },
            function (intercomRouterTracker_service_1_1) {
                intercomRouterTracker_service_1 = intercomRouterTracker_service_1_1;
            },
            function (bootstrap_1_1) {
                bootstrap_1 = bootstrap_1_1;
            }],
        execute: function() {
            UserProfileComponent = (function () {
                function UserProfileComponent(_profilesSvc, _assignmentsSvc, _organizations, _route, _ctx, _router, _profileUtil, _modal, _intercom) {
                    var _this = this;
                    this._profilesSvc = _profilesSvc;
                    this._assignmentsSvc = _assignmentsSvc;
                    this._organizations = _organizations;
                    this._route = _route;
                    this._ctx = _ctx;
                    this._router = _router;
                    this._profileUtil = _profileUtil;
                    this._modal = _modal;
                    this._intercom = _intercom;
                    this.organizationApprovedMessages = [];
                    this.organizationApprovedCount = 0;
                    this.profileImageUploadStateChangeHandler = function (s, f, r) { return _this.onProfileImageUploadStateChanged(s, f, r); };
                    this._route.params.subscribe(function (params) {
                        _this.profileId = params['userProfileId'];
                        _this.refresh();
                    });
                    console.log("After Login");
                    console.log(this._ctx);
                    this.organizationApprovedMessage();
                }
                UserProfileComponent.prototype.organizationApprovedMessage = function () {
                    var _this = this;
                    _.each(this._ctx.myProfiles, function (profile) {
                        if (profile.state) {
                            if (profile.state.pendingApproval !== undefined && profile.state.pendingApproval == true) {
                                if (_.intersection(profile.orgRoles, ['TRN']).length == 0) {
                                    //console.log("Roles===========================");
                                    //console.log(profile.orgRoles);
                                    //console.log(_.intersection(profile.orgRoles, ['PRN']));
                                    //console.log(_.intersection(profile.orgRoles, ['TRN', 'OTRN', 'ADM', 'CCH']).length);
                                    var isHide = false;
                                    if (_.intersection(profile.orgRoles, ['TRN', 'OTRN', 'ADM', 'CCH']).length == 0 && _.intersection(profile.orgRoles, ['PRN']).length == 1) {
                                        isHide = true;
                                    }
                                    var org = _.find(_this._ctx.availableOrganizations, function (o) {
                                        return o._id == profile.org;
                                    });
                                    //console.log("Org----------------------");
                                    //console.log(org.name);
                                    _this.organizationApprovedMessages.push({
                                        profileId: profile._id,
                                        profile: profile,
                                        name: org.name,
                                        sortName: org.sortName,
                                        hidden: isHide
                                    });
                                }
                            }
                            else {
                                _this.organizationApprovedCount++;
                            }
                        }
                    });
                };
                Object.defineProperty(UserProfileComponent.prototype, "isAdmin", {
                    get: function () {
                        if (!this.profile)
                            return false;
                        if (!this.profile.orgRoles)
                            return false;
                        return !!_.intersection(this.profile.orgRoles, ['OTRN', 'TRN', 'OADM']).length;
                    },
                    enumerable: true,
                    configurable: true
                });
                UserProfileComponent.prototype.refresh = function () {
                    var _this = this;
                    this.loading = true;
                    delete this.profileImageUrl;
                    var userProfileId = this.profileId;
                    this.profileImageUploadSettings = {
                        getFileParams: function () {
                            var fileId = df_uuid_gen_1.DfUuidGen.newUuid();
                            var imageUrl = "/training/api/userProfiles/" + userProfileId + "/images/" + fileId;
                            _this.profile.imageUris[0] = imageUrl;
                            return Promise.resolve({
                                fileId: fileId,
                                userProfileId: userProfileId,
                                paramsUrl: imageUrl
                            });
                        },
                        dfUploadTag: 'profile-image-' + userProfileId,
                        uploaderSettings: {
                            filters: {
                                max_file_size: '10mb',
                                mime_types: [
                                    { title: "Image files", extensions: "jpeg,jpg,gif,png" }
                                ]
                            },
                            resize: {
                                width: 600,
                                height: 600
                            }
                        }
                    };
                    var profilePromise = this._profilesSvc.getProfile(userProfileId).single().toPromise();
                    var documentationAssignmentsPromise = this._assignmentsSvc.getUserAssignments('Documentation', userProfileId);
                    Promise.all([profilePromise, documentationAssignmentsPromise])
                        .then(function (_a) {
                        var profile = _a[0], documentationAssignments = _a[1];
                        _this.profile = new user_profiles_service_1.UserProfile(profile);
                        _this.loadImage();
                        _this.documentationAssignments = documentationAssignments;
                        return _this._ctx.myOrganizations.find(function (o) { return o._id == profile.org; });
                    })
                        .then(function (org) {
                        _this.profileOrg = org;
                        _this.loading = false;
                    })
                        .catch(function (e) {
                        console.log(e);
                        _this.errorMessage = 'We encountered an unexpected error.  Try refreshing the page.';
                        throw e;
                    });
                };
                UserProfileComponent.prototype.onProfileImageUploadStateChanged = function (state, fromUploaderEvent, resultUrl) {
                    var _this = this;
                    if (state === plupload.DONE) {
                        this._intercom.track('set-profile-picture');
                        this.loadImage().then(function () { return _this.profileImageUploading = false; })
                            .catch(function (e) {
                            _this.profileImageUploading = false;
                            throw e;
                        });
                    }
                    else if (state === plupload.FAILED) {
                        console.log('UPLOAD FAILED');
                        this.profileImageUploading = false;
                        this.errorMessage = 'An error was encountered while uploading your image.  Refresh the page and try again.';
                    }
                    else {
                        console.log('UPLOAD OK');
                        this.profileImageUploading = true;
                    }
                };
                ;
                UserProfileComponent.prototype.loadImage = function () {
                    var _this = this;
                    return this._profilesSvc.getProfileImageUrl(this.profile).single().toPromise()
                        .then(function (url) { return _this.profileImageUrl = url; })
                        .catch(function (e) {
                        console.log('Logo error', e);
                        throw e;
                    });
                };
                UserProfileComponent.prototype.onClickRelatedUser = function (profile) {
                    this._router.navigate(['profile', profile._id], { relativeTo: this._route.parent });
                };
                UserProfileComponent.prototype.onClickEditRelatedUser = function (profile) {
                    this._router.navigate(['/max-forms/editFormsProfile', profile._id]);
                };
                UserProfileComponent.prototype.onClickDeleteRelatedUser = function (profile) {
                    var _this = this;
                    // cache this field's value because somehow it gets unset
                    var relatedList = this.relatedList;
                    if (!relatedList)
                        throw new Error('relatedList is undefined');
                    this._profileUtil.confirmProfileDelete(profile, function () {
                        _this.loading = true;
                        _this._profilesSvc.deleteProfile(profile)
                            .single().toPromise().then(function () {
                            relatedList.clear(profile);
                            _this.loading = false;
                        })
                            .catch(function (e) {
                            _this.loading = false;
                            _this.errorMessage = 'We encountered an unexpected error. Refresh the page and try again.';
                            throw e;
                        });
                    });
                };
                UserProfileComponent.prototype.onClickFillForms = function () {
                    var route = ['/max-forms/packetList'];
                    if (this.profile.orgRoles.indexOf('ATH') > -1)
                        route.push({ profileId: this.profileId });
                    this._router.navigate(route);
                };
                UserProfileComponent.prototype.onClickFormsAssignment = function (assignment) {
                    this._router.navigate(['/max-forms/athDocDashboard', assignment.activities[0]._id, this.profileId]);
                };
                UserProfileComponent.prototype.areYouSure = function (organizationName, profile) {
                    var _this = this;
                    this._modal.confirm()
                        .size('sm').isBlocking(true).showClose(false).keyboard(27)
                        .body("Are you sure you want to revoke your request to join  " + organizationName + "?")
                        .headerClass("hide")
                        .okBtn('Revoke My Request')
                        .okBtnClass("btn btn-danger")
                        .cancelBtnClass("btn btn-primary")
                        .open().then(function (dialog) {
                        return dialog.result;
                    }).then(function (result) {
                        _this._profilesSvc.deleteProfile(profile)
                            .single().toPromise().then(function () {
                            _this.organizationApprovedMessages = _.reject(_this.organizationApprovedMessages, function (arrItem) {
                                return arrItem.profileId === profile._id;
                            });
                            if (_this.organizationApprovedMessages.length === 0 && _this.organizationApprovedCount === 0) {
                                _this._ctx.resetOrg();
                            }
                        }).catch(function (e) {
                            _this.errorMessage = 'We encountered an unexpected error. Refresh the page and try again.';
                            throw e;
                        });
                    }).catch(function (e) {
                    });
                };
                __decorate([
                    core_1.ViewChild('profileList'), 
                    __metadata('design:type', relatedProfilesList_component_1.RelatedProfilesList)
                ], UserProfileComponent.prototype, "relatedList", void 0);
                UserProfileComponent = __decorate([
                    core_1.Component({
                        selector: 'user-profile',
                        template: "\n <!--<div class=\"profile-card\" style=\"background-color:#ffffe0\">\n            <div class=\"container-fluid\">\n                <div class=\"row\">\n                    <div class=\"col-md-12\" style=\"font-size:18px;\">Go get the app for the full<br/> DragonFly MAX experience!</div>\n                </div>\n                <div class=\"row\">\n                    <div class=\"col-xs-6\">\n                        <a target=\"_blank\" href=\"https://itunes.apple.com/us/app/dragonfly-max/id894686415\">\n                            <img style=\"width:90%; height:100%; margin:6%\" src=\"app/media/Download_on_the_App_Store_Badge_US-UK_135x40.svg\"/>\n                        </a>\n                    </div>\n                    <div class=\"col-xs-6\">\n                        <a target=\"_blank\" href='https://play.google.com/store/apps/details?id=com.dragonfly.max.live&hl=en&utm_source=global_co&utm_medium=prtnr&utm_content=Mar2515&utm_campaign=PartBadge&pcampaignid=MKT-Other-global-all-co-prtnr-py-PartBadge-Mar2515-1'>\n                            <img style=\"width:100%; height:100%\" alt='Get it on Google Play' src='https://play.google.com/intl/en_us/badges/images/generic/en_badge_web_generic.png'/>\n                        </a>\n                    </div>\n                </div>\n            </div>\n        </div>\n-->\n<div class=\"team-page\" >\n<div class=\"container-fluid\">\n    <div class=\"alert alert-info\" *ngFor=\"let msg of organizationApprovedMessages\" [hidden]=\"msg.hidden\">\n        Waiting for approval for {{msg.name}}.\n        <a (click)=\"areYouSure(msg.name, msg.profile)\" class=\"text-right cursor-pointer\">\n            <i class=\"fa fa-trash-o text-right\" aria-hidden=\"true\"></i>\n        </a>\n    </div>\n    <div class=\"profile-card\">\n        <div *ngIf=\"errorMessage\" class=\"alert alert-danger\">{{errorMessage}}</div>\n\n        <div *ngIf=\"loading\">\n            <img src=\"/maxweb/app/media/ajax-loader.gif\" />\n            Loading...\n        </div>\n\n        <div *ngIf=\"!loading && !errorMessage\">\n\n\n\n            <h1>{{profile?.athleteTitleName}}</h1>\n            <p *ngIf=\"profileOrg?.roles && profileOrg.roles.indexOf('Training') < 0\" style=\"margin-bottom:10px;\">{{profile?.roleDisplayTitle}} in {{profileOrg?.name}}</p>\n\n            <!-- <h5 *ngIf=\"relatedList?.relatedProfiles?.length\" style=\"text-align:left\">My Kids:</h5> -->\n            <h4 *ngIf=\"profileOrg?.roles && profile?.orgRoles?.indexOf('PRN') > -1 && relatedList?.relatedProfiles?.length==0\" class=\"profilelist-h4\">To get started filling out forms, click or tap \u2018Add a child\u2019</h4>\n            <related-profiles-list *ngIf=\"profileOrg?.roles && profile?.orgRoles?.indexOf('PRN') > -1\" #profileList [profileId]=\"profileId\" (itemDeleteClicked)=\"onClickDeleteRelatedUser($event)\" (itemClicked)=\"onClickRelatedUser($event)\" (itemEditClicked)=\"onClickEditRelatedUser($event)\" [relationRoles]=\"['PRN']\"></related-profiles-list>\n\n            <h5 *ngIf=\"documentationAssignments?.length\" style=\"text-align: left\">Available forms:</h5>\n            <div class=\"list-group\">\n                <button *ngFor=\"let assignment of documentationAssignments\" type=\"button\" class=\"list-group-item\" (click)=\"onClickFormsAssignment(assignment)\">\n                    {{assignment.activities[0].documentationEventDescription.eventName}}\n                    <span style=\"float:right\" class=\"glyphicon glyphicon-menu-right\"></span>\n                </button>\n            </div>\n\n            <button *ngIf=\"profile?.orgRoles?.indexOf('ATH') > -1 || (_ctx.currentProfile?._id == profile?._id && profile?.orgRoles?.indexOf('TRN') < 0 && profile?.orgRoles?.indexOf('PRN') < 0)\" (click)=\"onClickFillForms()\" class=\"btn btn-primary\">Fill out forms</button>\n\n            <div *ngIf=\"isAdmin\">\n                <table style=\"width:100%; margin:auto; margin-top:0px; margin-bottom:20px;\">\n                <tr><td style=\"border-bottom:1px solid #5d5d5d; width:30%;\">&nbsp;</td><td width=\"auto\"><p style=\"font-size:18px; margin-top:10px; margin-right:2px; margin-left:2px; height:1px;\">Administration</p></td><td style=\"border-bottom:1px solid #5d5d5d; width:30%\">&nbsp;</td></tr>\n              </table>\n                <max-admin-menu></max-admin-menu>\n            </div>\n        </div>\n    </div>\n</div>\n</div>\n\n"
                    }), 
                    __metadata('design:paramtypes', [user_profiles_service_1.UserProfiles, assignments_service_1.Assignments, organizations_service_1.Organizations, router_1.ActivatedRoute, maxAppContext_service_1.MaxAppContext, router_1.Router, confirmProfileDelete_1.ProfileUtil, bootstrap_1.Modal, intercomRouterTracker_service_1.IntercomRouterTracker])
                ], UserProfileComponent);
                return UserProfileComponent;
            }());
            exports_1("UserProfileComponent", UserProfileComponent);
        }
    }
});
//# sourceMappingURL=userProfile.component.js.map