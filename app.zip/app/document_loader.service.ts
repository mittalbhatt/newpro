import {Injectable, Inject} from "@angular/core";
import {RequestOptions} from "@angular/http";

@Injectable()
export class DocumentLoader {
    constructor(@Inject(RequestOptions) private _requestOps:RequestOptions) {
        
    }

    openPdf(docId:string, window, pages='')
    {
        var url = `/training/api/documents/${docId}/pdf`;
        if (pages && pages.length)
            url += '?pages=' + pages;

        return this.requestPdf(window, 'GET', url);
    }
    
    openpacketformsPdf(activityId:string,window, pages='')
    {
        var url = `/training/api/activities/documentation/${activityId}/pdf`;
        
        if (pages && pages.length)
            url += '?pages=' + pages;

        return this.requestPdf(window, 'GET', url);
    }
    opengettingstartedPdf(currentOrgDetailsId:string,username:string,password:string,window, pages='')
    {          
        
         var url = `/training/api/organizations/${currentOrgDetailsId}/parentSheet?auth.basic.username=${username}&auth.basic.password=${password}`;
        if (pages && pages.length)
            url += '?pages=' + pages;

        return this.requestPdf(window, 'GET', url);
    }

    openBulkPdf(documentStableIds:string[], window)
    {
        return this.requestPdf(window, 'PUT', '/training/api/documentbulk?cover=true', JSON.stringify(documentStableIds));
    }

    requestPdf(window, method, url, content=undefined)
    {
        var pdfWindow;

        // Pointing the window to the blob does not work on lte IE 11, but they have
        // their own method that does.
        if (!window.navigator.msSaveOrOpenBlob)
            pdfWindow = window.open(`/maxweb/app/media/spinner.html`);

        var xhr = new XMLHttpRequest();

        var p = new Promise((resolve, reject) =>
        {
            xhr.addEventListener('load', r =>
            {
                if (xhr.status != 200)
                {
                    reject(r);
                    return;
                }

                var pdfBlob = new Blob([xhr.response], { type: 'application/pdf' });
                if (!pdfWindow)
                    window.navigator.msSaveOrOpenBlob(pdfBlob, "document.pdf");
                else
                    pdfWindow.location = (window.URL || window.webkitURL).createObjectURL(pdfBlob);

                resolve();
            });

            xhr.addEventListener('error', e =>
            {
                reject(e);
            });
        });

        p.catch(() => { if (pdfWindow) pdfWindow.close(); });

        xhr.open(method, url, true);

        // IMPORTANT: for IE 11 to work you must set this after calling .open(...)
        xhr.responseType = 'blob';

        if (content)
            xhr.setRequestHeader('Content-Type', 'application/json');

        xhr.setRequestHeader('Authorization', this._requestOps.headers.get('Authorization'));

        xhr.send(content);

        return p;
    }
}

