System.register(["@angular/core", "./maxAppContext.service", "./user_profiles.service", "@angular/router", "./activities.service", "./assignments.service", "./document_factory.service", "angular2-modal", "./helper.service"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, maxAppContext_service_1, user_profiles_service_1, router_1, activities_service_1, assignments_service_1, document_factory_service_1, angular2_modal_1, helper_service_1;
    var TypeOfPacketList, PacketList;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (maxAppContext_service_1_1) {
                maxAppContext_service_1 = maxAppContext_service_1_1;
            },
            function (user_profiles_service_1_1) {
                user_profiles_service_1 = user_profiles_service_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (activities_service_1_1) {
                activities_service_1 = activities_service_1_1;
            },
            function (assignments_service_1_1) {
                assignments_service_1 = assignments_service_1_1;
            },
            function (document_factory_service_1_1) {
                document_factory_service_1 = document_factory_service_1_1;
            },
            function (angular2_modal_1_1) {
                angular2_modal_1 = angular2_modal_1_1;
            },
            function (helper_service_1_1) {
                helper_service_1 = helper_service_1_1;
            }],
        execute: function() {
            TypeOfPacketList = (function () {
                function TypeOfPacketList(org, type, packet, recommend_label, other_label) {
                    if (recommend_label === void 0) { recommend_label = 0; }
                    if (other_label === void 0) { other_label = 0; }
                    this.org = org;
                    this.type = type;
                    this.packet = packet;
                    this.recommend_label = recommend_label;
                    this.other_label = other_label;
                }
                return TypeOfPacketList;
            }());
            exports_1("TypeOfPacketList", TypeOfPacketList);
            PacketList = (function () {
                function PacketList(_ctx, _userProfiles, _activities, _assignments, _documents, _route, _router, _modal, _helper) {
                    this._ctx = _ctx;
                    this._userProfiles = _userProfiles;
                    this._activities = _activities;
                    this._assignments = _assignments;
                    this._documents = _documents;
                    this._route = _route;
                    this._router = _router;
                    this._modal = _modal;
                    this._helper = _helper;
                    this.packetList = [];
                    // packetList:any[][] = [];
                    this.groupByOrgPacketList = [];
                    this.profileId = "";
                    this.isLoading = false;
                    this.filedSection = [];
                    this.amrInfoFields = [];
                    this.isBasicFormUnfilled = false;
                    this.isValidRelative = false;
                    this.greenBadge = false;
                    this.isLoading = true;
                    this.profileId = this._route.snapshot.params['profileId'];
                }
                PacketList.prototype.compareTwoArr = function (arr1, arr2) {
                    var isCompare = false;
                    _.each(arr1, function (t) {
                        var is_recommended = _.contains(arr2, t);
                        if (is_recommended) {
                            isCompare = true;
                        }
                    });
                    return isCompare;
                };
                PacketList.prototype.ngOnInit = function () {
                    var _this = this;
                    if (!this.profileId)
                        throw new Error('profileId is required for PacketList.');
                    this._userProfiles.getProfile(this.profileId).single().toPromise()
                        .then(function (targetProfile) {
                        _this.targetProfile = targetProfile;
                        //console.log( this.targetProfile);
                        // For get amr object for count 
                        if (_this.targetProfile.$amr != undefined && _this.targetProfile.$amr.info != undefined) {
                            if (!_.has(_this.targetProfile.$amr.info, "email")) {
                                if (_.has(_this.targetProfile, "email")) {
                                    _this.targetProfile.$amr.info['email'] = _this.targetProfile.email;
                                }
                            }
                            if (!_.has(_this.targetProfile.$amr.info, "firstName")) {
                                if (_.has(_this.targetProfile, "firstName")) {
                                    _this.targetProfile.$amr.info['firstName'] = _this.targetProfile.firstName;
                                }
                            }
                            if (!_.has(_this.targetProfile.$amr.info, "lastName")) {
                                if (_.has(_this.targetProfile, "lastName")) {
                                    _this.targetProfile.$amr.info['lastName'] = _this.targetProfile.lastName;
                                }
                            }
                            if (!_.has(_this.targetProfile.$amr.info, "tel")) {
                                if (_.has(_this.targetProfile, "tel")) {
                                    _this.targetProfile.$amr.info['tel'] = _this.targetProfile.tel;
                                }
                            }
                            _this.amrInfoFields = _this.targetProfile.$amr.info;
                        }
                        if (_this.amrInfoFields) {
                            // Get All fields object from helper
                            _this.filedSection = _this._helper.basicMedicalFiledSection;
                            _this.isBasicFormUnfilled = _this.getRequiredUnfilled(_this.filedSection);
                        }
                        else {
                            _this.isBasicFormUnfilled = true;
                        }
                        _this.isValidRelative = _this.checkRelativeIsValid(_this.targetProfile, _this._ctx.currentProfile);
                        // if athelete(ATH) then check basic form and relative also otherwise check only basic form
                        if ((_.contains(_this.targetProfile.orgRoles, 'ATH') === true && _this.isBasicFormUnfilled == false && _this.isValidRelative) || (_.contains(_this.targetProfile.orgRoles, 'ATH') !== true && _this.isBasicFormUnfilled == false)) {
                            _this.greenBadge = true;
                        }
                        // get Packets Data
                        _this.getPacketList();
                        if (targetProfile.orgRoles.indexOf('TRN') > -1) {
                            _this._router.navigate(['/main']);
                            return;
                        }
                        var targetProfileOrg = _this._ctx.availableOrganizations.find(function (o) { return o._id == targetProfile.org; });
                        var medicalDocActivityId = (targetProfileOrg.defaultDocuments.find(function (d) { return d.form == 'medical' && d.context == 'userProfile'; }) || { activityId: undefined }).activityId;
                        _this.medicalDocumentActivityId = medicalDocActivityId;
                        var activitiesPromise = _this._activities.getDocumentationActivities(targetProfile.org).single().toPromise();
                        var assignmentsPromise = _this._assignments.getMine();
                        // All that matters is the first medicalRecords entry.  See documentFactoryHandler.js
                        var medRecordStableDocId = (targetProfile.medicalRecords || [{ medicalRecordStableDocumentId: null }])[0].medicalRecordStableDocumentId;
                        var medicalDocumentPromise = medRecordStableDocId ? _this._documents.getDocumentWithStableId(medRecordStableDocId).single().toPromise() : Promise.resolve(null);
                        Promise.all([activitiesPromise, assignmentsPromise, medicalDocumentPromise])
                            .then(function (_a) {
                            var activities = _a[0], assignments = _a[1], medicalDocument = _a[2];
                            if (medicalDocument && medicalDocument.originalDescription._id == medicalDocActivityId)
                                _this.medicalDocument = medicalDocument;
                            _this.docActs = activities.map(function (act) {
                                return {
                                    docAct: act,
                                    assignment: assignments.find(function (a) {
                                        return !!a.assignees.find(function (aa) { return aa.userProfileId == targetProfile._id; })
                                            && !!a.activities.find(function (aa) { return aa._id == act._id; });
                                    })
                                };
                            });
                        });
                    });
                };
                PacketList.prototype.getPacketList = function () {
                    var _this = this;
                    this._assignments.getAllPackets().subscribe(function (data) {
                        var pack = _.groupBy(data, function (o) {
                            return o.activities[0].documentationEventDescription.coordinatorName;
                        });
                        var i = 0;
                        var recommend_label = 1;
                        var other_label = 1;
                        _.each(pack, function (val, key) {
                            recommend_label = 1;
                            other_label = 1;
                            _.each(val, function (o) {
                                if (o.assignees.length > 0) {
                                    _.each(_this._ctx.myProfiles, function (p) {
                                        if (o.assignees[0].orgId == p.org && o.assignees[0].orgId == _this.targetProfile.org) {
                                            var tags = _.pluck(o.assignees, 'tag');
                                            var tag = _.map(tags, function (t) {
                                                if (t !== undefined) {
                                                    var res = t.split(":");
                                                    return res[0];
                                                }
                                            });
                                            var pTag = [];
                                            if (p.tags !== undefined && p.tags !== null) {
                                                pTag = _.map(p.tags, function (pt) {
                                                    if (pt !== undefined) {
                                                        return pt.replace(/[\,\!]/g, "");
                                                    }
                                                });
                                            }
                                            var pStag = [];
                                            if (p.pendingSports !== undefined && p.pendingSports !== null) {
                                                pStag = p.pendingSports;
                                            }
                                            var pTags = _.union(pTag, pStag);
                                            var is_recommended = _this.compareTwoArr(tag, pTags);
                                            if (is_recommended) {
                                                _this.packetList.push(new TypeOfPacketList(key, "recommended", o, recommend_label, 0));
                                                recommend_label = 0;
                                            }
                                            else {
                                                _this.packetList.push(new TypeOfPacketList(key, "other", o, 0, other_label));
                                                other_label = 0;
                                            }
                                        }
                                    });
                                }
                                i++;
                            });
                        });
                        var uniquePack = _.uniq(_this.packetList, function (p) {
                            return p.packet._id;
                        });
                        _this.packetList = uniquePack;
                        // Packelist 
                        _this.groupByOrgPacketList = _.groupBy(_this.packetList, function (o) {
                            var assigneesRoles = _.chain(o.packet.assignees)
                                .pluck('role')
                                .flatten()
                                .value();
                            _.each(_this.targetProfile.orgRoles, function (t) {
                                var roleAvailable = _.contains(assigneesRoles, t);
                                if (roleAvailable) {
                                    o.showPacketForCurrentAssignee = true;
                                }
                            });
                            return o.org;
                        });
                        _this.isLoading = false;
                    });
                };
                PacketList.prototype.onClickDocAct = function (docAct) {
                    if (!(this.medicalDocument && this.medicalDocument.completedDate))
                        this._modal.alert().message('You must complete Basic Medical Information first.').open();
                    else
                        this._router.navigate(['athDocDashboard', docAct.docAct._id, this.targetProfile._id], { relativeTo: this._route.parent });
                };
                PacketList.prototype.onClickMedDoc = function () {
                    this._router.navigate(['/main/basicmedicalForm', this.targetProfile._id, this.medicalDocumentActivityId], { relativeTo: this._route.parent });
                };
                PacketList.prototype.onClickMePacket = function (id, pack) {
                    var _this = this;
                    // When athelete(ATH) then check basic form and added relative also
                    if (_.contains(this.targetProfile.orgRoles, 'ATH') == true && (this.isBasicFormUnfilled === true || this.isValidRelative === false)) {
                        this._modal.alert()
                            .message('You must complete Basic Medical Information first.')
                            .okBtn("OK")
                            .open()
                            .then(function (dialog) {
                            return dialog.result;
                        }).then(function (result) {
                            if (result === true) {
                                _this._router.navigate(['/main/basicmedicalForm', _this.targetProfile._id, _this.medicalDocumentActivityId], { relativeTo: _this._route.parent });
                            }
                        });
                    }
                    else {
                        if (this.checkPacketIfSubmit(pack)) {
                            this._modal.alert().message('The forms have already been submitted.').open();
                        }
                        else {
                            this._router.navigate(['athDocDashboard', id, this.targetProfile._id], { relativeTo: this._route.parent });
                        }
                    }
                };
                PacketList.prototype.checkPacketIfSubmit = function (pack) {
                    var _this = this;
                    var isSubmited = false;
                    if (pack.packet.$responseHistory !== undefined) {
                        _.find(pack.packet.$responseHistory, function (o) {
                            if (o.userProfileId === _this.profileId) {
                                if (o.responseHistory[0] !== undefined && o.responseHistory[0].data.submitted === true) {
                                    isSubmited = true;
                                }
                            }
                        });
                    }
                    return isSubmited;
                };
                // Check relative is valid If firstname or lastName and email or phone value available
                PacketList.prototype.checkRelativeIsValid = function (targetProfile, currentProfile) {
                    if (targetProfile.relations != undefined && targetProfile.relations.length > 0) {
                        var allRelationObj_1 = [];
                        _.each(targetProfile.relations, function (relationObj, key) {
                            var isvalidObj = false;
                            if (relationObj.firstName != '' || relationObj.lastName != '') {
                                if (relationObj.email != '' || (relationObj.tel != undefined && relationObj.tel.length > 0 && relationObj.tel[0] != '')) {
                                    isvalidObj = true;
                                }
                            }
                            allRelationObj_1.push(isvalidObj);
                        });
                        var objectIsValid = true;
                        if (_.contains(allRelationObj_1, false) == true) {
                            objectIsValid = false;
                        }
                        return objectIsValid;
                    }
                    else if (targetProfile.relations == undefined && _.contains(this.targetProfile.orgRoles, 'ATH') == true) {
                        return false;
                    }
                    else if (_.has(targetProfile, 'relations') && _.contains(this.targetProfile.orgRoles, 'ATH') == true) {
                        if (targetProfile.relations.length == 0) {
                            return false;
                        }
                    }
                    else {
                        return true;
                    }
                };
                // Check Unfilled value data with get count 
                PacketList.prototype.getRequiredUnfilled = function (sections) {
                    var _this = this;
                    //console.log(this.amrInfoFields);
                    var requiredUnfilled = _.chain(sections)
                        .pluck('fields')
                        .flatten()
                        .filter(function (f) {
                        return (f.required || (f.requireIfAll && _.every(f.requireIfAll, function (ff) { return (_this.lookupValue(ff.ident) === ff.value) || (ff.value === 'Female' && _this.lookupValue(ff.ident) === 'Female') || ((ff.value == false || ff.value == 0) && _this.lookupValue(ff.ident) === undefined); }))) && (_this.valueIsNullUndefinedOrEmpty(f.ident) || _this.lookupTextValue(f.ident) == "") && (_this.lookupValue(f.ident) !== false && _this.lookupValue(f.ident) !== 0);
                    })
                        .pluck('ident')
                        .value();
                    var explanationsRequiredUnfulfilled = _.chain(sections)
                        .pluck('fields')
                        .flatten()
                        .filter(function (f) {
                        return f.explanationRequired && (_this.lookupValue(f.ident) == true || _this.lookupValue(f.ident) == 1) && _this.valueIsNullUndefinedOrEmpty(f.ident + '_explanation');
                    })
                        .pluck('ident')
                        .map(function (i) { return i + '_explanation'; })
                        .value();
                    var showIfAllRequiredUnfulfilled = _.chain(sections)
                        .pluck('fields')
                        .flatten()
                        .filter(function (f) {
                        return f.showIfAll && _.every(f.showIfAll, function (ff) { return (_this.lookupValue(ff.ident) != false && _this.lookupValue(ff.ident) != 0) && ff.mainIdent && (_this.arrayLength(ff.mainIdent) == undefined); });
                    })
                        .pluck('showIfAll')
                        .map(function (i) { return i[0].ident; })
                        .value();
                    showIfAllRequiredUnfulfilled = _.uniq(showIfAllRequiredUnfulfilled);
                    requiredUnfilled = requiredUnfilled.concat(explanationsRequiredUnfulfilled);
                    requiredUnfilled = requiredUnfilled.concat(showIfAllRequiredUnfulfilled);
                    //console.log(requiredUnfilled);
                    if (requiredUnfilled.length > 0) {
                        return true;
                    }
                    else {
                        return false;
                    }
                };
                PacketList.prototype.arrayLength = function (requiredField) {
                    if (!this.amrInfoFields)
                        return undefined;
                    var ident = requiredField.replace('info.', '');
                    var value = this.amrInfoFields[ident];
                    return (value != undefined && value.length > 0) ? value : undefined;
                };
                PacketList.prototype.lookupValue = function (requiredField) {
                    if (!this.amrInfoFields)
                        return undefined;
                    var ident = requiredField.replace('info.', '');
                    var value = this.amrInfoFields[ident];
                    return (value || value == 0) ? value : undefined;
                };
                PacketList.prototype.lookupTextValue = function (identVal) {
                    var ident = identVal.replace('info.', '');
                    var ret = this.lookupValue(ident);
                    if (!ret)
                        ret = "";
                    return ret;
                };
                PacketList.prototype.valueIsNullUndefinedOrEmpty = function (identVal) {
                    var ident = identVal.replace('info.', '');
                    var val = this.lookupValue(ident);
                    if (val && val.trim)
                        val = val.trim();
                    return !val && (val !== false);
                };
                PacketList = __decorate([
                    core_1.Component({
                        selector: 'max-forms-packet-list',
                        templateUrl: '/maxweb/app/app/packetList.component.html',
                    }), 
                    __metadata('design:paramtypes', [maxAppContext_service_1.MaxAppContext, user_profiles_service_1.UserProfiles, activities_service_1.Activities, assignments_service_1.Assignments, document_factory_service_1.Documents, router_1.ActivatedRoute, router_1.Router, angular2_modal_1.Modal, helper_service_1.Helper])
                ], PacketList);
                return PacketList;
            }());
            exports_1("PacketList", PacketList);
        }
    }
});
//# sourceMappingURL=packetList.component.js.map