import {Component, OnInit} from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';
import { DocumentationActivity } from './documentation_activity';
import {RegistrationContext} from "./registration_context.service";
import {Activities} from "./activities.service";
import {RegistrationHeading} from "./registration_heading.component";
import {Organizations} from "./organizations.service";
import {MaxAppContext} from "./maxAppContext.service";

@Component({
    selector: 'app-landing',
    template: `
    <div id="landing-title">
            <div [hidden]="!errorMessage" class="alert alert-danger">{{errorMessage}}</div>
            <div style="margin:auto">
                <div style="margin-bottom:27px;">
                    <org-heading></org-heading>
                </div>
                <p class="lead">
                    <a class="btn btn-lg btn-default" [routerLink]="['/max-forms/packetList']" [queryParams]="{orgId:orgId}">Get Started</a>
                </p>
                
            </div>
            <!--<div *ngIf="!coordinatorName && !docAct" style="max-width:300px; margin:auto;">-->
                <!--<div class="list-group">-->
                    <!--<a href="javascript:void(0)" (click)="onClickDocAct(act)" class="list-group-item" *ngFor="let act of allDocActs">-->
                        <!--<strong>{{act.documentationEventDescription.coordinatorName}}</strong><br/>-->
                        <!--{{act.documentationEventDescription.eventName}}-->
                    <!--</a>-->
                <!--</div>-->
            <!--</div>-->
            
            <a [routerLink]="['/max-cover/choose-org']">&lt;&lt; Choose a different team</a>
    </div>
        `,
    providers: [
        RegistrationContext, Activities, RegistrationHeading
    ]
})

export class LandingComponent implements OnInit {
    docAct: DocumentationActivity;
    errorMessage:string;
    allDocActs: DocumentationActivity[];
    coordinatorName:string;
    logo:string;
    orgId:string;

    constructor(
        private _route:ActivatedRoute,
        private _activities: Activities,
        private _orgs:Organizations,
        private _ctx:MaxAppContext
        )  {
    }

    ngOnInit()
    {
        let orgId = this._route.snapshot.queryParams['orgId'] || this._route.snapshot.params['orgId'];
        console.log(orgId);
        if (orgId)
            this._ctx.orgId = orgId;
        else
            orgId = this._ctx.orgId;

        let id = this._route.snapshot.queryParams['id']  || this._route.snapshot.params['id'];
        console.log(id);

        this.init(orgId, id);
    }

    onClickDocAct(act:DocumentationActivity)
    {
        this.init(act.orgId);
    }

    private init(orgId=null, id=null)
    {
        this.orgId = orgId;

        this._orgs.getOrgFromDirectory(orgId).single().toPromise()
            .then(org =>
            {
                this._ctx.currentOrg = org;
                console.log(org);
                if (org)
                    this.logo = org['logoUrl'];
            })
            .catch(e =>
            {
                console.log(e, 'Error loading org from directory.');
            });

        this._activities.getDocumentationActivities(orgId, id).single().toPromise()
            .then(activitiesResults =>
            {
                this.allDocActs = activitiesResults;

                if (!id && !orgId)
                    return;

                if (orgId && this.allDocActs[0])
                {
                    this.coordinatorName = this.allDocActs[0].documentationEventDescription.coordinatorName;
                }
            })
            .catch(e =>
            {
                console.error(e);
                this.errorMessage = 'We hit an error.  Please refresh to try again.';
            });
    }
}
