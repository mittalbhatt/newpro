System.register(["@angular/core", "angular2-modal", "./assignments.service", 'angular2-modal/plugins/bootstrap', "underscore"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __extends = (this && this.__extends) || function (d, b) {
        for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, angular2_modal_1, assignments_service_1, bootstrap_1, underscore_1;
    var Form, SelectedFormWithSport, SelectedFormWithoutSport, AssignFormModalContext, AssignFormModal;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (angular2_modal_1_1) {
                angular2_modal_1 = angular2_modal_1_1;
            },
            function (assignments_service_1_1) {
                assignments_service_1 = assignments_service_1_1;
            },
            function (bootstrap_1_1) {
                bootstrap_1 = bootstrap_1_1;
            },
            function (underscore_1_1) {
                underscore_1 = underscore_1_1;
            }],
        execute: function() {
            Form = (function () {
                function Form(data) {
                    this.name = data.name;
                    this.level = data.level;
                    this.tag = data.code;
                    this.isSelected = false;
                }
                return Form;
            }());
            exports_1("Form", Form);
            SelectedFormWithSport = (function () {
                function SelectedFormWithSport(data) {
                    this.orgId = data.orgId;
                    this.role = data.role;
                    this.tag = data.tag;
                }
                return SelectedFormWithSport;
            }());
            exports_1("SelectedFormWithSport", SelectedFormWithSport);
            SelectedFormWithoutSport = (function () {
                function SelectedFormWithoutSport(data) {
                    this.orgId = data.orgId;
                    this.role = data.role;
                }
                return SelectedFormWithoutSport;
            }());
            exports_1("SelectedFormWithoutSport", SelectedFormWithoutSport);
            AssignFormModalContext = (function (_super) {
                __extends(AssignFormModalContext, _super);
                function AssignFormModalContext(d) {
                    _super.call(this);
                    this.d = d;
                    this.data = d;
                    //this.size = "lg";
                }
                return AssignFormModalContext;
            }(bootstrap_1.BSModalContext));
            exports_1("AssignFormModalContext", AssignFormModalContext);
            AssignFormModal = (function () {
                function AssignFormModal(dialog, _assignment, _modal) {
                    var _this = this;
                    this.dialog = dialog;
                    this._assignment = _assignment;
                    this._modal = _modal;
                    this.selectedSport = [];
                    this.isProcessGetForm = false;
                    this.sportList = [];
                    this.howManySelectForm = 0;
                    this.selectAllSport = false;
                    this.sportRole = [{ role: "ATH", title: "Athletes", isSelected: false }, { role: "CCH", title: "Coaches", isSelected: false }];
                    if (this.dialog.context.data.currentOrgData.data) {
                        // For getting sport list
                        var sportList = this.dialog.context.data.currentOrgData.data.teams;
                        underscore_1.default.each(sportList, function (o) {
                            _this.sportList.push(new Form(o.team));
                        });
                        this.orgId = this.dialog.context.data.currentOrgData.org;
                        // For getting current selected Sports
                        var selectedSportList = this.dialog.context.data.selectedPacket;
                        if (selectedSportList) {
                            underscore_1.default.each(selectedSportList, function (sp) {
                                // For selected current role
                                if (sp.role) {
                                    underscore_1.default.each(_this.sportRole, function (o) {
                                        if (o.role == sp.role) {
                                            o.isSelected = true;
                                        }
                                    });
                                }
                                // For selected current sport
                                if (sp.tag !== undefined) {
                                    underscore_1.default.each(_this.sportList, function (sl) {
                                        if (sl.tag == sp.tag) {
                                            sl.isSelected = true;
                                        }
                                    });
                                }
                                else {
                                    _this.selectAllSport = true;
                                }
                            });
                        }
                    }
                }
                AssignFormModal.prototype.onCancel = function () {
                    this.dialog.close(false);
                };
                AssignFormModal.prototype.saveSportRole = function () {
                    var _this = this;
                    this.checkSportValidation().then(function (res) {
                        if (res == true) {
                            _this.selectedSport = [];
                            // replace sportList with sportRole for issue when no teams in currentOrgData
                            if (_this.sportRole.length > 0) {
                                underscore_1.default.each(_this.sportRole, function (r) {
                                    if (r.isSelected == true) {
                                        if (_this.selectAllSport) {
                                            var selectedSport = { orgId: _this.orgId, role: r.role };
                                            _this.selectedSport.push(new SelectedFormWithoutSport(selectedSport));
                                        }
                                        else {
                                            underscore_1.default.each(_this.sportList, function (o) {
                                                if (o.isSelected == true) {
                                                    var selectedSport = { orgId: _this.orgId, role: r.role, tag: o.tag };
                                                    _this.selectedSport.push(new SelectedFormWithSport(selectedSport));
                                                }
                                            });
                                        }
                                    }
                                });
                            }
                            _this._assignment.getPopupData.emit({ data: _this.selectedSport, type: "assignees" });
                            _this.dialog.close(false);
                        }
                        else {
                            _this._modal.alert()
                                .size('lg').isBlocking(true).showClose(false)
                                .headerClass("hide").keyboard(27)
                                .body("To assign forms, you must to select both what people and what sports to assign to.  If you don't want to assign to anyone right now, just clear all the boxes.")
                                .bodyClass('modal-body text-left')
                                .okBtn('OK').open().then(function (res) {
                                // this.dialog.close(false);
                            });
                        }
                    });
                };
                AssignFormModal.prototype.checkSportValidation = function () {
                    var _this = this;
                    return new Promise(function (resolve, reject) {
                        var isRoleTrue = underscore_1.default.where(_this.sportRole, { isSelected: true });
                        if (isRoleTrue !== undefined && isRoleTrue.length > 0) {
                            var isSportTrue = underscore_1.default.where(_this.sportList, { isSelected: true });
                            if ((isSportTrue !== undefined && isSportTrue.length > 0) || (_this.selectAllSport == true)) {
                                resolve(true);
                            }
                            else {
                                resolve(false);
                            }
                        }
                        else {
                            resolve(true);
                        }
                    });
                };
                AssignFormModal = __decorate([
                    core_1.Component({
                        selector: 'packet-form-modal-prompt',
                        template: "\n    <div class=\"modal-content\" style=\"text-align:left;\">\n        <div class=\"modal-header\">\n            <h4> Assign Forms </h4>\n        </div>\n        <div class=\"modal-body usa-map center-border\" >\n            <div class=\"row \" *ngIf=\"!isProcessGetForm\">\n                <div class=\"col-xs-12 col-sm-6\">\n                <ul class=\"forms-category mob-border\">\n                    <li class=\"sport-list-title\"> Assign To People </li>\n                    <li *ngFor=\"let srole of sportRole\" id=\"ck-button\"> \n                        <label>\n                            <input type=\"checkbox\" [(ngModel)]=\"srole.isSelected\" value=\"srole.isSelected\"/> \n                            <span [class]=\"'btn-'+srole.title\"> {{srole.title}} </span>\n                        </label>\n                    </li>\n                </ul>\n                </div>\n                <div class=\"col-xs-12 col-sm-6\">\n                <ul class=\"forms-category\" *ngIf=\"sportRole[0].isSelected == true || sportRole[1].isSelected == true \">\n                    <li class=\"sport-list-title\"> Assign To Sports </li>\n                    <li class=\"all-sport\"> \n                        <input type=\"checkbox\" id=\"all_sport_chk\" [(ngModel)]=\"selectAllSport\" />\n                        <label for=\"all_sport_chk\">All Sports</label>\n                    </li>\n                    <li  [hidden]=\"selectAllSport\" *ngFor=\"let sport of sportList\"> \n                    <input type=\"checkbox\" [(ngModel)]=\"sport.isSelected\" value=\"sport.isSelected\" [id]=\"'sport_'+sport.tag\" /> \n                    <label [attr.for]=\"'sport_'+sport.tag\">{{ sport.name }} <span class=\"assign-sport-level\" *ngIf=\"sport.level\">{{ sport.level }}</span></label>\n                    </li>\n                </ul>\n                <ul *ngIf=\"sportRole[0].isSelected ==false && sportRole[1].isSelected == false\" class=\"forms-category\">\n                    <li class=\"sport-list-title\">No People Selected</li>\n                </ul>\n                </div>\n            </div>\n            <div *ngIf=\"isProcessGetForm\" style=\"text-align: center; padding-top: 150px;\">\n                <img src=\"/maxweb/app/media/ajax-loader.gif\" />\n            </div>\n        </div>\n        <div class=\"modal-footer\">\n            <button (click)=\"saveSportRole()\" type=\"button\" class=\"btn btn-primary\" style=\"float:right; margin-right:10px;\">Assign</button>\n            <button (click)=\"onCancel()\" type=\"button\" class=\"btn btn-danger\" style=\"float:right; margin-right:10px;\">Cancel</button>\n        </div>\n    </div>\n    ",
                        styles: ["\n    .usa-map{\n        min-height:400px;\n    }\n    "]
                    }), 
                    __metadata('design:paramtypes', [angular2_modal_1.DialogRef, assignments_service_1.Assignments, bootstrap_1.Modal])
                ], AssignFormModal);
                return AssignFormModal;
            }());
            exports_1("AssignFormModal", AssignFormModal);
        }
    }
});
//# sourceMappingURL=assign-form-model.component.js.map