import * as _ from "underscore";
import {DocumentationDocument} from "./documentation_document";
import {IDocumentExpressionContext} from "./document_expression_context.interface";

export class DocumentDocContext implements IDocumentExpressionContext {
    constructor(private _doc:DocumentationDocument)
    {}

    evaluateDefaultValue(expression:string, fallbackValue:string = '', htmlWrapper:string = null):any
    {
        let val = ident => {
            var d = _.find(this._doc.data, function (d) { return d.ident == ident });
            return (d === undefined) ? fallbackValue : (d.value || fallbackValue);
        };

        let isSet = (arr, val) => {
            return _.any(arr, function(item) { return item == val });
        };

        var htmlOpen = '', htmlClose = '';
        if (htmlWrapper)
        {
            htmlOpen = '<' + htmlWrapper + '>';
            htmlClose = '</' + htmlWrapper + '>';
        }

        var parts = expression.split('.');
        if (parts[0] == 'data')
        {
            if (parts.length > 2)
                return isSet(val(parts[1]), parts[2]);
            else
                return htmlOpen + val(parts[1]) + htmlClose;
        }

        return null;
    }
}