// Works around issue where Chrome on iOS (and reportedly Safari in some cases)
// does not raise the input event after an auto-complete option has been selected.
// Watch this issue: https://github.com/angular/angular/issues/12395
// I believe if that is resolved we may be able to remove this.

import {Injectable, ElementRef} from "@angular/core";
import {Router, NavigationEnd, NavigationStart} from "@angular/router";
import * as _ from "underscore";

@Injectable()
export class AutoCompleteWorkaround
{
    constructor(private _router:Router)
    {

    }

    install(rootElement:ElementRef)
    {
        var inputElements = [];

        this._router.events.subscribe(e =>
        {
            if (e instanceof NavigationStart)
            {
                inputElements.forEach(el => el.removeEventListener('blur', this.blurListener));
                inputElements.splice(0, inputElements.length);
            }
            else if (e instanceof NavigationEnd)
            {
                this.findByLocalName(rootElement.nativeElement, 'input', inputElements);
                inputElements.forEach(el => el.addEventListener('blur', this.blurListener));
            }
        });
    }

    private blurListener(fe:FocusEvent)
    {
        var doc = window.document;
        var event = doc.createEvent("HTMLEvents");
        event.initEvent("input", true, true);
        fe.target.dispatchEvent(event);
    }

    private findByLocalName(element:any, localName:string, seed:any[])
    {
        _.forEach(element.childNodes, (child:any) =>
        {
            if (child.localName == localName)
                seed.push(child);

            this.findByLocalName(child, localName, seed);
        });
    }
}