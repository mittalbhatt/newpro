System.register(["@angular/http", "@angular/core"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var http_1, core_1;
    var SiteSearch, SiteSearchService;
    return {
        setters:[
            function (http_1_1) {
                http_1 = http_1_1;
            },
            function (core_1_1) {
                core_1 = core_1_1;
            }],
        execute: function() {
            SiteSearch = (function () {
                function SiteSearch() {
                }
                return SiteSearch;
            }());
            exports_1("SiteSearch", SiteSearch);
            SiteSearchService = (function () {
                function SiteSearchService(_http) {
                    this._http = _http;
                }
                SiteSearchService.prototype.siteSearch = function (search_text, skip, limit) {
                    if (skip === void 0) { skip = 0; }
                    if (limit === void 0) { limit = 10; }
                    var args = new http_1.RequestOptions();
                    args.search = new http_1.URLSearchParams();
                    args.search.append('skip', skip.toString());
                    args.search.append('limit', limit.toString());
                    args.search.append('query', search_text.toString());
                    return this._http.get("/training/api/search", args)
                        .map(function (res) { return res.json(); });
                    //.catch((error:any) =>   throw error);
                };
                SiteSearchService = __decorate([
                    core_1.Injectable(), 
                    __metadata('design:paramtypes', [http_1.Http])
                ], SiteSearchService);
                return SiteSearchService;
            }());
            exports_1("SiteSearchService", SiteSearchService);
        }
    }
});
//# sourceMappingURL=site-search.service.js.map