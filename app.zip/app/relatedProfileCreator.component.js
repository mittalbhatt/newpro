System.register(["@angular/core", "@angular/router", "./user_profiles.service", "./DfObjectId"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, router_1, user_profiles_service_1, DfObjectId_1;
    var RelatedProfileCreator;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (user_profiles_service_1_1) {
                user_profiles_service_1 = user_profiles_service_1_1;
            },
            function (DfObjectId_1_1) {
                DfObjectId_1 = DfObjectId_1_1;
            }],
        execute: function() {
            RelatedProfileCreator = (function () {
                function RelatedProfileCreator(route, _userProfiles) {
                    this._userProfiles = _userProfiles;
                    this.relationProfileId = route.snapshot.params['profileId'];
                }
                RelatedProfileCreator.prototype.onSelectedSportsChange = function (value) {
                    this.selectedSports = value;
                };
                RelatedProfileCreator.prototype.onSave = function () {
                    var _this = this;
                    if (!this.firstName || !this.lastName) {
                        this.errorMessage = 'All fields are required.';
                        window.scrollTo(0, 0);
                        return;
                    }
                    this.saving = true;
                    this._userProfiles.getProfile(this.relationProfileId).single().toPromise()
                        .then(function (ctxProfile) {
                        var amrId = (new DfObjectId_1.DfObjectId()).toString();
                        var profile = {
                            _id: undefined,
                            amrId: amrId,
                            tags: undefined,
                            email: undefined,
                            createdDate: (new Date()).toISOString(),
                            tel: undefined,
                            org: ctxProfile.org,
                            firstName: _this.firstName,
                            lastName: _this.lastName,
                            sortFirstName: (_this.firstName || '').toLowerCase(),
                            sortLastName: (_this.lastName || '').toLowerCase(),
                            state: { pendingApproval: true },
                            pendingSports: _this.selectedSports ? _this.selectedSports.map(function (s) { return s.code; }) : undefined,
                            orgRoles: ['MGA', 'SUB', 'ATH'],
                            relations: [
                                {
                                    firstName: ctxProfile.firstName,
                                    lastName: ctxProfile.lastName,
                                    userProfileId: ctxProfile._id,
                                    roles: ['PRN']
                                }
                            ],
                            $amr: {
                                _id: amrId,
                                info: {
                                    firstName: _this.firstName,
                                    lastName: _this.lastName
                                }
                            },
                            createdByRelatedProfileCreator: true
                        };
                        return _this._userProfiles.createProfile(profile).single().toPromise();
                    })
                        .then(function () {
                        _this.saving = false;
                        window.history.back();
                    })
                        .catch(function (e) {
                        _this.saving = false;
                        _this.errorMessage = 'An unexpected error has occurred.';
                        throw e;
                    });
                };
                RelatedProfileCreator.prototype.onCancel = function () {
                    window.history.back();
                };
                RelatedProfileCreator = __decorate([
                    core_1.Component({
                        selector: 'related-profile-creator',
                        template: "\n<div *ngIf=\"errorMessage\" style=\"max-width:400px; margin:auto;\" class=\"alert alert-danger\">{{errorMessage}}</div>\n<h3>Create a new athlete:</h3>\n<div style=\"max-width:500px; margin:auto;\">\n    <form>\n        <div class=\"form-group\">\n            <label for=\"username\">First Name</label>\n            <input [(ngModel)]=\"firstName\" type=\"text\" class=\"form-control\" id=\"firstName\" name=\"firstName\" placeholder=\"First Name\" required>\n          </div>\n          \n          <div class=\"form-group\">\n            <label for=\"username\">Last Name</label>\n            <input [(ngModel)]=\"lastName\" type=\"text\" class=\"form-control\" id=\"lastName\" name=\"lastName\" placeholder=\"Last Name\" required>\n          </div>\n    </form>\n    <label>Sports</label>\n    <default-sport-chooser (sportsSelected)=\"onSelectedSportsChange($event)\"></default-sport-chooser>\n    <div style=\"height:100px;\">\n        <button style=\"float:right;\" class=\"btn btn-default\" [disabled]=\"saving\" (click)=\"onSave()\">Save</button>\n        <button style=\"float:right; margin-right:10px;\" class=\"btn btn-danger\" [disabled]=\"saving\" (click)=\"onCancel()\">Cancel</button>\n    </div>\n</div>\n"
                    }), 
                    __metadata('design:paramtypes', [router_1.ActivatedRoute, user_profiles_service_1.UserProfiles])
                ], RelatedProfileCreator);
                return RelatedProfileCreator;
            }());
            exports_1("RelatedProfileCreator", RelatedProfileCreator);
        }
    }
});
//# sourceMappingURL=relatedProfileCreator.component.js.map