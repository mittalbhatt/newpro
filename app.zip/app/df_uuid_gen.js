System.register([], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var DfUuidGen;
    return {
        setters:[],
        execute: function() {
            DfUuidGen = (function () {
                function DfUuidGen() {
                }
                DfUuidGen.newUuid = function () {
                    var d = new Date().getTime();
                    var uuid = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
                        var r = (d + Math.random() * 16) % 16 | 0;
                        d = Math.floor(d / 16);
                        return (c == 'x' ? r : (r & 0x7 | 0x8)).toString(16);
                    });
                    return uuid;
                };
                return DfUuidGen;
            }());
            exports_1("DfUuidGen", DfUuidGen);
        }
    }
});
//# sourceMappingURL=df_uuid_gen.js.map