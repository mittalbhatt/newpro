import {Component, OnInit, ViewChild} from "@angular/core";
import {ProfileType, ProfileTypeChooser} from "./profileTypeChooser.component";
import {Router, ActivatedRoute} from "@angular/router";
import {UserProfiles} from "./user_profiles.service";
import {SportCode} from "./sportCodes";
import {MaxAppContext} from "./maxAppContext.service";
import {Organization, Organizations} from "./organizations.service";
import {DfObjectId} from "./DfObjectId";
import {LinkedOrgRoleRequests, LinkedOrgRoleRequest} from "./linkedOrgRoleRequests.service";
import * as momentTz from 'moment-timezone';
import {Observable} from "rxjs/Rx";
import {Http, Response} from "@angular/http";

@Component({
    selector:'own-profile-creator',
    template:
`
<div style="padding-top:10px; padding-bottom:50px; min-height:500px;">
    <div *ngIf="error" class="alert alert-danger">{{error}}</div>
    <h2>{{_ctx.currentAccount?.firstName}} {{_ctx.currentAccount?.lastName}}</h2>
    <h4 *ngIf="targetOrg">Joining <em>{{targetOrg?.name}}</em></h4>
    <div [style.display]="saving ? 'none' : 'block'">
        <h4>To continue with MAX, tell us which best describes you:</h4>
        <div>
            <profile-type-chooser #typeChooser (typeSelected)="onSelected($event)"></profile-type-chooser>
        </div>
    </div>
    <div *ngIf="selectedType && !saving">
        <div *ngIf="isAdminRole(selectedType.code)">
            <div *ngIf="!adminPath && !targetOrg" class="profile-types-container">
                <div class="profile-type-choice" (click)="selectAdminPath('start')">
                    I want to start using MAX for myself or my school.
                </div>
                <div class="profile-type-choice" (click)="selectAdminPath('using')">
                    My school is already using MAX.
                </div>
                <div class="profile-type-choice" (click)="selectAdminPath('unknown')">
                    I don't know.
                </div>
            </div>
        </div>
        
        <div *ngIf="adminPath == 'unknown'">
            Give us a call and we'll help you out.  256-270-1163 or <a href="mailto:max@dragonflyathletics.com">max@dragonflyathletics.com</a>
        </div>  
        
        <div *ngIf="adminPath == 'start'" style="max-width:300px; margin:auto;">
            <form #newOrgForm="ngForm" (ngSubmit)="onSubmitNewOrg()">
                <div class="form-group">
                    <template #schoolTypeAheadTemplate let-model="item">
                        <h5>{{model.value.formattedName}}</h5>
                        <h6>{{model.value.city}}, {{model.value.state}}</h6>
                        <h6>NCES ID: <em>{{model.value.ncesCode}}</em></h6>
                    </template>
                    <label for="schoolName">What's the name of your team or school?</label>
                    <input [(ngModel)]="newOrgName" 
                        [typeahead]="schoolSearchDataSource" 
                        [typeaheadItemTemplate]="schoolTypeAheadTemplate" 
                        [typeaheadWaitMs]="5"
                        [typeaheadMinLength]="1"
                        (typeaheadOnSelect)="onSelectExistingSchool($event)"
                        id="schoolName"
                        name="schoolName"
                        type="text" 
                        class="form-control"
                        placeholder="School Name" 
                        autofocus required autocomplete="off" />
                </div>
                <div class="form-group">
                    <label for="schoolCity">City</label>
                    <input [(ngModel)]="newOrgCity" id="schoolCity" name="schoolCity" type="text" class="form-control" placeholder="City" required />
                </div>
                <div class="form-group">
                    <label for="schoolState">State</label>
                    <select [(ngModel)]="newOrgState" name="schoolState" id="schoolState" required>
                        <option value="AL">Alabama</option>
                        <option value="AK">Alaska</option>
                        <option value="AZ">Arizona</option>
                        <option value="AR">Arkansas</option>
                        <option value="CA">California</option>
                        <option value="CO">Colorado</option>
                        <option value="CT">Connecticut</option>
                        <option value="DE">Delaware</option>
                        <option value="DC">District Of Columbia</option>
                        <option value="FL">Florida</option>
                        <option value="GA">Georgia</option>
                        <option value="HI">Hawaii</option>
                        <option value="ID">Idaho</option>
                        <option value="IL">Illinois</option>
                        <option value="IN">Indiana</option>
                        <option value="IA">Iowa</option>
                        <option value="KS">Kansas</option>
                        <option value="KY">Kentucky</option>
                        <option value="LA">Louisiana</option>
                        <option value="ME">Maine</option>
                        <option value="MD">Maryland</option>
                        <option value="MA">Massachusetts</option>
                        <option value="MI">Michigan</option>
                        <option value="MN">Minnesota</option>
                        <option value="MS">Mississippi</option>
                        <option value="MO">Missouri</option>
                        <option value="MT">Montana</option>
                        <option value="NE">Nebraska</option>
                        <option value="NV">Nevada</option>
                        <option value="NH">New Hampshire</option>
                        <option value="NJ">New Jersey</option>
                        <option value="NM">New Mexico</option>
                        <option value="NY">New York</option>
                        <option value="NC">North Carolina</option>
                        <option value="ND">North Dakota</option>
                        <option value="OH">Ohio</option>
                        <option value="OK">Oklahoma</option>
                        <option value="OR">Oregon</option>
                        <option value="PA">Pennsylvania</option>
                        <option value="RI">Rhode Island</option>
                        <option value="SC">South Carolina</option>
                        <option value="SD">South Dakota</option>
                        <option value="TN">Tennessee</option>
                        <option value="TX">Texas</option>
                        <option value="UT">Utah</option>
                        <option value="VT">Vermont</option>
                        <option value="VA">Virginia</option>
                        <option value="WA">Washington</option>
                        <option value="WV">West Virginia</option>
                        <option value="WI">Wisconsin</option>
                        <option value="WY">Wyoming</option>
                    </select>
                </div>
                <button type="submit" class="btn btn-default" [disabled]="!newOrgForm.form.valid">Continue</button>
            </form>
        </div>
        
        <div *ngIf="selectedType.code == 'ATH'">
            <h4>Choose your sports to continue as an <em>{{selectedType.name}}</em>:</h4>
            <div style="margin-bottom:25px;">
                <default-sport-chooser (sportsSelected)="onSelectedSportsChange($event)"></default-sport-chooser>
            </div>
        </div>
        
        <div style="max-width:500px; margin:auto; margin-top:10px;" *ngIf="(!targetOrg || !_ctx.currentOrg) && (!isAdminRole(selectedType.code) || adminPath == 'using')">
            <org-context-chooser (orgChosen)="onOrgChosen($event)"></org-context-chooser>
        </div>
        
         <div *ngIf="targetOrg" style="margin-top:20px;">
         <h4>Continue as {{selectedType.sentenceSubject}} in {{targetOrg.name}}</h4>
            <button class="btn btn-primary" (click)="confirmSelection()" style="margin-right:20px;">{{_userProfiles.createProfileRedirectUrl && _userProfiles.createProfileRedirectUrl.indexOf('packetList') > -1 ? 'Do Forms &gt;&gt;' : 'Next'}}</button>
            <button class="btn btn-danger" (click)="reset()">Reset</button>
        </div>
    </div>
    <div *ngIf="saving">
        <img src="/maxweb/app/media/ajax-loader.gif" />
        Saving...
    </div>
</div>
`
})
export class OwnProfileCreator implements OnInit
{
    selectedType:ProfileType;
    selectedSports:SportCode[];
    adminPath:string;
    saving:boolean;
    error:string;

    targetOrg:Organization;

    newOrgName:string;
    newOrgCity:string;
    newOrgState:string;
    newOrgKnownSchoolId:string;
    newOrgNCES:string;

    schoolSearchDataSource:Observable<any>;

    @ViewChild('typeChooser') profileTypeChooser:ProfileTypeChooser;

    constructor(
        private _userProfiles:UserProfiles,
        private _ctx:MaxAppContext,
        private _router:Router,
        private _route:ActivatedRoute,
        private _orgsSvc:Organizations,
        private _linkedOrgRoleReqs:LinkedOrgRoleRequests,
        private _http:Http)
    {
        console.log('OwnProfileCreator');

        this.schoolSearchDataSource = Observable.create((observer:any) =>
        {
            observer.next(this.newOrgName);
        }).mergeMap((token:string) =>
        {
            return this._http.get(`/training/api/lists/schoolNames/search?limit=5&skip=0&$search=${token}`).map((res: Response) => res.json())
        });
    }

    ngOnInit()
    {
        if (!this._ctx.currentAccount)
        {
            console.log('No account, redirecting to landing.');
            this._router.navigateByUrl('/max-cover/landing');
            return;
        }

        if (this._ctx.currentProfile)
        {
            if (this._userProfiles.createProfileRedirectUrl)
                this._router.navigateByUrl(this._userProfiles.createProfileRedirectUrl);
            else
                this._router.navigate(['packetList'], {relativeTo:this._route.parent});
        }

        this.targetOrg = this._ctx.currentOrg;

        this._route.params.subscribe(params =>
        {
            this.selectedType = this.profileTypeChooser.selectByCode(params['selectedType']);
            this.adminPath = params['adminPath'];
        });
    }

    private selectAdminPath(path:string)
    {
        this._router.navigate([{selectedType:this.selectedType.code, adminPath:path}], {relativeTo:this._route});
    }

    private onSelected(type:ProfileType)
    {
        this._router.navigate([{selectedType:type.code}], {relativeTo:this._route});
    }

    private onSubmitNewOrg()
    {
        let orgResolve:Promise<Organization>;
        let trainingOrgId:string;
        if (this.selectedType.code == 'TRN')
        {
            let trnResult = this.resolveOrCreateTrainerOrg();
            trainingOrgId = trnResult.trainingOrgId;
            orgResolve = trnResult.resolveOrg;
        }

        var newOrg = new Organization();
        newOrg._id = (new DfObjectId()).toString();
        newOrg.name = this.newOrgName;
        newOrg.timezone = momentTz.tz.guess();
        newOrg.roles = ['School'];
        newOrg.city = this.newOrgCity;
        newOrg.stateCode = this.newOrgState;
        newOrg.ncesCode = this.newOrgNCES;
        newOrg.formsSeedListName = this.newOrgState;
        if (this.newOrgKnownSchoolId)
            newOrg.knownSchoolId = this.newOrgKnownSchoolId;

        let linkedOrgRole;
        if (trainingOrgId)
        {
            var linkId = (new DfObjectId()).toString();
            newOrg.linkedOrgs = [{
                linkId: linkId,
                linkTypes:['Training', 'OrgAdmin'],
                granteeOrgId:trainingOrgId
            }];

            linkedOrgRole = {tags:[], roles:['OADM', 'UADM', 'SUB', 'MGA', 'TRN', 'OTRN'], linkId:linkId, orgId:newOrg._id};
        }

        let createSchoolOrg = () => this._orgsSvc.createOrg(newOrg).single().toPromise().then(() => newOrg);
        if (!orgResolve)
        {
            orgResolve = createSchoolOrg();
            createSchoolOrg = null;
        }

        this.confirmSelection(orgResolve, true, linkedOrgRole, createSchoolOrg);
    }

    private resolveOrCreateTrainerOrg()
    {
        let trnOrg = this._ctx.myOrganizations.find(o => o.roles && o.roles.indexOf('Training') > -1);
        if (!trnOrg)
        {
            // Brand new trainer, need to create the AT org
            let account = this._ctx.currentAccount;
            trnOrg = new Organization();
            trnOrg._id = (new DfObjectId()).toString();
            let trainingOrgId = trnOrg._id;
            trnOrg.name = `${account.firstName} ${account.lastName} AT`;
            trnOrg.timezone = momentTz.tz.guess();
            trnOrg.roles = ['Training'];
            return {trainingOrgId:trainingOrgId, resolveOrg:this._orgsSvc.createOrg(trnOrg).single().toPromise().then(() => trnOrg)};
        }
        else
        {
            return {trainingOrgId:trnOrg._id, resolveOrg:Promise.resolve(trnOrg)};
        }
    }

    private reset()
    {
        if (!this._ctx.currentOrg)
           delete this.targetOrg;

        this._router.navigate([{}], {relativeTo:this._route});
    }

    private confirmSelection(resolveTargetOrg?:Promise<Organization>, emptyOrg:boolean=false, linkedOrgRole?, createSchoolOrg?:() => Promise<Organization>)
    {
        if (this.saving)
            return;

        this.saving = true;
        delete this.error;

        let account = this._ctx.currentAccount;

        if (this.selectedType.code == 'TRN' && !resolveTargetOrg)
        {
            var resolveOrCreateTrainerOrg = this.resolveOrCreateTrainerOrg();
            resolveTargetOrg = resolveOrCreateTrainerOrg.resolveOrg;
            if (this._ctx.myProfiles.find(p => p.org == resolveOrCreateTrainerOrg.trainingOrgId))
            {
                resolveTargetOrg = resolveTargetOrg.then(() => null);
            }
            else
            {
                emptyOrg = true;
            }
        }

        resolveTargetOrg = resolveTargetOrg || Promise.resolve(this.targetOrg);

        resolveTargetOrg.then(profileTargetOrg =>
            {
                if (profileTargetOrg)
                {
                    var profile = {
                        _id: (new DfObjectId()).toString(),
                        tags: undefined,
                        email: undefined,
                        createdDate: (new Date()).toISOString(),
                        tel: undefined,
                        org: profileTargetOrg._id,
                        userAccountId: account._id,
                        firstName: account.firstName,
                        lastName: account.lastName,
                        sortFirstName:(account.firstName || '').toLowerCase(),
                        sortLastName:(account.lastName || '').toLowerCase(),
                        state: {pendingApproval: true},
                        pendingSports: this.selectedSports ? this.selectedSports.map(s => s.code) : undefined,
                        orgRoles: ['MGA', 'SUB', this.selectedType.code],
                        linkedOrgRoles:undefined
                    };

                    if (linkedOrgRole)
                        profile.linkedOrgRoles = [linkedOrgRole];

                    if (this.selectedType.code == 'TRN')
                        profile.orgRoles.push('OTRN');

                    if (emptyOrg)
                    {
                        profile.orgRoles.push('OADM');
                        profile.orgRoles.push('UADM');
                        delete profile.state.pendingApproval;
                    }

                    var email = account.usernames.find(un => un.type == 'email');
                    if (email)
                        profile.email = email.username;

                    var phone = account.usernames.find(un => un.type == 'mobile');
                    if (phone)
                        profile.tel = [phone.username];

                    return this._userProfiles.createProfile(profile).single().toPromise().then(() => profile._id);
                }
                else
                {
                    return Promise.resolve(this._ctx.myProfiles[0]._id);
                }
            })
            .then(profileId =>
            {
                if (createSchoolOrg)
                {
                    return createSchoolOrg();
                }
                else if (this.selectedType.code == 'TRN' && this.targetOrg)
                {
                    var req = new LinkedOrgRoleRequest();
                    req.profileId = profileId;
                    req.requestedOrgId = this.targetOrg._id;
                    req.requestedRoles = ['OTRN'];
                    return this._linkedOrgRoleReqs.createRequest(req).single().toPromise();
                }
                else
                {
                    return Promise.resolve(null);
                }
            })
            .then(() =>
            {
                let target = this._userProfiles.createProfileRedirectUrl || '/';
                if (target && target.indexOf('create-own-profile') > -1)
                    target = '/';
                return this._ctx.initialize(null, true).then(() => target);
            })
            .then(target =>
            {
                console.log('Profile created, navigating to ' + target);
                this._router.navigateByUrl(target);
            })
            .catch(err =>
            {
                console.log(err);
                this.saving = false;
                this.error = 'An unexpected failure has occurred.';
            });
    }

    private onSelectedSportsChange(value)
    {
        this.selectedSports = value;
    }

    private onOrgChosen(value)
    {
        this.targetOrg = value;
    }

    private isAdminRole(value)
    {
        return ['CCH', 'TRN', 'ADM'].indexOf(value) >  -1;
    }

    private onSelectExistingSchool(e:{item:any})
    {
        this.newOrgName = e.item.value.formattedName;
        this.newOrgCity = e.item.value.city;
        this.newOrgState = e.item.value.state;
        this.newOrgKnownSchoolId = e.item.value.schoolId;
        this.newOrgNCES = e.item.value.ncesCode;
    }
}