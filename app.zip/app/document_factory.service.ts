import {Injectable} from "@angular/core";
import {Http, RequestOptions, URLSearchParams, Response} from "@angular/http";
import {DocumentationDocument} from "./documentation_document";

@Injectable()
export class Documents {
    constructor(private _http:Http){
        
    }

    findOrCreateDocument(
        docDescriptionActivityId:string,
        assignmentId:string,
        userProfileId:string
    ) {

        var opts = new RequestOptions();
        var search = new URLSearchParams();
        opts.search = search;
        search.append('docDescriptionActivityId', docDescriptionActivityId);
        if (assignmentId)
            search.append('assignmentId', assignmentId);
        search.append('userProfileId', userProfileId);

        return this._http.get('/training/api/documents/factory', opts)
            .map((res:Response) => <DocumentationDocument[]>res.json());
    }

    findOrCreateAmrDocument(
        amrId:string        
    ) {
        return this._http.get('/training/api/amrs/'+amrId)
            .map((res:Response) => <DocumentationDocument[]>res.json());
    }

    completeDocument(
        documentId:string
    ) {
        return this._http.put('/training/api/documents/'+documentId+'/complete', '');
    }

    getDocumentationDocuments(assignmentStableId:string=null, profileId:string=null) {
        var opts = new RequestOptions();
        var search = new URLSearchParams();
        opts.search = search;
        search.append('$filter.0.originalDescription.documentType', 'Documentation');
        if (assignmentStableId)
            search.append('$filter.1.subjects.assignmentStableId', `ObjectId(${assignmentStableId})`);
        if (profileId)
            search.append('$filter.2.subjects.userProfileId', `ObjectId(${profileId})`);
        search.append('take', '1000');
        return this._http.get('/training/api/documents', opts)
            .map((res:Response) => <DocumentationDocument[]>res.json());
    }

    getDocumentWithStableId(documentStableId:string)
    {
        var opts = new RequestOptions();
        var search = new URLSearchParams();
        opts.search = search;
        search.append('$filter.0.documentStableId', `ObjectId(${documentStableId})`);
        search.append('take', '1');
        return this._http.get('/training/api/documents', opts)
            .map((res:Response) => (<DocumentationDocument[]>res.json())[0]);
    }
}