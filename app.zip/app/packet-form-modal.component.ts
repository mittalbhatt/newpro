import {Component, Output, EventEmitter, ElementRef, ViewChild} from "@angular/core";
import {ModalComponent, DialogRef} from "angular2-modal";
import {BSModalContext} from "angular2-modal/plugins/bootstrap";
import {DfObjectId} from "./DfObjectId";
import {MaxAppContext} from "./maxAppContext.service";
import { Assignments, Assignment } from "./assignments.service";
import { Observable } from 'rxjs';
import {Router} from '@angular/router';

import _ from "underscore";

export class Form{
    name:string;
    activityId:any;
    required:boolean;
    selected:boolean;
    category:string;
    constructor(data:any){
        this.name = data.name;
        this.activityId = data._id;
        this.required = true;
        this.category = data.documentLibraryCategory;
        this.selected = false;
        
    }
}

export class SelectedForm{
    name:string;
    activityId:any;
    required:boolean;
    constructor(data:Form){
        this.name = data.name;
        this.activityId = `${data.activityId}`;
        this.required = data.required;
    }
}
export class CustomModalContext extends BSModalContext {
    public data: any;

    constructor(private d:any){
        super();
        this.data = d;
        this.size = "lg";
    }
}

@Component({
    selector:'packet-form-modal-prompt',
    template:`
    <div class="modal-content" style="text-align:left;">
        <div class="modal-header">
            <h4> Select Forms </h4>
        </div>
    <div class="modal-body usa-map" >
    <div *ngIf="!isProcessGetForm">
        <div class="col-xs-12 col-sm-12 col-md-5 usa-map">
            <usa-map (selectedState)="onSelectState($event)"></usa-map>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-7 form-div" id="form-div">
            <ul class="forms-category">
                <div  *ngIf="dragonStandardForm.length" [id]="toLowerStr('DragonFly Standard')"> 
                    <li> <strong> 
                        <input type='checkbox' name="forms[]" value="DragonFly Standard" [id]="'dragon_standard'" (change)="checkUncheckAll('DragonFly Standard', $event)">
                        <label [attr.for]="'dragon_standard'"> DragonFly Standard </label>
                    </strong> 
                    </li>
                    <li *ngFor="let dragonStandard of dragonStandardForm; let i=index"> 
                        <input type='checkbox' name="forms[]" [id]="'dragonStandard_'+i" [(ngModel)]="dragonStandard.selected" value="dragonStandard" /> 
                        <label [attr.for]="'dragonStandard_'+i"> {{ dragonStandard?.name }} </label>
                        <a href="javascript:void(0)" (click)="onPrint(dragonStandard.activityId)" style="color:#000;">
                            <i class="glyphicon glyphicon-print" aria-hidden="true"></i>
                        </a>
                         <a href="javascript:void(0)" (click)="editForm(dragonStandard.activityId)" style="color:#000;">
                            <i class="glyphicon glyphicon-edit" aria-hidden="true"></i>
                        </a> 
                    </li>
                </div>
            
                <div *ngFor="let formCat of sortedForms | keys" [id]="toLowerStr(formCat.key)" > 
                    <li> 
                        <strong> 
                            <input type='checkbox' name="forms[]" [value]="formCat.key" (change)="checkUncheckAll(formCat.key, $event)" [id]="form?.name+i"> 
                            <label [attr.for]="form?.name+i"> {{ formCat?.key }} </label>
                        </strong> 
                    </li>
                    <li *ngFor="let form of formCat.value"> 
                        <input type='checkbox' name="forms[]" [(ngModel)]="form.selected" [id]="form?.name+i" /> 
                        <label [attr.for]="form?.name+i"> {{ form?.name }}  </label>
                        <a href="javascript:void(0)" (click)="onPrint(form.activityId)" style="color:#000;">
                            <i class="glyphicon glyphicon-print" aria-hidden="true"></i>
                        </a>
                        <!-- <a href="javascript:void(0)" (click)="editForm(form.activityId)" style="color:#000;">
                            <i class="glyphicon glyphicon-edit" aria-hidden="true"></i>
                        </a> -->

                        
                    </li>
                </div>
            </ul>
        </div>
    </div>
    
    <div *ngIf="isProcessGetForm" style="text-align: center; padding-top: 150px;">
        <img src="/maxweb/app/media/ajax-loader.gif" />
    </div>
    </div>
        <div class="modal-footer">
             <button (click)="createform(currentorgId)"  type="button" class="btn btn-primary" style="float:left; margin-right:10px;">Create Forms</button> 
            <button (click)="saveCategory()" type="button" class="btn btn-primary" [disabled]="!howManySelectForm" style="float:right; margin-right:10px;">Select These Forms</button>
            <button (click)="onCancel()" type="button" class="btn btn-danger" style="float:right; margin-right:10px;">Cancel</button>
        </div>
    </div>

    `,
    styles:[`
    .usa-map{
        min-height:400px;
        top: 0px;
    }
    .form-div{
        height: 400px;
        overflow: auto;
        top: 0px;
    }
    .modal-body{
        padding: 0px !important
    }
    `]
})
export class PacketFormModal implements ModalComponent<CustomModalContext>
{
    private allForms:any;
    private sortedForms:any=[];
    private isProcessGetForm:boolean=false;
    private dragonStandardForm:any;
    private howManySelectForm:number=0;
    context: CustomModalContext;
    SelectedDocumentList:any;
    currentDivPosition:number;
    currentorgId:string;

    constructor(public dialog:DialogRef<CustomModalContext>, private _assignment: Assignments, private _ctx:MaxAppContext,private router: Router)
    {
        console.log(this.dialog.context.data.org.org);
        this.currentorgId=this.dialog.context.data.org.org;
        
        this.isProcessGetForm = true;
        this._assignment.getActivities("Document").subscribe((data:any)=>{
            if(data){
                
                let allData = _.filter(data, (res:any) =>{
                    if(res.documentLibraryCategory !== undefined){
                        return res;
                    }
                });

                let chk = [];
                _.each(allData, (o:any)=>{
                    chk.push(new Form(o));
                });
                let groupCategory = _.groupBy(chk, (res:any) =>{
                    return res.category;
                });
                
                this.allForms = _.each(groupCategory, (val:any, key:string)=>{
                    if(key !== "DragonFly Standard"){
                        this.sortedForms[key] = _.sortBy(val, 'name');

                        if(this.dialog.context.data.data){
                            this.SelectedDocumentList = _.each(this.sortedForms[key], (d:any) =>{
                                var groupeotherdDocs = _.each(this.dialog.context.data.data, (t:any) =>{
                                    if(t.activityId == d.activityId ){
                                        d['selected']=true;
                                    }
                                })
                            });
                        }
                    }else{
                        this.dragonStandardForm =  _.sortBy(val, 'name');
                    }
                });

                if(this.dialog.context.data.data){
                    this.SelectedDocumentList = _.each(this.dragonStandardForm, (d:any) =>{
                        var groupeotherdDocs = _.each(this.dialog.context.data.data, (t:any) =>{
                            if(t.activityId == d.activityId ){
                                d['selected']=true;
                            }
                        })
                    });
                }
            }
            this.isProcessGetForm = false;
        },
        e=>{
            throw e;
        }
        );
    }
    createform(currentorgId)
    {
        
        this.router.navigate(['/max-forms/create-form/' + this.currentorgId]);
        this.dialog.close(false);
    }

    editForm(formId:String=null)
    {
        this.router.navigate([`/max-forms/edit-form/${this.currentorgId}/${formId}`]);
        this.dialog.close(false);
    }
    private onCancel()
    {
        this.dialog.close(false);
    }

    onPrint(id){
        this._assignment.getPopupData.emit({data:id,type:"print"});
    }

    onSelectState(event){
        event = this.toLowerStr(event);
        if(document.getElementById(event)){
            document.getElementById(event).scrollIntoView({behavior: "smooth"});
        }
    }

    toLowerStr(str: String=null){
        return str.toLowerCase();
    }

    checkUncheckAll(category, event){
        if(category == "DragonFly Standard"){
            _.map(this.dragonStandardForm, (obj:Form)=>{
                obj.selected = event.target.checked;
            });
        }else{
            _.map(this.allForms[category], (obj:Form)=>{
                obj.selected = event.target.checked;
            });
        }
    }

    ngDoCheck() {
        this.howManySelectForm=0;
        let a = _.where(this.dragonStandardForm, {selected: true});
        this.howManySelectForm = this.howManySelectForm + (a.length);
        for (var key in this.sortedForms)
        {
            var value = this.sortedForms[key];
            if(value.length){
                let b = _.where(value, {selected: true});
                this.howManySelectForm = this.howManySelectForm + (b.length);
            }
        }
    }

    saveCategory(){
        let selectForm =[];
        _.each(this.dragonStandardForm, (o:Form)=>{
            if(o.selected == true){
                selectForm.push(new SelectedForm(o));
            }
        });

        for (var key in this.sortedForms)
        {
            var value = this.sortedForms[key];
            if(value.length){
                _.each(value, (o:any)=>{
                    if(o.selected == true){
                        selectForm.push(new SelectedForm(o));
                    }
                });
            }
        }
        this._assignment.getPopupData.emit({data:selectForm,type:"form"});
        this.dialog.close(false);
    }
}
/*    <usa-map (selectedState)="onSelectState($event)"></usa-map>    */