import {DocumentationDocumentData} from "./documentation_document";
import {Http, Response} from "@angular/http";
import {Injectable, EventEmitter} from "@angular/core";
import {Observable} from "rxjs/Observable";

export class DocumentChangeSaverStatus {
    constructor(public saved:boolean, public response:Response=null){}
}

@Injectable()
export class DocumentChangeSaver {
    private _documentId:string;
    private _stopped:boolean;
    private _started:boolean;
    private _timeoutHandle:any;
    private _pendingChanges:DocumentationDocumentData[];
    private _currentSavingChanges:DocumentationDocumentData[];

    private _http:Http;

    status:EventEmitter<DocumentChangeSaverStatus>;

    constructor(http:Http){
        this._pendingChanges = [];
        this._http = http;
        this.status = new EventEmitter<DocumentChangeSaverStatus>();
    }

    addChange(data:DocumentationDocumentData)
    {
        var match = this._pendingChanges.filter(d => d.ident == data.ident)[0];
        if (match)
            match.value = data.value;
        else
            this._pendingChanges.push(data);
    }

    start(documentId)
    {
        if (!documentId)
            throw new Error('documentId is required');

        if (this._started)
            return;

        this._documentId = documentId;
        this._stopped = false;
        this._started = true;
        this.schedule();
    }

    stop()
    {
        if (this._timeoutHandle)
            clearTimeout(this._timeoutHandle);

        this._timeoutHandle = null;
        this._stopped = true;
        this._started = false;
        console.log('Change saver stopped.');
    }

    saveNow()
    {
        if (!this._stopped)
            throw new Error('Saver must be stopped before calling saveNow()');

        return this.savePending();
    }

    private schedule()
    {
        if (!this._stopped)
            this._timeoutHandle = setTimeout(() => this.savePending(), 2000);
    }

    private savePending() : Observable<any>
    {
        this._timeoutHandle = null;

        if (!this._currentSavingChanges)
        {
            this._currentSavingChanges = this._pendingChanges;
            this._pendingChanges = [];
        }

        if (!this._currentSavingChanges.length)
        {
            this._currentSavingChanges = null;
            this.schedule();
            return Observable.from([0], null);
        }

        var observable = this._http.put('/training/api/documents/' + this._documentId + '/data', this._currentSavingChanges);
        observable.single().subscribe(response =>
            {
                this._currentSavingChanges = null;
                this.schedule();
                this.status.emit(new DocumentChangeSaverStatus(true, response));
            },errorResponse =>
            {
                console.log(errorResponse);
                this.schedule();
                this.status.emit(new DocumentChangeSaverStatus(false, errorResponse));
            });

        return observable;
    }
}