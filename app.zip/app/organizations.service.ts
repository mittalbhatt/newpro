import {Http, RequestOptions, URLSearchParams, Response} from "@angular/http";
import {Injectable, Inject, EventEmitter} from "@angular/core";
import {Observable} from "rxjs/Rx";


export class OrgMedia {
    createdDate:Date;
    contentType:string;
    mediaId:string;
    purpose:string;
}

export class Organization {
    _id:string;
    name:string;
    shortCode:string;
    formsShortcut:string;
    media:OrgMedia[];
    defaultDocuments:{context:string, form:string, activityId:string}[];
    timezone:string;
    roles:string[];
    formsSeedListName:string;
    city:string;
    stateCode:string;
    ncesCode:string;
    userTagFormat=',Sport,Position,';
    knownSchoolId:string;
    linkedOrgs:{linkId:string, linkTypes:string[], granteeOrgId:string}[];
    primaryDocumentationActivityId:string;
}

export class Org { 
    name:string; 
    orgId:string; 
    verificationStatus:string; 
} 
export class Teams { 
    team:{
        code:string, 
        teamId:string, 
        level: string, 
        name: string
    }[]; 
    selected:boolean; 
    initiallyVisible:boolean; 
    positions:string[]; 
}
// export class Entries { 
//     org:Org[]; 
//     selected:boolean; 
//     initiallyVisible:boolean; 
//     teams:Teams[]
// }
export class OrgStructure { 
    entries:{
        org:Org[], 
        selected:boolean, 
        initiallyVisible:boolean, 
        teams:Teams[]
    }[]; 
}

@Injectable()
export class Organizations {

    public orgStructureData = new EventEmitter();
    constructor(private _http:Http, @Inject(RequestOptions) private _requestOps:RequestOptions) {

    }

    createOrg(org:Organization)
    {
        return this._http.put('/training/api/organizations', org);
    }

    getOrganizations(){
        return this._http.get('/training/api/organizations?limit=1000')
            .map(response => (<Organization[]>response.json()));
    }

    update(id:string, update:any) {
        return this._http.put(`/training/api/organizations/${id}/update`, update);
    }

    getLogoMedia(org:Organization, create:boolean=false):OrgMedia
    {
        var purpose = 'logo600';
        var logoMedia = (org.media || []).find(m => m.purpose == purpose);
        if (!logoMedia && create)
        {
            logoMedia = new OrgMedia();
            logoMedia.purpose = purpose;
            org.media = org.media || [];
            org.media.push(logoMedia);
        }
        return logoMedia;
    }
 

    getLogo(organization:Organization){
        return Observable.create(observer=>{
            var logoMedia = this.getLogoMedia(organization);
            if (!logoMedia)
            {
                observer.next(null);
                observer.complete();
                return;
            }

            let req = new XMLHttpRequest();
            var url = `/training/api/organizations/${organization._id}/media/${encodeURIComponent(logoMedia.mediaId)}`;
            req.open('get',url);
            req.onreadystatechange = () => {
                if (req.readyState == 4 && req.status == 200) {
                    var loc = req.getResponseHeader('location');
                    //console.log('Getting logo - ' + loc);
                    let req2 = new XMLHttpRequest();
                    req2.open('get', loc);
                    req2.responseType = 'blob';
                    req2.onreadystatechange = () =>
                    {
                        if (req2.readyState == 4 && req2.status == 200)
                        {
                            var win:any = <any>window;
                            var urlCreator = (win.URL || win.webkitURL);
                            var blobUrl = urlCreator.createObjectURL(req2.response);
                            observer.next(blobUrl);
                            observer.complete();
                        }
                        else if (req2.readyState == 4)
                        {
                            observer.error(new Error(req.responseText));
                        }
                    };

                    req2.send();
                }
                else if (req.readyState == 4)
                {
                    observer.error(new Error(req.responseText));
                }
            };

            req.setRequestHeader('Authorization', this._requestOps.headers.get('Authorization'));
            req.send();
        });
    }
    getLogoUrldocumentmedia(value:any){

        return Observable.create(observer=>{

        if(value.media[0].thumbnailId){
         var logoMedia = value.media[0].thumbnailId;
        }else{
        var logoMedia = value.media[0].mediaId;
        }
             
          
           if (!logoMedia)
            {
                observer.next(null);
                observer.complete();
                return;
            }
             let req = new XMLHttpRequest();

            var url = `/training/api/documents/${value._id}/media/${encodeURIComponent(logoMedia)}`;
            req.open('get',url);
            req.onreadystatechange = () => {
                if (req.readyState == 4 && req.status == 200)
                {
                    var loc = req.getResponseHeader('location');
                    observer.next(loc);
                    observer.complete();
                }
                else if (req.readyState == 4)
                {
                    observer.error(new Error(req.responseText));
                }
            };

            req.setRequestHeader('Authorization', this._requestOps.headers.get('Authorization'));
            req.send();
        });
    }
    getLogoUrldocumentmediapopup(currmediaid:any,id:any){

        return Observable.create(observer=>{

       
         var logoMedia = currmediaid;
        
             
          
           if (!logoMedia)
            {
                observer.next(null);
                observer.complete();
                return;
            }
             let req = new XMLHttpRequest();

            var url = `/training/api/documents/${id}/media/${encodeURIComponent(logoMedia)}`;
            req.open('get',url);
            req.onreadystatechange = () => {
                if (req.readyState == 4 && req.status == 200)
                {
                    var loc = req.getResponseHeader('location');
                    observer.next(loc);
                    observer.complete();
                }
                else if (req.readyState == 4)
                {
                    observer.error(new Error(req.responseText));
                }
            };

            req.setRequestHeader('Authorization', this._requestOps.headers.get('Authorization'));
            req.send();
        });
    }
    getLogoUrl(organization:Organization){

        return Observable.create(observer=>{
            var logoMedia = this.getLogoMedia(organization);
            if (!logoMedia)
            {
                observer.next(null);
                observer.complete();
                return;
            }

            let req = new XMLHttpRequest();
            var url = `/training/api/organizations/${organization._id}/media/${encodeURIComponent(logoMedia.mediaId)}`;
            req.open('get',url);
            req.onreadystatechange = () => {
                if (req.readyState == 4 && req.status == 200)
                {
                    var loc = req.getResponseHeader('location');
                    observer.next(loc);
                    observer.complete();
                }
                else if (req.readyState == 4)
                {
                    observer.error(new Error(req.responseText));
                }
            };

            req.setRequestHeader('Authorization', this._requestOps.headers.get('Authorization'));
            req.send();
        });
    }

    getOrgFromDirectory(orgId:string)
    {
        var args = new RequestOptions();
        args.search = new URLSearchParams();
        args.search.append('$filter.0._id', `ObjectId(${orgId})`);
        args.search.append('limit', '1');
        return this._http.get('/training/api/organizations/directory', args)
            .map((res:Response) => (<Organization[]>res.json())[0]);
    }

    getOrgByCodeFromDirectory(code:string)
    {
        var args = new RequestOptions();
        args.search = new URLSearchParams();
        args.search.append('$filter.0.shortCode', code.toUpperCase());
        args.search.append('limit', '1');
        return this._http.get('/training/api/organizations/directory', args)
            .map((res:Response) => (<Organization[]>res.json())[0]);
    }

    getOrgsBySearchFromDirectory(search:string, limit=25)
    {
        var args = new RequestOptions();
        args.search = new URLSearchParams();
        args.search.append('$search', search);
        args.search.append('limit', limit.toString());
        return this._http.get('/training/api/organizations/directory', args)
            .map((res:Response) => (<Organization[]>res.json()));
    }

    getOrgStructureConfig(profileId:string){
        return this._http.get(`/training/api/orgStructureConfig/byUser/${profileId}`).map((res:Response) => (<OrgStructure[]>res.json()));
    }
}