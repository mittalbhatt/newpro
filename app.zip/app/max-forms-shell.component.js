System.register(["@angular/core", "./maxAppContext.service", "@angular/router", "./user_profiles.service", 'angular2-modal/plugins/bootstrap', 'angular2-modal', "./change-password.component", "./assignments.service"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, maxAppContext_service_1, router_1, user_profiles_service_1, bootstrap_1, angular2_modal_1, change_password_component_1, assignments_service_1;
    var MaxFormsShell;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (maxAppContext_service_1_1) {
                maxAppContext_service_1 = maxAppContext_service_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (user_profiles_service_1_1) {
                user_profiles_service_1 = user_profiles_service_1_1;
            },
            function (bootstrap_1_1) {
                bootstrap_1 = bootstrap_1_1;
            },
            function (angular2_modal_1_1) {
                angular2_modal_1 = angular2_modal_1_1;
            },
            function (change_password_component_1_1) {
                change_password_component_1 = change_password_component_1_1;
            },
            function (assignments_service_1_1) {
                assignments_service_1 = assignments_service_1_1;
            }],
        execute: function() {
            MaxFormsShell = (function () {
                function MaxFormsShell(ctx, _router, _userProfilesSvc, _modal, _assignments) {
                    this.ctx = ctx;
                    this._router = _router;
                    this._userProfilesSvc = _userProfilesSvc;
                    this._modal = _modal;
                    this._assignments = _assignments;
                    this.isShowAeccessRequestMenu = false;
                    this.isShowTeamMenu = false;
                    var d = new Date();
                    this.currentDate = d.getFullYear();
                }
                MaxFormsShell.prototype.ngOnInit = function () {
                    //let profilePromise = this._userProfilesSvc.getProfile(userProfileId).single().toPromise();
                    var _this = this;
                    if (this.ctx.myProfiles && this.ctx.myProfiles !== null) {
                        // this.isShowAeccessRequestMenu = true;
                        // console.log(this.ctx.myProfiles);
                        this.ctx.myProfiles.forEach(function (profile) {
                            if (profile.orgRoles.indexOf("OADM") > -1 || profile.orgRoles.indexOf("UADM") > -1) {
                                _this.isShowAeccessRequestMenu = true;
                            }
                            if (_this.isShowAeccessRequestMenu === false) {
                                if (profile.linkedOrgRoles && profile.linkedOrgRoles !== undefined && profile.linkedOrgRoles.length > 0) {
                                    profile.linkedOrgRoles.forEach(function (orgRole) {
                                        if (orgRole.roles.indexOf("OADM") > -1 || orgRole.roles.indexOf("UADM") > -1) {
                                            _this.isShowAeccessRequestMenu = true;
                                        }
                                    });
                                }
                            }
                            if (profile.orgRoles.indexOf("TRN") > -1 || profile.orgRoles.indexOf("OTRN") > -1 || profile.orgRoles.indexOf("ADM") > -1 || profile.orgRoles.indexOf("CCH") > -1) {
                                _this.isShowTeamMenu = true;
                            }
                            if (_this.isShowTeamMenu === false) {
                                if (profile.linkedOrgRoles && profile.linkedOrgRoles !== undefined && profile.linkedOrgRoles.length > 0) {
                                    profile.linkedOrgRoles.forEach(function (orgRole) {
                                        if (profile.orgRoles.indexOf("TRN") > -1 || profile.orgRoles.indexOf("OTRN") > -1 || profile.orgRoles.indexOf("ADM") > -1 || profile.orgRoles.indexOf("CCH") > -1) {
                                            _this.isShowTeamMenu = true;
                                        }
                                    });
                                }
                            }
                        });
                    }
                    if (this.isShowTeamMenu) {
                        this._assignments.getMine(true).then(function (res) {
                            var packets = res;
                            var sideMenuPackets = packets.filter(function (p) {
                                return p.activities[0]
                                    && p.activities[0].documentationEventDescription
                                    && p.activities[0].documentationEventDescription.menuTitle;
                            });
                            _this.sideMenuPackets = sideMenuPackets;
                        });
                    }
                    this._userProfilesSvc.getPendingUserCount().single().toPromise().then(function (count) {
                        _this.pendingUserCount = count;
                    });
                    this.currentAccount = this.ctx.currentAccount;
                    var profile = this.ctx.currentProfile;
                    if (profile && profile !== undefined) {
                        this._userProfilesSvc.getProfile(profile._id).single().toPromise().then(function (data) {
                            _this.profile = data;
                            _this.loadImage();
                        });
                    }
                };
                MaxFormsShell.prototype.onDropdownToggleClick = function ($event) {
                    $event.stopPropagation();
                    this.orgSelectorOpen = !this.orgSelectorOpen;
                    this.profileSelectorOpen = false;
                };
                MaxFormsShell.prototype.onDropdownProfileMenu = function ($event) {
                    $event.stopPropagation();
                    this.profileSelectorOpen = !this.profileSelectorOpen;
                    this.orgSelectorOpen = false;
                };
                Object.defineProperty(MaxFormsShell.prototype, "orgChoices", {
                    // @HostListener('document:click', ['$event'])
                    // onOutsideClick($event)
                    // {
                    //     if (!this.orgSelectorDropdown.nativeElement.contains($event.target))
                    //         this.orgSelectorOpen = false;
                    //     if (!this.profileSelectorDropdown.nativeElement.contains($event.target))
                    //         this.profileSelectorOpen = false;
                    // }
                    get: function () {
                        var _this = this;
                        if (this.ctx.myOrganizations && this.ctx.currentOrg)
                            return this.ctx.myOrganizations.filter(function (o) { return o._id != _this.ctx.currentOrg._id; });
                        else
                            return [];
                    },
                    enumerable: true,
                    configurable: true
                });
                MaxFormsShell.prototype.loadImage = function () {
                    var _this = this;
                    return this._userProfilesSvc.getProfileImageUrl(this.profile).single().toPromise()
                        .then(function (url) {
                        _this.profileImageUrl = url;
                    })
                        .catch(function (e) {
                        console.log('Logo error', e);
                        throw e;
                    });
                };
                MaxFormsShell.prototype.onChooseOrg = function (org) {
                    this.orgSelectorOpen = false;
                    this.ctx.orgId = org._id;
                    this._router.navigate(['main']);
                };
                MaxFormsShell.prototype.changePassword = function () {
                    var profile = this.ctx.currentProfile;
                    var config = angular2_modal_1.overlayConfigFactory(new bootstrap_1.BSModalContext(), bootstrap_1.BSModalContext);
                    //let save = () => this._userProfiles.createProfile(profile).single().toPromise();
                    config = angular2_modal_1.overlayConfigFactory({ pendingProfile: profile }, change_password_component_1.ChangePasswordData);
                    return this._modal.open(change_password_component_1.ChangePasswordModal, config);
                };
                MaxFormsShell = __decorate([
                    core_1.Component({
                        selector: 'max-forms-shell',
                        templateUrl: '/maxweb/app/app/max-forms-shell.component.html'
                    }), 
                    __metadata('design:paramtypes', [maxAppContext_service_1.MaxAppContext, router_1.Router, user_profiles_service_1.UserProfiles, bootstrap_1.Modal, assignments_service_1.Assignments])
                ], MaxFormsShell);
                return MaxFormsShell;
            }());
            exports_1("MaxFormsShell", MaxFormsShell);
        }
    }
});
//# sourceMappingURL=max-forms-shell.component.js.map