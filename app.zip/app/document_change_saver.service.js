System.register(["@angular/http", "@angular/core", "rxjs/Observable"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var http_1, core_1, Observable_1;
    var DocumentChangeSaverStatus, DocumentChangeSaver;
    return {
        setters:[
            function (http_1_1) {
                http_1 = http_1_1;
            },
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (Observable_1_1) {
                Observable_1 = Observable_1_1;
            }],
        execute: function() {
            DocumentChangeSaverStatus = (function () {
                function DocumentChangeSaverStatus(saved, response) {
                    if (response === void 0) { response = null; }
                    this.saved = saved;
                    this.response = response;
                }
                return DocumentChangeSaverStatus;
            }());
            exports_1("DocumentChangeSaverStatus", DocumentChangeSaverStatus);
            DocumentChangeSaver = (function () {
                function DocumentChangeSaver(http) {
                    this._pendingChanges = [];
                    this._http = http;
                    this.status = new core_1.EventEmitter();
                }
                DocumentChangeSaver.prototype.addChange = function (data) {
                    var match = this._pendingChanges.filter(function (d) { return d.ident == data.ident; })[0];
                    if (match)
                        match.value = data.value;
                    else
                        this._pendingChanges.push(data);
                };
                DocumentChangeSaver.prototype.start = function (documentId) {
                    if (!documentId)
                        throw new Error('documentId is required');
                    if (this._started)
                        return;
                    this._documentId = documentId;
                    this._stopped = false;
                    this._started = true;
                    this.schedule();
                };
                DocumentChangeSaver.prototype.stop = function () {
                    if (this._timeoutHandle)
                        clearTimeout(this._timeoutHandle);
                    this._timeoutHandle = null;
                    this._stopped = true;
                    this._started = false;
                    console.log('Change saver stopped.');
                };
                DocumentChangeSaver.prototype.saveNow = function () {
                    if (!this._stopped)
                        throw new Error('Saver must be stopped before calling saveNow()');
                    return this.savePending();
                };
                DocumentChangeSaver.prototype.schedule = function () {
                    var _this = this;
                    if (!this._stopped)
                        this._timeoutHandle = setTimeout(function () { return _this.savePending(); }, 2000);
                };
                DocumentChangeSaver.prototype.savePending = function () {
                    var _this = this;
                    this._timeoutHandle = null;
                    if (!this._currentSavingChanges) {
                        this._currentSavingChanges = this._pendingChanges;
                        this._pendingChanges = [];
                    }
                    if (!this._currentSavingChanges.length) {
                        this._currentSavingChanges = null;
                        this.schedule();
                        return Observable_1.Observable.from([0], null);
                    }
                    var observable = this._http.put('/training/api/documents/' + this._documentId + '/data', this._currentSavingChanges);
                    observable.single().subscribe(function (response) {
                        _this._currentSavingChanges = null;
                        _this.schedule();
                        _this.status.emit(new DocumentChangeSaverStatus(true, response));
                    }, function (errorResponse) {
                        console.log(errorResponse);
                        _this.schedule();
                        _this.status.emit(new DocumentChangeSaverStatus(false, errorResponse));
                    });
                    return observable;
                };
                DocumentChangeSaver = __decorate([
                    core_1.Injectable(), 
                    __metadata('design:paramtypes', [http_1.Http])
                ], DocumentChangeSaver);
                return DocumentChangeSaver;
            }());
            exports_1("DocumentChangeSaver", DocumentChangeSaver);
        }
    }
});
//# sourceMappingURL=document_change_saver.service.js.map