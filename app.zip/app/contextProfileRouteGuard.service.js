System.register(["@angular/core", "./maxAppContext.service", "@angular/router"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, maxAppContext_service_1, router_1;
    var ContextProfileRouteGuard;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (maxAppContext_service_1_1) {
                maxAppContext_service_1 = maxAppContext_service_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            }],
        execute: function() {
            ContextProfileRouteGuard = (function () {
                function ContextProfileRouteGuard(_ctx, _router) {
                    this._ctx = _ctx;
                    this._router = _router;
                }
                ContextProfileRouteGuard.prototype.canActivate = function (route, state) {
                    var _this = this;
                    return this._ctx.initialize().then(function (res) {
                        if (res) {
                            _this._router.navigate(['/main/profile', _this._ctx.currentProfile._id]);
                            return false;
                        }
                    });
                };
                ContextProfileRouteGuard = __decorate([
                    core_1.Injectable(), 
                    __metadata('design:paramtypes', [maxAppContext_service_1.MaxAppContext, router_1.Router])
                ], ContextProfileRouteGuard);
                return ContextProfileRouteGuard;
            }());
            exports_1("ContextProfileRouteGuard", ContextProfileRouteGuard);
        }
    }
});
//# sourceMappingURL=contextProfileRouteGuard.service.js.map