import {Directive, ElementRef, HostListener, Input, OnDestroy, OnInit, Inject} from "@angular/core";
import {DfPlUploads2} from "./df_pl_uploads_ng2";

@Directive({
    selector:'[df-pl-upload-host]'
})
export class DfPlUploadHost implements OnDestroy, OnInit {
    private _uploader:any;

    private _uploadSettings:any;

    private _fileStatusHandler:(file:any, fromUploaderEvent:boolean) => void;

    constructor(
        private _el:ElementRef,
        @Inject(DfPlUploads2) private _uploads:DfPlUploads2)
    {
        this._fileStatusHandler = (f, fue) => this.fileStatusHandler(f, fue);
    }

    @Input('uploadSettings') set uploadSettings(value)
    {
        this._uploadSettings = value;
        this.initUploader();
    }

    get uploadSettings()
    {
        return this._uploadSettings;
    }

    /// @param fromUploaderEvent
    /// true if the entry point is not from the angular stack, as
    /// in the case of events from plupload, etc.
    @Input('uploadStateChanged') onUploadStateChanged:(state:any, fromUploaderEvent:boolean, resultUrl:string) => void;

    @Input('targetTooltip') targetTooltip:string;

    @HostListener('dragenter') onDragEnter() {
        this._el.nativeElement.classList.add('dragover');
    }

    @HostListener('dragleave') onDragLeave() {
        this._el.nativeElement.classList.remove('dragover');
    }

    @HostListener('drop') onDrop() {
        this._el.nativeElement.classList.remove('dragover');
    }

    fileStatusHandler(file, fromUploaderEvent) {
        console.log(file.dfUploadTag, this.uploadSettings.dfUploadTag);
        
        //if (file.dfUploadTag === this.uploadSettings.dfUploadTag) {
            if (this.onUploadStateChanged)
                this.onUploadStateChanged(file.status, fromUploaderEvent, file.dfResultUrl);
        //}
    }

    ngOnDestroy()
    {
        this._uploader = null;
        this._uploads.removeFileStatusHandler(this._fileStatusHandler);
    }

    ngOnInit()
    {
        this.initUploader();
    }

    private initUploader()
    {
        if (!this._uploader && this.uploadSettings)
        {
            this._uploads.addFileStatusHandler(this._fileStatusHandler);

            var uploadSettings = _.extend({}, this.uploadSettings);
            uploadSettings.uploaderSettings = _.extend({}, uploadSettings.uploaderSettings);
            uploadSettings.uploaderSettings.url = 'http://dragonflyathletics.com'; // temporary url.  Plupload requires some url to init.
            uploadSettings.uploaderSettings.drop_element = this._el.nativeElement;//element.context;
            uploadSettings.uploaderSettings.browse_button = this._el.nativeElement;//element.context;

            this._uploader = this._uploads.createUploader(uploadSettings);
            this._uploader.init();
        }
    }
}