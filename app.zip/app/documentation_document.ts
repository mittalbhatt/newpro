export interface HideableDocumentElement {
    showIfAll:DocumentationShowIfAllData[];
}

export class DocumentDescriptionFormatSectionField implements HideableDocumentElement{
    ident:string;
    name:string;
    type:string;
    required:boolean;
    explanationRequired:boolean;
    explanationPrompt:string;
    requirePrompt:string;
    allowUserDefinedResponse: boolean;
    defaultValue:string;
    flagIf:any;
    showIfAll:DocumentationShowIfAllData[];
    requireIfAll:DocumentationDocumentData[];
}

export class DocumentDescriptionFormatSection implements HideableDocumentElement {
    name:string;
    shortcutName:string;
    fields:DocumentDescriptionFormatSectionField[];
    extrafields:DocumentDescriptionFormatSectionField[];
    showIfAll:DocumentationShowIfAllData[];
}

export class DocumentDescriptionFormat {
    sections:DocumentDescriptionFormatSection[];
}

export class DocumentDescription {
    _id:string;
    documentType:string;
    name:string;
    format:DocumentDescriptionFormat;
    staffOnly:boolean;
}

export class DocumentationDocumentData {
    ident:string;
    value:any;
}

export class DocumentationShowIfAllData {
    ident:string;
    value:any;
    fieldsCount:number;
    checkvalue:any;
}

export class DocumentationDocument {
    _id:string;
    type:string;
    documentStableId:string;
    name:string;
    completedDate:Date;
    originalDescription:DocumentDescription;
    data:DocumentationDocumentData[];
    info:any;
}
