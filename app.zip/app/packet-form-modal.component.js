System.register(["@angular/core", "angular2-modal", "angular2-modal/plugins/bootstrap", "./maxAppContext.service", "./assignments.service", '@angular/router', "underscore"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __extends = (this && this.__extends) || function (d, b) {
        for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, angular2_modal_1, bootstrap_1, maxAppContext_service_1, assignments_service_1, router_1, underscore_1;
    var Form, SelectedForm, CustomModalContext, PacketFormModal;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (angular2_modal_1_1) {
                angular2_modal_1 = angular2_modal_1_1;
            },
            function (bootstrap_1_1) {
                bootstrap_1 = bootstrap_1_1;
            },
            function (maxAppContext_service_1_1) {
                maxAppContext_service_1 = maxAppContext_service_1_1;
            },
            function (assignments_service_1_1) {
                assignments_service_1 = assignments_service_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (underscore_1_1) {
                underscore_1 = underscore_1_1;
            }],
        execute: function() {
            Form = (function () {
                function Form(data) {
                    this.name = data.name;
                    this.activityId = data._id;
                    this.required = true;
                    this.category = data.documentLibraryCategory;
                    this.selected = false;
                }
                return Form;
            }());
            exports_1("Form", Form);
            SelectedForm = (function () {
                function SelectedForm(data) {
                    this.name = data.name;
                    this.activityId = "" + data.activityId;
                    this.required = data.required;
                }
                return SelectedForm;
            }());
            exports_1("SelectedForm", SelectedForm);
            CustomModalContext = (function (_super) {
                __extends(CustomModalContext, _super);
                function CustomModalContext(d) {
                    _super.call(this);
                    this.d = d;
                    this.data = d;
                    this.size = "lg";
                }
                return CustomModalContext;
            }(bootstrap_1.BSModalContext));
            exports_1("CustomModalContext", CustomModalContext);
            PacketFormModal = (function () {
                function PacketFormModal(dialog, _assignment, _ctx, router) {
                    var _this = this;
                    this.dialog = dialog;
                    this._assignment = _assignment;
                    this._ctx = _ctx;
                    this.router = router;
                    this.sortedForms = [];
                    this.isProcessGetForm = false;
                    this.howManySelectForm = 0;
                    console.log(this.dialog.context.data.org.org);
                    this.currentorgId = this.dialog.context.data.org.org;
                    this.isProcessGetForm = true;
                    this._assignment.getActivities("Document").subscribe(function (data) {
                        if (data) {
                            var allData = underscore_1.default.filter(data, function (res) {
                                if (res.documentLibraryCategory !== undefined) {
                                    return res;
                                }
                            });
                            var chk_1 = [];
                            underscore_1.default.each(allData, function (o) {
                                chk_1.push(new Form(o));
                            });
                            var groupCategory = underscore_1.default.groupBy(chk_1, function (res) {
                                return res.category;
                            });
                            _this.allForms = underscore_1.default.each(groupCategory, function (val, key) {
                                if (key !== "DragonFly Standard") {
                                    _this.sortedForms[key] = underscore_1.default.sortBy(val, 'name');
                                    if (_this.dialog.context.data.data) {
                                        _this.SelectedDocumentList = underscore_1.default.each(_this.sortedForms[key], function (d) {
                                            var groupeotherdDocs = underscore_1.default.each(_this.dialog.context.data.data, function (t) {
                                                if (t.activityId == d.activityId) {
                                                    d['selected'] = true;
                                                }
                                            });
                                        });
                                    }
                                }
                                else {
                                    _this.dragonStandardForm = underscore_1.default.sortBy(val, 'name');
                                }
                            });
                            if (_this.dialog.context.data.data) {
                                _this.SelectedDocumentList = underscore_1.default.each(_this.dragonStandardForm, function (d) {
                                    var groupeotherdDocs = underscore_1.default.each(_this.dialog.context.data.data, function (t) {
                                        if (t.activityId == d.activityId) {
                                            d['selected'] = true;
                                        }
                                    });
                                });
                            }
                        }
                        _this.isProcessGetForm = false;
                    }, function (e) {
                        throw e;
                    });
                }
                PacketFormModal.prototype.createform = function (currentorgId) {
                    this.router.navigate(['/max-forms/create-form/' + this.currentorgId]);
                    this.dialog.close(false);
                };
                PacketFormModal.prototype.editForm = function (formId) {
                    if (formId === void 0) { formId = null; }
                    this.router.navigate([("/max-forms/edit-form/" + this.currentorgId + "/" + formId)]);
                    this.dialog.close(false);
                };
                PacketFormModal.prototype.onCancel = function () {
                    this.dialog.close(false);
                };
                PacketFormModal.prototype.onPrint = function (id) {
                    this._assignment.getPopupData.emit({ data: id, type: "print" });
                };
                PacketFormModal.prototype.onSelectState = function (event) {
                    event = this.toLowerStr(event);
                    if (document.getElementById(event)) {
                        document.getElementById(event).scrollIntoView({ behavior: "smooth" });
                    }
                };
                PacketFormModal.prototype.toLowerStr = function (str) {
                    if (str === void 0) { str = null; }
                    return str.toLowerCase();
                };
                PacketFormModal.prototype.checkUncheckAll = function (category, event) {
                    if (category == "DragonFly Standard") {
                        underscore_1.default.map(this.dragonStandardForm, function (obj) {
                            obj.selected = event.target.checked;
                        });
                    }
                    else {
                        underscore_1.default.map(this.allForms[category], function (obj) {
                            obj.selected = event.target.checked;
                        });
                    }
                };
                PacketFormModal.prototype.ngDoCheck = function () {
                    this.howManySelectForm = 0;
                    var a = underscore_1.default.where(this.dragonStandardForm, { selected: true });
                    this.howManySelectForm = this.howManySelectForm + (a.length);
                    for (var key in this.sortedForms) {
                        var value = this.sortedForms[key];
                        if (value.length) {
                            var b = underscore_1.default.where(value, { selected: true });
                            this.howManySelectForm = this.howManySelectForm + (b.length);
                        }
                    }
                };
                PacketFormModal.prototype.saveCategory = function () {
                    var selectForm = [];
                    underscore_1.default.each(this.dragonStandardForm, function (o) {
                        if (o.selected == true) {
                            selectForm.push(new SelectedForm(o));
                        }
                    });
                    for (var key in this.sortedForms) {
                        var value = this.sortedForms[key];
                        if (value.length) {
                            underscore_1.default.each(value, function (o) {
                                if (o.selected == true) {
                                    selectForm.push(new SelectedForm(o));
                                }
                            });
                        }
                    }
                    this._assignment.getPopupData.emit({ data: selectForm, type: "form" });
                    this.dialog.close(false);
                };
                PacketFormModal = __decorate([
                    core_1.Component({
                        selector: 'packet-form-modal-prompt',
                        template: "\n    <div class=\"modal-content\" style=\"text-align:left;\">\n        <div class=\"modal-header\">\n            <h4> Select Forms </h4>\n        </div>\n    <div class=\"modal-body usa-map\" >\n    <div *ngIf=\"!isProcessGetForm\">\n        <div class=\"col-xs-12 col-sm-12 col-md-5 usa-map\">\n            <usa-map (selectedState)=\"onSelectState($event)\"></usa-map>\n        </div>\n        <div class=\"col-xs-12 col-sm-12 col-md-7 form-div\" id=\"form-div\">\n            <ul class=\"forms-category\">\n                <div  *ngIf=\"dragonStandardForm.length\" [id]=\"toLowerStr('DragonFly Standard')\"> \n                    <li> <strong> \n                        <input type='checkbox' name=\"forms[]\" value=\"DragonFly Standard\" [id]=\"'dragon_standard'\" (change)=\"checkUncheckAll('DragonFly Standard', $event)\">\n                        <label [attr.for]=\"'dragon_standard'\"> DragonFly Standard </label>\n                    </strong> \n                    </li>\n                    <li *ngFor=\"let dragonStandard of dragonStandardForm; let i=index\"> \n                        <input type='checkbox' name=\"forms[]\" [id]=\"'dragonStandard_'+i\" [(ngModel)]=\"dragonStandard.selected\" value=\"dragonStandard\" /> \n                        <label [attr.for]=\"'dragonStandard_'+i\"> {{ dragonStandard?.name }} </label>\n                        <a href=\"javascript:void(0)\" (click)=\"onPrint(dragonStandard.activityId)\" style=\"color:#000;\">\n                            <i class=\"glyphicon glyphicon-print\" aria-hidden=\"true\"></i>\n                        </a>\n                         <a href=\"javascript:void(0)\" (click)=\"editForm(dragonStandard.activityId)\" style=\"color:#000;\">\n                            <i class=\"glyphicon glyphicon-edit\" aria-hidden=\"true\"></i>\n                        </a> \n                    </li>\n                </div>\n            \n                <div *ngFor=\"let formCat of sortedForms | keys\" [id]=\"toLowerStr(formCat.key)\" > \n                    <li> \n                        <strong> \n                            <input type='checkbox' name=\"forms[]\" [value]=\"formCat.key\" (change)=\"checkUncheckAll(formCat.key, $event)\" [id]=\"form?.name+i\"> \n                            <label [attr.for]=\"form?.name+i\"> {{ formCat?.key }} </label>\n                        </strong> \n                    </li>\n                    <li *ngFor=\"let form of formCat.value\"> \n                        <input type='checkbox' name=\"forms[]\" [(ngModel)]=\"form.selected\" [id]=\"form?.name+i\" /> \n                        <label [attr.for]=\"form?.name+i\"> {{ form?.name }}  </label>\n                        <a href=\"javascript:void(0)\" (click)=\"onPrint(form.activityId)\" style=\"color:#000;\">\n                            <i class=\"glyphicon glyphicon-print\" aria-hidden=\"true\"></i>\n                        </a>\n                        <!-- <a href=\"javascript:void(0)\" (click)=\"editForm(form.activityId)\" style=\"color:#000;\">\n                            <i class=\"glyphicon glyphicon-edit\" aria-hidden=\"true\"></i>\n                        </a> -->\n\n                        \n                    </li>\n                </div>\n            </ul>\n        </div>\n    </div>\n    \n    <div *ngIf=\"isProcessGetForm\" style=\"text-align: center; padding-top: 150px;\">\n        <img src=\"/maxweb/app/media/ajax-loader.gif\" />\n    </div>\n    </div>\n        <div class=\"modal-footer\">\n             <button (click)=\"createform(currentorgId)\"  type=\"button\" class=\"btn btn-primary\" style=\"float:left; margin-right:10px;\">Create Forms</button> \n            <button (click)=\"saveCategory()\" type=\"button\" class=\"btn btn-primary\" [disabled]=\"!howManySelectForm\" style=\"float:right; margin-right:10px;\">Select These Forms</button>\n            <button (click)=\"onCancel()\" type=\"button\" class=\"btn btn-danger\" style=\"float:right; margin-right:10px;\">Cancel</button>\n        </div>\n    </div>\n\n    ",
                        styles: ["\n    .usa-map{\n        min-height:400px;\n        top: 0px;\n    }\n    .form-div{\n        height: 400px;\n        overflow: auto;\n        top: 0px;\n    }\n    .modal-body{\n        padding: 0px !important\n    }\n    "]
                    }), 
                    __metadata('design:paramtypes', [angular2_modal_1.DialogRef, assignments_service_1.Assignments, maxAppContext_service_1.MaxAppContext, router_1.Router])
                ], PacketFormModal);
                return PacketFormModal;
            }());
            exports_1("PacketFormModal", PacketFormModal);
        }
    }
});
/*    <usa-map (selectedState)="onSelectState($event)"></usa-map>    */ 
//# sourceMappingURL=packet-form-modal.component.js.map