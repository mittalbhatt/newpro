import {Component, HostListener, ElementRef, ViewChild, Renderer, Inject, trigger,  state,  style,  animate,  transition} from "@angular/core";
import {Router, ActivatedRoute, Event as RouterEvent, NavigationStart,NavigationEnd, RoutesRecognized } from "@angular/router";
import { Organizations, OrgStructure } from "./organizations.service";
import {MaxAppContext} from "./maxAppContext.service";
import { UserProfiles } from "./user_profiles.service";
import { Observable } from 'rxjs/Observable';
import { SharedService } from "./shared.service";
import { DOCUMENT } from "@angular/platform-browser";
import {DfUuidGen} from "./df_uuid_gen";
import {Subscription} from 'rxjs/Subscription';
import {DocumentLoader} from './document_loader.service';
import {RegistrationContext} from "./registration_context.service";

declare var plupload;

export class Team{
    code:string;
    level:string;
    name:string;
    teamId:string
}
export class Teams{
    initiallyVisible:boolean;
    positions:Array<any>;
    selected: boolean;
    team:Team
}
export class OrgStructureEntry{
    initiallyVisible: boolean;
    org:{
        name:string,
        orgId:string
    };
    selected:boolean;
    teams:Teams[]
}

@Component({
    selector: 'user-teams',
    templateUrl: '/maxweb/app/app/teams.component.html',
    host: {'(window:scroll)': 'scroll($event)'}
})

export class TeamsComponent  {

    private orgStructureData:any;
    private isSelectedOrganization:any=null;
    private isSelectedTeam:any=null;
    private currentRoute:string;
    private currentOrg:string="Everyone";
    private currentOrgTeam:string="";
    private currentRouteDetails: Observable<Object>;
    private sortingParameter:string="sortLastName,sortFirstName";
    private filterParameter:boolean=null;
    private sortingOrderParameter:string="";
    private roleFilterParameter:string="ATH";
    private logoImageUrl:string;
    private currentOrgDetails:any;
    printing:boolean;
    logoUploading:boolean;
    firstorgdata:any;
    firstorgId:any;
    private currentOrgSubscribe: Subscription;

    private _orgLogoUploadStateChange:(state:any, fromUploaderEvent:boolean, resultUrl:string) => void;
    orgdata:any;
    errorMessage:string;
    logoUploadSettings:any;
    public status: {isopen: boolean} = {isopen: true};

    private isScrollDown:boolean=false;
    // @Inject(DOCUMENT) private document: Document;

    constructor(
        public ctx:MaxAppContext,
        private _ctx: RegistrationContext,
        private _organizations: Organizations,
        private _userProfilesSvc: UserProfiles,
        private route: ActivatedRoute,
        private _docLoader:DocumentLoader,
        private router: Router,
        @Inject(Renderer) private renderer: Renderer,
        private _shared: SharedService
        ){
        let orgStructureData = this.route.snapshot.data['_orgStructureData'];

        if(orgStructureData !== null && orgStructureData !== undefined){
            this.orgStructureData = orgStructureData.entries;
            this.orgStructureData = _.where(orgStructureData.entries, { selected: true });
        }

        this.currentOrgSubscribe = this._shared.currentOrgTeamId.subscribe(data=>{
            let org = "Everyone";
            if(data.orgId && data.orgId !== undefined){
                org = data.orgId;
            }

            let team = "";
            if(data.teamId && data.teamId !== undefined){
                team = data.teamId;
            }

            this.selectOrgTeam(org, team);
        });
    }

    ngOnInit() {
        this.currentRoute = this.router.url;
        if (!sessionStorage['urlafterredict']) {
            if (this.currentRoute == '/main/teams') {
                //this.selectOrgTeam("Everyone","");
                this.firstorgdata = _.first(this.orgStructureData);
                if(_.has(this.firstorgdata, "org")){
                      if(_.has(this.firstorgdata.org, "orgId")){
                            this.firstorgId = this.firstorgdata.org.orgId;
                            this.router.navigate(['/main/teams/' + this.firstorgId]);  
                      }
                }
               
            } else {
                this.router.navigate([sessionStorage['urlafterredict']]);
            }
        } else {
            if (sessionStorage['urlafterredict'] == '/main/teams/Everyone/') {
                this.router.navigate(['/main/teams/']);
            } else {
                this.router.navigate([sessionStorage['urlafterredict']]);
            }

        }

        this.router.events.subscribe((event: RouterEvent): void => {
            if(event instanceof NavigationStart) {
                this.sortingParameter="sortLastName,sortFirstName";
                this.filterParameter=null;
                this.roleFilterParameter="ATH";
                this.sortingOrderParameter="";
            }
             if(event instanceof NavigationEnd) {
               
                sessionStorage['routeurl']=event.url;
                this.sortingParameter="sortLastName,sortFirstName";
                this.filterParameter=null;
                this.roleFilterParameter="ATH";
                this.sortingOrderParameter="";
            }
        });
    }

    ngOnDestroy() {
        this.currentOrgSubscribe.unsubscribe();
    }

    selectOrgTeam(org:string=null,team:string=null){
        if(org != "Everyone" && org != null){
            sessionStorage['urlafterredict'] = '/main/teams/'+org;
        }else if(team != null){
            sessionStorage['urlafterredict'] = `/main/teams/${org}/${team}`;
        }else{
            sessionStorage['urlafterredict'] = '/main/teams';
        }

        this.currentRoute = this.router.url;
        this.isSelectedOrganization = org;
        this.isSelectedTeam = team;
        this.currentOrgTeam = "";
        this.logoImageUrl = "";
        this.currentOrgDetails = null;

        // Send current selected organization for assign sport in "add assign" popup
        let currentOrg = _.find(this.orgStructureData, (o:any)=>{
            return o.org.orgId == org;
        });

        if(org !== "Everyone" && currentOrg !== undefined){
            this._organizations.orgStructureData.emit({data: currentOrg, org:org });
        }else{
            this._organizations.orgStructureData.emit({data: null, org:org });
        }

        if(this.isSelectedOrganization === "Everyone"){
            this.currentOrg = "Everyone";
        }else{

            _.each(this.orgStructureData, (o:OrgStructureEntry)=> {
                if(o.org.orgId == this.isSelectedOrganization){
                    this.currentOrg = o.org.name;
                    if(this.isSelectedTeam){
                        _.each(o.teams, (t:Teams)=> {
                            if(t.team.code == this.isSelectedTeam){
                                var level = (t.team.level) ? " ("+t.team.level+")" : "";
                                this.currentOrgTeam = t.team.name + level;
                            }
                        });
                    }
                }
            });

            if (this.ctx.availableOrganizations){
                this.currentOrgDetails = this.ctx.availableOrganizations.find(o => {
                    return o._id === this.isSelectedOrganization;
                });
                
                if(this.currentOrgDetails){
                    this._organizations.getLogoUrl(this.currentOrgDetails).single().toPromise()
                    .then(url =>{
                        this.logoImageUrl = url;
                    })
                    .catch(e => {
                        //console.log(e);
                    });
                    
                    this._orgLogoUploadStateChange = (s,f,r) => {
                        this.orgLogoUploadStateChanged(s,f,r,this.currentOrgDetails);
                    }

                    this.logoUploadSettings = {
                        getFileParams: (file) =>
                        {
                            var fileId = DfUuidGen.newUuid();
                            var logoMedia = this._organizations.getLogoMedia(this.currentOrgDetails, true);
                            logoMedia.createdDate = new Date();
                            logoMedia.contentType = file.type;
                            logoMedia.mediaId = fileId;

                            return this._organizations.update(this.currentOrgDetails._id, {$set:{media:this.currentOrgDetails.media}}).single().toPromise()
                            .then((data) => {
                                return {
                                    fileId: fileId,
                                    orgId: this.currentOrgDetails._id,
                                    paramsUrl: `/training/api/organizations/${this.currentOrgDetails._id}/media/${encodeURIComponent(fileId)}`
                                };
                            });
                        },
                        dfUploadTag: 'org-logo-' + this.currentOrgDetails._id,
                        uploaderSettings: {
                            filters: {
                                max_file_size: '10mb',
                                mime_types: [
                                { title: "Image files", extensions: "jpeg,jpg,gif,png" }
                                ]
                            },
                            resize: {
                                width: 600,
                                height: 600
                            }
                        }
                    };
                }
            }
        }
    }
    getOrgStateCity(org:string){
        
        let stateCityStr="";
        if(org){
            let currentOrgDetails = this.ctx.availableOrganizations.find(o => {
                return o._id === org;
            });

            if(currentOrgDetails !== undefined){
                if(currentOrgDetails.city !== undefined && currentOrgDetails.city != ""  && currentOrgDetails.city != null){
                    stateCityStr = currentOrgDetails.city;
                }

                if(currentOrgDetails.stateCode !== undefined && currentOrgDetails.stateCode != ""  && currentOrgDetails.stateCode != null){
                    if(stateCityStr == ""){
                        stateCityStr = currentOrgDetails.stateCode;
                    }else{
                        stateCityStr += " - " + currentOrgDetails.stateCode;
                    }
                }
            }
        }
        return stateCityStr;
    }
    scroll($event) {
        this.status.isopen=false;
        var bodyScrollTop = document.documentElement.scrollTop || document.body.scrollTop;
    }

    orgLogoUploadStateChanged(state, fromUploaderEvent, resultUrl, value)
    {
        if (state === plupload.DONE)
        {
            this._organizations.getLogoUrl(value).single().toPromise()
            .then(url =>{
                this.logoImageUrl = url;
                this.logoUploading = false;
            })
            .catch(e => {
                console.log('Logo error - ' + e.message);
                this.errorMessage = 'An error was encountered showing the image.';
                this.logoUploading = false;
            });
        }
        else if (state === plupload.FAILED)
        {
            this.logoUploading = false;
            this.errorMessage = 'An error was encountered while uploading your image.  Refresh the page and try again.';

            // Don't leave a bad image ref in the profile.
            //UserProfileUpdate.save({ profileId: userProfileId }, { $set: { images: [] } });
        }
        else
        {
            this.logoUploading = true;
        }
    }
    //use for generate gettting started pdf data
    onGettingStarted()
    {   
        console.log(this.currentOrgDetails._id);
        this.printing = true;
        this.errorMessage = '';
        var username = encodeURIComponent(this._ctx.creds.username);
        var password = encodeURIComponent(this._ctx.creds.password);

        if (this.currentOrgDetails._id.length < 1)
        {
            this.printing = false;
            this.errorMessage = 'The selected Form(s) have not filled out any of the selected forms.';
            return;
        }
        this._docLoader.opengettingstartedPdf(this.currentOrgDetails._id,username,password, window).then(() =>
        {
            this.printing = false;
        }).catch(error =>
        {
            this.printing = false;
            console.error(error);
            this.errorMessage = 'We encountered an error printing.Please try again.';
        });
    }
}