System.register(["@angular/core", "@angular/router", "./userAccount.service"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, router_1, userAccount_service_1;
    var ResetPassComponent;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (userAccount_service_1_1) {
                userAccount_service_1 = userAccount_service_1_1;
            }],
        execute: function() {
            ResetPassComponent = (function () {
                function ResetPassComponent(_acctSvc, _router, _route) {
                    this._acctSvc = _acctSvc;
                    this._router = _router;
                    this._route = _route;
                    var userAccountId = this._route.snapshot.params['userAccountId'];
                    if (userAccountId)
                        this.userAccountId = decodeURIComponent(userAccountId);
                    var username = this._route.snapshot.params['username'];
                    if (username)
                        this.username = decodeURIComponent(username);
                }
                ResetPassComponent.prototype.onSubmit = function () {
                    var _this = this;
                    if (this.submitting)
                        return;
                    this.submitting = true;
                    this.errorMessage = null;
                    if (!this.code || !this.password) {
                        this.errorMessage = 'All fields are required.';
                        this.submitting = false;
                        return;
                    }
                    if (this.code.length < 8) {
                        this.errorMessage = 'Please enter the code that was sent to ' + this.username + '.';
                        this.submitting = false;
                        return;
                    }
                    if (this.password.length < 5) {
                        this.errorMessage = 'Password must be at least 5 characters.';
                        this.submitting = false;
                        return;
                    }
                    this._acctSvc.resetPassword(this.userAccountId, this.username.trim(), this.password.trim(), this.code)
                        .then(function () {
                        _this.successMessage = 'Your password has been changed.';
                    })
                        .catch(function (err) {
                        _this.submitting = false;
                        console.log(err);
                        _this.errorMessage = 'We encountered an unexpected error.';
                    });
                };
                ResetPassComponent = __decorate([
                    core_1.Component({
                        selector: 'max-reset-pass',
                        template: "\n    <div *ngIf=\"errorMessage\" style=\"max-width:500px; margin:20px auto;\" class=\"alert alert-danger\">{{errorMessage}}</div>\n    <div *ngIf=\"successMessage\" style=\"max-width:500px; margin:20px auto;\" class=\"alert alert-success\">\n        <p>{{successMessage}}</p>\n        <button style=\"margin-top:10px;\" class=\"btn btn-primary\" [routerLink]=\"['/max-cover/login', {username:username}]\">Return to login</button>\n    </div>\n    <div *ngIf=\"!successMessage\" id=\"reset-pass-form\">\n        <p>\n            <img class=\"max-wordmark-logo\" src=\"app/media/hurricane-100.png\"/>\n            <span class=\"max-wordmark-text\">DragonFly MAX</span>\n            <br />Check your messages at {{username}} for a password reset code, and enter a new password below.\n        </p>\n        <form #resetPassForm=\"ngForm\" (ngSubmit)=\"onSubmit()\">\n        \n          <div class=\"form-group\">\n            <label for=\"username\">Password Reset Code</label>\n            <input autocomplete=\"new-password\" [(ngModel)]=\"code\" type=\"text\" class=\"form-control\" name=\"username\" placeholder=\"Reset code sent to {{username}}\" required>\n          </div>\n\n          <div *ngIf=\"!passwordShow\" class=\"form-group\">\n              <label for=\"password\">New Password</label>\n              <div class=\"input-group\">\n                <input autocomplete=\"new-password\" [(ngModel)]=\"password\" type=\"password\" class=\"form-control\" id=\"password\" name=\"password\" placeholder=\"New Password\" required>\n                <span class=\"input-group-btn\">\n                    <button class=\"btn btn-primary\" type=\"button\" (click)=\"passwordShow = true\">Show</button>\n                </span>\n              </div>\n          </div>\n          \n          <div *ngIf=\"passwordShow\" class=\"form-group\">\n              <label for=\"password\">New Password</label>\n              <div class=\"input-group\">\n                <input autocomplete=\"new-password\" [(ngModel)]=\"password\" type=\"text\" class=\"form-control\" id=\"password-text\" name=\"password-text\" placeholder=\"Password\" required>\n                <span class=\"input-group-btn\">\n                    <button class=\"btn btn-primary\" type=\"button\" (click)=\"passwordShow = false\">Hide</button>\n                </span>\n              </div>\n          </div>\n\n          <button class=\"btn btn-default\" style=\"float:left\" onclick=\"window.history.back()\">&lt; I Didn't Get My Code</button>\n          <button type=\"submit\" class=\"btn btn-default\" style=\"float:right\" [disabled]=\"!resetPassForm.form.valid\">Change Password</button>          \n\n          <button class=\"btn btn-default\" style=\"visibility: hidden\"></button> <!-- Dont let container collapse too small b/c of float on the other buttons -->\n          \n          <div style=\"height:30px;\">&nbsp;</div>\n        </form>\n    </div>\n"
                    }), 
                    __metadata('design:paramtypes', [userAccount_service_1.UserAccountService, router_1.Router, router_1.ActivatedRoute])
                ], ResetPassComponent);
                return ResetPassComponent;
            }());
            exports_1("ResetPassComponent", ResetPassComponent);
        }
    }
});
//# sourceMappingURL=reset_pass.component.js.map