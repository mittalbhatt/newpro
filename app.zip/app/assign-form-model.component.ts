import {Component, Output, EventEmitter} from "@angular/core";
import {ModalComponent, DialogRef} from "angular2-modal";
import {DfObjectId} from "./DfObjectId";
import {MaxAppContext} from "./maxAppContext.service";
import { Assignments, Assignment } from "./assignments.service";
import { Observable } from 'rxjs';
import {Modal, BSModalContext} from 'angular2-modal/plugins/bootstrap';

import _ from "underscore";

export class Form{
    name:string;
    level:string;
    tag:string;
    isSelected:boolean;
    constructor(data:any){
        this.name = data.name;
        this.level = data.level;
        this.tag = data.code;
        this.isSelected = false;
    }
}

export class SelectedFormWithSport{
    orgId:string;
    role:string;
    tag:string;
    constructor(data:any){
        this.orgId = data.orgId;
        this.role = data.role;
        this.tag = data.tag;
    }
}

export class SelectedFormWithoutSport{
    orgId:string;
    role:string;
    constructor(data:any){
        this.orgId = data.orgId;
        this.role = data.role;
    }
}

export class AssignFormModalContext extends BSModalContext {
    public data: any;

    constructor(private d:any){
        super();
        this.data = d;
        //this.size = "lg";
    }
}

@Component({
    selector:'packet-form-modal-prompt',
    template:`
    <div class="modal-content" style="text-align:left;">
        <div class="modal-header">
            <h4> Assign Forms </h4>
        </div>
        <div class="modal-body usa-map center-border" >
            <div class="row " *ngIf="!isProcessGetForm">
                <div class="col-xs-12 col-sm-6">
                <ul class="forms-category mob-border">
                    <li class="sport-list-title"> Assign To People </li>
                    <li *ngFor="let srole of sportRole" id="ck-button"> 
                        <label>
                            <input type="checkbox" [(ngModel)]="srole.isSelected" value="srole.isSelected"/> 
                            <span [class]="'btn-'+srole.title"> {{srole.title}} </span>
                        </label>
                    </li>
                </ul>
                </div>
                <div class="col-xs-12 col-sm-6">
                <ul class="forms-category" *ngIf="sportRole[0].isSelected == true || sportRole[1].isSelected == true ">
                    <li class="sport-list-title"> Assign To Sports </li>
                    <li class="all-sport"> 
                        <input type="checkbox" id="all_sport_chk" [(ngModel)]="selectAllSport" />
                        <label for="all_sport_chk">All Sports</label>
                    </li>
                    <li  [hidden]="selectAllSport" *ngFor="let sport of sportList"> 
                    <input type="checkbox" [(ngModel)]="sport.isSelected" value="sport.isSelected" [id]="'sport_'+sport.tag" /> 
                    <label [attr.for]="'sport_'+sport.tag">{{ sport.name }} <span class="assign-sport-level" *ngIf="sport.level">{{ sport.level }}</span></label>
                    </li>
                </ul>
                <ul *ngIf="sportRole[0].isSelected ==false && sportRole[1].isSelected == false" class="forms-category">
                    <li class="sport-list-title">No People Selected</li>
                </ul>
                </div>
            </div>
            <div *ngIf="isProcessGetForm" style="text-align: center; padding-top: 150px;">
                <img src="/maxweb/app/media/ajax-loader.gif" />
            </div>
        </div>
        <div class="modal-footer">
            <button (click)="saveSportRole()" type="button" class="btn btn-primary" style="float:right; margin-right:10px;">Assign</button>
            <button (click)="onCancel()" type="button" class="btn btn-danger" style="float:right; margin-right:10px;">Cancel</button>
        </div>
    </div>
    `,
    styles:[`
    .usa-map{
        min-height:400px;
    }
    `]
})
export class AssignFormModal implements ModalComponent<AssignFormModalContext>
{
    private allForms:any;
    private selectedSport:any=[];
    private isProcessGetForm:boolean=false;
    private sportList:any=[];
    private howManySelectForm:number=0;
    private selectAllSport:boolean=false;
    private sportRole:Array<Object> = [{role:"ATH", title:"Athletes", isSelected:false},{role:"CCH", title:"Coaches", isSelected:false}];
    private orgId:string;
    context: AssignFormModalContext;

    constructor(
        public dialog:DialogRef<AssignFormModalContext>, 
        private _assignment: Assignments,
        private _modal:Modal
        )
    {
        if(this.dialog.context.data.currentOrgData.data){
            // For getting sport list
            let sportList = this.dialog.context.data.currentOrgData.data.teams;
            _.each(sportList, (o:any)=>{
                this.sportList.push(new Form(o.team));
            });
            this.orgId = this.dialog.context.data.currentOrgData.org;

            // For getting current selected Sports
            let selectedSportList = this.dialog.context.data.selectedPacket;
            if(selectedSportList){
                _.each(selectedSportList, (sp:SelectedFormWithSport)=>{
                    // For selected current role
                    if(sp.role){
                        _.each(this.sportRole, (o:any)=>{ 
                            if(o.role == sp.role){
                                o.isSelected = true;
                            }
                        });
                    }
                    // For selected current sport
                    if(sp.tag !== undefined){
                        _.each(this.sportList, (sl:Form)=>{ 
                            if(sl.tag == sp.tag){
                                sl.isSelected = true;
                            }
                        });
                    }else{
                        this.selectAllSport = true;
                    }
                });
            }
        }
    }

    private onCancel()
    {
        this.dialog.close(false);
    }

    saveSportRole(){
        this.checkSportValidation().then((res:boolean)=>{
            if(res == true){
                this.selectedSport = [];
                // replace sportList with sportRole for issue when no teams in currentOrgData
                if(this.sportRole.length > 0) {
                    _.each(this.sportRole, (r:any)=>{
                        if(r.isSelected == true){
                            if(this.selectAllSport){
                                let selectedSport = {orgId: this.orgId, role: r.role};
                                this.selectedSport.push(new SelectedFormWithoutSport(selectedSport));
                            }else{
                                _.each(this.sportList, (o:Form)=>{
                                    if(o.isSelected == true){
                                        let selectedSport = {orgId: this.orgId ,role: r.role, tag: o.tag};
                                        this.selectedSport.push(new SelectedFormWithSport(selectedSport));
                                    }
                                });
                            }
                        }
                    });
                }
                this._assignment.getPopupData.emit({data:this.selectedSport,type:"assignees"});
                this.dialog.close(false);    
            }else{
                this._modal.alert()
                .size('lg').isBlocking(true).showClose(false)
                .headerClass("hide").keyboard(27)
                .body(`To assign forms, you must to select both what people and what sports to assign to.  If you don't want to assign to anyone right now, just clear all the boxes.`)
                .bodyClass('modal-body text-left')
                .okBtn('OK').open().then(res =>{
                    // this.dialog.close(false);
                });
            }
        });
    }

    checkSportValidation():Promise<boolean>{
        return new Promise((resolve, reject) => {
            let isRoleTrue = _.where(this.sportRole, {isSelected: true});
            if(isRoleTrue !== undefined && isRoleTrue.length > 0){
                let isSportTrue = _.where(this.sportList, {isSelected: true});
                if((isSportTrue !== undefined && isSportTrue.length > 0) || (this.selectAllSport==true)){
                    resolve(true);
                }else{
                    resolve(false);
                }
            }else{
                resolve(true);
            }
        });
    }
}