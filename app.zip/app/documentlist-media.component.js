System.register(["@angular/core", "@angular/router", "./organizations.service", 'angular2-modal/plugins/bootstrap', "./basic_medical_saver.service"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, router_1, organizations_service_1, bootstrap_1, basic_medical_saver_service_1;
    var DocumentlistMediaComponent;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (organizations_service_1_1) {
                organizations_service_1 = organizations_service_1_1;
            },
            function (bootstrap_1_1) {
                bootstrap_1 = bootstrap_1_1;
            },
            function (basic_medical_saver_service_1_1) {
                basic_medical_saver_service_1 = basic_medical_saver_service_1_1;
            }],
        execute: function() {
            DocumentlistMediaComponent = (function () {
                function DocumentlistMediaComponent(_router, _organizations, _modal, _changeSaver) {
                    this._router = _router;
                    this._organizations = _organizations;
                    this._modal = _modal;
                    this._changeSaver = _changeSaver;
                    this.otherdocuments = [];
                    this.groupyearotherdocuments = [];
                    this.alldoc = [];
                    this.isShowDocumentGif = false;
                    this.chkResult = new core_1.EventEmitter();
                }
                Object.defineProperty(DocumentlistMediaComponent.prototype, "documentmedia", {
                    set: function (value) {
                        this.documentlist = value;
                        if (this.documentlist.media !== undefined) {
                            // this.isShowDocumentGif=true;
                            this.loadImage();
                        }
                    },
                    enumerable: true,
                    configurable: true
                });
                DocumentlistMediaComponent.prototype.removeDocumentImage = function () {
                    var _this = this;
                    this._modal.confirm()
                        .size('sm').isBlocking(true).showClose(false).keyboard(27)
                        .body("Are you sure you want to remove this document  image?")
                        .headerClass("hide")
                        .okBtnClass("btn btn-danger")
                        .okBtn("Remove")
                        .cancelBtn("Cancel").cancelBtnClass("btn btn-primary")
                        .open().then(function (dialog) {
                        return dialog.result;
                    }).then(function (result) {
                        _this.isShowDocumentGif = true;
                        if (result == true) {
                            _this._changeSaver.removeInsuranceDocument(_this.documentlist._id)
                                .single().toPromise().then(function (data) {
                                if (data.ok == true) {
                                    //this.documentlist.splice(this.documentlist._id, 1); 
                                    _this.chkResult.emit({
                                        value: _this.documentlist._id
                                    });
                                }
                            })
                                .catch(function (e) {
                                _this.errorMessage = 'We encountered an unexpected error. Refresh the page and try again.';
                                throw e;
                            });
                        }
                    }).catch(function (e) {
                    });
                };
                DocumentlistMediaComponent.prototype.loadImage = function () {
                    var _this = this;
                    var xhr = new XMLHttpRequest();
                    return this._organizations.getLogoUrldocumentmedia(this.documentlist).single().toPromise()
                        .then(function (url) {
                        _this._user_img = url;
                    })
                        .catch(function (e) {
                        _this.isShowDocumentGif = false;
                        console.log('Logo error', e);
                        throw e;
                    });
                };
                DocumentlistMediaComponent.prototype.UploaddocumentImage = function () {
                    alert('here');
                    var logoMedia = {};
                };
                DocumentlistMediaComponent.prototype.onApprove = function (curmediaid, curid, thumbid) {
                    var _this = this;
                    this.thumbidvideo = thumbid;
                    return this._organizations.getLogoUrldocumentmediapopup(curmediaid, curid).single().toPromise()
                        .then(function (url) {
                        _this._user_img = url;
                        if (_this.thumbidvideo != undefined) {
                            var mediadetail = "\n                   <video width=\"868px\" height=\"570px\" controls>\n                   <source src=\"" + _this._user_img + "\" type=\"video/mp4\">\n                   </video>\n\n                ";
                        }
                        else {
                            var mediadetail = "\n                   <img src=\"" + _this._user_img + "\" width=\"100%\">\n                   ";
                        }
                        _this._modal.alert()
                            .size('lg')
                            .body(mediadetail)
                            .showClose(true)
                            .okBtn('close')
                            .okBtnClass('modal-btn-hide')
                            .open().then(function (result) {
                            result.result.then(function () {
                            }, function () { _this.loadImage(); });
                        });
                    })
                        .catch(function (e) {
                        throw e;
                    });
                };
                __decorate([
                    core_1.Output(), 
                    __metadata('design:type', core_1.EventEmitter)
                ], DocumentlistMediaComponent.prototype, "chkResult", void 0);
                __decorate([
                    core_1.Input('documentmedia'), 
                    __metadata('design:type', Object), 
                    __metadata('design:paramtypes', [Object])
                ], DocumentlistMediaComponent.prototype, "documentmedia", null);
                DocumentlistMediaComponent = __decorate([
                    core_1.Component({
                        selector: 'documentlist-media',
                        template: "\n  \n    <a href=\"javascript:void(0)\" *ngIf=\"_user_img && documentlist.media && documentlist.media[0].thumbnailId!=undefined\" (click)=\"onApprove(documentlist.media[0].mediaId,documentlist._id,documentlist.media[0].thumbnailId)\">\n     <img  *ngIf=\"_user_img && documentlist.media\" [src]=\"_user_img\" style=\"max-width:100px; max-height:100px; width:100px\">\n     <div class=\"playpause\"></div>\n    </a>\n    <a href=\"javascript:void(0)\" *ngIf=\"_user_img && documentlist.media && documentlist.media[0].thumbnailId==undefined\" (click)=\"onApprove(documentlist.media[0].mediaId,documentlist._id,documentlist.media[0].thumbnailId)\">\n     <img  *ngIf=\"_user_img && documentlist.media && !isShowDocumentGif\" [src]=\"_user_img\" style=\"max-width:100px; max-height:100px; width:100px\">\n     <div *ngIf=\"isShowDocumentGif\" style=\"text-align: center\">\n                            <img style=\"max-width:30px; max-height:30px; width:30px\" src=\"/maxweb/app/media/ajax-loader.gif\" /> \n             </div>\n     </a> \n      <span *ngIf=\"_user_img && documentlist.media && !isShowDocumentGif && documentlist.$canEdit==true\" class=\"deletimgbtndoc\">\n                <i  (click)=\"removeDocumentImage()\" class=\"glyphicon glyphicon-remove-circle\"></i>\n    </span>                  \n    ",
                    }), 
                    __metadata('design:paramtypes', [router_1.Router, organizations_service_1.Organizations, bootstrap_1.Modal, basic_medical_saver_service_1.BasicMedicalSaver])
                ], DocumentlistMediaComponent);
                return DocumentlistMediaComponent;
            }());
            exports_1("DocumentlistMediaComponent", DocumentlistMediaComponent);
        }
    }
});
//# sourceMappingURL=documentlist-media.component.js.map