System.register(["@angular/http", "@angular/core", "rxjs/Observable", "./maxAppContext.service"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var http_1, core_1, Observable_1, maxAppContext_service_1;
    var DocumentChangeSaverStatus, BasicMedicalSaver;
    return {
        setters:[
            function (http_1_1) {
                http_1 = http_1_1;
            },
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (Observable_1_1) {
                Observable_1 = Observable_1_1;
            },
            function (maxAppContext_service_1_1) {
                maxAppContext_service_1 = maxAppContext_service_1_1;
            }],
        execute: function() {
            DocumentChangeSaverStatus = (function () {
                function DocumentChangeSaverStatus(saved, response) {
                    if (response === void 0) { response = null; }
                    this.saved = saved;
                    this.response = response;
                }
                return DocumentChangeSaverStatus;
            }());
            exports_1("DocumentChangeSaverStatus", DocumentChangeSaverStatus);
            BasicMedicalSaver = (function () {
                function BasicMedicalSaver(http, _ctx, _requestOps) {
                    this._ctx = _ctx;
                    this._requestOps = _requestOps;
                    this._pendingChanges = [];
                    this._http = http;
                    this.status = new core_1.EventEmitter();
                }
                BasicMedicalSaver.prototype.canDeactivate = function (component) {
                    return component.confirmChangeRoute().then(function (res) {
                        return res;
                    }).catch(function (e) {
                        return false;
                    });
                };
                BasicMedicalSaver.prototype.addChange = function (data) {
                    var match = this._pendingChanges.filter(function (d) { return d.ident == data.ident; })[0];
                    if (match)
                        match.value = data.value;
                    else
                        this._pendingChanges.push(data);
                };
                BasicMedicalSaver.prototype.start = function (amrId, profileId) {
                    if (!amrId)
                        throw new Error('documentId is required');
                    if (this._started)
                        return;
                    this._amrId = amrId;
                    this.profileId = profileId;
                    this._stopped = false;
                    this._started = true;
                    this.schedule();
                };
                BasicMedicalSaver.prototype.stop = function () {
                    if (this._timeoutHandle)
                        clearTimeout(this._timeoutHandle);
                    this._timeoutHandle = null;
                    this._stopped = true;
                    this._started = false;
                };
                BasicMedicalSaver.prototype.saveNow = function () {
                    if (!this._stopped)
                        throw new Error('Saver must be stopped before calling saveNow()');
                    return this.savePending();
                };
                BasicMedicalSaver.prototype.schedule = function () {
                    var _this = this;
                    if (!this._stopped)
                        this._timeoutHandle = setTimeout(function () { return _this.savePending(); }, 2000);
                };
                BasicMedicalSaver.prototype.update = function (update) {
                    return this._http.put("/training/api/documents", update);
                };
                BasicMedicalSaver.prototype.removeInsuranceDocument = function (id) {
                    return this._http.delete("/training/api/documents/" + id);
                };
                BasicMedicalSaver.prototype.getLogoUrldocumentmedia = function (value) {
                    var _this = this;
                    console.log(value);
                    return Observable_1.Observable.create(function (observer) {
                        if (value.media[0].thumbnailId) {
                            var logoMedia = value.media[0].thumbnailId;
                        }
                        else {
                            var logoMedia = value.media[0].mediaId;
                        }
                        if (!logoMedia) {
                            observer.next(null);
                            observer.complete();
                            return;
                        }
                        var req = new XMLHttpRequest();
                        var url = "/training/api/documents/" + value._id + "/media/" + encodeURIComponent(logoMedia);
                        req.open('get', url);
                        req.onreadystatechange = function () {
                            if (req.status == 200) {
                                var loc = req.getResponseHeader('location');
                                observer.next(loc);
                                observer.complete();
                            }
                            else if (req.readyState == 4) {
                                observer.error(new Error(req.responseText));
                            }
                        };
                        req.setRequestHeader('Authorization', _this._requestOps.headers.get('Authorization'));
                        req.send();
                    });
                };
                BasicMedicalSaver.prototype.savePending = function () {
                    var _this = this;
                    this._timeoutHandle = null;
                    if (!this._currentSavingChanges) {
                        this._currentSavingChanges = this._pendingChanges;
                        this._pendingChanges = [];
                    }
                    if (!this._currentSavingChanges.length) {
                        this._currentSavingChanges = null;
                        this.schedule();
                        return Observable_1.Observable.from([0], null);
                    }
                    var setObject = [];
                    _.each(this._currentSavingChanges, function (obj) {
                        setObject.push((_a = {},
                            _a[obj.ident] = obj.value,
                            _a
                        ));
                        var _a;
                    });
                    var finalSetObject = setObject.reduce(function (acc, x) {
                        for (var key in x)
                            acc[key] = x[key];
                        return acc;
                    }, {});
                    var finaluserproObject = setObject.reduce(function (acc, x) {
                        for (var key in x) {
                            if (key == 'info.firstName' || key == 'info.lastName' || key == 'info.tel' || key == 'info.email') {
                                var keynew = key.split(".")[1];
                                if (key == 'info.email') {
                                    keynew = 'emails';
                                    if (x[key][0]) {
                                        acc['email'] = x[key][0];
                                    }
                                    else {
                                        acc['email'] = null;
                                    }
                                }
                                acc[keynew] = x[key];
                            }
                        }
                        return acc;
                    }, {});
                    var amrObject = {
                        "$set": finalSetObject
                    };
                    var userproObject = {
                        "$set": finaluserproObject
                    };
                    var observableamr = this._http.put('/training/api/amrs/' + this._amrId + '/update', amrObject);
                    if (Object.keys(finaluserproObject).length != 0) {
                        var observablepro = this._http.put('/training/api/userProfiles/' + this.profileId + '/update', userproObject);
                        Observable_1.Observable.forkJoin([observableamr, observablepro]).subscribe(function (response) {
                            _this._currentSavingChanges = null;
                            _this.schedule();
                            _this.status.emit(new DocumentChangeSaverStatus(true, response[0]));
                        }, function (errorResponse) {
                            _this.schedule();
                            _this.status.emit(new DocumentChangeSaverStatus(false, errorResponse));
                        });
                        return observablepro;
                    }
                    else {
                        observableamr.subscribe(function (response) {
                            _this._currentSavingChanges = null;
                            _this.schedule();
                            _this.status.emit(new DocumentChangeSaverStatus(true, response));
                        }, function (errorResponse) {
                            _this.schedule();
                            _this.status.emit(new DocumentChangeSaverStatus(false, errorResponse));
                        });
                        return observableamr;
                    }
                };
                BasicMedicalSaver = __decorate([
                    core_1.Injectable(), 
                    __metadata('design:paramtypes', [http_1.Http, maxAppContext_service_1.MaxAppContext, http_1.RequestOptions])
                ], BasicMedicalSaver);
                return BasicMedicalSaver;
            }());
            exports_1("BasicMedicalSaver", BasicMedicalSaver);
        }
    }
});
//# sourceMappingURL=basic_medical_saver.service.js.map