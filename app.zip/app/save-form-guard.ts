import { CanDeactivate } from '@angular/router';
import { Injectable } from '@angular/core';
import { TeamsPlayersComponent } from './teams-players.component';
// import {SharedService} from './shared.service';

@Injectable()
export class SaveFormGuard implements CanDeactivate<TeamsPlayersComponent> {

  constructor(
    // private _shared: SharedService
  ){

  }
  canDeactivate(component: TeamsPlayersComponent) {
    sessionStorage['currentPacket'] = "";
    return component.confirmChangeRoute().then((res:boolean):boolean =>{
        return res;
    }).catch(e=> {
      return false;
    });
  }
}