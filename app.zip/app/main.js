// import {bootstrap}    from '@angular/platform-browser-dynamic'
// import {AppComponent} from './app.component'
// import {HTTP_PROVIDERS} from '@angular/http';
// import {provide} from "@angular/core";
// import {AppBaseRequestOptions} from "./app_base_request_options";
// import {RequestOptions} from "@angular/http";
// import {AppErrorHandler} from "./app_error_handler.service";
//
// bootstrap(AppComponent, [
//     HTTP_PROVIDERS,
//     provide(RequestOptions, {useClass:AppBaseRequestOptions}),
//
//     // I have tried and tried to use an OpaqueToken like in examples but I get a cryptic error.
//     provide('AppErrorHandler', {useClass:AppErrorHandler})
// ]);
System.register(['@angular/platform-browser-dynamic', './app.module', '@angular/core'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var platform_browser_dynamic_1, app_module_1, core_1;
    return {
        setters:[
            function (platform_browser_dynamic_1_1) {
                platform_browser_dynamic_1 = platform_browser_dynamic_1_1;
            },
            function (app_module_1_1) {
                app_module_1 = app_module_1_1;
            },
            function (core_1_1) {
                core_1 = core_1_1;
            }],
        execute: function() {
            core_1.enableProdMode();
            platform_browser_dynamic_1.platformBrowserDynamic().bootstrapModule(app_module_1.AppModule);
        }
    }
});
//# sourceMappingURL=main.js.map