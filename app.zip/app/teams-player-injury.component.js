System.register(["@angular/core", "@angular/common", "./user_profiles.service", 'angular2-modal/plugins/bootstrap'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, common_1, user_profiles_service_1, bootstrap_1;
    var TeamsPlayerInjuryComponent;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (common_1_1) {
                common_1 = common_1_1;
            },
            function (user_profiles_service_1_1) {
                user_profiles_service_1 = user_profiles_service_1_1;
            },
            function (bootstrap_1_1) {
                bootstrap_1 = bootstrap_1_1;
            }],
        execute: function() {
            TeamsPlayerInjuryComponent = (function () {
                function TeamsPlayerInjuryComponent(_model, datepipe) {
                    this._model = _model;
                    this.datepipe = datepipe;
                    this.playerInjuryAllData = [];
                    this.innerWidth = (document.body.clientWidth);
                    var filterPipe = new Date();
                }
                Object.defineProperty(TeamsPlayerInjuryComponent.prototype, "playerInjuryData", {
                    set: function (value) {
                        var _this = this;
                        this.playerInjuryAllData = [];
                        if (value.length >= 0) {
                            value.forEach(function (d) {
                                _this.playerInjuryAllData.push(new user_profiles_service_1.UserInjuryDetails(d));
                            });
                            if (this.playerInjuryAllData.length >= 1) {
                                this.currentInjuryDetail = this.playerInjuryAllData[0];
                            }
                        }
                    },
                    enumerable: true,
                    configurable: true
                });
                TeamsPlayerInjuryComponent.prototype.showInjuryDetails = function (data) {
                    this.currentInjuryDetail = data;
                    this.innerWidth = (document.body.clientWidth);
                    var injury_date = "None";
                    if (this.currentInjuryDetail.injuryName !== null) {
                        injury_date = this.datepipe.transform(this.currentInjuryDetail.doi, 'MM/dd/yyyy');
                    }
                    var injurydetails = "\n                <p><strong>Injury </strong> " + ((this.currentInjuryDetail.injuryName !== null) ? this.currentInjuryDetail.injuryName : 'None') + "</p>\n                <p><strong>Date of Injury </strong> " + injury_date + "</p>\n                <p><strong>Body Part </strong> " + ((this.currentInjuryDetail.bodyPart !== null) ? this.currentInjuryDetail.bodyPart : 'None') + "</p>\n                <p><strong>Initial Treatmen </strong> " + ((this.currentInjuryDetail.treatments !== null) ? this.currentInjuryDetail.treatments : 'None') + "</p>\n                <br>\n                <p class=\"injury-details\"><strong>Injury Details </strong> " + ((this.currentInjuryDetail.injuryDetails !== null) ? this.currentInjuryDetail.injuryDetails : 'None') + "</p>\n                <p><strong>Practice/Play Instr</strong> " + ((this.currentInjuryDetail.particePlayInstructions !== null) ? this.currentInjuryDetail.particePlayInstructions : 'None') + "</p>\n            ";
                    if (Number(this.innerWidth) <= 976) {
                        this._model.alert().title("Previous Injuries & Illnesses")
                            .body(injurydetails)
                            .bodyClass("col-xs-12 col-sm-12 col-md-7 col-lg-8 text-left injury")
                            .showClose(true)
                            .okBtn("Close")
                            .okBtnClass("hidden-xs hidden-sm")
                            .open().then(function (result) { result.result.then(function () { }, function () { }); });
                    }
                };
                TeamsPlayerInjuryComponent.prototype.onResize = function (event) {
                    this.innerWidth = (document.body.clientWidth);
                };
                __decorate([
                    core_1.Input('playerInjuryData'), 
                    __metadata('design:type', Object), 
                    __metadata('design:paramtypes', [Object])
                ], TeamsPlayerInjuryComponent.prototype, "playerInjuryData", null);
                __decorate([
                    core_1.HostListener('window:resize', ['$event']), 
                    __metadata('design:type', Function), 
                    __metadata('design:paramtypes', [Object]), 
                    __metadata('design:returntype', void 0)
                ], TeamsPlayerInjuryComponent.prototype, "onResize", null);
                TeamsPlayerInjuryComponent = __decorate([
                    core_1.Component({
                        selector: 'teams-players-injury',
                        templateUrl: '/maxweb/app/app/teams-player-injury.component.html'
                    }), 
                    __metadata('design:paramtypes', [bootstrap_1.Modal, common_1.DatePipe])
                ], TeamsPlayerInjuryComponent);
                return TeamsPlayerInjuryComponent;
            }());
            exports_1("TeamsPlayerInjuryComponent", TeamsPlayerInjuryComponent);
        }
    }
});
//# sourceMappingURL=teams-player-injury.component.js.map