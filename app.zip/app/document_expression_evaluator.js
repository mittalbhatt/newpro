System.register([], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var DocumentExpressionEvaluator;
    return {
        setters:[],
        execute: function() {
            DocumentExpressionEvaluator = (function () {
                function DocumentExpressionEvaluator() {
                }
                DocumentExpressionEvaluator.prototype.evaluateExpression = function (expression, context, fallbackValue, htmlWrapper) {
                    if (fallbackValue === void 0) { fallbackValue = null; }
                    if (htmlWrapper === void 0) { htmlWrapper = null; }
                    var result;
                    var regExp = /{([^}]+)}/g;
                    var replacements = [];
                    var val = null;
                    var isExactlyOneReplacement = /^{([^}]+)}$/g.test(expression);
                    while ((result = regExp.exec(expression)) !== null) {
                        var parts = result[1].split(':').map(function (part) {
                            return part.replace(/\s/g, '');
                        });
                        parts.reverse();
                        parts.forEach(function (part) {
                            // See if this is a known function or a default value.
                            if (part === 'not') {
                                val = !(val && val !== 'false');
                            }
                            else if (part === 'nil') {
                                val = val === undefined || val === null;
                            }
                            else if (part === 'now') {
                                val = new Date();
                            }
                            else if (part === 'true') {
                                val = true;
                            }
                            else if (part === 'false') {
                                val = false;
                            }
                            else {
                                val = context.evaluateDefaultValue(part, fallbackValue, htmlWrapper);
                            }
                        });
                        replacements.push({ search: result[0], val: val });
                    }
                    // If the expression consists of exactly one interpolation and no other
                    // characters, then the result is whatever the result of the interpolation
                    // is (which might not be a string).  Otherwise the result is always the
                    // string result of interpolation.
                    if (isExactlyOneReplacement) {
                        return val;
                    }
                    else {
                        return replacements.reduce(function (curr, part) {
                            return curr.replace(part.search, part.val);
                        }, expression);
                    }
                };
                return DocumentExpressionEvaluator;
            }());
            exports_1("DocumentExpressionEvaluator", DocumentExpressionEvaluator);
        }
    }
});
//# sourceMappingURL=document_expression_evaluator.js.map