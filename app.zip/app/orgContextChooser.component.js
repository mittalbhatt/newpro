System.register(["@angular/core", "./organizations.service", "rxjs/Rx", "./intercomRouterTracker.service"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, organizations_service_1, Rx_1, intercomRouterTracker_service_1;
    var OrgContextChooser;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (organizations_service_1_1) {
                organizations_service_1 = organizations_service_1_1;
            },
            function (Rx_1_1) {
                Rx_1 = Rx_1_1;
            },
            function (intercomRouterTracker_service_1_1) {
                intercomRouterTracker_service_1 = intercomRouterTracker_service_1_1;
            }],
        execute: function() {
            OrgContextChooser = (function () {
                function OrgContextChooser(_orgsService, _intercom) {
                    var _this = this;
                    this._orgsService = _orgsService;
                    this._intercom = _intercom;
                    this.orgChosen = new core_1.EventEmitter();
                    this.orgSearchDataSource = Rx_1.Observable.create(function (observer) {
                        observer.next(_this.orgSearch);
                    }).mergeMap(function (token) {
                        return _this._orgsService.getOrgsBySearchFromDirectory(token, 6);
                    });
                }
                OrgContextChooser.prototype.reset = function () {
                    delete this.org;
                    delete this.code;
                };
                OrgContextChooser.prototype.onSubmit = function () {
                    var _this = this;
                    if (!this.code)
                        return;
                    this.errorMessage = null;
                    this._orgsService.getOrgByCodeFromDirectory(this.code).single().toPromise()
                        .then(function (org) {
                        if (!org) {
                            _this.errorMessage = 'The code you entered did not match any teams.';
                        }
                        else {
                            _this._intercom.track('found-org-by-code', { code: _this.code, org: org.name, orgId: org._id });
                            _this.org = org;
                            _this.orgChosenByCode = true;
                            _this.orgChosen.emit(org);
                        }
                    })
                        .catch(function (e) {
                        _this.errorMessage = 'An unexpected error was encountered. Please try again.';
                        throw e;
                    });
                };
                OrgContextChooser.prototype.onContinue = function () {
                    this.orgChosen.emit(this.org);
                };
                OrgContextChooser.prototype.onSelectSearchOrg = function (e) {
                    this._intercom.track('found-org-by-search', { org: e.item.name, orgId: e.item._id });
                    this.org = e.item;
                    this.orgChosenByCode = false;
                    this.orgChosen.emit(e.item);
                };
                OrgContextChooser.prototype.changeTypeaheadNoResults = function (e) {
                    this.noOrgSearchResults = e;
                };
                OrgContextChooser.prototype.changeTypeaheadLoading = function (e) {
                    this.searching = e;
                };
                __decorate([
                    core_1.Output(), 
                    __metadata('design:type', Object)
                ], OrgContextChooser.prototype, "orgChosen", void 0);
                OrgContextChooser = __decorate([
                    core_1.Component({
                        selector: 'org-context-chooser',
                        template: "\n<div>\n    <div style=\"max-width:500px;\" *ngIf=\"errorMessage\" class=\"alert alert-danger\">{{errorMessage}}</div>\n    <div *ngIf=\"!org\">\n        <h4>Find school by school code:</h4>\n        <p><em>Ask your Coach or Athletic Trainer for the code.</em></p>\n        <form #codeForm=\"ngForm\" (ngSubmit)=\"onSubmit()\">\n            <div style=\"max-width:200px; margin:auto;\" class=\"input-group\">\n                <input [(ngModel)]=\"code\" style=\"border-left:1px solid #ccc;\" name=\"code\" id=\"code\"  autocorrect=\"off\" autocapitalize=\"off\" spellcheck=\"false\" type=\"text\" class=\"form-control\" placeholder=\"School Code\" required />\n                <span class=\"input-group-btn\">\n                    <button type=\"submit\" class=\"btn btn-default\" [disabled]=\"!codeForm.form.valid\">Go</button>\n                </span>\n            </div>\n        </form>\n    </div>\n    <!--<div *ngIf=\"!org\">-->\n         <!--<table style=\"width:80%; margin: 10px 30px 30px;\">-->\n            <!--<tr><td style=\"border-bottom:1px solid #5d5d5d; width:45%;\">&nbsp;</td><td width=\"auto\"><p style=\"margin-top:10px; margin-right:2px; margin-left:2px; height:1px;\">or</p></td><td style=\"border-bottom:1px solid #5d5d5d; width:45%\">&nbsp;</td></tr>-->\n         <!--</table>-->\n    <!---->\n                    <!--<h4>Search for your school:</h4>-->\n                    <!--<template #orgTypeAheadTemplate let-org=\"item\">-->\n                             <!--<div>-->\n                                <!--<h5>{{org.name}}</h5>-->\n                                <!--<h6 *ngIf=\"org.city && org.stateCode\">{{org.city}}, {{org.stateCode}}</h6>-->\n                                <!--<h6>School Code: <em>{{org.shortCode}}</em></h6>-->\n                                <!--<h6 *ngIf=\"org.ncesCode\">NCES ID: <em>{{org.ncesCode}}</em></h6>-->\n                            <!--</div>-->\n                    <!--</template>-->\n                    <!---->\n                    <!--<div class=\"input-group\">-->\n                        <!--<span class=\"input-group-addon\"><span class=\"glyphicon glyphicon-search\"></span></span>-->\n                        <!--<input -->\n                            <!--[(ngModel)]=\"orgSearch\"-->\n                            <!--[typeahead]=\"orgSearchDataSource\"-->\n                            <!--[typeaheadItemTemplate]=\"orgTypeAheadTemplate\"-->\n                            <!--[typeaheadItemTemplate]=\"schoolTypeAheadTemplate\" -->\n                            <!--[typeaheadWaitMs]=\"5\"-->\n                            <!--[typeaheadMinLength]=\"1\"-->\n                            <!--(typeaheadOnSelect)=\"onSelectSearchOrg($event)\"-->\n                            <!--(typeaheadNoResults)=\"changeTypeaheadNoResults($event)\"-->\n                            <!--(typeaheadLoading)=\"changeTypeaheadLoading($event)\"-->\n                            <!--style=\"border-left:0px;\"-->\n                            <!--id=\"schoolName\"-->\n                            <!--name=\"schoolName\"-->\n                            <!--type=\"text\" -->\n                            <!--class=\"form-control\"-->\n                            <!--placeholder=\"School or Team Name\" -->\n                            <!--autocomplete=\"off\" />-->\n                    <!--</div>-->\n                    <!--<img [hidden]=\"!searching\" src=\"app/media/linear-activity-indicator.gif\" />-->\n                    <!---->\n                    <!--<div *ngIf=\"noOrgSearchResults===true\"><em>No results found.</em></div>-->\n    <!--</div>-->\n    <div *ngIf=\"org && orgChosenByCode\">\n        <h4>The code <strong>{{org.shortCode}}</strong> matches <strong>{{org.name}}</strong></h4>\n        <!--<button style=\"margin-right:20px;\" (click)=\"onContinue()\" type=\"button\" class=\"btn btn-primary\">Continue with {{org.name}}</button>-->\n        <!--<button (click)=\"onBack()\" type=\"button\" class=\"btn btn-danger\">Back</button>-->\n    </div>\n    <div *ngIf=\"org && !orgChosenByCode\">\n        <h4>You have chosen <strong>{{org.name}}</strong> with school code <strong>{{org.shortCode}}</strong></h4>              \n    </div>\n</div>\n"
                    }), 
                    __metadata('design:paramtypes', [organizations_service_1.Organizations, intercomRouterTracker_service_1.IntercomRouterTracker])
                ], OrgContextChooser);
                return OrgContextChooser;
            }());
            exports_1("OrgContextChooser", OrgContextChooser);
        }
    }
});
//# sourceMappingURL=orgContextChooser.component.js.map