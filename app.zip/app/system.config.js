(function(global) {


    // map tells the System loader where to look for things
    var map = {
        'app': 'app/app',
        'moment': 'app/node_modules/moment/min',
        'moment-timezone': 'app/node_modules/moment-timezone/builds',
        'underscore': 'app/node_modules/underscore',
        // 'rxjs':                       'app/node_modules/rxjs',
        'angular2-in-memory-web-api': 'app/node_modules/angular2-in-memory-web-api',
        '@angular': 'app/node_modules/@angular',
        'angular2-recaptcha': 'app/node_modules/angular2-recaptcha',
        'angular2-modal': 'app/node_modules/angular2-modal',
        'angular2-modal/plugins/bootstrap': 'app/node_modules/angular2-modal/bundles',
        'ng2-dnd': 'app/node_modules/ng2-dnd/bundles/index.umd.js',
        'ngx-swiper-wrapper': 'app/node_modules/ngx-swiper-wrapper'
    };

    // packages tells the System loader how to load when no filename and/or no extension
    var packages = {
        'app': {
            main: 'main.js',
            defaultExtension: 'js'
        },
        'moment': {
            main: 'moment.min.js',
            type: 'cjs',
            defaultExtension: 'js'
        },
        'moment-timezone': {
            main: 'moment-timezone-with-data.min.js',
            type: 'cjs',
            defaultExtension: 'js'
        },
        'underscore': {
            main: 'underscore-min.js',
            type: 'cjs',
            defaultExtension: 'js'
        },
        'ngx-swiper-wrapper': {
            main: 'bundles/ngx-swiper-wrapper.umd.js',
            defaultExtension: 'js'
        },
        'rxjs': { main: '/app/bundles/rxjs.min.js' },
        'angular2-in-memory-web-api': { main: 'index.js', defaultExtension: 'js' },
        'angular2-recaptcha': { defaultExtension: 'js' },
        'angular2-modal': { main: 'bundles/angular2-modal.umd.js', defaultExtension: 'js' },
        'angular2-modal/plugins/bootstrap': { main: 'angular2-modal.bootstrap.umd.js', defaultExtension: 'js' }
    };

    var packageNames = [
        'common',
        'compiler',
        'core',
        'http',
        'platform-browser',
        'platform-browser-dynamic',
        'router',
        'forms'
    ];

    // add package entries for angular packages in the form '@angular/common': { main: 'index.js', defaultExtension: 'js' }
    packageNames.forEach(function(pkgName) {
        packages['@angular/' + pkgName] = { main: 'bundles/' + pkgName + '.umd.min.js', defaultExtension: 'js' };
    });

    // the rxjs bundle is generated from the builder at /deployment/bundleRxjs.js
    var bundles = {
        "/maxweb/app/bundles/rxjs.min.js": [
            "rxjs/*",
            "rxjs/operator/*",
            "rxjs/observable/*",
            "rxjs/add/operator/*",
            "rxjs/add/observable/*",
            "rxjs/util/*"
        ]
    };

    var config = {
        map: map,
        packages: packages,
        bundles: bundles
    };

    // filterSystemConfig - index.html's chance to modify config before we register it.
    if (global.filterSystemConfig) { global.filterSystemConfig(config); }

    System.config(config);

})(this);