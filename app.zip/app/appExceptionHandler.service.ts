import {Injectable} from "@angular/core";
import {RegistrationContext} from "./registration_context.service";

// Should implement some type of interface, but ExceptionHandler is a class.  I think https://angular.io/docs/ts/latest/api/core/index/ExceptionHandler-class.html is outdated.
@Injectable()
export class MaxAppExceptionHandler
{
    constructor(private _ctx:RegistrationContext)
    {

    }

    handleError(exception:any)
    {
        console.error(exception.rejection || exception);

        if (exception.rejection)
            console.error(exception.rejection.stack);

        if(exception.status && exception.status == 401){
            this._ctx.creds = null;
            location.reload();
        }

        if (exception.rejection && exception.rejection.status == 401)
        {
            this._ctx.creds = null;

            // Reload the page with cleared credentials.  AuthGuard should take over from here.
            location.reload();
        }
    }
}