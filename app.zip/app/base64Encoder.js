System.register(["@angular/core"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1;
    var Base64Encoder;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            }],
        execute: function() {
            Base64Encoder = (function () {
                /*
                 * Copyright (c) 2010 Nick Galbreath
                 * http://code.google.com/p/stringencoders/source/browse/#svn/trunk/javascript
                 *
                 * Permission is hereby granted, free of charge, to any person
                 * obtaining a copy of this software and associated documentation
                 * files (the "Software"), to deal in the Software without
                 * restriction, including without limitation the rights to use,
                 * copy, modify, merge, publish, distribute, sublicense, and/or sell
                 * copies of the Software, and to permit persons to whom the
                 * Software is furnished to do so, subject to the following
                 * conditions:
                 *
                 * The above copyright notice and this permission notice shall be
                 * included in all copies or substantial portions of the Software.
                 *
                 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
                 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
                 * OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
                 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
                 * HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
                 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
                 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
                 * OTHER DEALINGS IN THE SOFTWARE.
                 */
                /* base64 encode/decode compatible with window.btoa/atob
                 *
                 * window.atob/btoa is a Firefox extension to convert binary data (the "b")
                 * to base64 (ascii, the "a").
                 *
                 * It is also found in Safari and Chrome.  It is not available in IE.
                 *
                 * if (!window.btoa) window.btoa = base64.encode
                 * if (!window.atob) window.atob = base64.decode
                 *
                 * The original spec's for atob/btoa are a bit lacking
                 * https://developer.mozilla.org/en/DOM/window.atob
                 * https://developer.mozilla.org/en/DOM/window.btoa
                 *
                 * window.btoa and base64.encode takes a string where charCodeAt is [0,255]
                 * If any character is not [0,255], then an exception is thrown.
                 *
                 * window.atob and base64.decode take a base64-encoded string
                 * If the input length is not a multiple of 4, or contains invalid characters
                 *   then an exception is thrown.
                 */
                function Base64Encoder() {
                    this.PADCHAR = '=';
                    this.ALPHA = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
                }
                Base64Encoder.prototype.getbyte64 = function (s, i) {
                    var idx = this.ALPHA.indexOf(s.charAt(i));
                    if (idx == -1) {
                        throw "Cannot decode base64";
                    }
                    return idx;
                };
                Base64Encoder.prototype.decode = function (s) {
                    // convert to string
                    s = "" + s;
                    var pads, i, b10;
                    var imax = s.length;
                    if (imax == 0) {
                        return s;
                    }
                    if (imax % 4 != 0) {
                        throw "Cannot decode base64";
                    }
                    pads = 0;
                    if (s.charAt(imax - 1) == this.PADCHAR) {
                        pads = 1;
                        if (s.charAt(imax - 2) == this.PADCHAR) {
                            pads = 2;
                        }
                        // either way, we want to ignore this last block
                        imax -= 4;
                    }
                    var x = [];
                    for (i = 0; i < imax; i += 4) {
                        b10 = (this.getbyte64(s, i) << 18) | (this.getbyte64(s, i + 1) << 12) |
                            (this.getbyte64(s, i + 2) << 6) | this.getbyte64(s, i + 3);
                        x.push(String.fromCharCode(b10 >> 16, (b10 >> 8) & 0xff, b10 & 0xff));
                    }
                    switch (pads) {
                        case 1:
                            b10 = (this.getbyte64(s, i) << 18) | (this.getbyte64(s, i + 1) << 12) | (this.getbyte64(s, i + 2) << 6);
                            x.push(String.fromCharCode(b10 >> 16, (b10 >> 8) & 0xff));
                            break;
                        case 2:
                            b10 = (this.getbyte64(s, i) << 18) | (this.getbyte64(s, i + 1) << 12);
                            x.push(String.fromCharCode(b10 >> 16));
                            break;
                    }
                    return x.join('');
                };
                Base64Encoder.prototype.getbyte = function (s, i) {
                    var x = s.charCodeAt(i);
                    if (x > 255) {
                        throw "INVALID_CHARACTER_ERR: DOM Exception 5";
                    }
                    return x;
                };
                Base64Encoder.prototype.encode = function (s) {
                    if (arguments.length != 1) {
                        throw "SyntaxError: Not enough arguments";
                    }
                    var i, b10;
                    var x = [];
                    // convert to string
                    s = "" + s;
                    var imax = s.length - s.length % 3;
                    if (s.length == 0) {
                        return s;
                    }
                    for (i = 0; i < imax; i += 3) {
                        b10 = (this.getbyte(s, i) << 16) | (this.getbyte(s, i + 1) << 8) | this.getbyte(s, i + 2);
                        x.push(this.ALPHA.charAt(b10 >> 18));
                        x.push(this.ALPHA.charAt((b10 >> 12) & 0x3F));
                        x.push(this.ALPHA.charAt((b10 >> 6) & 0x3f));
                        x.push(this.ALPHA.charAt(b10 & 0x3f));
                    }
                    switch (s.length - imax) {
                        case 1:
                            b10 = this.getbyte(s, i) << 16;
                            x.push(this.ALPHA.charAt(b10 >> 18) + this.ALPHA.charAt((b10 >> 12) & 0x3F) +
                                this.PADCHAR + this.PADCHAR);
                            break;
                        case 2:
                            b10 = (this.getbyte(s, i) << 16) | (this.getbyte(s, i + 1) << 8);
                            x.push(this.ALPHA.charAt(b10 >> 18) + this.ALPHA.charAt((b10 >> 12) & 0x3F) +
                                this.ALPHA.charAt((b10 >> 6) & 0x3f) + this.PADCHAR);
                            break;
                    }
                    return x.join('');
                };
                Base64Encoder = __decorate([
                    core_1.Injectable(), 
                    __metadata('design:paramtypes', [])
                ], Base64Encoder);
                return Base64Encoder;
            }());
            exports_1("Base64Encoder", Base64Encoder);
        }
    }
});
//# sourceMappingURL=base64Encoder.js.map