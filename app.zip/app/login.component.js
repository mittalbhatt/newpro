System.register(["@angular/core", "./auth.service", "@angular/router", "./userAccount.service", "./maxAppContext.service"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, auth_service_1, router_1, userAccount_service_1, maxAppContext_service_1;
    var LoginComponent;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (auth_service_1_1) {
                auth_service_1 = auth_service_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (userAccount_service_1_1) {
                userAccount_service_1 = userAccount_service_1_1;
            },
            function (maxAppContext_service_1_1) {
                maxAppContext_service_1 = maxAppContext_service_1_1;
            }],
        execute: function() {
            LoginComponent = (function () {
                function LoginComponent(_auth, _acctSvc, _router, _route, _ctx) {
                    this._auth = _auth;
                    this._acctSvc = _acctSvc;
                    this._router = _router;
                    this._route = _route;
                    this._ctx = _ctx;
                    this.isSignUpLink = false;
                    var username = this._route.snapshot.params['username'];
                    if (username)
                        this.username = decodeURIComponent(username);
                }
                LoginComponent.prototype.ngOnInit = function () {
                    if (this._auth.isLoggedIn) {
                        this._router.navigateByUrl('/');
                    }
                };
                LoginComponent.prototype.onSubmit = function () {
                    var _this = this;
                    if (this.submitting)
                        return;
                    this.submitting = true;
                    this.errorMessage = null;
                    this.isSignUpLink = false;
                    this._auth.login(this.username.trim(), this.password.trim(), this.persistent)
                        .then(function () {
                        _this.submitting = false;
                        var url = _this._auth.redirectUrl;
                        console.log("Logged in.  Redirect url: " + url);
                        _this._auth.redirectUrl = null;
                        if (url)
                            _this._router.navigateByUrl(url);
                        else
                            _this._router.navigateByUrl('/');
                    })
                        .catch(function (err) {
                        window.scrollTo(0, 0);
                        _this.submitting = false;
                        console.log(err);
                        if (err.status == 401) {
                            if (err.json().VerificationRequired == true) {
                                _this._acctSvc.cachedPassword = _this.password;
                                _this._router.navigate(['verify-account', _this.username.trim()], { relativeTo: _this._route.parent });
                                return;
                            }
                            _this.isSignUpLink = true;
                            _this.errorMessage = 'The username or password is incorrect. Did you sign up with your phone # or email?';
                        }
                        else {
                            _this.errorMessage = 'We encountered an unexpected error.';
                        }
                    });
                };
                LoginComponent.prototype.reset = function () {
                    this._ctx.logout();
                    this._router.navigate(['/max-cover/choose-org']);
                };
                LoginComponent = __decorate([
                    core_1.Component({
                        selector: 'max-login',
                        template: "\n    <div *ngIf=\"errorMessage\" style=\"max-width:500px; margin:20px auto;padding:10px\" [class]=\"'alert alert-danger animated shake'\">\n    {{errorMessage}}\n    <br/><a *ngIf=\"isSignUpLink\" [routerLink]=\"['/max-cover/signup']\" style=\"color:#6495ed;\">Sign up here if you don't have an account</a>\n    </div>\n    <div id=\"login-form\">\n        <div>\n            <org-heading #heading></org-heading>\n            <img *ngIf=\"!heading.org\" class=\"max-wordmark-logo\" src=\"app/media/hurricane-100.png\"/>\n            <span *ngIf=\"!heading.org\" class=\"max-wordmark-text\">DragonFly MAX</span>\n            <a style=\"font-size:10px;\" href=\"javascript:void(0)\" (click)=\"reset()\" *ngIf=\"heading.org\">Not part of {{heading.org.name}}? Click here.</a>\n        </div>\n        <form #loginForm=\"ngForm\" (ngSubmit)=\"onSubmit()\">\n          <div class=\"form-group\">\n            <label for=\"username\">Email or Phone</label>\n            <input [(ngModel)]=\"username\" autocorrect=\"off\" autocapitalize=\"off\" spellcheck=\"false\" type=\"text\" class=\"form-control\" name=\"username\" placeholder=\"Mobile # or email address\" required autofocus>\n          </div>\n          <div class=\"form-group\">\n            <label for=\"password\">Password</label>\n            <input [(ngModel)]=\"password\" type=\"password\" class=\"form-control\" name=\"password\" placeholder=\"Password\" required>\n            <a style=\"color:#6495ed; font-weight:bold;\" href=\"javascript:void(0)\" [routerLink]=\"['/max-cover/forgot-pass', username ? {username:username} : {}]\">Forgot your password?</a>\n          </div>\n          <!--<div class=\"form-group\">-->\n            <!--<p class=\"help-block\">Example block-level help text here.</p>-->\n          <!--</div>-->\n          <!--<div class=\"checkbox\">-->\n            <!--<label>-->\n              <!--<input [(ngModel)]=\"persistent\" name=\"persistent\" type=\"checkbox\"> Stay logged in?-->\n            <!--</label>-->\n          <!--</div>-->\n          <button type=\"submit\" class=\"btn btn-primary\" style=\"height:45px; width:170px; font-size:20px;\" [disabled]=\"!loginForm.form.valid\">Login</button>\n        </form>\n          <table style=\"width:108%; margin: 10px -10px 30px;\">\n            <tr><td style=\"border-bottom:1px solid #5d5d5d; width:19%;\">&nbsp;</td><td width=\"auto\"><p style=\"margin-top:10px; margin-right:2px; margin-left:2px; height:1px;\">Don't have an account?</p></td><td style=\"border-bottom:1px solid #5d5d5d; width:19%\">&nbsp;</td></tr>\n          </table>\n          <button class=\"btn btn-primary\" style=\"height:45px; width:170px; font-size:20px;\" [routerLink]=\"['/max-cover/signup', {username:username}]\">Sign Up for Free</button>\n    </div>\n"
                    }), 
                    __metadata('design:paramtypes', [auth_service_1.AuthService, userAccount_service_1.UserAccountService, router_1.Router, router_1.ActivatedRoute, maxAppContext_service_1.MaxAppContext])
                ], LoginComponent);
                return LoginComponent;
            }());
            exports_1("LoginComponent", LoginComponent);
        }
    }
});
//# sourceMappingURL=login.component.js.map