System.register([], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var Credentials;
    return {
        setters:[],
        execute: function() {
            Credentials = (function () {
                function Credentials() {
                }
                return Credentials;
            }());
            exports_1("Credentials", Credentials);
        }
    }
});
//# sourceMappingURL=credentials.js.map