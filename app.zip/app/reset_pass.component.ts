import {Component} from "@angular/core";
import {Router, ActivatedRoute} from "@angular/router";
import {UserAccountService} from "./userAccount.service";

@Component({
    selector: 'max-reset-pass',
    template:`
    <div *ngIf="errorMessage" style="max-width:500px; margin:20px auto;" class="alert alert-danger">{{errorMessage}}</div>
    <div *ngIf="successMessage" style="max-width:500px; margin:20px auto;" class="alert alert-success">
        <p>{{successMessage}}</p>
        <button style="margin-top:10px;" class="btn btn-primary" [routerLink]="['/max-cover/login', {username:username}]">Return to login</button>
    </div>
    <div *ngIf="!successMessage" id="reset-pass-form">
        <p>
            <img class="max-wordmark-logo" src="app/media/hurricane-100.png"/>
            <span class="max-wordmark-text">DragonFly MAX</span>
            <br />Check your messages at {{username}} for a password reset code, and enter a new password below.
        </p>
        <form #resetPassForm="ngForm" (ngSubmit)="onSubmit()">
        
          <div class="form-group">
            <label for="username">Password Reset Code</label>
            <input autocomplete="new-password" [(ngModel)]="code" type="text" class="form-control" name="username" placeholder="Reset code sent to {{username}}" required>
          </div>

          <div *ngIf="!passwordShow" class="form-group">
              <label for="password">New Password</label>
              <div class="input-group">
                <input autocomplete="new-password" [(ngModel)]="password" type="password" class="form-control" id="password" name="password" placeholder="New Password" required>
                <span class="input-group-btn">
                    <button class="btn btn-primary" type="button" (click)="passwordShow = true">Show</button>
                </span>
              </div>
          </div>
          
          <div *ngIf="passwordShow" class="form-group">
              <label for="password">New Password</label>
              <div class="input-group">
                <input autocomplete="new-password" [(ngModel)]="password" type="text" class="form-control" id="password-text" name="password-text" placeholder="Password" required>
                <span class="input-group-btn">
                    <button class="btn btn-primary" type="button" (click)="passwordShow = false">Hide</button>
                </span>
              </div>
          </div>

          <button class="btn btn-default" style="float:left" onclick="window.history.back()">&lt; I Didn't Get My Code</button>
          <button type="submit" class="btn btn-default" style="float:right" [disabled]="!resetPassForm.form.valid">Change Password</button>          

          <button class="btn btn-default" style="visibility: hidden"></button> <!-- Dont let container collapse too small b/c of float on the other buttons -->
          
          <div style="height:30px;">&nbsp;</div>
        </form>
    </div>
`
})
export class ResetPassComponent {

    errorMessage:string;
    successMessage:string;
    passwordShow:boolean;

    code:string;
    userAccountId:string;
    username:string;
    password:string;

    submitting:boolean;

    constructor(
        private _acctSvc:UserAccountService,
        private _router:Router,
        private _route:ActivatedRoute)
    {
        let userAccountId = this._route.snapshot.params['userAccountId'];
        if (userAccountId)
            this.userAccountId = decodeURIComponent(userAccountId);

        let username = this._route.snapshot.params['username'];
        if (username)
            this.username = decodeURIComponent(username);
    }

    onSubmit()
    {
        if (this.submitting)
            return;

        this.submitting = true;
        this.errorMessage = null;

        if (!this.code || !this.password)
        {
            this.errorMessage = 'All fields are required.';
            this.submitting = false;
            return;
        }

        if (this.code.length < 8)
        {
            this.errorMessage = 'Please enter the code that was sent to ' + this.username + '.';
            this.submitting = false;
            return;
        }

        if (this.password.length < 5)
        {
            this.errorMessage = 'Password must be at least 5 characters.';
            this.submitting = false;
            return;
        }

        this._acctSvc.resetPassword(this.userAccountId, this.username.trim(), this.password.trim(), this.code)
            .then(() =>
            {
                this.successMessage = 'Your password has been changed.';
            })
            .catch(err =>
            {
                this.submitting = false;

                console.log(err);

                this.errorMessage = 'We encountered an unexpected error.';
            });
    }
}