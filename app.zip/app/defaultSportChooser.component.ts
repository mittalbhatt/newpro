import {SportCodes, SportCode} from "./sportCodes"
import {Component, Output, EventEmitter, Input} from "@angular/core";
import * as _ from "underscore";

class SportCodeOptionModel
{
    private _selected = false;
    private _onSelectedChanged:(SportCodeOptionModel) => void;

    constructor(sportCode:SportCode, onSelectedChanged:(SportCodeOptionModel) => void)
    {
        this.sportCode = sportCode;
        this._onSelectedChanged = onSelectedChanged;
    }

    set selected(value)
    {
        this._selected = value;

        if (this._onSelectedChanged)
            this._onSelectedChanged(this);
    }

    get selected()
    {
        return this._selected;
    }

    sportCode:SportCode;
}

var template = `
<div class="container-fluid" style="max-width:700px">
    <div class="row" *ngFor="let row of sportOptionsRows">
        <div class="col-xs-4" *ngFor="let sport of row">
            <div class="checkbox">
                <label>
                    <input type="checkbox" [(ngModel)]="sport.selected"> {{sport.sportCode.name}}
                </label>
            </div>
        </div>
    </div>
</div>
`;

@Component({
    selector:'default-sport-chooser',
    template:template
})
export class DefaultSportChooser
{
    @Output() sportsSelected:EventEmitter<SportCode[]> = new EventEmitter<SportCode[]>();

    @Input() set initialSelectedSportCodes(value:string[])
    {
        if (!value)
            return;

        this.sportOptions.forEach(so => so.selected = value.indexOf(so.sportCode.code) > -1);
    }

    sportOptions:SportCodeOptionModel[];
    sportOptionsRows:SportCodeOptionModel[][];

    constructor()
    {
        this.sportOptions = SportCodes.map(sc => {return new SportCodeOptionModel(sc, x => this.onSelected());});

        const cols = 3;
        this.sportOptionsRows = _.chain(this.sportOptions)
            .map((so, idx) => {return {so:so, col:Math.floor(idx/cols)};})
            .groupBy('col')
            .values()
            .map(v => v.map(vv => vv.so))
            .value();
    }

    onSelected()
    {
        this.sportsSelected.emit(this.sportOptions.filter(so => so.selected).map(so => so.sportCode));
    }
}