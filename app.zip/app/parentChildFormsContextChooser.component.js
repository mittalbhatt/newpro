System.register(["@angular/core", "@angular/router", "./user_profiles.service", "./maxAppContext.service", "./confirmProfileDelete", "./relatedProfilesList.component"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, router_1, user_profiles_service_1, maxAppContext_service_1, confirmProfileDelete_1, relatedProfilesList_component_1;
    var ParentChildFormsContextChooser;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (user_profiles_service_1_1) {
                user_profiles_service_1 = user_profiles_service_1_1;
            },
            function (maxAppContext_service_1_1) {
                maxAppContext_service_1 = maxAppContext_service_1_1;
            },
            function (confirmProfileDelete_1_1) {
                confirmProfileDelete_1 = confirmProfileDelete_1_1;
            },
            function (relatedProfilesList_component_1_1) {
                relatedProfilesList_component_1 = relatedProfilesList_component_1_1;
            }],
        execute: function() {
            ParentChildFormsContextChooser = (function () {
                function ParentChildFormsContextChooser(_route, _router, _profileSvc, _profileUtil, ctx) {
                    this._route = _route;
                    this._router = _router;
                    this._profileSvc = _profileSvc;
                    this._profileUtil = _profileUtil;
                    this.ctx = ctx;
                    this.profileId = this._route.snapshot.params['profileId'];
                }
                ParentChildFormsContextChooser.prototype.onAddNew = function () {
                    this._router.navigate(['chooseFormsProfile', this.profileId, 'create'], { relativeTo: this._route.parent });
                };
                ParentChildFormsContextChooser.prototype.editProfile = function (profile) {
                    this._router.navigate(['editFormsProfile', profile._id], { relativeTo: this._route.parent });
                };
                ParentChildFormsContextChooser.prototype.deleteProfile = function (profile) {
                    var _this = this;
                    this._profileUtil.confirmProfileDelete(profile, function () {
                        _this.loading = true;
                        _this._profileSvc.deleteProfile(profile)
                            .single().toPromise().then(function () {
                            _this.relatedProfilesList.clear(profile);
                            _this.loading = false;
                        })
                            .catch(function (e) {
                            _this.loading = false;
                            _this.errorMessage = 'We encountered an unexpected error. Refresh the page and try again.';
                            throw e;
                        });
                    });
                };
                ParentChildFormsContextChooser.prototype.startForms = function (profile) {
                    this._router.navigate(['packetList', { profileId: profile._id }], { relativeTo: this._route.parent });
                };
                __decorate([
                    core_1.ViewChild(relatedProfilesList_component_1.RelatedProfilesList), 
                    __metadata('design:type', relatedProfilesList_component_1.RelatedProfilesList)
                ], ParentChildFormsContextChooser.prototype, "relatedProfilesList", void 0);
                ParentChildFormsContextChooser = __decorate([
                    core_1.Component({
                        selector: 'parent-child-forms-context-chooser',
                        template: "\n<div style=\"min-height:300px; max-width:500px; padding:20px; margin: 30px auto auto;\">\n    <h3>Who are you filling out forms for?</h3>\n    <div *ngIf=\"errorMessage\" class=\"alert alert-danger\">{{errorMessage}}</div>\n    <img *ngIf=\"loading\" src=\"/maxweb/app/media/ajax-loader.gif\" />\n    <related-profiles-list [style.display]=\"loading ? 'none' : 'block'\" [profileId]=\"profileId\" [relationRoles]=\"['PRN']\" (itemDeleteClicked)=\"deleteProfile($event)\" (itemEditClicked)=\"editProfile($event)\" (itemClicked)=\"startForms($event)\"></related-profiles-list>\n    <div class=\"list-group\">\n        <button type=\"button\" class=\"list-group-item\" (click)=\"onAddNew()\">Add new athlete in {{ctx.currentOrg?.name || '...loading school name...'}} <span style=\"float:right; color:green;\" class=\"glyphicon glyphicon-plus\"></span></button>    \n    </div>\n    <p style=\"font-style: italic;\">Have children in other schools? Log in via that school's forms link.</p>\n</div>\n"
                    }), 
                    __metadata('design:paramtypes', [router_1.ActivatedRoute, router_1.Router, user_profiles_service_1.UserProfiles, confirmProfileDelete_1.ProfileUtil, maxAppContext_service_1.MaxAppContext])
                ], ParentChildFormsContextChooser);
                return ParentChildFormsContextChooser;
            }());
            exports_1("ParentChildFormsContextChooser", ParentChildFormsContextChooser);
        }
    }
});
//# sourceMappingURL=parentChildFormsContextChooser.component.js.map