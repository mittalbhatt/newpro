import {Pipe, PipeTransform} from "@angular/core";

@Pipe({name:'phone', pure:true})
export class PhoneDisplayPipe implements PipeTransform
{
    transform(value:string, expression:string) : any
    {
        // http://stackoverflow.com/a/8358141
        var s2 = (""+value).replace(/\D/g, '');
        if (s2.length == 11 && s2[0] == '1')
            s2 = s2.substr(1);

        var m = s2.match(/^(\d{3})(\d{3})(\d{4})$/);
        return (!m) ? value : "(" + m[1] + ") " + m[2] + "-" + m[3];
    }
}