System.register(["@angular/core", "./user_profiles.service", "@angular/router", "./maxAppContext.service", 'angular2-modal/plugins/bootstrap', 'angular2-modal', "./invite-modal.component"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, user_profiles_service_1, router_1, maxAppContext_service_1, bootstrap_1, angular2_modal_1, invite_modal_component_1;
    var RelationComponent;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (user_profiles_service_1_1) {
                user_profiles_service_1 = user_profiles_service_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (maxAppContext_service_1_1) {
                maxAppContext_service_1 = maxAppContext_service_1_1;
            },
            function (bootstrap_1_1) {
                bootstrap_1 = bootstrap_1_1;
            },
            function (angular2_modal_1_1) {
                angular2_modal_1 = angular2_modal_1_1;
            },
            function (invite_modal_component_1_1) {
                invite_modal_component_1 = invite_modal_component_1_1;
            }],
        execute: function() {
            RelationComponent = (function () {
                function RelationComponent(_userProfiles, _route, _router, _appCtx, _model) {
                    this._userProfiles = _userProfiles;
                    this._route = _route;
                    this._router = _router;
                    this._appCtx = _appCtx;
                    this._model = _model;
                    this.changeData = new core_1.EventEmitter();
                    this.ngModelChangeFun = new core_1.EventEmitter();
                    this.item = { "firstName": "", "lastName": "", "rel": "", "tel": [""], "address": "", "city": "", "state": "", "zip": "" };
                    //initRelationObj :any = {"firstName": "","lastName": "","rel": "Relation","tel":[""],"address": "", "city": "", "state": "Select state", "zip": ""};
                    this.phoneArrayrelation = [];
                    this.errorclassphone = [];
                    this.errorclassemail = [];
                    this.relationArray = [];
                    this.sitesearch = null;
                    this.openingPages = false;
                    this.deleteloader = false;
                    this.userProfileData = [];
                    this.showEmailPhone = false;
                    this.emailParent = null;
                    this.telParent = null;
                    this.showLockedIcon = false;
                    this._athleteProfile = [];
                    this.athleteFullName = "";
                    this.parentFullName = "";
                    this.deleteTrue = false;
                    this.deleteDisable = true;
                    if (this.phoneArrayrelation.length == 0) {
                        this.phoneArrayrelation.push({ phone: '' });
                    }
                    var params = this._route.snapshot.params;
                    this.profileId = params['profileId'];
                    this.item.rel = 'this.item';
                }
                RelationComponent.prototype.ngOnInit = function () {
                    if (this.item.userProfileId != undefined && this.item.userProfileId != null) {
                        this.loadEmailAndPhone(this.item.userProfileId);
                        this.checkUserAccount(this.item.userProfileId);
                    }
                    else {
                        this.deleteDisable = false;
                    }
                };
                RelationComponent.prototype.loadEmailAndPhone = function (profileid) {
                    var _this = this;
                    //console.log("load Email & phone for relation");
                    var loadRelationProfile = this._userProfiles.getProfile(profileid).single().toPromise();
                    loadRelationProfile.then(function (user) {
                        var userProfile = user;
                        if (_.has(userProfile, 'orgRoles') && userProfile.orgRoles.indexOf("PRN") > -1) {
                            _this.showEmailPhone = true;
                            _this.firstNameParent = (userProfile.firstName != undefined) ? userProfile.firstName : "";
                            _this.emailParent = (userProfile.email != undefined) ? userProfile.email : "";
                            _this.telParent = (userProfile.tel != undefined) ? userProfile.tel[0] : "";
                            if (_this.indexre != undefined && _this.indexre == '0') {
                                _this.item.email = _this.emailParent;
                                _this.item['tel'][0] = _this.telParent;
                            }
                        }
                    });
                };
                RelationComponent.prototype.checkUserAccount = function (profileId) {
                    var _this = this;
                    console.log("profileId=========" + profileId);
                    // get edited athlete name
                    if (this._athleteProfile.lastName == undefined) {
                        this.athleteFullName = "" + this._athleteProfile.firstName;
                    }
                    else if (this._athleteProfile.firstName == undefined) {
                        this.athleteFullName = "" + this._athleteProfile.lastName;
                    }
                    else if (this._athleteProfile.firstName !== undefined && this._athleteProfile.lastName !== undefined) {
                        this.athleteFullName = this._athleteProfile.firstName + " " + this._athleteProfile.lastName;
                    }
                    else {
                        this.athleteFullName = "this Athelete";
                    }
                    // get parent name
                    if (this.item.lastName == undefined) {
                        this.parentFullName = "" + this.item.firstName;
                    }
                    else if (this.item.firstName == undefined) {
                        this.parentFullName = "" + this.item.lastName;
                    }
                    else if (this.item.firstName !== undefined && this.item.lastName !== undefined) {
                        this.parentFullName = this.item.firstName + " " + this.item.lastName;
                    }
                    else {
                        this.parentFullName = "this Parent";
                    }
                    // console.log("Start..................");
                    this._userProfiles.getAllProfilesToCheck()
                        .then(function (profiles) {
                        //console.log("Starting+++++++++++++"+profileId);
                        var userAccount = profiles.filter(function (p) { return p._id == profileId; }).map(function (p) { return new user_profiles_service_1.UserProfile(p); });
                        console.log(userAccount);
                        if (_.has(userAccount[0], '$userAccount')) {
                            //console.log("TRUE======#$userAccount");
                            _this.showLockedIcon = true;
                        }
                        //console.log("One-----------------");
                        var myProfileCheck = _this._appCtx.myProfiles.filter(function (mp) { return mp._id == profileId; });
                        //console.log(this._appCtx.currentProfile.orgRoles);
                        if (_.has(_this._appCtx.currentProfile, 'orgRoles') == true && _this._appCtx.currentProfile.orgRoles.indexOf("UADM") > -1) {
                            _this.deleteTrue = true;
                            _this.relationDeleteMsg = "If you delete this entry, " + _this.parentFullName + " will no longer be linked to " + _this.athleteFullName + " in MAX, \n                    and will lose access to " + _this.athleteFullName + "'s records.\n                     <br><br> Are you sure you want to do this?";
                        }
                        else if ((_.has(_this._appCtx.currentProfile, 'orgRoles') == true && _this._appCtx.currentProfile.orgRoles.indexOf("PRN") > -1) || (myProfileCheck != undefined && myProfileCheck.length == 1)) {
                            _this.deleteTrue = true;
                            _this.relationDeleteMsg = "If you delete this entry, you will no longer be linked to " + _this.athleteFullName + " in MAX, \n                    and you will lose access to " + _this.athleteFullName + "'s records.\n                     <br><br> Are you sure you want to do this?";
                        }
                        else {
                            _this.deleteTrue = false;
                            _this.relationDeleteMsg = "You do not have access to remove the link between " + _this.athleteFullName + " \n                    and " + _this.parentFullName + " and do not allow the delete.";
                        }
                        _this.deleteDisable = false;
                    })
                        .catch(function (e) {
                        console.log(e);
                        _this.errorMessage = 'We encountered an unexpected error. Refresh the page and try again.';
                        throw e;
                    });
                };
                Object.defineProperty(RelationComponent.prototype, "relationdata", {
                    set: function (value) {
                        this.item = value;
                        if (this.item.tel == undefined) {
                            this.item['tel'] = [];
                        }
                        if (this.item.state == undefined || this.item.state == '') {
                            this.item.state = '';
                        }
                        if (this.item.rel == undefined || this.item.rel == '') {
                            this.item.rel = '';
                        }
                    },
                    enumerable: true,
                    configurable: true
                });
                RelationComponent.prototype.checkerror = function (field) {
                    // console.log(field);
                    if (field === null || field === undefined || field === "") {
                        return true;
                    }
                    else {
                        return false;
                    }
                };
                Object.defineProperty(RelationComponent.prototype, "stateOptions", {
                    get: function () {
                        var stateObj = this._appCtx.getStates();
                        return _.chain(stateObj)
                            .flatten()
                            .value();
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(RelationComponent.prototype, "parentOptions", {
                    get: function () {
                        var parentObj = this._appCtx.getParents();
                        return _.chain(parentObj)
                            .flatten()
                            .value();
                    },
                    enumerable: true,
                    configurable: true
                });
                RelationComponent.prototype.changeRelationData = function (event) {
                    this.unsaveData = true;
                    this.ngModelChangeFun.emit(event);
                };
                RelationComponent.prototype.addmoreData = function (type) {
                    if (type == 'phonerelation') {
                        this.phoneArrayrelation.push({ phone: '' });
                    }
                };
                RelationComponent.prototype.addmoreRelation = function () {
                    this.relationArray.push({ "firstName": "", "lastName": "", "rel": "", "tel": [], "address": "", "city": "", "state": "", "zip": "", "email": "" });
                };
                RelationComponent.prototype.saveDataRelation = function (relationArray, indexrel, indexphone, type, event) {
                    this.changeRelationData(event);
                    if (type == 'phone') {
                        if (relationArray.tel.length > 0) {
                            //let PHONE_REGEXP = /^[0-9\-+\)\(]+$/;
                            //if (PHONE_REGEXP.test(relationArray.tel[0])) {
                            if (relationArray.tel[0].length > 0) {
                                this.errorclassphone[0] = 'false';
                                if (event.type !== undefined && event.type === 'blur') {
                                    this.saveData().then(function (res) {
                                        return res;
                                    }).catch(function (e) {
                                        throw e;
                                    });
                                }
                            }
                            else {
                                this.errorclassphone[0] = 'true';
                            }
                        }
                    }
                    else if (type == 'email') {
                        //let EMAIL_REGEXP = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
                        //if (EMAIL_REGEXP.test(relationArray.email)) {
                        if (relationArray.email.length > 0) {
                            this.errorclassemail[0] = 'false';
                            if (event.type !== undefined && event.type === 'blur') {
                                this.saveData().then(function (res) {
                                    return res;
                                }).catch(function (e) {
                                    throw e;
                                });
                            }
                        }
                        else {
                            this.errorclassemail[0] = 'true';
                        }
                    }
                    else {
                        //console.log("SaveData Relation...");
                        this.saveData().then(function (res) {
                            //console.log("SaveData Complete");
                            return res;
                        }).catch(function (e) {
                            throw e;
                        });
                    }
                };
                RelationComponent.prototype.saveData = function () {
                    var _this = this;
                    //console.log("saveData = Unsave Data 1: "+this.unsaveData);
                    return new Promise(function (resolve, reject) {
                        _this.relationObject = {
                            $set: {
                                relations: _this.relationArray
                            }
                        };
                        if (_this.sitesearch) {
                            _this.sitesearch.unsubscribe();
                        }
                        if (_this.unsaveData !== undefined && _this.unsaveData == true) {
                            _this.sitesearch = _this._userProfiles.updateProfile(_this.profileId, _this.relationObject)
                                .subscribe(function (res) {
                                //console.log("Start Data Save Function...");
                                _this.unsaveData = false;
                                _this._userProfiles.updateRelativeData.emit({ data: true });
                                resolve(true);
                            }, function (e) {
                                resolve(false);
                            });
                        }
                        else {
                            _this._userProfiles.updateRelativeData.emit({ data: true });
                            resolve(true);
                        }
                    });
                };
                RelationComponent.prototype.texttoinvite = function (item) {
                    var inviteobj = { userProfileId: item.userProfileId, requireUniqueVerificationCode: "true", invitationSenderName: "Ms Butler" };
                    this._userProfiles.texttoinvite(inviteobj).single().toPromise().then(function (resdata) {
                        if (resdata !== undefined) {
                        }
                    });
                };
                RelationComponent.prototype.invite = function (inviteId, item) {
                    var _this = this;
                    if (item.firstName == '' && item.lastName == '' && item.rel == '' && item.city == '' && (item.tel[0] == '' || item.tel[0] == undefined)) {
                        this._model.confirm()
                            .size('sm').isBlocking(true).showClose(false).keyboard(27)
                            .body("Please insert at least one field value for this relative.")
                            .headerClass("hide")
                            .okBtnClass("hide")
                            .cancelBtn("OK").cancelBtnClass("btn btn-primary")
                            .open().then(function (dialog) {
                            return dialog.result;
                        }).then(function (result) {
                        }).catch(function (e) {
                        });
                    }
                    else {
                        var inviteobj = { userProfileId: inviteId, requireUniqueVerificationCode: "false" };
                        this.openingPages = true;
                        this._userProfiles.inviterelation(inviteobj).single().toPromise().then(function (resdata) {
                            if (resdata !== undefined) {
                                _this.openingPages = false;
                                var adminFormPrintModalData = new invite_modal_component_1.CustomModalContext({ data: item, resdata: resdata, size: "md" });
                                var config = angular2_modal_1.overlayConfigFactory(adminFormPrintModalData, bootstrap_1.BSModalContext);
                                _this._model.open(invite_modal_component_1.InviteModal, config).then(function (result) {
                                })
                                    .catch(function (e) { return console.log(e); });
                            }
                        });
                    }
                };
                RelationComponent.prototype.onRemoveRelation = function (i, firstname, lastname) {
                    var _this = this;
                    this.deleteloader = true;
                    if (this.deleteTrue == false && this.relationDeleteMsg == undefined && this.item.userProfileId == undefined) {
                        this.deleteTrue = true;
                        this.relationDeleteMsg = "Are you sure you want to do this?";
                    }
                    if (this.deleteTrue == true) {
                        this._model.confirm()
                            .size('md')
                            .isBlocking(true)
                            .showClose(false)
                            .headerClass("hide")
                            .cancelBtnClass("btn btn-primary")
                            .keyboard(27)
                            .body("" + this.relationDeleteMsg)
                            .bodyClass('modal-body text-left')
                            .okBtn("Ok").okBtnClass("btn btn-danger okbutton")
                            .open()
                            .then(function (res) {
                            _this.deleteloader = false;
                            res.result.then(function (r) {
                                if (r === true) {
                                    var relationArray = _this.relationArray.splice(i, 1);
                                    _this.relationObject = {
                                        $set: {
                                            relations: _this.relationArray
                                        }
                                    };
                                    var loadProfileInfo = _this._userProfiles.getProfile(_this.profileId).single().toPromise();
                                    var flag = false;
                                    loadProfileInfo.then(function (data) {
                                        _this.userProfileData = data;
                                        var userProfileId = '';
                                        var currentParentId = '';
                                        if (i === 0) {
                                            userProfileId = _this.userProfileData.relations[0].userProfileId;
                                            currentParentId = _this._appCtx.currentProfile._id;
                                        }
                                        _this._userProfiles.updateProfile(_this.profileId, _this.relationObject).subscribe();
                                        if (userProfileId !== '' && currentParentId !== '' && userProfileId == currentParentId && _this._appCtx.currentProfile.orgRoles.indexOf("PRN") > -1) {
                                            _this._router.navigate(['/max-forms/chooseFormsProfile', currentParentId]);
                                        }
                                    });
                                    return;
                                }
                            })
                                .catch(function (e) {
                                if (e)
                                    throw e;
                            });
                        });
                    }
                    else {
                        this._model.alert()
                            .headerClass("hide")
                            .keyboard(27)
                            .body("" + this.relationDeleteMsg)
                            .bodyClass('modal-body text-left')
                            .okBtn("Ok").okBtnClass("btn btn-primary")
                            .open()
                            .then(function (res) {
                            _this.deleteloader = false;
                        });
                    }
                };
                Object.defineProperty(RelationComponent.prototype, "subjectProfile", {
                    set: function (value) {
                        this._athleteProfile = value;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(RelationComponent.prototype, "relationdataarray", {
                    set: function (value) {
                        this.relationArray = value;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(RelationComponent.prototype, "index", {
                    set: function (value) {
                        this.indexre = value;
                    },
                    enumerable: true,
                    configurable: true
                });
                RelationComponent.prototype.addPhone = function () {
                    this.phoneArrayrelation.push({ phone: '' });
                };
                RelationComponent.prototype.savePhone = function () {
                    var a = _.pluck(this.item, "phone");
                    this.changeData.emit(this.item);
                    //  console.log(this.changeData);
                };
                __decorate([
                    core_1.Output(), 
                    __metadata('design:type', Object)
                ], RelationComponent.prototype, "changeData", void 0);
                __decorate([
                    core_1.Output(), 
                    __metadata('design:type', Object)
                ], RelationComponent.prototype, "ngModelChangeFun", void 0);
                __decorate([
                    core_1.Input('relationdata'), 
                    __metadata('design:type', Object), 
                    __metadata('design:paramtypes', [Object])
                ], RelationComponent.prototype, "relationdata", null);
                __decorate([
                    core_1.Input('subjectProfile'), 
                    __metadata('design:type', Object), 
                    __metadata('design:paramtypes', [Object])
                ], RelationComponent.prototype, "subjectProfile", null);
                __decorate([
                    core_1.Input('relationdataarray'), 
                    __metadata('design:type', Object), 
                    __metadata('design:paramtypes', [Object])
                ], RelationComponent.prototype, "relationdataarray", null);
                __decorate([
                    core_1.Input('index'), 
                    __metadata('design:type', Object), 
                    __metadata('design:paramtypes', [Object])
                ], RelationComponent.prototype, "index", null);
                RelationComponent = __decorate([
                    core_1.Component({
                        selector: 'relation-box',
                        templateUrl: '/maxweb/app/app/realtion_data.component.html',
                    }), 
                    __metadata('design:paramtypes', [user_profiles_service_1.UserProfiles, router_1.ActivatedRoute, router_1.Router, maxAppContext_service_1.MaxAppContext, bootstrap_1.Modal])
                ], RelationComponent);
                return RelationComponent;
            }());
            exports_1("RelationComponent", RelationComponent);
        }
    }
});
//# sourceMappingURL=relationdata.component.js.map