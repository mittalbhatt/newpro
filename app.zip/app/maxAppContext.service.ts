import {Injectable} from "@angular/core";
import {UserProfiles, UserProfile} from "./user_profiles.service";
import {Router, CanActivate, RouterStateSnapshot, ActivatedRouteSnapshot} from "@angular/router";
import {Organization, Organizations} from "./organizations.service";
import {DomSanitizer} from "@angular/platform-browser";
import {RegistrationContext} from "./registration_context.service";
import {UserAccount, UserAccountService} from "./userAccount.service";
import {IntercomRouterTracker} from "./intercomRouterTracker.service";

declare var store:any;

@Injectable()
export class MaxAppContext implements CanActivate
{
    private static ORG_ID = 'df_orgId';

    // NOTE: add new fields to cleared files in logout(...)
    myProfiles:UserProfile[];
    myOrganizations:Organization[];
    availableOrganizations:Organization[];

    currentOrg:Organization;
    currentOrgLogoBlobUrl:any;
    currentProfile:UserProfile;
    currentAccount:UserAccount;

    intercomBooted:boolean;

    constructor(
        private _router:Router,
        private _userProfiles:UserProfiles,
        private _organizations:Organizations,
        private _accounts:UserAccountService,
        private _sanitizer:DomSanitizer,
        private _regCtx:RegistrationContext,
        private _intercom:IntercomRouterTracker)
    {

    }

    canActivate(route:ActivatedRouteSnapshot, state:RouterStateSnapshot)
    {
        //console.log('MaxAppCtx');

        this.orgId = route.queryParams['orgId'] || this.orgId;

        return this.initialize(state.url);
    }

    initialize(url:string=null, rebootIntercom:boolean=false)
    {
        return Promise.all<any>([
            this._accounts.getMyUserAccount(),
            this._userProfiles.getMine().single().toPromise(),
            this._organizations.getOrganizations().single().toPromise()])
            .then(([account, myProfiles, organizations]:[UserAccount, UserProfile[], Organization[]]) =>
            {
                // console.log("============");
                // console.log(myProfiles);
                // console.log("============");

                if (!this.intercomBooted || rebootIntercom)
                {
                    (<any>window).Intercom(rebootIntercom ? "update" : "boot", (<any>account).$intercomPayload);

                    this.intercomBooted = true;
                }

                this.myProfiles = myProfiles.map(p => new UserProfile(p));
                this.availableOrganizations = organizations;
                this.myOrganizations = organizations.filter(o => !!myProfiles.find(p => p.org == o._id));
                this.currentAccount = account;

                if (!this.orgId && myProfiles[0])
                    this.orgId = myProfiles[0].org;

                if (!this.currentOrg || this.currentOrg._id != this.orgId)
                    this.currentOrg = _.find(this.myOrganizations, o => o._id == this.orgId);
                // console.log('Current org :', this.currentOrg);
                this.currentProfile = _.find(this.myProfiles, p => p.org == this.orgId);
                if (!this.currentProfile)
                {
                    this.currentProfile = _.find(this.myProfiles, p => !!_.find(p.linkedOrgRoles, lor => lor.orgId == this.orgId));
                    if (this.currentProfile)
                    {
                        this.orgId = this.currentProfile.org;
                        this.currentOrg = _.find(this.availableOrganizations, o => o._id == this.orgId);
                    }
                }

                // console.log(this.currentProfile);

                if (!this.currentProfile)
                {
                    if (url && url.indexOf('create-own-profile') < 0)
                        this._userProfiles.createProfileRedirectUrl = url;

                    var ret = true;
                    if (window.location.href.indexOf('create-own-profile') < 0 && (!url || url.indexOf('create-own-profile') < 0) && sessionStorage['createlogin']==undefined)
                    {
                        sessionStorage['createlogin']='signintrue';
                        console.log('No current profile, redirecting to create.');
                        this._router.navigateByUrl('/max-forms/create-own-profile');
                        ret = false;
                    }

                    if (this.orgId)
                    {
                        return this._organizations.getOrgFromDirectory(this.orgId).single().toPromise().then(o =>
                        {
                            this.currentOrg = o;
                            if (this.currentOrg)
                                this.currentOrgLogoBlobUrl = this.currentOrg['logoUrl'];

                            return ret;
                        });
                    }

                    return ret;
                }

                this._organizations.getLogo(this.currentOrg).single().toPromise()
                    .then(l => {
                        if (l)
                            this.currentOrgLogoBlobUrl = this._sanitizer.bypassSecurityTrustResourceUrl(l)
                    });

                return true;
            });
    }

    set orgId(value)
    {
        if (!value)
            store.session.remove(MaxAppContext.ORG_ID);
        else
            store.session(MaxAppContext.ORG_ID, value);
    }

    get orgId()
    {
        return store.session(MaxAppContext.ORG_ID);
    }

    logout(nav=true)
    {
        store.clearAll();

        delete this.myProfiles;
        delete this.myOrganizations;
        delete this.availableOrganizations;

        delete this.currentOrg;
        delete this.currentOrgLogoBlobUrl;
        delete this.currentProfile;
        delete this.currentAccount;

        delete this._regCtx.persistent;

        (<any>window).Intercom('shutdown');
        this.intercomBooted = false;

        this._intercom.loggedOutBoot();

        if (nav)
            this._router.navigateByUrl('/max-cover/login');
           // window.location.replace('http://www.dragonflymax.com');
    }

    resetOrg(){
        store.session.remove(MaxAppContext.ORG_ID);
        delete this.currentOrgLogoBlobUrl;
        this._router.navigateByUrl('/max-forms/create-own-profile');
    }

    getStates(){
      var stateObj = [
        {key: "OT", value: "Other"},
        {key: "AL", value: "Alabama"},
        {key: "AK", value: "Alaska"},
        {key: "AZ", value: "Arizona"},
        {key: "AR", value: "Arkansas"},
        {key: "CA", value: "California"},
        {key: "CO", value: "Colorado"},
        {key: "CT", value: "Connecticut"},
        {key: "DC", value: "District of Columbia"},
        {key: "DE", value: "Deleware"},
        {key: "FL", value: "Florida"},
        {key: "GA", value: "Georgia"},
        {key: "HI", value: "Hawaii"},
        {key: "ID", value: "Idaho"},
        {key: "IL", value: "Illinois"},
        {key: "IN", value: "Indiana"},
        {key: "IA", value: "Iowa"},
        {key: "KS", value: "Kansas"},
        {key: "KY", value: "Kentucky"},
        {key: "LA", value: "Louisiana"},
        {key: "ME", value: "Maine"},
        {key: "MD", value: "Maryland"},
        {key: "MA", value: "Massachusetts"},
        {key: "MI", value: "Michigan"},
        {key: "MS", value: "Mississippi"},
        {key: "MN", value: "Minnesota"},
        {key: "MO", value: "Missouri"},
        {key: "MT", value: "Montana"},
        {key: "NE", value: "Nebraska"},
        {key: "NV", value: "Nevada"},
        {key: "NH", value: "New Hampshire"},
        {key: "NJ", value: "New Jersey"},
        {key: "NM", value: "New Mexico"},
        {key: "NY", value: "New York"},
        {key: "NC", value: "North Carolina"},
        {key: "ND", value: "North Dakota"},
        {key: "OH", value: "Ohio"},
        {key: "OK", value: "Oklahoma"},
        {key: "OR", value: "Oregon"},
        {key: "PA", value: "Pennsylvania"},
        {key: "RI", value: "Rhode Island"},
        {key: "SC", value: "South Carolina"},
        {key: "SD", value: "South Dakota"},
        {key: "TN", value: "Tennessee"},
        {key: "TX", value: "Texas"},
        {key: "UT", value: "Utah"},
        {key: "VT", value: "Vermont"},
        {key: "VA", value: "Virginia"},
        {key: "WA", value: "Washington"},
        {key: "WV", value: "West Virginia"},
        {key: "WI", value: "Wisconsin"},
        {key: "WY", value: "Wyoming"}
      ];  
      return stateObj;
    }

    getParents()
    {
        var parentObj = [
            { key : "Mother", value : "Mother"},
            { key : "Father", value : "Father"},
            { key : "Grandmother", value : "Grandmother"},
            { key : "Grandfather", value : "Grandfather"},
            { key : "Guardian", value : "Guardian"},
        ]
        return parentObj;
    }
}