System.register(["@angular/core", "@angular/router", "./organizations.service", "./maxAppContext.service", "./user_profiles.service", "./shared.service", "./df_uuid_gen", './document_loader.service', "./registration_context.service"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var __param = (this && this.__param) || function (paramIndex, decorator) {
        return function (target, key) { decorator(target, key, paramIndex); }
    };
    var core_1, router_1, organizations_service_1, maxAppContext_service_1, user_profiles_service_1, shared_service_1, df_uuid_gen_1, document_loader_service_1, registration_context_service_1;
    var Team, Teams, OrgStructureEntry, TeamsComponent;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (organizations_service_1_1) {
                organizations_service_1 = organizations_service_1_1;
            },
            function (maxAppContext_service_1_1) {
                maxAppContext_service_1 = maxAppContext_service_1_1;
            },
            function (user_profiles_service_1_1) {
                user_profiles_service_1 = user_profiles_service_1_1;
            },
            function (shared_service_1_1) {
                shared_service_1 = shared_service_1_1;
            },
            function (df_uuid_gen_1_1) {
                df_uuid_gen_1 = df_uuid_gen_1_1;
            },
            function (document_loader_service_1_1) {
                document_loader_service_1 = document_loader_service_1_1;
            },
            function (registration_context_service_1_1) {
                registration_context_service_1 = registration_context_service_1_1;
            }],
        execute: function() {
            Team = (function () {
                function Team() {
                }
                return Team;
            }());
            exports_1("Team", Team);
            Teams = (function () {
                function Teams() {
                }
                return Teams;
            }());
            exports_1("Teams", Teams);
            OrgStructureEntry = (function () {
                function OrgStructureEntry() {
                }
                return OrgStructureEntry;
            }());
            exports_1("OrgStructureEntry", OrgStructureEntry);
            TeamsComponent = (function () {
                // @Inject(DOCUMENT) private document: Document;
                function TeamsComponent(ctx, _ctx, _organizations, _userProfilesSvc, route, _docLoader, router, renderer, _shared) {
                    var _this = this;
                    this.ctx = ctx;
                    this._ctx = _ctx;
                    this._organizations = _organizations;
                    this._userProfilesSvc = _userProfilesSvc;
                    this.route = route;
                    this._docLoader = _docLoader;
                    this.router = router;
                    this.renderer = renderer;
                    this._shared = _shared;
                    this.isSelectedOrganization = null;
                    this.isSelectedTeam = null;
                    this.currentOrg = "Everyone";
                    this.currentOrgTeam = "";
                    this.sortingParameter = "sortLastName,sortFirstName";
                    this.filterParameter = null;
                    this.sortingOrderParameter = "";
                    this.roleFilterParameter = "ATH";
                    this.status = { isopen: true };
                    this.isScrollDown = false;
                    var orgStructureData = this.route.snapshot.data['_orgStructureData'];
                    if (orgStructureData !== null && orgStructureData !== undefined) {
                        this.orgStructureData = orgStructureData.entries;
                        this.orgStructureData = _.where(orgStructureData.entries, { selected: true });
                    }
                    this.currentOrgSubscribe = this._shared.currentOrgTeamId.subscribe(function (data) {
                        var org = "Everyone";
                        if (data.orgId && data.orgId !== undefined) {
                            org = data.orgId;
                        }
                        var team = "";
                        if (data.teamId && data.teamId !== undefined) {
                            team = data.teamId;
                        }
                        _this.selectOrgTeam(org, team);
                    });
                }
                TeamsComponent.prototype.ngOnInit = function () {
                    var _this = this;
                    this.currentRoute = this.router.url;
                    if (!sessionStorage['urlafterredict']) {
                        if (this.currentRoute == '/main/teams') {
                            //this.selectOrgTeam("Everyone","");
                            this.firstorgdata = _.first(this.orgStructureData);
                            if (_.has(this.firstorgdata, "org")) {
                                if (_.has(this.firstorgdata.org, "orgId")) {
                                    this.firstorgId = this.firstorgdata.org.orgId;
                                    this.router.navigate(['/main/teams/' + this.firstorgId]);
                                }
                            }
                        }
                        else {
                            this.router.navigate([sessionStorage['urlafterredict']]);
                        }
                    }
                    else {
                        if (sessionStorage['urlafterredict'] == '/main/teams/Everyone/') {
                            this.router.navigate(['/main/teams/']);
                        }
                        else {
                            this.router.navigate([sessionStorage['urlafterredict']]);
                        }
                    }
                    this.router.events.subscribe(function (event) {
                        if (event instanceof router_1.NavigationStart) {
                            _this.sortingParameter = "sortLastName,sortFirstName";
                            _this.filterParameter = null;
                            _this.roleFilterParameter = "ATH";
                            _this.sortingOrderParameter = "";
                        }
                        if (event instanceof router_1.NavigationEnd) {
                            sessionStorage['routeurl'] = event.url;
                            _this.sortingParameter = "sortLastName,sortFirstName";
                            _this.filterParameter = null;
                            _this.roleFilterParameter = "ATH";
                            _this.sortingOrderParameter = "";
                        }
                    });
                };
                TeamsComponent.prototype.ngOnDestroy = function () {
                    this.currentOrgSubscribe.unsubscribe();
                };
                TeamsComponent.prototype.selectOrgTeam = function (org, team) {
                    var _this = this;
                    if (org === void 0) { org = null; }
                    if (team === void 0) { team = null; }
                    if (org != "Everyone" && org != null) {
                        sessionStorage['urlafterredict'] = '/main/teams/' + org;
                    }
                    else if (team != null) {
                        sessionStorage['urlafterredict'] = "/main/teams/" + org + "/" + team;
                    }
                    else {
                        sessionStorage['urlafterredict'] = '/main/teams';
                    }
                    this.currentRoute = this.router.url;
                    this.isSelectedOrganization = org;
                    this.isSelectedTeam = team;
                    this.currentOrgTeam = "";
                    this.logoImageUrl = "";
                    this.currentOrgDetails = null;
                    // Send current selected organization for assign sport in "add assign" popup
                    var currentOrg = _.find(this.orgStructureData, function (o) {
                        return o.org.orgId == org;
                    });
                    if (org !== "Everyone" && currentOrg !== undefined) {
                        this._organizations.orgStructureData.emit({ data: currentOrg, org: org });
                    }
                    else {
                        this._organizations.orgStructureData.emit({ data: null, org: org });
                    }
                    if (this.isSelectedOrganization === "Everyone") {
                        this.currentOrg = "Everyone";
                    }
                    else {
                        _.each(this.orgStructureData, function (o) {
                            if (o.org.orgId == _this.isSelectedOrganization) {
                                _this.currentOrg = o.org.name;
                                if (_this.isSelectedTeam) {
                                    _.each(o.teams, function (t) {
                                        if (t.team.code == _this.isSelectedTeam) {
                                            var level = (t.team.level) ? " (" + t.team.level + ")" : "";
                                            _this.currentOrgTeam = t.team.name + level;
                                        }
                                    });
                                }
                            }
                        });
                        if (this.ctx.availableOrganizations) {
                            this.currentOrgDetails = this.ctx.availableOrganizations.find(function (o) {
                                return o._id === _this.isSelectedOrganization;
                            });
                            if (this.currentOrgDetails) {
                                this._organizations.getLogoUrl(this.currentOrgDetails).single().toPromise()
                                    .then(function (url) {
                                    _this.logoImageUrl = url;
                                })
                                    .catch(function (e) {
                                    //console.log(e);
                                });
                                this._orgLogoUploadStateChange = function (s, f, r) {
                                    _this.orgLogoUploadStateChanged(s, f, r, _this.currentOrgDetails);
                                };
                                this.logoUploadSettings = {
                                    getFileParams: function (file) {
                                        var fileId = df_uuid_gen_1.DfUuidGen.newUuid();
                                        var logoMedia = _this._organizations.getLogoMedia(_this.currentOrgDetails, true);
                                        logoMedia.createdDate = new Date();
                                        logoMedia.contentType = file.type;
                                        logoMedia.mediaId = fileId;
                                        return _this._organizations.update(_this.currentOrgDetails._id, { $set: { media: _this.currentOrgDetails.media } }).single().toPromise()
                                            .then(function (data) {
                                            return {
                                                fileId: fileId,
                                                orgId: _this.currentOrgDetails._id,
                                                paramsUrl: "/training/api/organizations/" + _this.currentOrgDetails._id + "/media/" + encodeURIComponent(fileId)
                                            };
                                        });
                                    },
                                    dfUploadTag: 'org-logo-' + this.currentOrgDetails._id,
                                    uploaderSettings: {
                                        filters: {
                                            max_file_size: '10mb',
                                            mime_types: [
                                                { title: "Image files", extensions: "jpeg,jpg,gif,png" }
                                            ]
                                        },
                                        resize: {
                                            width: 600,
                                            height: 600
                                        }
                                    }
                                };
                            }
                        }
                    }
                };
                TeamsComponent.prototype.getOrgStateCity = function (org) {
                    var stateCityStr = "";
                    if (org) {
                        var currentOrgDetails = this.ctx.availableOrganizations.find(function (o) {
                            return o._id === org;
                        });
                        if (currentOrgDetails !== undefined) {
                            if (currentOrgDetails.city !== undefined && currentOrgDetails.city != "" && currentOrgDetails.city != null) {
                                stateCityStr = currentOrgDetails.city;
                            }
                            if (currentOrgDetails.stateCode !== undefined && currentOrgDetails.stateCode != "" && currentOrgDetails.stateCode != null) {
                                if (stateCityStr == "") {
                                    stateCityStr = currentOrgDetails.stateCode;
                                }
                                else {
                                    stateCityStr += " - " + currentOrgDetails.stateCode;
                                }
                            }
                        }
                    }
                    return stateCityStr;
                };
                TeamsComponent.prototype.scroll = function ($event) {
                    this.status.isopen = false;
                    var bodyScrollTop = document.documentElement.scrollTop || document.body.scrollTop;
                };
                TeamsComponent.prototype.orgLogoUploadStateChanged = function (state, fromUploaderEvent, resultUrl, value) {
                    var _this = this;
                    if (state === plupload.DONE) {
                        this._organizations.getLogoUrl(value).single().toPromise()
                            .then(function (url) {
                            _this.logoImageUrl = url;
                            _this.logoUploading = false;
                        })
                            .catch(function (e) {
                            console.log('Logo error - ' + e.message);
                            _this.errorMessage = 'An error was encountered showing the image.';
                            _this.logoUploading = false;
                        });
                    }
                    else if (state === plupload.FAILED) {
                        this.logoUploading = false;
                        this.errorMessage = 'An error was encountered while uploading your image.  Refresh the page and try again.';
                    }
                    else {
                        this.logoUploading = true;
                    }
                };
                //use for generate gettting started pdf data
                TeamsComponent.prototype.onGettingStarted = function () {
                    var _this = this;
                    console.log(this.currentOrgDetails._id);
                    this.printing = true;
                    this.errorMessage = '';
                    var username = encodeURIComponent(this._ctx.creds.username);
                    var password = encodeURIComponent(this._ctx.creds.password);
                    if (this.currentOrgDetails._id.length < 1) {
                        this.printing = false;
                        this.errorMessage = 'The selected Form(s) have not filled out any of the selected forms.';
                        return;
                    }
                    this._docLoader.opengettingstartedPdf(this.currentOrgDetails._id, username, password, window).then(function () {
                        _this.printing = false;
                    }).catch(function (error) {
                        _this.printing = false;
                        console.error(error);
                        _this.errorMessage = 'We encountered an error printing.Please try again.';
                    });
                };
                TeamsComponent = __decorate([
                    core_1.Component({
                        selector: 'user-teams',
                        templateUrl: '/maxweb/app/app/teams.component.html',
                        host: { '(window:scroll)': 'scroll($event)' }
                    }),
                    __param(7, core_1.Inject(core_1.Renderer)), 
                    __metadata('design:paramtypes', [maxAppContext_service_1.MaxAppContext, registration_context_service_1.RegistrationContext, organizations_service_1.Organizations, user_profiles_service_1.UserProfiles, router_1.ActivatedRoute, document_loader_service_1.DocumentLoader, router_1.Router, core_1.Renderer, shared_service_1.SharedService])
                ], TeamsComponent);
                return TeamsComponent;
            }());
            exports_1("TeamsComponent", TeamsComponent);
        }
    }
});
//# sourceMappingURL=teams.component.js.map