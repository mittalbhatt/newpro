System.register(["@angular/core", "./profileTypeChooser.component", "@angular/router", "./user_profiles.service", "./maxAppContext.service", "./organizations.service", "./DfObjectId", "./linkedOrgRoleRequests.service", 'moment-timezone', "rxjs/Rx", "@angular/http"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, profileTypeChooser_component_1, router_1, user_profiles_service_1, maxAppContext_service_1, organizations_service_1, DfObjectId_1, linkedOrgRoleRequests_service_1, momentTz, Rx_1, http_1;
    var OwnProfileCreator;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (profileTypeChooser_component_1_1) {
                profileTypeChooser_component_1 = profileTypeChooser_component_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (user_profiles_service_1_1) {
                user_profiles_service_1 = user_profiles_service_1_1;
            },
            function (maxAppContext_service_1_1) {
                maxAppContext_service_1 = maxAppContext_service_1_1;
            },
            function (organizations_service_1_1) {
                organizations_service_1 = organizations_service_1_1;
            },
            function (DfObjectId_1_1) {
                DfObjectId_1 = DfObjectId_1_1;
            },
            function (linkedOrgRoleRequests_service_1_1) {
                linkedOrgRoleRequests_service_1 = linkedOrgRoleRequests_service_1_1;
            },
            function (momentTz_1) {
                momentTz = momentTz_1;
            },
            function (Rx_1_1) {
                Rx_1 = Rx_1_1;
            },
            function (http_1_1) {
                http_1 = http_1_1;
            }],
        execute: function() {
            OwnProfileCreator = (function () {
                function OwnProfileCreator(_userProfiles, _ctx, _router, _route, _orgsSvc, _linkedOrgRoleReqs, _http) {
                    var _this = this;
                    this._userProfiles = _userProfiles;
                    this._ctx = _ctx;
                    this._router = _router;
                    this._route = _route;
                    this._orgsSvc = _orgsSvc;
                    this._linkedOrgRoleReqs = _linkedOrgRoleReqs;
                    this._http = _http;
                    console.log('OwnProfileCreator');
                    this.schoolSearchDataSource = Rx_1.Observable.create(function (observer) {
                        observer.next(_this.newOrgName);
                    }).mergeMap(function (token) {
                        return _this._http.get("/training/api/lists/schoolNames/search?limit=5&skip=0&$search=" + token).map(function (res) { return res.json(); });
                    });
                }
                OwnProfileCreator.prototype.ngOnInit = function () {
                    var _this = this;
                    if (!this._ctx.currentAccount) {
                        console.log('No account, redirecting to landing.');
                        this._router.navigateByUrl('/max-cover/landing');
                        return;
                    }
                    if (this._ctx.currentProfile) {
                        if (this._userProfiles.createProfileRedirectUrl)
                            this._router.navigateByUrl(this._userProfiles.createProfileRedirectUrl);
                        else
                            this._router.navigate(['packetList'], { relativeTo: this._route.parent });
                    }
                    this.targetOrg = this._ctx.currentOrg;
                    this._route.params.subscribe(function (params) {
                        _this.selectedType = _this.profileTypeChooser.selectByCode(params['selectedType']);
                        _this.adminPath = params['adminPath'];
                    });
                };
                OwnProfileCreator.prototype.selectAdminPath = function (path) {
                    this._router.navigate([{ selectedType: this.selectedType.code, adminPath: path }], { relativeTo: this._route });
                };
                OwnProfileCreator.prototype.onSelected = function (type) {
                    this._router.navigate([{ selectedType: type.code }], { relativeTo: this._route });
                };
                OwnProfileCreator.prototype.onSubmitNewOrg = function () {
                    var _this = this;
                    var orgResolve;
                    var trainingOrgId;
                    if (this.selectedType.code == 'TRN') {
                        var trnResult = this.resolveOrCreateTrainerOrg();
                        trainingOrgId = trnResult.trainingOrgId;
                        orgResolve = trnResult.resolveOrg;
                    }
                    var newOrg = new organizations_service_1.Organization();
                    newOrg._id = (new DfObjectId_1.DfObjectId()).toString();
                    newOrg.name = this.newOrgName;
                    newOrg.timezone = momentTz.tz.guess();
                    newOrg.roles = ['School'];
                    newOrg.city = this.newOrgCity;
                    newOrg.stateCode = this.newOrgState;
                    newOrg.ncesCode = this.newOrgNCES;
                    newOrg.formsSeedListName = this.newOrgState;
                    if (this.newOrgKnownSchoolId)
                        newOrg.knownSchoolId = this.newOrgKnownSchoolId;
                    var linkedOrgRole;
                    if (trainingOrgId) {
                        var linkId = (new DfObjectId_1.DfObjectId()).toString();
                        newOrg.linkedOrgs = [{
                                linkId: linkId,
                                linkTypes: ['Training', 'OrgAdmin'],
                                granteeOrgId: trainingOrgId
                            }];
                        linkedOrgRole = { tags: [], roles: ['OADM', 'UADM', 'SUB', 'MGA', 'TRN', 'OTRN'], linkId: linkId, orgId: newOrg._id };
                    }
                    var createSchoolOrg = function () { return _this._orgsSvc.createOrg(newOrg).single().toPromise().then(function () { return newOrg; }); };
                    if (!orgResolve) {
                        orgResolve = createSchoolOrg();
                        createSchoolOrg = null;
                    }
                    this.confirmSelection(orgResolve, true, linkedOrgRole, createSchoolOrg);
                };
                OwnProfileCreator.prototype.resolveOrCreateTrainerOrg = function () {
                    var trnOrg = this._ctx.myOrganizations.find(function (o) { return o.roles && o.roles.indexOf('Training') > -1; });
                    if (!trnOrg) {
                        // Brand new trainer, need to create the AT org
                        var account = this._ctx.currentAccount;
                        trnOrg = new organizations_service_1.Organization();
                        trnOrg._id = (new DfObjectId_1.DfObjectId()).toString();
                        var trainingOrgId = trnOrg._id;
                        trnOrg.name = account.firstName + " " + account.lastName + " AT";
                        trnOrg.timezone = momentTz.tz.guess();
                        trnOrg.roles = ['Training'];
                        return { trainingOrgId: trainingOrgId, resolveOrg: this._orgsSvc.createOrg(trnOrg).single().toPromise().then(function () { return trnOrg; }) };
                    }
                    else {
                        return { trainingOrgId: trnOrg._id, resolveOrg: Promise.resolve(trnOrg) };
                    }
                };
                OwnProfileCreator.prototype.reset = function () {
                    if (!this._ctx.currentOrg)
                        delete this.targetOrg;
                    this._router.navigate([{}], { relativeTo: this._route });
                };
                OwnProfileCreator.prototype.confirmSelection = function (resolveTargetOrg, emptyOrg, linkedOrgRole, createSchoolOrg) {
                    var _this = this;
                    if (emptyOrg === void 0) { emptyOrg = false; }
                    if (this.saving)
                        return;
                    this.saving = true;
                    delete this.error;
                    var account = this._ctx.currentAccount;
                    if (this.selectedType.code == 'TRN' && !resolveTargetOrg) {
                        var resolveOrCreateTrainerOrg = this.resolveOrCreateTrainerOrg();
                        resolveTargetOrg = resolveOrCreateTrainerOrg.resolveOrg;
                        if (this._ctx.myProfiles.find(function (p) { return p.org == resolveOrCreateTrainerOrg.trainingOrgId; })) {
                            resolveTargetOrg = resolveTargetOrg.then(function () { return null; });
                        }
                        else {
                            emptyOrg = true;
                        }
                    }
                    resolveTargetOrg = resolveTargetOrg || Promise.resolve(this.targetOrg);
                    resolveTargetOrg.then(function (profileTargetOrg) {
                        if (profileTargetOrg) {
                            var profile = {
                                _id: (new DfObjectId_1.DfObjectId()).toString(),
                                tags: undefined,
                                email: undefined,
                                createdDate: (new Date()).toISOString(),
                                tel: undefined,
                                org: profileTargetOrg._id,
                                userAccountId: account._id,
                                firstName: account.firstName,
                                lastName: account.lastName,
                                sortFirstName: (account.firstName || '').toLowerCase(),
                                sortLastName: (account.lastName || '').toLowerCase(),
                                state: { pendingApproval: true },
                                pendingSports: _this.selectedSports ? _this.selectedSports.map(function (s) { return s.code; }) : undefined,
                                orgRoles: ['MGA', 'SUB', _this.selectedType.code],
                                linkedOrgRoles: undefined
                            };
                            if (linkedOrgRole)
                                profile.linkedOrgRoles = [linkedOrgRole];
                            if (_this.selectedType.code == 'TRN')
                                profile.orgRoles.push('OTRN');
                            if (emptyOrg) {
                                profile.orgRoles.push('OADM');
                                profile.orgRoles.push('UADM');
                                delete profile.state.pendingApproval;
                            }
                            var email = account.usernames.find(function (un) { return un.type == 'email'; });
                            if (email)
                                profile.email = email.username;
                            var phone = account.usernames.find(function (un) { return un.type == 'mobile'; });
                            if (phone)
                                profile.tel = [phone.username];
                            return _this._userProfiles.createProfile(profile).single().toPromise().then(function () { return profile._id; });
                        }
                        else {
                            return Promise.resolve(_this._ctx.myProfiles[0]._id);
                        }
                    })
                        .then(function (profileId) {
                        if (createSchoolOrg) {
                            return createSchoolOrg();
                        }
                        else if (_this.selectedType.code == 'TRN' && _this.targetOrg) {
                            var req = new linkedOrgRoleRequests_service_1.LinkedOrgRoleRequest();
                            req.profileId = profileId;
                            req.requestedOrgId = _this.targetOrg._id;
                            req.requestedRoles = ['OTRN'];
                            return _this._linkedOrgRoleReqs.createRequest(req).single().toPromise();
                        }
                        else {
                            return Promise.resolve(null);
                        }
                    })
                        .then(function () {
                        var target = _this._userProfiles.createProfileRedirectUrl || '/';
                        if (target && target.indexOf('create-own-profile') > -1)
                            target = '/';
                        return _this._ctx.initialize(null, true).then(function () { return target; });
                    })
                        .then(function (target) {
                        console.log('Profile created, navigating to ' + target);
                        _this._router.navigateByUrl(target);
                    })
                        .catch(function (err) {
                        console.log(err);
                        _this.saving = false;
                        _this.error = 'An unexpected failure has occurred.';
                    });
                };
                OwnProfileCreator.prototype.onSelectedSportsChange = function (value) {
                    this.selectedSports = value;
                };
                OwnProfileCreator.prototype.onOrgChosen = function (value) {
                    this.targetOrg = value;
                };
                OwnProfileCreator.prototype.isAdminRole = function (value) {
                    return ['CCH', 'TRN', 'ADM'].indexOf(value) > -1;
                };
                OwnProfileCreator.prototype.onSelectExistingSchool = function (e) {
                    this.newOrgName = e.item.value.formattedName;
                    this.newOrgCity = e.item.value.city;
                    this.newOrgState = e.item.value.state;
                    this.newOrgKnownSchoolId = e.item.value.schoolId;
                    this.newOrgNCES = e.item.value.ncesCode;
                };
                __decorate([
                    core_1.ViewChild('typeChooser'), 
                    __metadata('design:type', profileTypeChooser_component_1.ProfileTypeChooser)
                ], OwnProfileCreator.prototype, "profileTypeChooser", void 0);
                OwnProfileCreator = __decorate([
                    core_1.Component({
                        selector: 'own-profile-creator',
                        template: "\n<div style=\"padding-top:10px; padding-bottom:50px; min-height:500px;\">\n    <div *ngIf=\"error\" class=\"alert alert-danger\">{{error}}</div>\n    <h2>{{_ctx.currentAccount?.firstName}} {{_ctx.currentAccount?.lastName}}</h2>\n    <h4 *ngIf=\"targetOrg\">Joining <em>{{targetOrg?.name}}</em></h4>\n    <div [style.display]=\"saving ? 'none' : 'block'\">\n        <h4>To continue with MAX, tell us which best describes you:</h4>\n        <div>\n            <profile-type-chooser #typeChooser (typeSelected)=\"onSelected($event)\"></profile-type-chooser>\n        </div>\n    </div>\n    <div *ngIf=\"selectedType && !saving\">\n        <div *ngIf=\"isAdminRole(selectedType.code)\">\n            <div *ngIf=\"!adminPath && !targetOrg\" class=\"profile-types-container\">\n                <div class=\"profile-type-choice\" (click)=\"selectAdminPath('start')\">\n                    I want to start using MAX for myself or my school.\n                </div>\n                <div class=\"profile-type-choice\" (click)=\"selectAdminPath('using')\">\n                    My school is already using MAX.\n                </div>\n                <div class=\"profile-type-choice\" (click)=\"selectAdminPath('unknown')\">\n                    I don't know.\n                </div>\n            </div>\n        </div>\n        \n        <div *ngIf=\"adminPath == 'unknown'\">\n            Give us a call and we'll help you out.  256-270-1163 or <a href=\"mailto:max@dragonflyathletics.com\">max@dragonflyathletics.com</a>\n        </div>  \n        \n        <div *ngIf=\"adminPath == 'start'\" style=\"max-width:300px; margin:auto;\">\n            <form #newOrgForm=\"ngForm\" (ngSubmit)=\"onSubmitNewOrg()\">\n                <div class=\"form-group\">\n                    <template #schoolTypeAheadTemplate let-model=\"item\">\n                        <h5>{{model.value.formattedName}}</h5>\n                        <h6>{{model.value.city}}, {{model.value.state}}</h6>\n                        <h6>NCES ID: <em>{{model.value.ncesCode}}</em></h6>\n                    </template>\n                    <label for=\"schoolName\">What's the name of your team or school?</label>\n                    <input [(ngModel)]=\"newOrgName\" \n                        [typeahead]=\"schoolSearchDataSource\" \n                        [typeaheadItemTemplate]=\"schoolTypeAheadTemplate\" \n                        [typeaheadWaitMs]=\"5\"\n                        [typeaheadMinLength]=\"1\"\n                        (typeaheadOnSelect)=\"onSelectExistingSchool($event)\"\n                        id=\"schoolName\"\n                        name=\"schoolName\"\n                        type=\"text\" \n                        class=\"form-control\"\n                        placeholder=\"School Name\" \n                        autofocus required autocomplete=\"off\" />\n                </div>\n                <div class=\"form-group\">\n                    <label for=\"schoolCity\">City</label>\n                    <input [(ngModel)]=\"newOrgCity\" id=\"schoolCity\" name=\"schoolCity\" type=\"text\" class=\"form-control\" placeholder=\"City\" required />\n                </div>\n                <div class=\"form-group\">\n                    <label for=\"schoolState\">State</label>\n                    <select [(ngModel)]=\"newOrgState\" name=\"schoolState\" id=\"schoolState\" required>\n                        <option value=\"AL\">Alabama</option>\n                        <option value=\"AK\">Alaska</option>\n                        <option value=\"AZ\">Arizona</option>\n                        <option value=\"AR\">Arkansas</option>\n                        <option value=\"CA\">California</option>\n                        <option value=\"CO\">Colorado</option>\n                        <option value=\"CT\">Connecticut</option>\n                        <option value=\"DE\">Delaware</option>\n                        <option value=\"DC\">District Of Columbia</option>\n                        <option value=\"FL\">Florida</option>\n                        <option value=\"GA\">Georgia</option>\n                        <option value=\"HI\">Hawaii</option>\n                        <option value=\"ID\">Idaho</option>\n                        <option value=\"IL\">Illinois</option>\n                        <option value=\"IN\">Indiana</option>\n                        <option value=\"IA\">Iowa</option>\n                        <option value=\"KS\">Kansas</option>\n                        <option value=\"KY\">Kentucky</option>\n                        <option value=\"LA\">Louisiana</option>\n                        <option value=\"ME\">Maine</option>\n                        <option value=\"MD\">Maryland</option>\n                        <option value=\"MA\">Massachusetts</option>\n                        <option value=\"MI\">Michigan</option>\n                        <option value=\"MN\">Minnesota</option>\n                        <option value=\"MS\">Mississippi</option>\n                        <option value=\"MO\">Missouri</option>\n                        <option value=\"MT\">Montana</option>\n                        <option value=\"NE\">Nebraska</option>\n                        <option value=\"NV\">Nevada</option>\n                        <option value=\"NH\">New Hampshire</option>\n                        <option value=\"NJ\">New Jersey</option>\n                        <option value=\"NM\">New Mexico</option>\n                        <option value=\"NY\">New York</option>\n                        <option value=\"NC\">North Carolina</option>\n                        <option value=\"ND\">North Dakota</option>\n                        <option value=\"OH\">Ohio</option>\n                        <option value=\"OK\">Oklahoma</option>\n                        <option value=\"OR\">Oregon</option>\n                        <option value=\"PA\">Pennsylvania</option>\n                        <option value=\"RI\">Rhode Island</option>\n                        <option value=\"SC\">South Carolina</option>\n                        <option value=\"SD\">South Dakota</option>\n                        <option value=\"TN\">Tennessee</option>\n                        <option value=\"TX\">Texas</option>\n                        <option value=\"UT\">Utah</option>\n                        <option value=\"VT\">Vermont</option>\n                        <option value=\"VA\">Virginia</option>\n                        <option value=\"WA\">Washington</option>\n                        <option value=\"WV\">West Virginia</option>\n                        <option value=\"WI\">Wisconsin</option>\n                        <option value=\"WY\">Wyoming</option>\n                    </select>\n                </div>\n                <button type=\"submit\" class=\"btn btn-default\" [disabled]=\"!newOrgForm.form.valid\">Continue</button>\n            </form>\n        </div>\n        \n        <div *ngIf=\"selectedType.code == 'ATH'\">\n            <h4>Choose your sports to continue as an <em>{{selectedType.name}}</em>:</h4>\n            <div style=\"margin-bottom:25px;\">\n                <default-sport-chooser (sportsSelected)=\"onSelectedSportsChange($event)\"></default-sport-chooser>\n            </div>\n        </div>\n        \n        <div style=\"max-width:500px; margin:auto; margin-top:10px;\" *ngIf=\"(!targetOrg || !_ctx.currentOrg) && (!isAdminRole(selectedType.code) || adminPath == 'using')\">\n            <org-context-chooser (orgChosen)=\"onOrgChosen($event)\"></org-context-chooser>\n        </div>\n        \n         <div *ngIf=\"targetOrg\" style=\"margin-top:20px;\">\n         <h4>Continue as {{selectedType.sentenceSubject}} in {{targetOrg.name}}</h4>\n            <button class=\"btn btn-primary\" (click)=\"confirmSelection()\" style=\"margin-right:20px;\">{{_userProfiles.createProfileRedirectUrl && _userProfiles.createProfileRedirectUrl.indexOf('packetList') > -1 ? 'Do Forms &gt;&gt;' : 'Next'}}</button>\n            <button class=\"btn btn-danger\" (click)=\"reset()\">Reset</button>\n        </div>\n    </div>\n    <div *ngIf=\"saving\">\n        <img src=\"/maxweb/app/media/ajax-loader.gif\" />\n        Saving...\n    </div>\n</div>\n"
                    }), 
                    __metadata('design:paramtypes', [user_profiles_service_1.UserProfiles, maxAppContext_service_1.MaxAppContext, router_1.Router, router_1.ActivatedRoute, organizations_service_1.Organizations, linkedOrgRoleRequests_service_1.LinkedOrgRoleRequests, http_1.Http])
                ], OwnProfileCreator);
                return OwnProfileCreator;
            }());
            exports_1("OwnProfileCreator", OwnProfileCreator);
        }
    }
});
//# sourceMappingURL=ownProfileCreator.component.js.map