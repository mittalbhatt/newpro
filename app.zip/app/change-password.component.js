System.register(["@angular/core", "angular2-modal/plugins/bootstrap", "./user_profiles.service", "angular2-modal", "./userAccount.service", "./maxAppContext.service", "./helper.service"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __extends = (this && this.__extends) || function (d, b) {
        for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, bootstrap_1, user_profiles_service_1, angular2_modal_1, userAccount_service_1, maxAppContext_service_1, helper_service_1;
    var ChangePasswordData, ChangePasswordModel, ChangePasswordModal;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (bootstrap_1_1) {
                bootstrap_1 = bootstrap_1_1;
            },
            function (user_profiles_service_1_1) {
                user_profiles_service_1 = user_profiles_service_1_1;
            },
            function (angular2_modal_1_1) {
                angular2_modal_1 = angular2_modal_1_1;
            },
            function (userAccount_service_1_1) {
                userAccount_service_1 = userAccount_service_1_1;
            },
            function (maxAppContext_service_1_1) {
                maxAppContext_service_1 = maxAppContext_service_1_1;
            },
            function (helper_service_1_1) {
                helper_service_1 = helper_service_1_1;
            }],
        execute: function() {
            ChangePasswordData = (function (_super) {
                __extends(ChangePasswordData, _super);
                function ChangePasswordData() {
                    _super.apply(this, arguments);
                }
                return ChangePasswordData;
            }(bootstrap_1.BSModalContext));
            exports_1("ChangePasswordData", ChangePasswordData);
            ChangePasswordModel = (function () {
                function ChangePasswordModel() {
                }
                return ChangePasswordModel;
            }());
            exports_1("ChangePasswordModel", ChangePasswordModel);
            ChangePasswordModal = (function () {
                function ChangePasswordModal(dialog, _profilesSvc, _acctSvc, _max, _helper) {
                    this.dialog = dialog;
                    this._profilesSvc = _profilesSvc;
                    this._acctSvc = _acctSvc;
                    this._max = _max;
                    this._helper = _helper;
                    this.submitting = true;
                    this.model = new ChangePasswordModel();
                }
                ChangePasswordModal.prototype.ngOnInit = function () {
                    console.log(this._max);
                };
                ChangePasswordModal.prototype.closeModel = function () {
                    this.dialog.close(false);
                };
                ChangePasswordModal.prototype.changePassword = function () {
                    var _this = this;
                    this.errorMessage = "";
                    this.submitting = true;
                    if (this.model.new_password === undefined || this.model.confirm_password === undefined) {
                        this.errorMessage = "Please enter password & confirm password.";
                        this.submitting = false;
                        return;
                    }
                    if (this.model.new_password !== this.model.confirm_password) {
                        this.errorMessage = "Please enter password and confirm password are equal.";
                        this.submitting = false;
                        return;
                    }
                    var password_valid = this._helper.validatePassword(this.model.new_password);
                    if (!password_valid) {
                        this.errorMessage = "Your password must be at least 8 characters long and must contain at least 3 of the following:";
                        this.errorMessage += "<ul>";
                        this.errorMessage += "<li> a symbol (like: !@#$%^&*) </li>";
                        this.errorMessage += "<li> a number. </li>";
                        this.errorMessage += "<li> a lower case letter. </li>";
                        this.errorMessage += "<li> an upper case letter. </li>";
                        this.errorMessage += "</ul>";
                        this.submitting = false;
                        return;
                    }
                    // if(this.submitting == false){ 
                    //     this.errorMessage = "We encountered an unexpected error.";
                    //     return;
                    // }
                    if (this.submitting) {
                        this.successMessage = "";
                        this._acctSvc.changePassword(this._max.currentAccount._id, this.model.new_password).then(function () {
                            _this.successMessage = "Your password has been changed successfully.";
                        }).catch(function (err) {
                            _this.errorMessage = "We encountered an unexpected error.";
                            console.log(err);
                        });
                    }
                    /*
                    POST to /training/api/accounts/:userAccountId/passwordUpdates
                    JSON Body:
                    {password: .... }
                    */
                };
                ChangePasswordModal = __decorate([
                    core_1.Component({
                        selector: 'change-password-modal-content',
                        template: "\n    <div class=\"modal-content\">\n        <form (ngSubmit)=\"changePassword()\">\n        <div class=\"modal-header\">\n        <h4 class=\"modal-title pull-left\">Change Password</h4>\n        <button type=\"button\" class=\"close pull-right\" (click)=\"closeModel()\" aria-label=\"Close\">\n            <span aria-hidden=\"true\">&times;</span>\n        </button>\n        </div>\n        <div class=\"modal-body\">\n            <div *ngIf=\"errorMessage\" class=\"alert alert-danger\"><span [innerHTML]=\"errorMessage\" class=\"error-msg\"></span></div>\n            <div *ngIf=\"successMessage\" class=\"alert alert-success\"><span [innerHTML]=\"successMessage\" class=\"error-msg\"></span></div>\n            <span *ngIf=\"!successMessage\">\n            <div class=\"form-group\">\n                <label for=\"level\">Password</label>\n                <input [(ngModel)]=\"model.new_password\" type=\"password\" class=\"form-control\" name=\"new_password\" id=\"new_password\" placeholder=\"New Password\" />\n            </div>\n            <div class=\"form-group\">\n                <label for=\"level\">Confirm Password</label>\n                <input [(ngModel)]=\"model.confirm_password\" type=\"password\" class=\"form-control\" name=\"confirm_password\" id=\"confirm_password\" placeholder=\"Confirm Password\" />\n            </div>\n            </span>\n        </div>\n        <div class=\"modal-footer\">\n            <button type=\"submit\" class=\"btn btn-primary\" *ngIf=\"!successMessage\">Change Password</button>\n            <button type=\"button\" class=\"btn btn-danger\" (click)=\"closeModel()\" *ngIf=\"!successMessage\">Cancel</button>\n            <button type=\"button\" class=\"btn btn-default\" (click)=\"closeModel()\" *ngIf=\"successMessage\">Ok</button>\n        </div>\n        </form>\n    </div>\n"
                    }), 
                    __metadata('design:paramtypes', [angular2_modal_1.DialogRef, user_profiles_service_1.UserProfiles, userAccount_service_1.UserAccountService, maxAppContext_service_1.MaxAppContext, helper_service_1.Helper])
                ], ChangePasswordModal);
                return ChangePasswordModal;
            }());
            exports_1("ChangePasswordModal", ChangePasswordModal);
        }
    }
});
//# sourceMappingURL=change-password.component.js.map