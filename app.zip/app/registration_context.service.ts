import {DocumentationActivity} from "./documentation_activity";
import {Credentials} from "./credentials";
import {Injectable, Inject, Optional} from "@angular/core";

declare var store:any;

@Injectable()
export class RegistrationContext {

    private static DOC_ACT_KEY = 'df_docAct';
    private static CREDENTIALS = 'df_creds';

    persistent:boolean;

    constructor(){
        let persistentCreds = store(RegistrationContext.CREDENTIALS);
        this.persistent = !!persistentCreds;
        if (this.persistent)
            this.creds = persistentCreds;
    }

    get docAct():DocumentationActivity
    {
        return store.session(RegistrationContext.DOC_ACT_KEY);
    }

    set docAct(value)
    {
        store.session(RegistrationContext.DOC_ACT_KEY, value);
    }
    
    get creds()
    {
        return store.session(RegistrationContext.CREDENTIALS);
    }
    
    set creds(value:Credentials)
    {
        if (!value)
        {
            store.session.remove(RegistrationContext.CREDENTIALS);
            store.remove(RegistrationContext.CREDENTIALS);
        }
        else
        {
            store.session(RegistrationContext.CREDENTIALS, value);
            if (this.persistent)
                store(RegistrationContext.CREDENTIALS, value);
        }
    }
}
