import {Component, OnInit, ChangeDetectionStrategy} from "@angular/core";
import {MaxAppContext} from "./maxAppContext.service";
import {UserProfiles, UserProfile} from "./user_profiles.service";
import {ActivatedRoute, Router} from "@angular/router";
import {Activities} from "./activities.service";
import {Assignments, Assignment, Packet} from "./assignments.service";
import {DocumentationActivity} from "./documentation_activity";
import {Documents} from "./document_factory.service";
import {DocumentationDocument, DocumentationDocumentData} from "./documentation_document";
import {Modal} from "angular2-modal";
import {Helper} from "./helper.service";

export class TypeOfPacketList {
    org: string;
    type: string;
    packet: Packet;
    recommend_label: number;
    other_label: number;

    constructor(org, type, packet, recommend_label = 0, other_label = 0) {
        this.org = org;
        this.type = type;
        this.packet = packet;
        this.recommend_label = recommend_label;
        this.other_label = other_label;
    }
}


@Component({
    selector: 'max-forms-packet-list',
    templateUrl: '/maxweb/app/app/packetList.component.html',
    // changeDetection: ChangeDetectionStrategy.OnPush
})
export class PacketList implements OnInit {
    docActs: { docAct: DocumentationActivity, assignment: Assignment }[];
    medicalDocument: DocumentationDocument;
    targetProfile: UserProfile;
    medicalDocumentActivityId: string;
    packetList: any = [];
    // packetList:any[][] = [];
    groupByOrgPacketList: any = [];
    profileId: string = "";
    isLoading: boolean = false;
    filedSection = [];
    amrInfoFields = [];
    requiredFields: any;
    allFieldsArr: any;
    isBasicFormUnfilled: boolean = false;
    isValidRelative: boolean = false;
    greenBadge: boolean = false;

    constructor(
        private _ctx: MaxAppContext,
        private _userProfiles: UserProfiles,
        private _activities: Activities,
        private _assignments: Assignments,
        private _documents: Documents,
        private _route: ActivatedRoute,
        private _router: Router,
        private _modal: Modal,
        private _helper: Helper) {
        this.isLoading = true;
        this.profileId = this._route.snapshot.params['profileId'];
    }

    compareTwoArr(arr1: Array<string>, arr2: Array<string>) {
        let isCompare = false;
        _.each(arr1, (t) => {
            let is_recommended = _.contains(arr2, t);
            if (is_recommended) {
                isCompare = true;
            }
        });

        return isCompare;
    }

    ngOnInit() {
        if (!this.profileId)
            throw new Error('profileId is required for PacketList.');

        this._userProfiles.getProfile(this.profileId).single().toPromise()
            .then(targetProfile => {
                this.targetProfile = targetProfile;
                //console.log( this.targetProfile);
                // For get amr object for count 
                if (this.targetProfile.$amr != undefined && this.targetProfile.$amr.info != undefined) {
                    if(!_.has( this.targetProfile.$amr.info, "email")) {
                      if(_.has( this.targetProfile, "email")) {
                         this.targetProfile.$amr.info['email']=this.targetProfile.email;
                      }
                     }
                    if(!_.has( this.targetProfile.$amr.info, "firstName")) {
                      if(_.has( this.targetProfile, "firstName")) {
                         this.targetProfile.$amr.info['firstName']=this.targetProfile.firstName;
                      }
                     }
                     if(!_.has( this.targetProfile.$amr.info, "lastName")) {
                      if(_.has( this.targetProfile, "lastName")) {
                         this.targetProfile.$amr.info['lastName']=this.targetProfile.lastName;
                      }
                     }
                      if(!_.has( this.targetProfile.$amr.info, "tel")) {
                      if(_.has( this.targetProfile, "tel")) {
                         this.targetProfile.$amr.info['tel']=this.targetProfile.tel;
                      }
                     }
                    this.amrInfoFields = this.targetProfile.$amr.info;
                }
                
                if (this.amrInfoFields) {
                    // Get All fields object from helper
                    this.filedSection = this._helper.basicMedicalFiledSection;
                    this.isBasicFormUnfilled = this.getRequiredUnfilled(this.filedSection);
                } else {
                    this.isBasicFormUnfilled = true;
                }
                this.isValidRelative = this.checkRelativeIsValid(this.targetProfile, this._ctx.currentProfile);

                // if athelete(ATH) then check basic form and relative also otherwise check only basic form
                if ((_.contains(this.targetProfile.orgRoles, 'ATH') === true && this.isBasicFormUnfilled == false && this.isValidRelative) || (_.contains(this.targetProfile.orgRoles, 'ATH') !== true && this.isBasicFormUnfilled == false)) {
                    this.greenBadge = true;
                }

                // get Packets Data
                this.getPacketList();

                if (targetProfile.orgRoles.indexOf('TRN') > -1) {
                    this._router.navigate(['/main']);
                    return;
                }

                let targetProfileOrg = this._ctx.availableOrganizations.find(o => o._id == targetProfile.org);

                let medicalDocActivityId = (targetProfileOrg.defaultDocuments.find(d => d.form == 'medical' && d.context == 'userProfile') || { activityId: undefined }).activityId;
                this.medicalDocumentActivityId = medicalDocActivityId;

                let activitiesPromise = this._activities.getDocumentationActivities(targetProfile.org).single().toPromise();
                let assignmentsPromise = this._assignments.getMine();

                // All that matters is the first medicalRecords entry.  See documentFactoryHandler.js
                let medRecordStableDocId = (targetProfile.medicalRecords || [{ medicalRecordStableDocumentId: null }])[0].medicalRecordStableDocumentId;
                let medicalDocumentPromise = medRecordStableDocId ? this._documents.getDocumentWithStableId(medRecordStableDocId).single().toPromise() : Promise.resolve(null);
                Promise.all<any>([activitiesPromise, assignmentsPromise, medicalDocumentPromise])
                    .then(([activities, assignments, medicalDocument]: [DocumentationActivity[], Assignment[], DocumentationDocument]) => {
                        if (medicalDocument && medicalDocument.originalDescription._id == medicalDocActivityId)
                            this.medicalDocument = medicalDocument;

                        this.docActs = activities.map(act => {
                            return {
                                docAct: act,
                                assignment: assignments.find(a =>
                                    !!a.assignees.find(aa => aa.userProfileId == targetProfile._id)
                                    && !!a.activities.find(aa => aa._id == act._id))
                            }
                        });
                    });
            })
    }

    getPacketList() {
        this._assignments.getAllPackets().subscribe((data: any) => {
            var pack = _.groupBy(data, (o: any) => {
                return o.activities[0].documentationEventDescription.coordinatorName;
            });

            let i = 0;
            let recommend_label = 1;
            let other_label = 1;
            _.each(pack, (val: any, key: string) => {
                recommend_label = 1;
                other_label = 1;
                _.each(val, (o: Packet) => {
                    if (o.assignees.length > 0) {
                        _.each(this._ctx.myProfiles, (p) => {
                            if (o.assignees[0].orgId == p.org && o.assignees[0].orgId == this.targetProfile.org) {
                                let tags = _.pluck(o.assignees, 'tag');
                                let tag = _.map(tags, (t) => {
                                    if (t !== undefined) {
                                        let res = t.split(":");
                                        return res[0];
                                    }
                                });

                                let pTag = [];
                                if (p.tags !== undefined && p.tags !== null) {
                                    pTag = _.map(p.tags, (pt) => {
                                        if (pt !== undefined) {
                                            return pt.replace(/[\,\!]/g, "");
                                        }
                                    });
                                }
                                let pStag = [];
                                if (p.pendingSports !== undefined && p.pendingSports !== null) {
                                    pStag = p.pendingSports;
                                }
                                let pTags = _.union(pTag, pStag);

                                let is_recommended = this.compareTwoArr(tag, pTags);
                                if (is_recommended) {
                                    this.packetList.push(new TypeOfPacketList(key, "recommended", o, recommend_label, 0));
                                    recommend_label = 0;
                                } else {
                                    this.packetList.push(new TypeOfPacketList(key, "other", o, 0, other_label));
                                    other_label = 0;
                                }
                            }
                        });
                    }
                    i++;
                });
            });

            var uniquePack = _.uniq(this.packetList, (p: TypeOfPacketList) => {
                return p.packet._id;
            });

            this.packetList = uniquePack;

            // Packelist 
            this.groupByOrgPacketList = _.groupBy(this.packetList, (o: any) => {

                let assigneesRoles = _.chain(o.packet.assignees)
                    .pluck('role')
                    .flatten()
                    .value();
                _.each(this.targetProfile.orgRoles, (t) => {
                    let roleAvailable = _.contains(assigneesRoles, t);
                    if (roleAvailable) {
                        o.showPacketForCurrentAssignee = true;
                    }
                });

                return o.org;
            });

            this.isLoading = false;

        });
    }

    onClickDocAct(docAct: { docAct: DocumentationActivity, assignment: Assignment }) {
        if (!(this.medicalDocument && this.medicalDocument.completedDate))
            (<any>this._modal.alert()).message('You must complete Basic Medical Information first.').open();
        else
            this._router.navigate(['athDocDashboard', docAct.docAct._id, this.targetProfile._id], { relativeTo: this._route.parent });
    }

    onClickMedDoc() {
        this._router.navigate(['/main/basicmedicalForm', this.targetProfile._id, this.medicalDocumentActivityId], { relativeTo: this._route.parent });
    }


    onClickMePacket(id, pack: any) {
        // When athelete(ATH) then check basic form and added relative also
        if (_.contains(this.targetProfile.orgRoles, 'ATH') == true && (this.isBasicFormUnfilled === true || this.isValidRelative === false)) {
            (<any>this._modal.alert())
                .message('You must complete Basic Medical Information first.')
                .okBtn("OK")
                .open()
                .then((dialog: any) => {
                    return dialog.result;
                }).then(result => {
                    if (result === true) {
                        this._router.navigate(['/main/basicmedicalForm', this.targetProfile._id, this.medicalDocumentActivityId], { relativeTo: this._route.parent });
                    }
                });
        } else {
            if (this.checkPacketIfSubmit(pack)) {
                (<any>this._modal.alert()).message('The forms have already been submitted.').open();
            } else {
                this._router.navigate(['athDocDashboard', id, this.targetProfile._id], { relativeTo: this._route.parent });
            }
        }
    }

    checkPacketIfSubmit(pack: any): boolean {
        let isSubmited: boolean = false;
        if (pack.packet.$responseHistory !== undefined) {
            _.find(pack.packet.$responseHistory, (o: any) => {
                if (o.userProfileId === this.profileId) {
                    if (o.responseHistory[0] !== undefined && o.responseHistory[0].data.submitted === true) {
                        isSubmited = true;
                    }
                }
            });
        }

        return isSubmited;
    }

    // Check relative is valid If firstname or lastName and email or phone value available
    checkRelativeIsValid(targetProfile, currentProfile) {

        if (targetProfile.relations != undefined && targetProfile.relations.length > 0) {
            let allRelationObj = [];
            _.each(targetProfile.relations, function (relationObj: any, key) {
                let isvalidObj = false;
                if (relationObj.firstName != '' || relationObj.lastName != '') {
                    if (relationObj.email != '' || (relationObj.tel != undefined && relationObj.tel.length > 0 && relationObj.tel[0] != '')) {
                        isvalidObj = true;
                    }
                }
                allRelationObj.push(isvalidObj);
            });
            let objectIsValid = true;

            if (_.contains(allRelationObj, false) == true) {
                objectIsValid = false;
            }                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                   
            return objectIsValid;
        } else if(targetProfile.relations== undefined  && _.contains(this.targetProfile.orgRoles, 'ATH')==true){
            return false;
        }else if(_.has(targetProfile,'relations') &&  _.contains(this.targetProfile.orgRoles, 'ATH')==true){
            if(targetProfile.relations.length==0){
                return false;
            }
        }
         else {
            return true;
        }
    }

    // Check Unfilled value data with get count 
    getRequiredUnfilled(sections) {
        //console.log(this.amrInfoFields);
        var requiredUnfilled = _.chain(sections)
            .pluck('fields')
            .flatten()
            .filter(f => {
                return (f.required || (f.requireIfAll && _.every(f.requireIfAll, (ff: DocumentationDocumentData) => (this.lookupValue(ff.ident) === ff.value) || (ff.value === 'Female' && this.lookupValue(ff.ident) === 'Female') || ((ff.value == false || ff.value == 0) && this.lookupValue(ff.ident) === undefined)))) && (this.valueIsNullUndefinedOrEmpty(f.ident) || this.lookupTextValue(f.ident) == "") && (this.lookupValue(f.ident) !== false && this.lookupValue(f.ident) !== 0);
            })
            .pluck('ident')
            .value();

        var explanationsRequiredUnfulfilled = _.chain(sections)
            .pluck('fields')
            .flatten()
            .filter(f => {
                return f.explanationRequired && (this.lookupValue(f.ident) == true || this.lookupValue(f.ident) == 1) && this.valueIsNullUndefinedOrEmpty(f.ident + '_explanation')
            })
            .pluck('ident')
            .map(i => i + '_explanation')
            .value();

        var showIfAllRequiredUnfulfilled = _.chain(sections)
            .pluck('fields')
            .flatten()
            .filter(f => {
                return f.showIfAll && _.every(f.showIfAll,
                    (ff: any) => (this.lookupValue(ff.ident) != false && this.lookupValue(ff.ident) != 0) && ff.mainIdent && (this.arrayLength(ff.mainIdent) == undefined));
            })
            .pluck('showIfAll')
            .map(i => i[0].ident)
            .value();

        showIfAllRequiredUnfulfilled = _.uniq(showIfAllRequiredUnfulfilled);
        requiredUnfilled = requiredUnfilled.concat(explanationsRequiredUnfulfilled);
        requiredUnfilled = requiredUnfilled.concat(showIfAllRequiredUnfulfilled);
        //console.log(requiredUnfilled);
        if (requiredUnfilled.length > 0) {
            return true;
        } else {
            return false;
        }
    }

    arrayLength(requiredField: any) {
        if (!this.amrInfoFields)
            return undefined;

        let ident = requiredField.replace('info.', '');
        let value = this.amrInfoFields[ident];

        return (value != undefined && value.length > 0) ? value : undefined;
    }

    lookupValue(requiredField: any) {
        if (!this.amrInfoFields)
            return undefined;

        let ident = requiredField.replace('info.', '');
        let value = this.amrInfoFields[ident];

        return (value || value == 0) ? value : undefined;
    }

    lookupTextValue(identVal: string) {
        let ident = identVal.replace('info.', '');
        let ret = this.lookupValue(ident);
        if (!ret)
            ret = "";
        return ret;
    }

    valueIsNullUndefinedOrEmpty(identVal) {
        let ident = identVal.replace('info.', '');
        let val = this.lookupValue(ident);
        if (val && val.trim)
            val = val.trim();
        return !val && (val !== false);
    }

}