import {Component, Input, HostListener} from "@angular/core";
import { DatePipe } from "@angular/common";
import { UserInjuryDetails } from "./user_profiles.service";

import { Modal } from 'angular2-modal/plugins/bootstrap';

@Component({
    selector: 'teams-players-injury',
    templateUrl: '/maxweb/app/app/teams-player-injury.component.html'
})
export class TeamsPlayerInjuryComponent {
    
    playerInjuryAllData:UserInjuryDetails[]=[];
    currentInjuryDetail:UserInjuryDetails;
    innerWidth: any = (document.body.clientWidth);
    constructor(
        private _model:Modal,
        public datepipe: DatePipe
    ){
        let filterPipe = new Date();
    }

    @Input('playerInjuryData') 
    set playerInjuryData(value:any){
        this.playerInjuryAllData=[];
        if(value.length >= 0){
            value.forEach((d)=>{
                this.playerInjuryAllData.push(new UserInjuryDetails(d));
            });
    
            if(this.playerInjuryAllData.length >=1 ){
                this.currentInjuryDetail = this.playerInjuryAllData[0];
            }
        }
    }

    showInjuryDetails(data:UserInjuryDetails){
        this.currentInjuryDetail = data;
        this.innerWidth = (document.body.clientWidth);

        let injury_date = "None";
        if(this.currentInjuryDetail.injuryName !==null){
            injury_date = this.datepipe.transform(this.currentInjuryDetail.doi, 'MM/dd/yyyy');
        }

        let injurydetails=`
                <p><strong>Injury </strong> ${(this.currentInjuryDetail.injuryName !==null) ? this.currentInjuryDetail.injuryName: 'None'}</p>
                <p><strong>Date of Injury </strong> ${injury_date}</p>
                <p><strong>Body Part </strong> ${(this.currentInjuryDetail.bodyPart !==null) ? this.currentInjuryDetail.bodyPart: 'None'}</p>
                <p><strong>Initial Treatmen </strong> ${(this.currentInjuryDetail.treatments !==null) ? this.currentInjuryDetail.treatments: 'None'}</p>
                <br>
                <p class="injury-details"><strong>Injury Details </strong> ${(this.currentInjuryDetail.injuryDetails !==null) ? this.currentInjuryDetail.injuryDetails: 'None'}</p>
                <p><strong>Practice/Play Instr</strong> ${(this.currentInjuryDetail.particePlayInstructions !==null) ? this.currentInjuryDetail.particePlayInstructions: 'None'}</p>
            `;
        
        if(Number(this.innerWidth) <= 976){
            this._model.alert().title("Previous Injuries & Illnesses")
            .body(injurydetails)
            .bodyClass("col-xs-12 col-sm-12 col-md-7 col-lg-8 text-left injury")
            .showClose(true)
            .okBtn("Close")
            .okBtnClass("hidden-xs hidden-sm")
            .open().then(result => { result.result.then(() => {}, () => {}); });
        }
    }

    @HostListener('window:resize', ['$event'])
    onResize(event) {
        this.innerWidth = (document.body.clientWidth);
    }
}
