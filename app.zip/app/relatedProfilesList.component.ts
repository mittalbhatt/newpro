import {Component, Input, Output, EventEmitter, ViewChild} from "@angular/core";
import {ActivatedRoute, Router} from "@angular/router";
import {UserProfiles, UserProfile} from "./user_profiles.service";
import {MaxAppContext} from "./maxAppContext.service";
import {RelatedProfile} from "./relatedProfile.component";

@Component({
    selector:'related-profiles-list',
    template:
        `
<div>
    <div class="list-group">
        <div *ngIf="isloading">
            <img src="/maxweb/app/media/ajax-loader.gif" />
        </div>
        <related-profile *ngFor="let profile of relatedProfiles" [userProfile]="profile"></related-profile>
    </div>
    <div class="list-group">
        <button type="button" class="list-group-item" (click)="onAddNew()"><span style="float:left; color:green;" class="glyphicon glyphicon-plus"></span>&nbsp;&nbsp;&nbsp;Add a Child in {{_ctx.currentOrg?.name || '...loading school name...'}}</button>    
    </div>
</div>
`
})
export class RelatedProfilesList
{
    @Input() relationRoles:string[];

    
    private _profileId:string;
    public _user_img:any=[];
    isloading:boolean=false;
    errorMessage:string;

    @Input() set profileId(value:string)
    {
        this.isloading = true;
        if (this._profileId == value)
            return;

        this._profileId = value;

        if (!value)
        {
            this.relatedProfiles = [];
            return;
        }

        this._profilesSvc.getAllProfiles()
            .then(profiles =>
            {    
                this.relatedProfiles = profiles.filter(p => p.org == this._ctx.orgId &&
                p.relations && p.relations.find(r => r.userProfileId == this._profileId && (r.roles || []).filter(ro => this.relationRoles.indexOf(ro) != -1)))
                    .map(p => new UserProfile(p));
                this.isloading = false;    
  
            })
            .catch(e =>
            {
                console.log(e);
                this.errorMessage = 'We encountered an unexpected error. Refresh the page and try again.';
                this.isloading = false;
                throw e;
            });;
    }

    @Output() itemClicked = new EventEmitter<UserProfile>();
    @Output() itemEditClicked = new EventEmitter<UserProfile>();
    @Output() itemDeleteClicked = new EventEmitter<UserProfile>();

    relatedProfiles:UserProfile[];

    constructor(private _route:ActivatedRoute, private _router:Router, private _profilesSvc:UserProfiles, private _ctx:MaxAppContext)
    {

    }

    onAddNew()
    {
        this._router.navigate(['/max-forms/chooseFormsProfile', this._profileId, 'create'], {relativeTo:this._route.parent});
    }

    onRowClick(profile:UserProfile)
    {
        this.itemClicked.emit(profile);
    }

    onEditClick(profile:UserProfile, event:MouseEvent)
    {
        event.stopPropagation();
        this.itemEditClicked.emit(profile);
    }

    onDeleteClick(profile:UserProfile, event:MouseEvent)
    {
        event.stopPropagation();
        this.itemDeleteClicked.emit(profile);
    }

    clear(profile:UserProfile)
    {
        let idx = this.relatedProfiles.indexOf(profile);
        this.relatedProfiles.splice(idx, 1);
    }
}