System.register(["@angular/core", "@angular/common", "@angular/router", "./organizations.service", "./maxAppContext.service", "./user_profiles.service", "./shared.service", "@angular/platform-browser", 'angular2-modal/plugins/bootstrap', './teams-form.component', 'ng2-bootstrap/ng2-bootstrap'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var __param = (this && this.__param) || function (paramIndex, decorator) {
        return function (target, key) { decorator(target, key, paramIndex); }
    };
    var core_1, common_1, router_1, organizations_service_1, maxAppContext_service_1, user_profiles_service_1, shared_service_1, platform_browser_1, bootstrap_1, teams_form_component_1, ng2_bootstrap_1, core_2;
    var filterPipe, filterParameters, TeamsPlayersComponent;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
                core_2 = core_1_1;
            },
            function (common_1_1) {
                common_1 = common_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (organizations_service_1_1) {
                organizations_service_1 = organizations_service_1_1;
            },
            function (maxAppContext_service_1_1) {
                maxAppContext_service_1 = maxAppContext_service_1_1;
            },
            function (user_profiles_service_1_1) {
                user_profiles_service_1 = user_profiles_service_1_1;
            },
            function (shared_service_1_1) {
                shared_service_1 = shared_service_1_1;
            },
            function (platform_browser_1_1) {
                platform_browser_1 = platform_browser_1_1;
            },
            function (bootstrap_1_1) {
                bootstrap_1 = bootstrap_1_1;
            },
            function (teams_form_component_1_1) {
                teams_form_component_1 = teams_form_component_1_1;
            },
            function (ng2_bootstrap_1_1) {
                ng2_bootstrap_1 = ng2_bootstrap_1_1;
            }],
        execute: function() {
            filterPipe = (function () {
                function filterPipe() {
                }
                filterPipe.prototype.transform = function (value, args) {
                    if (!value) {
                        return value;
                    }
                    return value.filter(function (o) { return _.contains(o.orgRoles, 'CCH') == false; });
                    //console.log(sessionStorage['userProfileData']);
                };
                filterPipe = __decorate([
                    core_2.Pipe({ name: 'filterdata' }), 
                    __metadata('design:paramtypes', [])
                ], filterPipe);
                return filterPipe;
            }());
            exports_1("filterPipe", filterPipe);
            filterParameters = (function () {
                function filterParameters() {
                    this.orgRoles = "ATH";
                    this.orgViews = "Cards";
                }
                return filterParameters;
            }());
            exports_1("filterParameters", filterParameters);
            TeamsPlayersComponent = (function () {
                function TeamsPlayersComponent(ctx, _route, _router, _userProfilesSvc, _organizations, _shared, element, document, _model, location) {
                    var _this = this;
                    this.ctx = ctx;
                    this._route = _route;
                    this._router = _router;
                    this._userProfilesSvc = _userProfilesSvc;
                    this._organizations = _organizations;
                    this._shared = _shared;
                    this.element = element;
                    this.document = document;
                    this._model = _model;
                    this.location = location;
                    this.skip = 0;
                    this.take = 50;
                    this.userProfileData = [];
                    this.loading = true;
                    this.isAutoloading = false;
                    this.currentOrgTeam = { org: "Everyone", team: '' };
                    this.isDataLoaded = true;
                    this.sortingParameter = "sortLastName,sortFirstName";
                    this.filterParameter = new filterParameters();
                    this.sortingOrderParameter = "";
                    this.noMoreRecords = false;
                    this.isCurrentTab = "teamtab";
                    this.bodyScrollTop = 0;
                    this.eligibilitychecktrue = false;
                    this.eligibilitycheck = false;
                    this._element = this.element.nativeElement;
                    this.selectOrgTeamSubscribe = this._shared.selectedOrgTeam.subscribe(function (data) {
                        _this.currentOrgTeam = data;
                    });
                }
                TeamsPlayersComponent.prototype.ngOnDestroy = function () {
                    document.body.className = "";
                    this.selectOrgTeamSubscribe.unsubscribe();
                };
                TeamsPlayersComponent.prototype.ngOnInit = function () {
                    // this.getPrevRoute.unsubscribe();
                    // this.getPrevRoute = this._router.events
                    //     .filter((e:any) => e.constructor.name === 'RoutesRecognized')
                    //     .pairwise()
                    //     .subscribe((e: any[]) => {
                    //         let url = e[0].urlAfterRedirects;
                    //         var urlSplitted = url.split("/");
                    var _this = this;
                    //         if(urlSplitted.length > 0){
                    //             if(urlSplitted[1] !== "player" && urlSplitted[2] !== "player"){
                    //                 console.log("Not previous player details route");
                    //             }else{
                    //                 console.log("previous player details route");
                    //                 sessionStorage['numberOfRecords'] = "";
                    //                 sessionStorage['bodyScrollTop'] = 0;
                    //                 this.getPrevRoute.unsubscribe();
                    //             }
                    //         }
                    //     });
                    // this.getPrevRoute.unsubscribe();
                    document.body.className = "team-fix-page";
                    this._route.params.subscribe(function (params) {
                        console.log('here');
                        _this.filterParameter.orgId = params['orgId'];
                        _this.selectedOrgDetails = _this.ctx.availableOrganizations.find(function (o) {
                            return o._id === _this.filterParameter.orgId;
                        });
                        _this.filterParameter.teamId = params['teamId'];
                        _this.sortingOrderParameter = "";
                        if (sessionStorage['sortorderview'] !== 'null') {
                            _this.sortingOrderParameter = sessionStorage['sortorderview'];
                        }
                        else {
                            _this.sortingOrderParameter = "";
                        }
                        if (sessionStorage['filterview'] !== 'null') {
                            if (sessionStorage['filterview'] == 'All') {
                                _this.filterParameter.injured = null;
                            }
                            else {
                                console.log(sessionStorage['filterview']);
                                _this.filterParameter.injured = (sessionStorage['filterview'] == 'true') ? true : false;
                            }
                        }
                        else {
                            _this.filterParameter.injured = null;
                        }
                        _this.viewType = 'Cards';
                        if (sessionStorage['sortview'] !== 'null') {
                            _this.sortingParameter = sessionStorage['sortview'];
                        }
                        else {
                            _this.sortingParameter = "sortLastName,sortFirstName";
                        }
                        // this.filterParameter.orgRoles = "ATH";
                        //use for role filter tab set
                        if (sessionStorage['roleviewlist'] !== 'null') {
                            if (sessionStorage['roleviewlist'] == 'All') {
                                _this.filterParameter.orgRoles = null;
                            }
                            else {
                                _this.filterParameter.orgRoles = sessionStorage['roleviewlist'];
                            }
                        }
                        else {
                            _this.filterParameter.orgRoles = "ATH";
                        }
                        var isAdmin = function (roles) {
                            // console.log(roles);
                            // return roles;
                            if (roles == true) {
                                return _this.eligibilitychecktrue = true;
                            }
                            else {
                            }
                        };
                        var istags = function (roles) {
                            if (',' + _this.filterParameter.teamId + ',' == roles) {
                                console.log(',' + _this.filterParameter.teamId + '==' + roles);
                                return true;
                            }
                            return false;
                        };
                        var checkorgroleadmin = _.intersection(_this.ctx.currentProfile.orgRoles, ['ADM', 'OTRN', 'OADM', 'UADM']).length;
                        var checkorgroletrn = _.intersection(_this.ctx.currentProfile.orgRoles, ['TRN', 'CCH']).length;
                        var checkorgroletrnCCN = _.intersection(_this.ctx.currentProfile.orgRoles, ['TRN', 'CCN']).length;
                        if (checkorgroleadmin > 0) {
                            _this.eligibilitychecktrue = true;
                        }
                        else if (checkorgroletrn > 0 && checkorgroletrnCCN == 0) {
                            if (_this.ctx.currentProfile.org == _this.filterParameter.orgId && (_this.filterParameter.teamId == undefined || _this.filterParameter.teamId == '')) {
                                // isAdmin(true);
                                _this.eligibilitychecktrue = true;
                            }
                            else if (_this.ctx.currentProfile.org == _this.filterParameter.orgId && (_this.filterParameter.teamId !== undefined || _this.filterParameter.teamId !== '')) {
                                _.find(_this.ctx.currentProfile.tags, function (lor) {
                                    if (lor.includes(_this.filterParameter.teamId)) {
                                        return _this.eligibilitychecktrue = true;
                                    }
                                    else {
                                        return _this.eligibilitychecktrue = false;
                                    }
                                });
                            }
                        }
                        else {
                            _this.eligibilitychecktrue = false;
                        }
                        //console.log(this.eligibilitychecktrue);
                        if (_this.eligibilitychecktrue !== undefined && _this.eligibilitychecktrue == true) {
                            _this.eligibilitycheck = true;
                        }
                        //use for view filter set
                        if (sessionStorage['cardview'] !== undefined) {
                            if (_this.eligibilitychecktrue !== undefined && _this.eligibilitychecktrue == true) {
                                _this.filterParameter.orgViews = sessionStorage['cardview'];
                            }
                            else {
                                _this.filterParameter.orgViews = "Cards";
                            }
                        }
                        else {
                            _this.filterParameter.orgViews = "Cards";
                        }
                        _this.getFreshTeamList();
                        _this._shared.currentOrgTeamId.emit({ orgId: _this.filterParameter.orgId, teamId: _this.filterParameter.teamId });
                    });
                    if (sessionStorage['isCurrentTab'] !== undefined) {
                        this.isCurrentTab = sessionStorage['isCurrentTab'];
                    }
                };
                TeamsPlayersComponent.prototype.goToDetails = function (id) {
                    if (id) {
                        // sessionStorage['numberOfRecords'] = this.skip;
                        // sessionStorage['bodyScrollTop'] = this.bodyScrollTop;
                        this._router.navigate(['main/player', id]);
                    }
                };
                TeamsPlayersComponent.prototype.isSaveData = function () {
                    console.log(this.isSaveData);
                };
                TeamsPlayersComponent.prototype.getFreshTeamList = function () {
                    this.filterParameter.orgRoles;
                    this.userProfileData = [];
                    this.skip = 0;
                    if (sessionStorage['numberOfRecords'] !== undefined && sessionStorage['numberOfRecords'] !== "null" && sessionStorage['numberOfRecords'] !== null && sessionStorage['numberOfRecords'] >= 50) {
                        this.take = sessionStorage['numberOfRecords'];
                    }
                    this.loading = true;
                    this.getTeamList();
                };
                TeamsPlayersComponent.prototype.getTeamList = function () {
                    var _this = this;
                    this.isAutoloading = true;
                    this.isDataLoaded = false;
                    this._userProfilesSvc.getTeamUserProfiles(this.skip, this.take, false, this.sortingParameter, this.sortingOrderParameter, this.filterParameter).subscribe(function (data) {
                        if (data.length) {
                            if (_this.filterParameter.orgRoles == null && _this.filterParameter.orgViews == 'Eligibility') {
                                //this.userProfileData
                                var teamfilterdata = data.filter(function (o) { return _.contains(o.orgRoles, 'CCH') == false; });
                                // console.log(teamInfoValues);
                                _this.userProfileData = _this.userProfileData.concat(teamfilterdata);
                            }
                            else {
                                _this.userProfileData = _this.userProfileData.concat(data);
                            }
                            if (_this.skip === 0 && sessionStorage['bodyScrollTop'] != '0') {
                                setTimeout(function () {
                                    if (sessionStorage['bodyScrollTop'] !== undefined && sessionStorage['bodyScrollTop'] !== 0 && sessionStorage['bodyScrollTop'] !== '0') {
                                        window.scrollTo(0, sessionStorage['bodyScrollTop']);
                                        sessionStorage['numberOfRecords'] = null;
                                        sessionStorage['bodyScrollTop'] = 0;
                                    }
                                }, 500);
                            }
                            _this.skip += data.length;
                            _this.take = 50;
                        }
                        _this.isAutoloading = false;
                        _this.loading = false;
                        if ((data.length % _this.take) == 0) {
                            _this.isDataLoaded = true;
                            _this.noMoreRecords = false;
                        }
                        else {
                            _this.noMoreRecords = true;
                        }
                    }, function (e) {
                        console.log('Logo error', e);
                        throw e;
                    }, function () {
                    });
                };
                TeamsPlayersComponent.prototype.onWindowScroll = function () {
                    var bodyScrollTop = this.document.documentElement.scrollTop || this.document.body.scrollTop;
                    if (bodyScrollTop / (this.document.body.scrollHeight - this.document.body.clientHeight) > 0.9) {
                        if (this.isDataLoaded == true && this.isCurrentTab == "teamtab") {
                            this.getTeamList();
                        }
                    }
                    if (bodyScrollTop >= 1 && bodyScrollTop <= 19) {
                        document.querySelector('body').classList.add("filter-opacity");
                        document.querySelector('body').classList.remove("filter-fix");
                        document.querySelector('body').classList.remove("filter-opacity-2");
                        document.querySelector('body').classList.remove("filter-opacity-3");
                    }
                    else if (bodyScrollTop >= 20 && bodyScrollTop <= 39) {
                        document.querySelector('body').classList.remove("filter-fix");
                        document.querySelector('body').classList.remove("filter-opacity");
                        document.querySelector('body').classList.remove("filter-opacity-3");
                        document.querySelector('body').classList.add("filter-opacity-2");
                    }
                    else if (bodyScrollTop >= 40 && bodyScrollTop <= 56) {
                        document.querySelector('body').classList.remove("filter-opacity-2");
                        document.querySelector('body').classList.remove("filter-fix");
                        document.querySelector('body').classList.remove("filter-opacity");
                        document.querySelector('body').classList.add("filter-opacity-3");
                    }
                    else if (bodyScrollTop >= 57) {
                        document.querySelector('body').classList.remove("filter-opacity-3");
                        document.querySelector('body').classList.remove("filter-opacity-2");
                        document.querySelector('body').classList.remove("filter-opacity");
                        document.querySelector('body').classList.add("filter-fix");
                    }
                    else {
                        document.querySelector('body').classList.remove("filter-fix");
                        document.querySelector('body').classList.remove("filter-opacity-3");
                        document.querySelector('body').classList.remove("filter-opacity-2");
                        document.querySelector('body').classList.remove("filter-opacity");
                    }
                    this.bodyScrollTop = bodyScrollTop;
                    if (bodyScrollTop >= 57) {
                        sessionStorage['numberOfRecords'] = this.skip;
                        sessionStorage['bodyScrollTop'] = this.bodyScrollTop;
                    }
                };
                TeamsPlayersComponent.prototype.setSorting = function (sort) {
                    if (sort == 'currentDesignationStatus.sortInjuryStatus') {
                        this.sortingOrderParameter = "-";
                        sessionStorage['sortorderview'] = "-";
                    }
                    else {
                        this.sortingOrderParameter = "";
                        sessionStorage['sortorderview'] = "";
                    }
                    if (sort) {
                        this.setSessiondata();
                        sessionStorage['sortview'] = sort;
                        this.sortingParameter = sort;
                    }
                    this.getFreshTeamList();
                };
                TeamsPlayersComponent.prototype.setSortingOrder = function (order) {
                    this.setSessiondata();
                    if (order == "") {
                        this.sortingOrderParameter = "-";
                        sessionStorage['sortorderview'] = "-";
                    }
                    else {
                        this.sortingOrderParameter = "";
                        sessionStorage['sortorderview'] = "";
                    }
                    this.getFreshTeamList();
                };
                TeamsPlayersComponent.prototype.setFilter = function (filter) {
                    if (filter == null) {
                        sessionStorage['filterview'] = 'All';
                    }
                    else {
                        sessionStorage['filterview'] = filter;
                    }
                    if (filter !== undefined) {
                        this.setSessiondata();
                        this.filterParameter.injured = filter;
                        sessionStorage['filterview'] = filter;
                    }
                    this.getFreshTeamList();
                };
                TeamsPlayersComponent.prototype.setView = function (view) {
                    if (view !== undefined) {
                        this.viewType = view;
                    }
                };
                TeamsPlayersComponent.prototype.setOrgRoles = function (role) {
                    if (role == 'CCH') {
                        this.eligibilitychecktrue = false;
                        if (sessionStorage['cardview'] == 'Eligibility') {
                            this.filterParameter.orgViews = 'Cards';
                        }
                    }
                    else {
                        this.eligibilitychecktrue = true;
                    }
                    if (role == null) {
                        sessionStorage['roleviewlist'] = 'All';
                    }
                    else {
                        sessionStorage['roleviewlist'] = role;
                        this.filterParameter.orgRoles = role;
                    }
                    if (role !== undefined) {
                        this.setSessiondata();
                        this.filterParameter.orgRoles = role;
                        sessionStorage['roleviewlist'] = role;
                    }
                    this.getFreshTeamList();
                };
                TeamsPlayersComponent.prototype.setCardview = function (viewtype) {
                    //this.userProfileData=  sessionStorage['userProfileData'];
                    sessionStorage['cardview'] = viewtype;
                    if (viewtype !== undefined) {
                        this.setSessiondata();
                        this.filterParameter.orgViews = viewtype;
                    }
                };
                TeamsPlayersComponent.prototype.setSessiondata = function () {
                    sessionStorage['numberOfRecords'] = null;
                    sessionStorage['bodyScrollTop'] = 0;
                };
                TeamsPlayersComponent.prototype.changeTab = function (e, type) {
                    var _this = this;
                    sessionStorage['isCurrentTab'] = type;
                    if (type == "teamtab") {
                        e.preventDefault();
                        e.stopPropagation();
                        this.teamForm.lostCurrentRoute().then(function (res) {
                            console.log(res);
                            if (res) {
                                _this.isCurrentTab = "teamtab";
                                _this.sortingOrderParameter = "";
                                _this.sortingParameter = "sortLastName,sortFirstName";
                                _this.filterParameter.injured = null;
                                _this.filterParameter.orgRoles = "ATH";
                                _this.viewType = "Cards";
                                _this.filterParameter.orgViews = "Cards";
                                _this.getFreshTeamList();
                            }
                            else {
                                _this.isCurrentTab = "formtab";
                            }
                        });
                    }
                    if (type == "formtab" && this.filterParameter.orgId !== "Everyone" && this.filterParameter.orgId !== null && this.filterParameter.orgId !== undefined) {
                        this.isCurrentTab = "formtab";
                        this.teamForm.refresh();
                    }
                };
                // ========== START: this all code related to packet tab form ====================
                // Save data for packet tab on route change only
                TeamsPlayersComponent.prototype.confirmChangeRoute = function () {
                    var _this = this;
                    return new Promise(function (resolve, reject) {
                        _this.teamForm.lostCurrentRoute().then(function (data) {
                            if (data) {
                                resolve(true);
                            }
                            else {
                                resolve(false);
                            }
                        });
                    });
                };
                __decorate([
                    core_1.ViewChild(teams_form_component_1.TeamsFormComponent), 
                    __metadata('design:type', teams_form_component_1.TeamsFormComponent)
                ], TeamsPlayersComponent.prototype, "teamForm", void 0);
                __decorate([
                    core_1.ViewChild('staticTabs'), 
                    __metadata('design:type', ng2_bootstrap_1.TabsetComponent)
                ], TeamsPlayersComponent.prototype, "staticTabs", void 0);
                __decorate([
                    core_1.Input("isSaveData"), 
                    __metadata('design:type', Function), 
                    __metadata('design:paramtypes', []), 
                    __metadata('design:returntype', void 0)
                ], TeamsPlayersComponent.prototype, "isSaveData", null);
                __decorate([
                    core_1.HostListener("window:scroll", []), 
                    __metadata('design:type', Function), 
                    __metadata('design:paramtypes', []), 
                    __metadata('design:returntype', void 0)
                ], TeamsPlayersComponent.prototype, "onWindowScroll", null);
                TeamsPlayersComponent = __decorate([
                    core_1.Component({
                        selector: 'teams-players',
                        animations: [
                            core_1.trigger('fadeInOut', [
                                core_1.transition('void => *', [
                                    core_1.style({ opacity: 0 }),
                                    core_1.animate(1000, core_1.style({ opacity: 1 })) // the new state of the transition(after transiton it removes)
                                ]),
                                core_1.transition('* => void', [
                                    core_1.animate(1000, core_1.style({ opacity: 0 })) // the new state of the transition(after transiton it removes)
                                ])
                            ])
                        ],
                        templateUrl: '/maxweb/app/app/teams-players.component.html'
                    }),
                    __param(7, core_1.Inject(platform_browser_1.DOCUMENT)), 
                    __metadata('design:paramtypes', [maxAppContext_service_1.MaxAppContext, router_1.ActivatedRoute, router_1.Router, user_profiles_service_1.UserProfiles, organizations_service_1.Organizations, shared_service_1.SharedService, core_1.ElementRef, Document, bootstrap_1.Modal, common_1.Location])
                ], TeamsPlayersComponent);
                return TeamsPlayersComponent;
            }());
            exports_1("TeamsPlayersComponent", TeamsPlayersComponent);
        }
    }
});
//# sourceMappingURL=teams-players.component.js.map