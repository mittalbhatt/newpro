
import {Component, Output, Input,Injectable,ViewChild, EventEmitter} from "@angular/core";
import { UserProfiles, UserProfile } from "./user_profiles.service";
import {Router,ActivatedRoute} from "@angular/router";
import { SiteSearch } from "./site-search.service";
import {MaxAppContext} from "./maxAppContext.service";
import {Modal, BSModalContext} from 'angular2-modal/plugins/bootstrap';
import {Overlay, overlayConfigFactory} from 'angular2-modal';
import {InviteModal, CustomModalContext} from "./invite-modal.component";
 

@Component({
    selector: 'relation-box',
    templateUrl:'/maxweb/app/app/realtion_data.component.html',
    
})
export class RelationComponent {

    @Output() changeData = new EventEmitter();
    @Output() ngModelChangeFun = new EventEmitter();
    item:any = {"firstName": "","lastName": "","rel": "","tel":[""],"address": "", "city": "", "state": "", "zip": ""};
    //initRelationObj :any = {"firstName": "","lastName": "","rel": "Relation","tel":[""],"address": "", "city": "", "state": "Select state", "zip": ""};
    phoneArrayrelation: any = [];
    errorclassphone: any = [];
    errorclassemail:any=[];
    relationArray:any=[];
    relationObject:any;
    sitesearch:any=null;
    profileId:string;
    indexre:string;
    openingPages:boolean=false;
    deleteloader:boolean=false;
    unsaveData:boolean;
    userProfileData:any=[];

    parentImageurl:any;
    profile:any;

    showEmailPhone: boolean=false;
    emailParent:any=null;
    telParent:any=null;
    firstNameParent:string;
    showLockedIcon:boolean=false;
    errorMessage:string;
    relationDeleteMsg:string;
    _athleteProfile: any=[];
    athleteFullName:string="";
    parentFullName:string="";
    deleteTrue:boolean=false;
    deleteDisable:boolean=true;

    constructor(
        private _userProfiles: UserProfiles,
        private _route: ActivatedRoute,
        private _router: Router,
        private _appCtx: MaxAppContext,
        public _model:Modal
        ){
            if(this.phoneArrayrelation.length==0){
                this.phoneArrayrelation.push({phone: ''});
            }
            let params = this._route.snapshot.params;
            this.profileId= params['profileId'];
            this.item.rel='this.item';

    }
   

    ngOnInit(){
        if(this.item.userProfileId!=undefined && this.item.userProfileId!=null){
            this.loadEmailAndPhone(this.item.userProfileId);
            this.checkUserAccount(this.item.userProfileId);
        }
        else{
            this.deleteDisable=false;
        }
    }

    loadEmailAndPhone(profileid){
        //console.log("load Email & phone for relation");
        let loadRelationProfile = this._userProfiles.getProfile(profileid).single().toPromise();

        loadRelationProfile.then(user => {
            let userProfile  = user;

            if(_.has(userProfile,'orgRoles') && userProfile.orgRoles.indexOf("PRN") > -1){
                this.showEmailPhone = true;
                this.firstNameParent = (userProfile.firstName!=undefined) ? userProfile.firstName : "";
                this.emailParent = (userProfile.email!=undefined) ? userProfile.email : "";
                this.telParent = (userProfile.tel!=undefined) ? userProfile.tel[0] : "";
                if(this.indexre!=undefined && this.indexre=='0'){
                    this.item.email = this.emailParent;
                    this.item['tel'][0] = this.telParent;
                }
            }
        });
    }

    checkUserAccount(profileId){
        console.log("profileId========="+profileId);
            // get edited athlete name
            if(this._athleteProfile.lastName==undefined){
                this.athleteFullName=`${this._athleteProfile.firstName}`
            }else if(this._athleteProfile.firstName==undefined){
                this.athleteFullName=`${this._athleteProfile.lastName}`
            }else if(this._athleteProfile.firstName!==undefined && this._athleteProfile.lastName!==undefined){
                this.athleteFullName=`${this._athleteProfile.firstName} ${this._athleteProfile.lastName}`
            }
            else{
                 this.athleteFullName = "this Athelete";
            }

            // get parent name
            if(this.item.lastName==undefined){
                this.parentFullName=`${this.item.firstName}`
            }else if(this.item.firstName==undefined){
                this.parentFullName=`${this.item.lastName}`
            }else if(this.item.firstName!==undefined && this.item.lastName!==undefined){
                this.parentFullName=`${this.item.firstName} ${this.item.lastName}`
            }else{
                this.parentFullName = "this Parent";
            }
            // console.log("Start..................");
            this._userProfiles.getAllProfilesToCheck()
            .then(profiles =>
            {    
                //console.log("Starting+++++++++++++"+profileId);
                let userAccount = profiles.filter(p => p._id == profileId).map( p => new UserProfile(p));
                console.log(userAccount);
                if(_.has(userAccount[0],'$userAccount')){
                    //console.log("TRUE======#$userAccount");
                    this.showLockedIcon = true;
                }
                //console.log("One-----------------");
                let myProfileCheck = this._appCtx.myProfiles.filter(mp=> mp._id == profileId);
                //console.log(this._appCtx.currentProfile.orgRoles);
                if(_.has(this._appCtx.currentProfile, 'orgRoles')==true && this._appCtx.currentProfile.orgRoles.indexOf("UADM") > -1){
                    this.deleteTrue = true;
                    this.relationDeleteMsg = `If you delete this entry, ${this.parentFullName} will no longer be linked to ${this.athleteFullName} in MAX, 
                    and will lose access to ${this.athleteFullName}'s records.
                     <br><br> Are you sure you want to do this?`;
                } else if((_.has(this._appCtx.currentProfile, 'orgRoles')==true && this._appCtx.currentProfile.orgRoles.indexOf("PRN") > -1) || (myProfileCheck!=undefined && myProfileCheck.length==1)){
                    this.deleteTrue = true;
                    this.relationDeleteMsg = `If you delete this entry, you will no longer be linked to ${this.athleteFullName} in MAX, 
                    and you will lose access to ${this.athleteFullName}'s records.
                     <br><br> Are you sure you want to do this?`;
                } else{
                    this.deleteTrue = false;
                    this.relationDeleteMsg = `You do not have access to remove the link between ${this.athleteFullName} 
                    and ${this.parentFullName} and do not allow the delete.`;
                }
                this.deleteDisable=false;
            })
            .catch(e =>
            {
                console.log(e);
                this.errorMessage = 'We encountered an unexpected error. Refresh the page and try again.';
                throw e;
            });

    }

    @Input('relationdata')
    set relationdata(value: any){
        this.item = value;

        if( this.item.tel==undefined){
            this.item['tel']=[];
        }
        if( this.item.state==undefined || this.item.state==''){
            this.item.state='';
        }
          if( this.item.rel==undefined || this.item.rel==''){
            this.item.rel='';
        }
    }

    checkerror(field:any):boolean{
        // console.log(field);
        if( field === null || field === undefined || field === "" ){
            return true;
        }else{
            return false;
        }
    }

    get stateOptions(): string[] {
        var stateObj = this._appCtx.getStates();
        return _.chain(stateObj)
        .flatten()
        .value();
    }

    get parentOptions(): string[] {
        var parentObj = this._appCtx.getParents();
        return _.chain(parentObj)
            .flatten()
            .value();
    }

    changeRelationData(event:any){
        this.unsaveData = true;
        this.ngModelChangeFun.emit(event);
    }

    addmoreData(type: string) {
        if(type=='phonerelation'){
            this.phoneArrayrelation.push({phone: ''})
        }
    }

   
    addmoreRelation(){
        this.relationArray.push({"firstName": "","lastName": "","rel": "","tel":[],"address": "", "city": "", "state": "", "zip": "","email":""});
    }

    saveDataRelation(relationArray:any,indexrel:any,indexphone:any,type:any, event:any) {
        this.changeRelationData(event);
        if(type=='phone'){
             if( relationArray.tel.length>0){
                //let PHONE_REGEXP = /^[0-9\-+\)\(]+$/;
            
                //if (PHONE_REGEXP.test(relationArray.tel[0])) {
                if(relationArray.tel[0].length>0) {
                    this.errorclassphone[0] = 'false';
                    if(event.type!==undefined && event.type==='blur'){
                        this.saveData().then((res:boolean):boolean =>{
                            return res;
                        }).catch(e=> {
                            throw e;
                        });
                    }
                    
                }else{
                    this.errorclassphone[0] = 'true';
                }
             }
        }else if(type=='email'){
            
             //let EMAIL_REGEXP = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
            //if (EMAIL_REGEXP.test(relationArray.email)) {
            if (relationArray.email.length>0) {
                this.errorclassemail[0] = 'false';
                
                if(event.type!==undefined && event.type==='blur'){
                    this.saveData().then((res:boolean):boolean =>{
                        return res;
                    }).catch(e=> {
                        throw e;
                    });
                }
             
            }else{
                this.errorclassemail[0] = 'true';
            }
        }else{
                //console.log("SaveData Relation...");
                this.saveData().then((res:boolean) =>{
                    //console.log("SaveData Complete");
                    return res;
                }).catch(e=> {
                    throw e;
                });
        }
        
    }

    saveData():Promise<boolean>{
        //console.log("saveData = Unsave Data 1: "+this.unsaveData);
        return new Promise((resolve, reject) => {
        this.relationObject = {
            $set:{
                relations:
                this.relationArray
            }
        };

        if(this.sitesearch){
            this.sitesearch.unsubscribe();
        }

        if(this.unsaveData!==undefined && this.unsaveData==true){
            this.sitesearch=this._userProfiles.updateProfile(this.profileId, this.relationObject)
            .subscribe(
                  (res:any)=>{
                      //console.log("Start Data Save Function...");
                      this.unsaveData = false;
                      this._userProfiles.updateRelativeData.emit({data:true});
                      resolve(true);
                  },
                  e=>{ 
                      resolve(false);
                  }
            );

        }else {
            this._userProfiles.updateRelativeData.emit({data:true});
            resolve(true);
        }

        });
    }

    texttoinvite(item:any){
         var inviteobj ={userProfileId:item.userProfileId,requireUniqueVerificationCode:"true",invitationSenderName:"Ms Butler"}
         this._userProfiles.texttoinvite(inviteobj).single().toPromise().then((resdata:any)=>{
            if(resdata!==undefined){
                
            }
         });
    }

    invite(inviteId:string,item:any){
  

       if(item.firstName=='' && item.lastName=='' && item.rel=='' && item.city=='' && (item.tel[0]=='' || item.tel[0]==undefined) ){
          
           this._model.confirm()
                .size('sm').isBlocking(true).showClose(false).keyboard(27)
                // .body(`code: ${resdata.code}`)
                .body(`Please insert at least one field value for this relative.`)
                .headerClass("hide")
                .okBtnClass("hide")
                .cancelBtn("OK").cancelBtnClass("btn btn-primary")
                .open().then((dialog : any ) => {
                    return dialog.result;
                }).then(result =>{

                }).catch((e:any)=>{

                });
       }else{
            var inviteobj ={userProfileId:inviteId,requireUniqueVerificationCode:"false"}
                this.openingPages=true;
                this._userProfiles.inviterelation(inviteobj).single().toPromise().then((resdata:any)=>{
                    if(resdata!==undefined){
                        this.openingPages=false;
                        let adminFormPrintModalData = new CustomModalContext({data:item,resdata:resdata,size:"md"});
                let config = overlayConfigFactory(adminFormPrintModalData, BSModalContext);
                this._model.open(InviteModal, config).then(result =>{
                })
                .catch(e => console.log(e));
                    }
                });
       }
       

                

    }
    
    onRemoveRelation(i:number,firstname:any,lastname:any)
    {
        this.deleteloader=true;
        if(this.deleteTrue==false && this.relationDeleteMsg==undefined && this.item.userProfileId==undefined){
            this.deleteTrue=true;
            this.relationDeleteMsg = "Are you sure you want to do this?";
        }

        if(this.deleteTrue==true){
            (<any>this._model.confirm())
            .size('md')
            .isBlocking(true)
            .showClose(false)
            .headerClass("hide")
            .cancelBtnClass("btn btn-primary")
            .keyboard(27)
            .body(`${this.relationDeleteMsg}`)
            .bodyClass('modal-body text-left')
            .okBtn(`Ok`).okBtnClass("btn btn-danger okbutton")
            .open()
            .then(res =>
            {
                this.deleteloader=false;
                res.result.then(r =>
                {
                    if (r === true)
                    {
                        var relationArray =this.relationArray.splice(i,1);
                        this.relationObject = {
                            $set:{
                                relations:
                                this.relationArray
                            }
                        };
                        var loadProfileInfo = this._userProfiles.getProfile(this.profileId).single().toPromise();
                        var flag = false;
                        loadProfileInfo.then(data => {
                            this.userProfileData = data;
                            var userProfileId =  '';
                            var currentParentId =  '';
                            
                            if(i===0){
                                userProfileId = this.userProfileData.relations[0].userProfileId;
                                currentParentId = this._appCtx.currentProfile._id;
                            }
                            
                            this._userProfiles.updateProfile(this.profileId, this.relationObject
                            ).subscribe();

                            if(userProfileId !=='' && currentParentId!=='' && userProfileId == currentParentId && this._appCtx.currentProfile.orgRoles.indexOf("PRN") > -1){
                                this._router.navigate(['/max-forms/chooseFormsProfile', currentParentId]);    
                            }
                        });
                        return;
                    }
                })
                .catch(e =>
                {
                    if (e)
                        throw e;
                });
            });
        }
        else{

            this._model.alert()
            .headerClass("hide")
            .keyboard(27)
            .body(`${this.relationDeleteMsg}`)
            .bodyClass('modal-body text-left')
            .okBtn(`Ok`).okBtnClass("btn btn-primary")
            .open()
            .then(res =>
            {
                this.deleteloader=false;

            });
        }
    }

    @Input('subjectProfile')
    set subjectProfile(value: any){
        this._athleteProfile = value;
    }

    @Input('relationdataarray')
    set relationdataarray(value: any){
        this.relationArray = value;
    }

    @Input('index')
    set index(value: any){
        this.indexre = value;
    }

    addPhone(){
        this.phoneArrayrelation.push({phone: ''})
    }

    savePhone(){
        var a = _.pluck(this.item,"phone");
        this.changeData.emit(this.item);
        //  console.log(this.changeData);
    }
}

