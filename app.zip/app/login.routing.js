System.register(['./auth-guard.service', './auth.service', './login.component', "./signup.component", "./forgot_pass.component", "./reset_pass.component", "./verifyAccount.component", "./accountVerificationCanDeactivate.service"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var auth_guard_service_1, auth_service_1, login_component_1, signup_component_1, forgot_pass_component_1, reset_pass_component_1, verifyAccount_component_1, accountVerificationCanDeactivate_service_1;
    var loginRoutes, authProviders;
    return {
        setters:[
            function (auth_guard_service_1_1) {
                auth_guard_service_1 = auth_guard_service_1_1;
            },
            function (auth_service_1_1) {
                auth_service_1 = auth_service_1_1;
            },
            function (login_component_1_1) {
                login_component_1 = login_component_1_1;
            },
            function (signup_component_1_1) {
                signup_component_1 = signup_component_1_1;
            },
            function (forgot_pass_component_1_1) {
                forgot_pass_component_1 = forgot_pass_component_1_1;
            },
            function (reset_pass_component_1_1) {
                reset_pass_component_1 = reset_pass_component_1_1;
            },
            function (verifyAccount_component_1_1) {
                verifyAccount_component_1 = verifyAccount_component_1_1;
            },
            function (accountVerificationCanDeactivate_service_1_1) {
                accountVerificationCanDeactivate_service_1 = accountVerificationCanDeactivate_service_1_1;
            }],
        execute: function() {
            exports_1("loginRoutes", loginRoutes = [
                { path: 'login', component: login_component_1.LoginComponent },
                { path: 'login/:username', component: login_component_1.LoginComponent },
                { path: 'signup', component: signup_component_1.SignupComponent },
                { path: 'forgot-pass', component: forgot_pass_component_1.ForgotPassComponent },
                { path: 'reset-pass/:userAccountId/:username', component: reset_pass_component_1.ResetPassComponent },
                { path: 'verify-account/:username', component: verifyAccount_component_1.AccountVerificationComponent, canDeactivate: [accountVerificationCanDeactivate_service_1.AccountVerificationCanDeactivate] }
            ]);
            exports_1("authProviders", authProviders = [
                auth_guard_service_1.AuthGuard,
                auth_service_1.AuthService,
                accountVerificationCanDeactivate_service_1.AccountVerificationCanDeactivate
            ]);
        }
    }
});
//# sourceMappingURL=login.routing.js.map