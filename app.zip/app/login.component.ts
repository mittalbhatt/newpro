import {Component, OnInit} from "@angular/core";
import {AuthService} from "./auth.service";
import {Router, ActivatedRoute} from "@angular/router";
import {UserAccountService} from "./userAccount.service";
import {MaxAppContext} from "./maxAppContext.service";

@Component({
    selector: 'max-login',
    template:`
    <div *ngIf="errorMessage" style="max-width:500px; margin:20px auto;padding:10px" [class]="'alert alert-danger animated shake'">
    {{errorMessage}}
    <br/><a *ngIf="isSignUpLink" [routerLink]="['/max-cover/signup']" style="color:#6495ed;">Sign up here if you don't have an account</a>
    </div>
    <div id="login-form">
        <div>
            <org-heading #heading></org-heading>
            <img *ngIf="!heading.org" class="max-wordmark-logo" src="app/media/hurricane-100.png"/>
            <span *ngIf="!heading.org" class="max-wordmark-text">DragonFly MAX</span>
            <a style="font-size:10px;" href="javascript:void(0)" (click)="reset()" *ngIf="heading.org">Not part of {{heading.org.name}}? Click here.</a>
        </div>
        <form #loginForm="ngForm" (ngSubmit)="onSubmit()">
          <div class="form-group">
            <label for="username">Email or Phone</label>
            <input [(ngModel)]="username" autocorrect="off" autocapitalize="off" spellcheck="false" type="text" class="form-control" name="username" placeholder="Mobile # or email address" required autofocus>
          </div>
          <div class="form-group">
            <label for="password">Password</label>
            <input [(ngModel)]="password" type="password" class="form-control" name="password" placeholder="Password" required>
            <a style="color:#6495ed; font-weight:bold;" href="javascript:void(0)" [routerLink]="['/max-cover/forgot-pass', username ? {username:username} : {}]">Forgot your password?</a>
          </div>
          <!--<div class="form-group">-->
            <!--<p class="help-block">Example block-level help text here.</p>-->
          <!--</div>-->
          <!--<div class="checkbox">-->
            <!--<label>-->
              <!--<input [(ngModel)]="persistent" name="persistent" type="checkbox"> Stay logged in?-->
            <!--</label>-->
          <!--</div>-->
          <button type="submit" class="btn btn-primary" style="height:45px; width:170px; font-size:20px;" [disabled]="!loginForm.form.valid">Login</button>
        </form>
          <table style="width:108%; margin: 10px -10px 30px;">
            <tr><td style="border-bottom:1px solid #5d5d5d; width:19%;">&nbsp;</td><td width="auto"><p style="margin-top:10px; margin-right:2px; margin-left:2px; height:1px;">Don't have an account?</p></td><td style="border-bottom:1px solid #5d5d5d; width:19%">&nbsp;</td></tr>
          </table>
          <button class="btn btn-primary" style="height:45px; width:170px; font-size:20px;" [routerLink]="['/max-cover/signup', {username:username}]">Sign Up for Free</button>
    </div>
`
})
export class LoginComponent implements OnInit {

    errorMessage:string;

    username:string;
    password:string;
    submitting:boolean;
    persistent:boolean;
    isSignUpLink:boolean=false;

    constructor(
        private _auth:AuthService,
        private _acctSvc:UserAccountService,
        private _router:Router,
        private _route:ActivatedRoute,
        private _ctx:MaxAppContext)
    {
        let username = this._route.snapshot.params['username'];
        if (username)
            this.username = decodeURIComponent(username);
    }

    ngOnInit()
    {
        if (this._auth.isLoggedIn)
        {
            this._router.navigateByUrl('/');
        }
    }

    onSubmit()
    {

        if (this.submitting)
            return;

        this.submitting = true;
        this.errorMessage = null;

        this.isSignUpLink = false;
        this._auth.login(this.username.trim(), this.password.trim(), this.persistent)
            .then(() =>
            {
                this.submitting = false;

                let url = this._auth.redirectUrl;
                console.log(`Logged in.  Redirect url: ${url}`);
                this._auth.redirectUrl = null;
                if (url)
                    this._router.navigateByUrl(url);
                else
                    this._router.navigateByUrl('/');
            })
            .catch(err =>
            {
                window.scrollTo(0,0);
                this.submitting = false;

                console.log(err);

                if (err.status == 401)
                {
                    if (err.json().VerificationRequired == true)
                    {
                        this._acctSvc.cachedPassword = this.password;
                        this._router.navigate(['verify-account', this.username.trim()], {relativeTo:this._route.parent});
                        return;
                    }
                    this.isSignUpLink = true;
                    this.errorMessage = 'The username or password is incorrect. Did you sign up with your phone # or email?';
                }
                else
                {
                    this.errorMessage = 'We encountered an unexpected error.';
                }
            });
    }

    reset()
    {
        this._ctx.logout();
        this._router.navigate(['/max-cover/choose-org']);
    }

}