import {Component, Input, Output, EventEmitter} from "@angular/core";
import {Router, ActivatedRoute } from "@angular/router";
import {MaxAppContext} from "./maxAppContext.service";
import { SiteSearchService, SiteSearch } from "./site-search.service";
import {Documents} from "./document_factory.service";
import {DocumentLoader} from './document_loader.service';
import {UserProfiles, UserProfile} from "./user_profiles.service";
import {DfObjectId} from "./DfObjectId";
import {DfUuidGen} from "./df_uuid_gen";
import {BasicMedicalSaver} from "./basic_medical_saver.service";
import { DatePipe } from "@angular/common";
import {Pipe, PipeTransform} from "@angular/core";

@Pipe({name: 'hiddencheck'})
export class hiddenPipe implements PipeTransform {
  transform(value, args:any) : any {
     if (!value) {
      return value;
    } 
    let keys = [];
     _.each(value, (data: any) => {
        
         if((data.hidden!=true || data.hidden!=1) && (data.hidden==undefined)  ){
            
             keys.push(data);
            
         }
         
     })
    
     if(keys.length==0){
         console.log(keys);
         return keys[0]=[{data:'notfound'}];
     }else{
      return keys;
     }
      

   
     
    } 
} 


 declare var plupload;


@Component({
    selector: 'document-data',
     providers:[DocumentLoader],
    template:`
        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-6 text-left pull-right">
                <ul class="doument-list">
                    <span *ngFor="let otherdocument of teamDocumentotherData | keys; let i=index;">
                        <h4 class="doument-group">{{otherdocument?.key}}</h4>
                        <li  *ngFor="let otherdocument of otherdocument.value | hiddencheck">
                            <span  *ngIf="otherdocument.data  != 'notfound'" class="doument-icon"></span> <a  *ngIf="otherdocument.data  != 'notfound'" href="javascript:void(0)" (click)="onPrint(otherdocument.documentStableId)" class="dropdown-item">{{otherdocument?.name}}</a><i *ngIf="otherdocument.data  != 'notfound'" class="doument-date" >{{otherdocument.createdDate | date: 'MM/dd/yyyy'}}</i>
                            <div *ngIf="otherdocument.data  == 'notfound'" class="alert alert-info" style="text-align: center">
                               No documents on file
                 </div> 
                        </li>
                        </span>   
            </ul>
                 <div *ngIf="(teamDocumentotherData | json) == '{}'" class="alert alert-info" style="text-align: center">
                               No documents on file
                 </div> 
            </div>
            <div class="col-xs-12 col-sm-12 col-md-6 doument-img pull-left">
            <div>
             <button  [disabled]="isShowDocumentGif" type="button" df-pl-upload-host class="btn btn-primary" [uploadSettings]="logoUploadSettings" [uploadStateChanged]="_orgLogoUploadStateChange"><span class="glyphicon glyphicon-plus"></span> Upload</button>
             <span *ngIf="isShowDocumentGif">Uploading image...</span>
             </div>
             
              <div *ngIf="isShowDocumentGif" style="text-align: center">
                            <img style="max-width:30px; max-height:30px; width:30px" src="/maxweb/app/media/ajax-loader.gif" /> 
             </div>
             <div *ngIf="!isShowDocumentGif" style="padding-top:22px;"> <documentlist-media style="position: relative;" (chkResult)="refreshdatadocument()" *ngFor="let document of teamDocumentmediaData | hiddencheck; let i=index;" [documentmedia]="document"></documentlist-media></div>
            
                <div *ngIf="teamDocumentmediaData.length == 0" class="alert alert-info" style="text-align: center">
                           No media found
                 </div> 
             </div>  
        </div>`
})
export class DocumentsComponent {
 
    private teamDocumentmediaData:any;
    private teamDocumentotherData:any;
    private teamDocumentDatabyyear:any;
    private teamDocumentothersortData:any;
    private orgData:any;
    private _user_img:any;
    public isShowDocumentGif:boolean=false;
    printing:boolean;
    errorMessage:string;
     private _orgLogoUploadStateChange:(state:any, fromUploaderEvent:boolean, resultUrl:string) => void;
    logoUploadSettings:any;
    _amrId:any="";
    logoMedia:any={};
    frontLogoImageUrl:any="";
    profileId:string;
     @Output() chkResult: EventEmitter<any> = new EventEmitter();
     teamDocumentotherDatahidden:any;
  
    constructor(
        private _router:Router,
        private _route: ActivatedRoute,
        private _ctx: MaxAppContext,
        private _documents:Documents,
        private _docLoader:DocumentLoader,
        private _changeSaver: BasicMedicalSaver,
        private _userProfiles: UserProfiles,
        public datepipe: DatePipe
    ){
      this._orgLogoUploadStateChange = (s,f,r) => this.orgLogoUploadStateChanged(s,f,r);
    }

    @Input('documentData') 
    set documentData(data:SiteSearch){
        console.log(data);
        var groupedDocs = _.filter(data, (d:any) =>{
            if(d.type !== undefined && d.type === "Media"){
                return d;
            }
        });
        this.teamDocumentmediaData = groupedDocs;
       
            this.teamDocumentmediaData.reverse();
           var checkhideninmedia = _.filter(this.teamDocumentmediaData, (d:any) =>{
            if(d.hidden == true ){
                return d;
            }
        });
     
        var groupeotherdDocs = _.filter(data, (d:any) =>{
            if(d.type !== "Media" ){
                return d;
            }
        });
    
        var sortotherdDocs = _.sortBy(groupeotherdDocs, (od:any) =>{
            if(od.createdDate !== undefined){
                var d = new Date(od.createdDate);
                var n = d.getDate();
                return n;
            }
        });
        var sortotherdDocsreverse=sortotherdDocs.reverse();
        this.teamDocumentotherData = _.groupBy(sortotherdDocsreverse, (od:any) => { 
            
            if(od.createdDate !== undefined){
                var d = new Date(od.createdDate);
                var n = d.getFullYear();
                return n;
            }
        });
       
        
        
       
    }
     @Input('userProfile') 
    set userProfile(data:any){
     
        this._amrId=data.amrId;
         
    }
    ngOnInit() {
      
        var uuid = DfUuidGen.newUuid();
        var logoMedia: any = {};
        var mediaId = uuid;
        let params = this._route.snapshot.params;
        this.profileId = params['id'];
        var loadProfile = this._userProfiles.getProfile(this.profileId).single().toPromise();

       // console.log(this._amrId);
        
         this.logoUploadSettings = {
             
            getFileParams: (file) =>
            {
                this.isShowDocumentGif = true;
                var fileId = DfUuidGen.newUuid();
                 var uuid = DfUuidGen.newUuid();
                 var mediaId = uuid;
                 var createdDate=this.datepipe.transform(new Date(), 'MM/dd/yyyy');
 
                logoMedia = {
                    _id: (new DfObjectId()).toString(),
                    type: 'Media',
                    documentStableId: (new DfObjectId()).toString(),
                    name: "Picture",
                    createdDate: (new Date()).toISOString(),
                    subjects: [
                    {
                        amrId: this._amrId
                    }
                    ],
                    media: [
                    {
                        contentType: file.type, // "image/jpeg"
                        mediaId: mediaId
                    }
                    ],
                   
                    lastModifiedDate: (new Date()).toISOString()
                };
             
               this.logoMedia=logoMedia;
               //console.log(this.logoMedia);
         
                return this._changeSaver.update(this.logoMedia).single().toPromise()
                .then((data) => {
                 //  this.isShowDocumentGif = false;
                     return {
                                   
                                    paramsUrl: `/training/api/documents/${this.logoMedia._id}/media/${encodeURIComponent(mediaId)}`
                                };
                   // return logoMedia;
                });
            },
            dfUploadTag: mediaId,
            uploaderSettings: {
                filters: {
                    max_file_size: '10mb',
                    mime_types: [
                    { title: "Image files", extensions: "jpeg,jpg,gif,png" }
                    ]
                },
                resize: {
                    width: 600,
                    height: 600
                }
            },
            
        };
        
    }
    removeDocumentImage(){
        
    }
     onPrint(documentStableId)
    {
   
        this.printing = true;
        this.errorMessage = '';

        if (documentStableId.length < 1)
        {
            this.printing = false;
            this.errorMessage = 'The selected athlete(s) have not filled out any of the selected forms.';
            return;
        }

        this._docLoader.openPdf(documentStableId, window).then(() =>
        {
            this.printing = false;
           // console.log('success');
        }).catch(error =>
        {
            this.printing = false;
            console.error(error);
            this.errorMessage = 'We encountered an error printing.  Please try again.';
        });
    }
    refreshdatadocument(){
       
        this._userProfiles.getTeamUserDocument(this.profileId).single().toPromise()
            .then(data => {
                    this.isShowDocumentGif = false;
                        var groupedDocs = _.filter(data, (d:any) =>{
                                if(d.type !== undefined && d.type === "Media"){
                                    return d;
                                }
                        });
                         this.teamDocumentmediaData = groupedDocs;
                         this.teamDocumentmediaData.reverse();
                         this.chkResult.emit({
                              value: true
                            })
                    })
                    .catch(e => {
                    this.isShowDocumentGif = false;

                        throw e;
                    });

    }
    orgLogoUploadStateChanged(state, fromUploaderEvent, resultUrl)
    {
        this.isShowDocumentGif = true;
        if (state === plupload.DONE)
        {
            console.log(this.logoMedia);
            this._changeSaver.getLogoUrldocumentmedia(this.logoMedia).single().toPromise()
                .then(url =>{
                     
                    this.frontLogoImageUrl = url;
                })
                .catch(e => {
                    console.log('Logo error - ' + e.message);
                    this.errorMessage = 'An error was encountered showing the image.';
                   // this.logoUploading = false;
                });
                this.refreshdatadocument();
                
                        
        }
        else if (state === plupload.FAILED)
        {
           // this.logoUploading = false;
            this.errorMessage = 'An error was encountered while uploading your image.  Refresh the page and try again.';

        }
        else
        {
           // this.logoUploading = true;
        }
    };
   
}