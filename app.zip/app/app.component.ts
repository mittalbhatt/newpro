import {Component, ViewContainerRef, ElementRef} from '@angular/core';
import {Overlay} from "angular2-modal";
import {AutoCompleteWorkaround} from "./autoCompleteWorkaround";
import {IntercomRouterTracker} from "./intercomRouterTracker.service";


@Component({
    selector: 'maxweb-app',
    template: `
    <router-outlet></router-outlet>
    `
})
export class AppComponent
{
    constructor(o:Overlay,
                v:ViewContainerRef,
                element:ElementRef,
                acw:AutoCompleteWorkaround,
                intercom:IntercomRouterTracker)
    {
        // globally configure the VC for modals
        o.defaultViewContainer = v;

        acw.install(element);
        intercom.install();
    }
}
