import { Injectable, EventEmitter} from "@angular/core";
import { Observable } from 'rxjs/Observable';

@Injectable()
export class SharedService {
    currentOrgTeamId = new EventEmitter();
    selectedOrgTeam =  new EventEmitter();
    selectSortingParameter =  new EventEmitter();
    tabeventGet = new EventEmitter();
    savePacketData = new EventEmitter();
    constructor() { }
}