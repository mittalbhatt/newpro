System.register(["underscore"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var _;
    var DocumentDocContext;
    return {
        setters:[
            function (_1) {
                _ = _1;
            }],
        execute: function() {
            DocumentDocContext = (function () {
                function DocumentDocContext(_doc) {
                    this._doc = _doc;
                }
                DocumentDocContext.prototype.evaluateDefaultValue = function (expression, fallbackValue, htmlWrapper) {
                    var _this = this;
                    if (fallbackValue === void 0) { fallbackValue = ''; }
                    if (htmlWrapper === void 0) { htmlWrapper = null; }
                    var val = function (ident) {
                        var d = _.find(_this._doc.data, function (d) { return d.ident == ident; });
                        return (d === undefined) ? fallbackValue : (d.value || fallbackValue);
                    };
                    var isSet = function (arr, val) {
                        return _.any(arr, function (item) { return item == val; });
                    };
                    var htmlOpen = '', htmlClose = '';
                    if (htmlWrapper) {
                        htmlOpen = '<' + htmlWrapper + '>';
                        htmlClose = '</' + htmlWrapper + '>';
                    }
                    var parts = expression.split('.');
                    if (parts[0] == 'data') {
                        if (parts.length > 2)
                            return isSet(val(parts[1]), parts[2]);
                        else
                            return htmlOpen + val(parts[1]) + htmlClose;
                    }
                    return null;
                };
                return DocumentDocContext;
            }());
            exports_1("DocumentDocContext", DocumentDocContext);
        }
    }
});
//# sourceMappingURL=document_doc_context.js.map