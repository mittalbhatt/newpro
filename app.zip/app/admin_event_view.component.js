System.register(['@angular/core', 'underscore', './document_loader.service', './registration_context.service', "./documentation_activity_summaries.service", "./assignments.service", "./admin_form_print_modal", "./df_uuid_gen", "./organizations.service", 'angular2-modal', 'angular2-modal/plugins/bootstrap', "@angular/router", "./userProfileCreationModalPrompt.component", "./accessRequestApprovalModal.component", "./user_profiles.service", "./DfObjectId"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, _, document_loader_service_1, registration_context_service_1, documentation_activity_summaries_service_1, assignments_service_1, admin_form_print_modal_1, df_uuid_gen_1, organizations_service_1, angular2_modal_1, bootstrap_1, router_1, userProfileCreationModalPrompt_component_1, accessRequestApprovalModal_component_1, user_profiles_service_1, DfObjectId_1;
    var AdminEventView;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (_1) {
                _ = _1;
            },
            function (document_loader_service_1_1) {
                document_loader_service_1 = document_loader_service_1_1;
            },
            function (registration_context_service_1_1) {
                registration_context_service_1 = registration_context_service_1_1;
            },
            function (documentation_activity_summaries_service_1_1) {
                documentation_activity_summaries_service_1 = documentation_activity_summaries_service_1_1;
            },
            function (assignments_service_1_1) {
                assignments_service_1 = assignments_service_1_1;
            },
            function (admin_form_print_modal_1_1) {
                admin_form_print_modal_1 = admin_form_print_modal_1_1;
            },
            function (df_uuid_gen_1_1) {
                df_uuid_gen_1 = df_uuid_gen_1_1;
            },
            function (organizations_service_1_1) {
                organizations_service_1 = organizations_service_1_1;
            },
            function (angular2_modal_1_1) {
                angular2_modal_1 = angular2_modal_1_1;
            },
            function (bootstrap_1_1) {
                bootstrap_1 = bootstrap_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (userProfileCreationModalPrompt_component_1_1) {
                userProfileCreationModalPrompt_component_1 = userProfileCreationModalPrompt_component_1_1;
            },
            function (accessRequestApprovalModal_component_1_1) {
                accessRequestApprovalModal_component_1 = accessRequestApprovalModal_component_1_1;
            },
            function (user_profiles_service_1_1) {
                user_profiles_service_1 = user_profiles_service_1_1;
            },
            function (DfObjectId_1_1) {
                DfObjectId_1 = DfObjectId_1_1;
            }],
        execute: function() {
            AdminEventView = (function () {
                function AdminEventView(_router, _route, _modal, _assignments, _summaries, _ctx, _docLoader, _organizations, _userProfiles) {
                    var _this = this;
                    this._router = _router;
                    this._route = _route;
                    this._modal = _modal;
                    this._assignments = _assignments;
                    this._summaries = _summaries;
                    this._ctx = _ctx;
                    this._docLoader = _docLoader;
                    this._organizations = _organizations;
                    this._userProfiles = _userProfiles;
                    this.selectedStatusItems = [];
                    this.selectedPrintForms = [];
                    this._orgLogoUploadStateChange = function (s, f, r) { return _this.orgLogoUploadStateChanged(s, f, r); };
                }
                AdminEventView.prototype.ngOnInit = function () {
                    //this.statusSummary = new AthleteDocumentationFormStatusSummary();
                    // this.statusSummary.documentationActivity = {
                    //     _id:"56c7a4e00d8de000bf5bb527",
                    //     type:"Documentation",
                    //     documentationEventDescription:{
                    //         eventName:"2016 Physicals Day",
                    //         coordinatorName:"Hughston Clinic",
                    //         documents:[]
                    //     }
                    // };
                    this.refresh();
                };
                Object.defineProperty(AdminEventView.prototype, "sortField", {
                    get: function () {
                        return this._sortField;
                    },
                    set: function (value) {
                        var _this = this;
                        this.sortDescending = !this.sortDescending;
                        this._sortField = value;
                        var select;
                        switch (value) {
                            case 'athleteDisplayName':
                                select = function (item) { return item.athleteDisplayName; };
                                break;
                            case 'athleteDob':
                                select = function (item) { return item.athleteDob; };
                                break;
                            case 'alerts':
                                select = function (item) { return _this.itemAlertCount(item); };
                                break;
                            case 'accepted':
                                select = function (item) { return item.summaryValues.physicalFormClearedStatus; };
                                break;
                            case 'processed':
                                select = function (item) { return !!item.processedDate; };
                                break;
                        }
                        this.statusItems.sort(function (x, y) {
                            var valueX = select(x);
                            var valueY = select(y);
                            if (valueX !== valueY) {
                                var ret = 0;
                                if (valueX === undefined)
                                    return 1;
                                else if (valueY === undefined)
                                    return -1;
                                else if (typeof valueX == 'string')
                                    ret = valueX.localeCompare(valueY);
                                else
                                    ret = valueX > valueY ? 1 : -1;
                                ret = ret * (_this.sortDescending ? -1 : 1);
                                return ret;
                            }
                            if (x.athleteDisplayName != y.athleteDisplayName)
                                return x.athleteDisplayName.localeCompare(y.athleteDisplayName);
                            else if (x.athleteDob != y.athleteDob && x.athleteDob)
                                return x.athleteDob.localeCompare(y.athleteDob);
                            else
                                return 0;
                        });
                    },
                    enumerable: true,
                    configurable: true
                });
                AdminEventView.prototype.itemAlertCount = function (item) {
                    return _.chain(item.statuses).map(function (s) { return s.fieldsWithAlerts; }).flatten().value().length;
                };
                AdminEventView.prototype.docAlertCount = function (item, docDesc) {
                    var doc = _.find(item.statuses, function (s) {
                        return docDesc.activityId == s.documentDescriptionActivityId;
                    });
                    if (!doc)
                        return 0;
                    return doc.fieldsWithAlerts.length;
                };
                AdminEventView.prototype.itemHasProgress = function (item) {
                    return !!_.chain(item.statuses)
                        .filter(function (d) { return !!d.completedDate; })
                        .map(function (d) { return d.documentDescriptionActivityId; })
                        .intersection(_.pluck(this.statusSummary.documentationActivity.documentationEventDescription.documents, 'activityId'))
                        .value()
                        .length;
                };
                AdminEventView.prototype.docIsComplete = function (item, docDesc) {
                    return !!_.find(item.statuses, function (s) {
                        return (!!s.completedDate) && docDesc.activityId == s.documentDescriptionActivityId;
                    });
                };
                AdminEventView.prototype.toggleDropdown = function ($event, rowId) {
                    $event.preventDefault();
                    $event.stopPropagation();
                    if (this.openDropdown == rowId)
                        delete this.openDropdown;
                    else
                        this.openDropdown = rowId;
                };
                AdminEventView.prototype.itemIsSelected = function (item) {
                    return !!_.find(this.selectedStatusItems, function (i) { return i == item; });
                };
                AdminEventView.prototype.toggleSelectAllForms = function ($event, checked) {
                    $event.stopPropagation();
                    this.selectedPrintForms = checked ? this.statusSummary.documentationActivity.documentationEventDescription.documents.concat() : [];
                };
                AdminEventView.prototype.toggleSelectAllItems = function ($event, checked) {
                    $event.stopPropagation();
                    this.selectedStatusItems = checked ? this.statusItems.concat() : [];
                };
                AdminEventView.prototype.toggleSelectItem = function ($event, item) {
                    $event.stopPropagation();
                    this.selectedStatusItems = this.toggleSelect(item, this.selectedStatusItems);
                };
                AdminEventView.prototype.openForm = function (item, docDesc) {
                    this._router.navigate(['/max-forms/form', item.profileId, this.eventId, item.assignmentId, docDesc.activityId]);
                    // this.$location.path('/dashboard/form/' + this.eventId + '/' + item.profileId + '/' + item.assignmentId + '/' + docDesc.activityId);
                };
                AdminEventView.prototype.addAthlete = function () {
                    var _this = this;
                    var profileId = (new DfObjectId_1.DfObjectId()).toString();
                    var config = angular2_modal_1.overlayConfigFactory(new bootstrap_1.BSModalContext(), bootstrap_1.BSModalContext);
                    this._modal.open(userProfileCreationModalPrompt_component_1.UserProfileCreationModalPrompt, config)
                        .then(function (result) { return result.result; })
                        .then(function (result) {
                        if (!result)
                            throw 'Canceled';
                        var profileTemplate = {
                            _id: profileId,
                            tags: undefined,
                            email: undefined,
                            createdDate: (new Date()).toISOString(),
                            tel: undefined,
                            pendingSports: undefined,
                            state: undefined,
                            org: _this.statusSummary.org._id,
                            firstName: result.firstName,
                            sortFirstName: (result.firstName || '').toLowerCase(),
                            sortLastName: (result.lastName || '').toLowerCase(),
                            lastName: result.lastName,
                            orgRoles: ['MGA', 'SUB', 'ATH'],
                            createdByAdminForForms: true
                        };
                        var profile = new user_profiles_service_1.UserProfile(profileTemplate);
                        var save = function () { return _this._userProfiles.createProfile(profile).single().toPromise(); };
                        config = angular2_modal_1.overlayConfigFactory({ pendingProfile: profile, save: save }, accessRequestApprovalModal_component_1.AccessRequestApprovalData);
                        return _this._modal.open(accessRequestApprovalModal_component_1.AccessRequestApprovalModal, config);
                    })
                        .then(function (result) { return result.result; })
                        .then(function (result) {
                        return result ? _this._assignments.submitAdministratively(_this.statusSummary.documentationAssignment._id, _this.statusSummary.documentationActivity._id, profileId).single().toPromise() : null;
                    })
                        .then(function (result) {
                        if (result)
                            _this.refresh();
                    })
                        .catch(function (e) { return console.log(e); });
                };
                AdminEventView.prototype.onOpenPrintWindow = function () {
                    var _this = this;
                    var adminFormPrintModalData = new admin_form_print_modal_1.AdminFormPrintModalData(this.statusSummary.documentationActivity.documentationEventDescription.documents, this.selectedStatusItems.concat(), this.statusItems);
                    var config = angular2_modal_1.overlayConfigFactory(adminFormPrintModalData, admin_form_print_modal_1.AdminFormPrintModalData);
                    this._modal.open(admin_form_print_modal_1.AdminFormPrintModal, config)
                        .then(function (dialogRef) {
                        dialogRef.result.then(function (ids) {
                            if (ids)
                                _this.onPrint(ids);
                        });
                    });
                };
                AdminEventView.prototype.onPrint = function (ids) {
                    var _this = this;
                    this.printing = true;
                    this.errorMessage = '';
                    if (ids.length < 1) {
                        this.printing = false;
                        this.errorMessage = 'The selected athlete(s) have not filled out any of the selected forms.';
                        return;
                    }
                    this._docLoader.openBulkPdf(ids, window).then(function () {
                        _this.printing = false;
                        console.log('success');
                    }).catch(function (error) {
                        _this.printing = false;
                        console.error(error);
                        _this.errorMessage = 'We encountered an error printing.  Please try again.';
                    });
                };
                AdminEventView.prototype.onClickPrintDocRow = function ($event, doc) {
                    this.selectedPrintForms = this.toggleSelect(doc, this.selectedPrintForms);
                };
                AdminEventView.prototype.formIsPrintSelected = function (doc) {
                    return !!_.find(this.selectedPrintForms, function (d) { return d == doc; });
                };
                AdminEventView.prototype.orgLogoUploadStateChanged = function (state, fromUploaderEvent, resultUrl) {
                    var _this = this;
                    if (state === plupload.DONE) {
                        console.log('UPLOAD DONE');
                        this._organizations.getLogoUrl(this.statusSummary.org).single().toPromise()
                            .then(function (url) {
                            _this.logoImageUrl = url;
                            _this.logoUploading = false;
                        })
                            .catch(function (e) {
                            console.log('Logo error - ' + e.message);
                            _this.errorMessage = 'An error was encountered showing the image.';
                            _this.logoUploading = false;
                        });
                    }
                    else if (state === plupload.FAILED) {
                        this.logoUploading = false;
                        this.errorMessage = 'An error was encountered while uploading your image.  Refresh the page and try again.';
                    }
                    else {
                        this.logoUploading = true;
                    }
                };
                ;
                AdminEventView.prototype.toggleSelect = function (item, items) {
                    var match = _.find(items, function (i) { return i == item; });
                    if (!match)
                        items.push(item);
                    else
                        items = items.filter(function (i) { return i != item; });
                    return items;
                };
                AdminEventView.prototype.refresh = function () {
                    var _this = this;
                    this.loading = true;
                    this.eventId = this._route.snapshot.params['eventId'];
                    this._summaries.getSummary(this.eventId)
                        .single()
                        .subscribe(function (summary) {
                        _this.loading = false;
                        _this.statusSummary = summary;
                        _this.eventName = _this.statusSummary.documentationActivity.documentationEventDescription.eventName;
                        _this.statusItems = _this.statusSummary.items;
                        _this.selectedStatusItems = [];
                        var baseUrl = 'http://dragonflymax.com/forms/';
                        _this.athleteUrl = baseUrl + (summary.org.formsShortcut || summary.org.shortCode);
                        _this.sortDescending = true; // will be reversed in the sortField setter
                        _this.sortField = 'athleteDisplayName';
                        _this._ctx.docAct = _this.statusSummary.documentationActivity;
                        _this.logoUploadSettings = {
                            getFileParams: function (file) {
                                var fileId = df_uuid_gen_1.DfUuidGen.newUuid();
                                var logoMedia = _this._organizations.getLogoMedia(_this.statusSummary.org, true);
                                logoMedia.createdDate = new Date();
                                logoMedia.contentType = file.type;
                                logoMedia.mediaId = fileId;
                                return _this._organizations.update(_this.statusSummary.org._id, { $set: { media: _this.statusSummary.org.media } }).single().toPromise()
                                    .then(function () {
                                    return {
                                        fileId: fileId,
                                        orgId: _this.statusSummary.org._id,
                                        paramsUrl: "/training/api/organizations/" + _this.statusSummary.org._id + "/media/" + encodeURIComponent(fileId)
                                    };
                                });
                            },
                            dfUploadTag: 'org-logo-' + _this.statusSummary.org._id,
                            uploaderSettings: {
                                filters: {
                                    max_file_size: '10mb',
                                    mime_types: [
                                        { title: "Image files", extensions: "jpeg,jpg,gif,png" }
                                    ]
                                },
                                resize: {
                                    width: 600,
                                    height: 600
                                }
                            }
                        };
                        console.log(_this.statusSummary.org);
                        _this._organizations.getLogoUrl(_this.statusSummary.org).single().toPromise()
                            .then(function (url) {
                            _this.logoImageUrl = url;
                        })
                            .catch(function (e) {
                            console.log(e);
                            _this.errorMessage = 'An error was encountered showing the org logo.';
                        });
                    }, function (error) {
                        console.log(error);
                        _this.loading = false;
                        _this.errorMessage = 'An error occurred.  Please refresh the page. (' + error.status + ')';
                        throw error;
                    });
                };
                AdminEventView = __decorate([
                    core_1.Component({
                        selector: 'admin-event-view',
                        providers: [documentation_activity_summaries_service_1.DocumentationActivitySummaries, assignments_service_1.Assignments, organizations_service_1.Organizations, registration_context_service_1.RegistrationContext, document_loader_service_1.DocumentLoader],
                        template: "\n    <div *ngIf=\"errorMessage\" class=\"alert alert-danger\">{{errorMessage}}</div>\n    <h1 *ngIf=\"loading\">Loading...</h1>\n    <div *ngIf=\"!loading\" (click)=\"openDropdown = undefined\" style=\"text-align:left;\">\n        <div style=\"max-width:800px; margin:0 auto\">\n                <div class=\"hidden-xs\">\n                    <a href=\"javascript:void(0)\" style=\"float:right\" class=\"btn btn-default\" (click)=\"refresh()\"><span class=\"glyphicon glyphicon-refresh\"></span></a>\n                    <a href=\"javascript:void(0)\" style=\"float:right; margin-right:5px;\" class=\"btn btn-default\" (click)=\"addAthlete()\"><span class=\"glyphicon glyphicon-plus\"></span> Add Athlete</a>\n                    <button style=\"margin-right:5px; float:right\" type=\"button\" class=\"btn btn-primary\" (click)=\"onOpenPrintWindow()\">\n                        <span *ngIf=\"!printing\" class=\"glyphicon glyphicon-print\"></span><img [hidden]=\"!printing\" src=\"/maxweb/app/media/ajax-loader-white.gif\" /> Print\n                    </button>\n                </div>\n                \n                <div class=\"visible-xs\" style=\"text-align:center; margin-bottom:10px;\">\n                    <button style=\"margin-right:5px;\" type=\"button\" class=\"btn btn-primary\" (click)=\"onOpenPrintWindow()\">\n                        <span *ngIf=\"!printing\" class=\"glyphicon glyphicon-print\"></span><img [hidden]=\"!printing\" src=\"/maxweb/app/media/ajax-loader-white.gif\" /> Print\n                    </button>\n                    \n                    <a href=\"javascript:void(0)\" style=\"margin-right:5px;\" class=\"btn btn-default\" (click)=\"addAthlete()\"><span class=\"glyphicon glyphicon-plus\"></span> Add Athlete</a>\n                    \n                    <a href=\"javascript:void(0)\" class=\"btn btn-default\" (click)=\"refresh()\"><span class=\"glyphicon glyphicon-refresh\"></span></a>\n                </div>\n        \n                <div style=\"text-align:center; width:150px; min-height:110px; float:left; margin-right:10px; cursor:pointer;\" df-pl-upload-host [targetTooltip]=\"'Team Logo'\" [uploadSettings]=\"logoUploadSettings\" [uploadStateChanged]=\"_orgLogoUploadStateChange\">\n                    <img style=\"max-width:150px; max-height:100px;\" [src]=\"(logoImageUrl && !logoUploading) ? logoImageUrl : '/maxweb/app/media/placeholder.png'\" />       \n                    <p [hidden]=\"logoImageUrl || logoUploading\" style=\"margin-top:-60px; text-align:center; font-size:12px; color:#428bca;\">Click to upload team logo</p>\n                    <p *ngIf=\"logoUploading\" style=\"margin-top:-60px; text-align:center; color:#428bca\">Uploading logo...</p>\n                    <!--<img [hidden]=\"!logoUploading\" src=\"/mgmt/app/img/ajax-loader-white.gif\" />-->\n                </div>\n                <div style=\"text-align:left\">\n                    <h3 style=\"font-weight:normal; margin-left:20px; margin-bottom:0px\">{{eventName}}</h3>\n                    <h4 style=\"font-weight:bolder; margin-top:2px; color:#808080\">{{statusSummary.org.name}}</h4>\n                </div>\n                <table>\n                    <tr><td style=\"font-weight:bold; text-align:right\">Your School Code</td><td style=\"padding-left:30px; font-weight:bold; color:#3f48cc\">{{statusSummary.org.shortCode}}</td></tr>\n                    <tr><td style=\"font-weight:bold; text-align:right\">Forms Link</td><td style=\"padding-left:30px;\">{{athleteUrl}}</td></tr>\n                </table>\n                <br />\n         </div>\n        <table class=\"table table-hover\" style=\"max-width:800px; margin:0 auto\">\n            <tr>\n                <th width=\"20\"></th>\n                <th width=\"20\"><input #chk type=\"checkbox\" (click)=\"toggleSelectAllItems($event, chk.checked)\" /></th>\n                <th width=\"*\">\n                    <a href=\"javascript:void(0)\" (click)=\"sortField = 'athleteDisplayName'\">\n                    Name\n                    <span *ngIf=\"(sortField == 'athleteDisplayName') && sortDescending\" class=\"glyphicon glyphicon-circle-arrow-down\"></span>\n                    <span *ngIf=\"(sortField == 'athleteDisplayName') && !sortDescending\" class=\"glyphicon glyphicon-circle-arrow-up\"></span>\n                    </a>\n                </th>\n                <th width=\"100\">\n                    <a href=\"javascript:void(0)\" (click)=\"sortField = 'alerts'\">\n                        <span style=\"color:red; font-size:20px;\" class=\"glyphicon glyphicon-exclamation-sign\"></span>\n                        <span *ngIf=\"(sortField == 'alerts') && sortDescending\" class=\"glyphicon glyphicon-circle-arrow-down\"></span>\n                        <span *ngIf=\"(sortField == 'alerts') && !sortDescending\" class=\"glyphicon glyphicon-circle-arrow-up\"></span>\n                    </a>\n                </th>\n                <th width=\"150\">\n                    <a href=\"javascript:void(0)\" (click)=\"sortField = 'athleteDob'\">\n                    DOB\n                    <span *ngIf=\"(sortField == 'athleteDob') && sortDescending\" class=\"glyphicon glyphicon-circle-arrow-down\"></span>\n                    <span *ngIf=\"(sortField == 'athleteDob') && !sortDescending\" class=\"glyphicon glyphicon-circle-arrow-up\"></span>\n                    </a>\n                </th>\n                <th width=\"100\">\n                    <a href=\"javascript:void(0)\" (click)=\"sortField = 'accepted'\">\n                    Cleared\n                    <span *ngIf=\"(sortField == 'accepted') && sortDescending\" class=\"glyphicon glyphicon-circle-arrow-down\"></span>\n                    <span *ngIf=\"(sortField == 'accepted') && !sortDescending\" class=\"glyphicon glyphicon-circle-arrow-up\"></span>\n                    </a>\n                </th>\n            </tr>\n            <tr style=\"cursor:pointer\" *ngFor=\"let item of statusItems; let i = index\" (click)=\"toggleDropdown($event,'row'+i)\">\n                <td><strong>{{i+1}}</strong></td>\n                <td>\n                    <input type=\"checkbox\" (click)=\"toggleSelectItem($event, item)\" [checked]=\"itemIsSelected(item)\" />\n                </td>\n                <td>\n                    {{item.athleteDisplayName}}\n                     <div dropdown autoClose=\"outsideClick\" [isOpen]=\"openDropdown == 'row'+i\">\n                         <ul class=\"dropdown-menu\">\n                            <li role=\"menuitem\" *ngFor=\"let docDesc of statusSummary.documentationActivity.documentationEventDescription.documents\">\n                                <a href=\"javascript:void(0)\" (click)=\"openForm(item, docDesc)\" class=\"dropdown-item\">\n                                    <span *ngIf=\"!docIsComplete(item, docDesc)\" class=\"glyphicon glyphicon-unchecked\"></span>\n                                    <span *ngIf=\"docIsComplete(item, docDesc)\" style=\"color:green\" class=\"glyphicon glyphicon-check\"></span>\n                                    {{docDesc.name}}\n                                    <span *ngIf=\"docAlertCount(item, docDesc)\" [style.background]=\"docAlertCount(item, docDesc) > 0 ? 'red' : 'grey'\" class=\"badge\">{{docAlertCount(item, docDesc)}}</span>\n                                </a>\n                            </li>\n                        </ul>\n                    </div>\n                </td>\n                <td>\n                      <span [style.background]=\"itemAlertCount(item) > 0 ? 'red' : 'grey'\" class=\"badge\">{{itemAlertCount(item)}}</span>              \n                </td>\n                <td>{{item.athleteDob?.substr(0,10)}}</td>\n                <td style=\"text-align:center\" [ngSwitch]=\"item.summaryValues.physicalFormClearedStatus\">\n                    <template ngSwitchDefault>\n                        <span class=\"glyphicon glyphicon-unchecked\"></span>\n                    </template>\n                    <template [ngSwitchCase]=\"'a_cleared'\">\n                        <span class=\"glyphicon glyphicon-check\" style=\"color:green\"></span>\n                    </template>\n                    <template [ngSwitchCase]=\"'b_clearedWithEval'\">\n                        <span style=\"color:gold\">*</span>&nbsp;<span class=\"glyphicon glyphicon-check\" style=\"color:gold\"></span>\n                    </template>\n                    <template [ngSwitchCase]=\"'c_notCleared'\">\n                        <span class=\"glyphicon glyphicon-ban-circle\" style=\"color:red\"></span>\n                    </template>\n                </td>\n            </tr>\n        </table>\n    </div>\n    "
                    }), 
                    __metadata('design:paramtypes', [router_1.Router, router_1.ActivatedRoute, bootstrap_1.Modal, assignments_service_1.Assignments, documentation_activity_summaries_service_1.DocumentationActivitySummaries, registration_context_service_1.RegistrationContext, document_loader_service_1.DocumentLoader, organizations_service_1.Organizations, user_profiles_service_1.UserProfiles])
                ], AdminEventView);
                return AdminEventView;
            }());
            exports_1("AdminEventView", AdminEventView);
        }
    }
});
//# sourceMappingURL=admin_event_view.component.js.map