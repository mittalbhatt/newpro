import {Injectable} from "@angular/core";
import {Http, Response} from "@angular/http";
import {DocumentationActivity} from "./documentation_activity";

@Injectable()
export class Activities {
    constructor(
        private _http:Http
    ) { }

    getDocumentationActivities(orgId?:string, id?:string, limit:number=100) {
        var url = '/training/api/activities?type=Documentation&limit='+limit;
        if (orgId)
            url += `&$filter.0.orgId=ObjectId(${orgId})`;
        if (id)
            url += `&$filter.1._id=ObjectId(${id})`;

        return this._http.get(url)
            .map((res:Response) => <DocumentationActivity[]>res.json());
    }
}