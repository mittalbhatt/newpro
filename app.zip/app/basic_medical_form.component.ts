import {Router, ActivatedRoute, ActivatedRouteSnapshot, CanDeactivate, RouterStateSnapshot} from "@angular/router";
import {UserProfiles, UserProfile} from "./user_profiles.service";
import {RegistrationContext} from "./registration_context.service";
import {
    Component, OnInit, OnDestroy, Input, ViewChild,
    HostListener, ElementRef
} from "@angular/core";
import {Documents} from "./document_factory.service";
import {
    DocumentationDocument,
    DocumentDescriptionFormatSection,
    DocumentDescriptionFormatSectionField,
    DocumentationDocumentData,
    HideableDocumentElement
} from "./documentation_document";
import * as _ from "underscore";
import {DocumentChangeSaver} from "./document_change_saver.service";
import {BasicMedicalSaver} from "./basic_medical_saver.service";

import {Pipe, PipeTransform} from '@angular/core';
import {MaxAppContext} from "./maxAppContext.service";
import {IntercomRouterTracker} from "./intercomRouterTracker.service";
import {RelationComponent} from "./relationdata.component";
import {Helper} from "./helper.service";
import {DfObjectId} from "./DfObjectId";
declare var store: any;

@Pipe({ name: 'dataItem' })
export class BasicMedicalPipe implements PipeTransform {
    static lookupValue(ident: string, data: any[], cache: any) {
        var value = cache[ident];
        return value ? value.value : undefined;
    }

    static lookupTextValue(ident: string, data, cache: any) {
        var ret = BasicMedicalPipe.lookupValue(ident, data, cache);
        if (!ret)
            ret = "";
        return ret;
    }

    transform(value: any[], ident: string, cache: any): any {
        return BasicMedicalPipe.lookupTextValue(ident, value, cache);
    }
}

@Component({
    selector: 'basic-medical-form',
    templateUrl: '/maxweb/app/app/basic_medical_form.component.html',
})

export class BasicMedicalForm implements OnInit, OnDestroy {
    private _documentDescriptionActivity: string;
    private _assignmentId: string;

    document: DocumentationDocument;
    documentSections: DocumentDescriptionFormatSection[];
    errorMessage: string;
    validationErrors: any;
    validationSummary: string;
    submitting: boolean;
    printing: boolean;
    loading: boolean;
    pdfUrl: string;
    packetActivityId: string;

    subjectProfileId: string;
    subjectProfile: UserProfile;

    files: any;
    file: any;
    filename: string = '';
    addmoreaddress: boolean = false;
    index: number = 0;
    valdata: string = '';
    targetVal: string = '';
    // should be able to specify @Input('viewer-as-admin') to have a better parameter name, but that's not working with ngUpgrade
    @Input() admin: boolean;
    @ViewChild(RelationComponent) relationData: RelationComponent;
    @ViewChild('leftMenu') leftMenu: ElementRef;
    stickMenu: boolean;
    startingMenuOffset: number;

    dataCache: any = {};
    //use for email/phone
    emailArray: any = [];
    phoneArray: any = [];
    errorclassemail: any = [];
    errorclassphone: any = [];
    firstname: any = [];
    lastname: any = [];


    //use for relation
    relationArray: any = [];
    relationObject: any;
    initRelationObj: any = { "firstName": "", "lastName": "", "rel": "", "tel": [], "address": "", "city": "", "state": "", "zip": "", "email": "" };
    profileId: string;
    sitesearch: any = null;
    phoneArrayrelation: any = [];
    teldata: any;

    filedSection = [];
    documentSectionsaddress: any;

    msgClassName: string = "";
    //successMessage: string = "";
    timer: any;
    _amrId: any;
    userprofileImage: any;
    scrollClass: string = '';
    isLoader: boolean = false;
    isLoaderInsurence: boolean = false;
    //use for checkbox arry medical conditions
    medicalmainIdent: any = ["Asthma", "Anemia", "Diabetes", "Infections"];
    existingMedicalConditionarry: any = [];
    checkmedicalCondition: any = [];
    othervalmedicalCondition: any = [];

    //use for checkbox arry allergies
    existingallergiesarry: any = [];
    allergiesmainIdent: any = ["Medicines", "Pollens", "Food", "Stinging Insects"];
    checkallergies: any = [];
    othervalallergies: any = [];

    //use for chekbox arry heartProblemsList
    existinheartProblemsarry: any = [];
    heartProblemsmainIdent: any = ["High blood pressure", "High cholesterol", "Kawasaki disease", "A heart murmur", "A heart infection"];
    checkheartProblems: any = [];
    othervalheartProblems: any = [];
    relationCount: any;
    destroyCheckValues:boolean = false;
    relationerror:boolean=false;
    currentuserFname:string;
    currentuserLname:string;
    profile:any;
    parentImageurl:any;
    isLinkedAccount:boolean=false;

    

    constructor(
        private _ctx: RegistrationContext,
        private _appCtx: MaxAppContext,
        private _router: Router,
        private _route: ActivatedRoute,
        private _documents: Documents,
        private _userProfiles: UserProfiles,
        private _changeSaver: BasicMedicalSaver,
        private _intercom: IntercomRouterTracker,
        private _helper: Helper
    ) {
        this.validationErrors = {};

        this._changeSaver.status.subscribe(status => {
            if (!status.saved) {
                this.handleError(status.response);
            }
        });

        this._userProfiles.updateRelativeData.subscribe(res => {
            this.isLoader = false;
            if (!res.data) {
                this.handleError(res.data);
            }
        });

        store.session('BasicMedicalRedirectURL', '/max-forms/packetList');
    }

    @HostListener('window:scroll')
    onScroll() {

        this.stickMenu = document.body.scrollTop > this.startingMenuOffset - 5; // 5 matches the 'top' setting in the .left-menu-stick css class

        if (document.body.scrollTop > 0) {
            this.scrollClass = "boza-athlete-fix";
        } else {
            this.scrollClass = "";
        }
    }

    ngOnDestroy() {
        this._changeSaver.stop();
        store.session('BasicMedicalRedirectURL', '');
        this.checkboxarraymaintain(this.documentSections, true);
    }

    ngOnInit() {
        //this.startingMenuOffset = this.leftMenu.nativeElement.offsetTop;
        this.filedSection = this._helper.basicMedicalFiledSection;
        this.refresh();
    }

    changeDataFunction() { // I want to call this function
        this.relationData.unsaveData = true;
    }

    get gradYearOptions(): string[] {
        var currentYear = (new Date()).getFullYear();
        return _.range(currentYear, currentYear + 13).map(i => i.toString());
    }

    get stateOptions(): string[] {
        var stateObj = this._appCtx.getStates();
        return _.chain(stateObj)
            .flatten()
            .value();
    }

    get parentOptions(): string[] {
        var stateObj = this._appCtx.getParents();
        return _.chain(stateObj)
            .flatten()
            .value();
    }

    get flaggedFields(): DocumentDescriptionFormatSectionField[] {
        return _.chain(this.documentSections)
            .pluck('fields')
            .flatten()
            .filter((f: DocumentDescriptionFormatSectionField) => {
                return f.flagIf !== undefined && this.lookupValue(f.ident) === f.flagIf;
            })
            .value();
    }

    showIfAllFields(section: DocumentDescriptionFormatSection, field: DocumentDescriptionFormatSectionField) {

        let currentSection = this.documentSections.filter((f) => {
            return f.name !== undefined && f.name === section.name;
        });

        var Obj = _.chain(currentSection)
            .pluck('fields')
            .flatten()
            .filter((f: DocumentDescriptionFormatSectionField) => {
                if (f.showIfAll != undefined) {
                    return (f.showIfAll != undefined && _.every(f.showIfAll,
                        (ff: DocumentationDocumentData) =>
                            ((this.lookupValue(ff.ident) == true || this.lookupValue(ff.ident) == 1) && ff.ident === field.ident)
                    ))
                }
            })
            .map(i => i)
            .value();

        return Obj;
    }

    get sectionsWithShortcuts() {
        if (!this.documentSections)
            return [];

        return this.documentSections.filter(ds => !!ds.shortcutName && !this.shouldHideHideable(ds));
    }

    fieldHasFormAlert(field: DocumentDescriptionFormatSectionField) {
        return (this.admin && (field.flagIf !== undefined) && (field.flagIf === this.lookupValue(field.ident)));
    }

    explainText(field: DocumentDescriptionFormatSectionField) {
        return field.explanationPrompt ? field.explanationPrompt : 'Please explain: ';
    }

    lookupValue(ident: string) {
        if (!this.document)
            return undefined;
        return BasicMedicalPipe.lookupValue(ident, this.document.data, this.dataCache);
    }

    lookupTextValue(ident: string) {
        return BasicMedicalPipe.lookupTextValue(ident, this.document.data, this.dataCache);
    }



    addmoreRelation() {
        this.relationArray = [];
        this.initRelationObj = { "firstName": "", "lastName": "", "rel": "", "tel": [], "address": "", "city": "", "state": "", "zip": "", "email": "" };
        this.phoneArrayrelation = [{ phone: "" }];
        this.relationArray.push(this.initRelationObj);
    }

    // add more textboxez on type email/phone
    changeEventField(type: string, event: any, index: any) {
        if (event.length > 0) {
            if (type == 'phone') {
                var length = this.phoneArray.length;
            } else {
                var length = this.emailArray.length;
            }
            if ((length - 1) === index) {
                this.addmoreData(type);
            }
        }
    }

    //use for email/phone
    addmoreData(type: string) {
        if (type == 'email') {
            this.emailArray.push({ email: '' });
        }
        else if (type == 'phone') {
            this.phoneArray.push({ phone: '' });

        } else if (type == 'phonerelation') {
            this.phoneArrayrelation.push({ phone: '' })
        }

    }

    removeData(i: number, type: string) {
        if (type == 'email') {
            this.emailArray.splice(i, 1);
            var a = _.pluck(this.emailArray, "email");
            a = a.filter(function (a) { return a != "" });
            this.updateValue("info.email", a);
        } else if (type == 'phone') {
            this.phoneArray.splice(i, 1);
            var a = _.pluck(this.phoneArray, "phone");
            a = a.filter(function (a) { return a != "" });
            this.updateValue("info.tel", a);
        }
    }

    saveData(event: any, type: string, index: any) {
        var eventVal = "";
        if (type == 'email') {
            //let EMAIL_REGEXP = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
            if (event.type !== undefined && event.type === 'blur') {
                eventVal = event.target.value;
            }
            else {
                eventVal = event;
            }
            this.changeEventField(type, eventVal, index);
            //if (EMAIL_REGEXP.test(eventVal)) {
            if (eventVal.length > 0) {
                this.errorclassemail[index] = 'false';

                var a = _.pluck(this.emailArray, "email");
                a = a.filter(function (a) { return a != "" });
                if (event.type !== undefined && event.type === 'blur') {
                    this.updateValue("info.email", a);
                }
            } else {
                this.errorclassemail[index] = 'true';
            }
        } else if (type == 'phone') {
            //let PHONE_REGEXP = /^[0-9\-+\)\(]+$/;
            if (event.type !== undefined && event.type === 'blur') {
                eventVal = event.target.value;
            }
            else {
                eventVal = event;
            }
            this.changeEventField(type, eventVal, index);
            //if (PHONE_REGEXP.test(eventVal)) {
            if (eventVal.length > 0) {
                this.errorclassphone[index] = 'false';

                var a = _.pluck(this.phoneArray, "phone");

                a = a.filter(function (a) { return a != "" });
                if (event.type !== undefined && event.type === 'blur') {
                    this.updateValue("info.tel", a);
                }
            } else {
                this.errorclassphone[index] = 'true';
            }
        }
        return false;
    }


    onYesNo(ident: string, answer: boolean) {
        this.updateValue(ident, answer);
        // if (answer === 0)
        //     this.updateValue(ident + '_explanation', '');
    }

    onTextChange(ident: any, event: any, mainIdent: string = null) {
        delete this.validationErrors[mainIdent];
        this.targetVal = event.target.value;
        if (this.dataCache[ident] != undefined && this.dataCache[ident].value != this.targetVal) {
            this.updateValue(ident, this.targetVal);
        }
        else if (this.dataCache[ident] == undefined) {
            this.updateValue(ident, this.targetVal);
        }
    }

    onNumberChange(ident: any, event: any, mainIdent: string = null) {
        delete this.validationErrors[mainIdent];
        this.updateValue(ident, event.target.value);
    }

    onSelect(ident: any, event: any, mainIdent: string = null) {
        delete this.validationErrors[mainIdent];
        this.updateValue(ident, event.target.value, 'select');
    }

    onSelectMultiCheckChange(ident: string, option: string, event: any) {
        this.updateListValue(ident, option, event.target.checked);
    }

    valueArrayContains(ident: string, elemValue: any) {
        if (!this.document)
            return false;

        var value = _.find(this.document.data, d => d.ident == ident);
        if (value)
            return _.contains(value.value, elemValue);

        return false;
    }

    checkboxvalueContains(arrytype: any, compairarry: any, event: any, mainIdent: string = null, name: any) {
        if (event.type !== undefined && event.type === 'blur') {
            var eventVal = event.target.value;
            var other = _.difference(arrytype, compairarry);
            if (other.length > 0) {
                var ind = _.indexOf(arrytype, other[0]);
                arrytype[ind] = eventVal;
            } else {
                arrytype.push(eventVal);
            }
        } else {
            if (event == true) {
                arrytype.push(name);
                arrytype = _.uniq(arrytype);
            }
            else {
                var ind = _.indexOf(arrytype, name);
                arrytype.splice(ind, 1);
            }
        }
        var arr = arrytype.filter(function (n) { return n != "" });
        delete this.validationErrors[mainIdent];
        this.updateValue(mainIdent, arr);
    }

    onSelectCheckboxChange(ident: string, event: any, mainIdent: string = null, name: any, index: any) {
        if (mainIdent == 'info.medicalConditionsList') {
            this.checkboxvalueContains(this.existingMedicalConditionarry, this.medicalmainIdent, event, mainIdent, name);
            delete this.validationErrors[ident];
        } else if (mainIdent == 'info.allergiesList') {
            this.checkboxvalueContains(this.existingallergiesarry, this.allergiesmainIdent, event, mainIdent, name);
            delete this.validationErrors[ident];
        } else if (mainIdent == 'info.heartProblemsList') {
            this.checkboxvalueContains(this.existinheartProblemsarry, this.heartProblemsmainIdent, event, mainIdent, name);
            delete this.validationErrors[ident];
        }
        else {
            delete this.validationErrors[mainIdent];
            this.updateValue(ident, event.target.checked);
        }
    }

    updateValue(ident: string, value: any, inputType = '') {

        delete this.validationErrors[ident];
        var item = _.find(this.document.data, d => d.ident == ident);

        this._changeSaver.addChange({ ident: ident, value: value });
        if (item) {
            item.value = value;
        }
        else {
            this.document.data.push({ ident: ident, value: value });
        }

        this.dataCache[ident] = { ident: ident, value: value };
    }

    updateListValue(ident: string, value: any, included: boolean) {
        var item = _.find(this.document.data, d => d.ident == ident);
        if (!item) {
            item = { ident: ident, value: [] };
            this.document.data.push(item);
        }

        if (included)
            item.value = _.union(item.value, [value]);
        else
            item.value = _.difference(item.value, [value]);

        this._changeSaver.addChange({ ident: ident, value: item.value });

        this.dataCache[ident] = { ident: ident, value: item.value };
    }

    goToSection(name: string) {
        this.scrollIntoView(name);
    }

    goToField(ident: string) {
        this.scrollIntoView(ident);
    }

    private scrollIntoView(id: string) {
        document.getElementById(id).scrollIntoView();

        if (this.admin) {
            // Account for name floating at top.
            window.scrollBy(0, -100);
        }
    }

    shouldHideHideable(field: HideableDocumentElement) {
        return field.showIfAll && !_.every(field.showIfAll, f => this.lookupValue(f.ident) === f.value || (f.value == false && this.lookupValue(f.ident) === undefined));
    }

    valueIsNullUndefinedOrEmpty(ident) {
        var val = this.lookupValue(ident);
        if (val && val.trim)
            val = val.trim();

        return !val && (val !== false);
    }

    onClickReviewPdfPages(field) {
        this.onYesNo(field.ident, true);
    }

    onPrint() {
        var win = window.open(`/maxweb/app/media/spinner.html`);

        this._changeSaver.stop();
        this._changeSaver.saveNow().single().toPromise()
            .then(() => {
                this._changeSaver.start(this._amrId, this.profileId);
                win.location.assign(this.pdfUrl);
            })
            .catch(e => {
                win.close();
                this._changeSaver.start(this._amrId, this.profileId);
                this.handleError(e, 'We encountered an error saving your changes. Please refresh and try again.');
            });
    }

    getRequiredUnfilled(sections) {

        var requiredUnfilled = _.chain(sections)
            .pluck('fields')
            .flatten()
            .filter(f => {
                return (f.required || (f.requireIfAll && _.every(f.requireIfAll, (ff: DocumentationDocumentData) => (this.lookupValue(ff.ident) === ff.value) || (ff.value === 'Female' && this.lookupValue(ff.ident) === 'Female') || ((ff.value == false || ff.value == 0) && this.lookupValue(ff.ident) === undefined))))
                    && (this.valueIsNullUndefinedOrEmpty(f.ident) || this.lookupTextValue(f.ident) == "") && (this.lookupValue(f.ident) !== false && this.lookupValue(f.ident) !== 0);
            })
            .pluck('ident')
            .value();

        var showIfAllRequiredUnfulfilled = _.chain(sections)
            .pluck('fields')
            .flatten()
            .filter(f => {
                return (f.showIfAll && _.every(f.showIfAll,
                    (ff: DocumentationDocumentData) =>
                        (this.lookupValue(ff.ident) == true || this.lookupValue(ff.ident) == 1)
                )) && ((this.lookupValue(f.ident) == 0 || this.lookupValue(f.ident) == false) || this.lookupTextValue(f.ident) == "")
            })
            .pluck('showIfAll')
            .map(i => i[0].ident + "_" + i[0].fieldsCount)
            .value();



        var explanationsRequiredUnfulfilled = _.chain(sections)
            .pluck('fields')
            .flatten()
            .filter(f => {
                return f.explanationRequired && (this.lookupValue(f.ident) == true || this.lookupValue(f.ident) == 1) && this.valueIsNullUndefinedOrEmpty(f.ident + '_explanation')
            })
            .pluck('ident')
            .map(i => i + '_explanation')
            .value();

        var showIfAllRequiredUnfulfilledUnique = showIfAllRequiredUnfulfilled.filter(function (item, pos, self) {
            var count = pos - (self.indexOf(item));
            var fieldCount = item.slice(-1);
            if (Number(fieldCount) == count && self.lastIndexOf(item) == pos) {
                return item;
            }
            else {
                return false;
            }
        }).map(ident =>
            ident.substring(0, ident.length - 2)
            );

        //requiredUnfilled = requiredUnfilled.concat(showIfAllRequiredUnfulfilledUnique);
        requiredUnfilled = requiredUnfilled.concat(explanationsRequiredUnfulfilled);
        requiredUnfilled.forEach(ident => this.validationErrors[ident] = true);

        return requiredUnfilled;
    }


    applyValidations(type: boolean = false) {

        this.validationErrors = {};
        this.validationSummary = null;

        var requiredUnfilled = this.getRequiredUnfilled(this.documentSections);

        if (type == true) {
            if (requiredUnfilled.length) {
                var summary = requiredUnfilled.length > 1 ? 'There are' : 'There is';
                summary += ' ' + requiredUnfilled.length + ' ';
                summary += requiredUnfilled.length > 1 ? 'fields' : 'field';
                summary += ' that you haven\'t filled in. Look for the fields marked in red.';
                this.validationSummary = summary;
                window.scrollTo(0, 0);
                return;
            }
        }

        var requiredResponseNotMatching = _.chain(this.documentSections)
            .pluck('fields')
            .flatten()
            .filter(f => {
                return f.requiredResponse !== undefined && !_.isEqual(this.lookupValue(f.ident), f.requiredResponse);
            })
            .pluck('ident')
            .value();

        requiredResponseNotMatching.forEach(ident => this.validationErrors[ident] = true);

        if (type == true) {
            if (requiredResponseNotMatching.length) {
                var summary = requiredResponseNotMatching.length > 1 ? 'There are' : 'There is';
                summary += ' ' + requiredResponseNotMatching.length + ' ';
                summary += requiredResponseNotMatching.length > 1 ? 'fields' : 'field';
                summary += ' that does not contain the required response.  Look for the fields marked in red.';
                this.validationSummary = summary;
                window.scrollTo(0, 0);
                return;
            }
        }
    }

    getRequireFieldCount(section) {
        let mainSection = this.documentSections.filter((f) => {
            return f.name !== undefined && f.name === section.name;
        });

        var requiredUnfilled = this.getRequiredUnfilled(mainSection);

        // For email count
        if(section.name == 'Contact Info' && requiredUnfilled.length>0){           
            if(_.indexOf(requiredUnfilled, 'info.email') != -1){
                if(this.emailArray.length>0) {
                    if(this.emailArray[0].email != '') {                       
                        requiredUnfilled = _.without(requiredUnfilled, 'info.email');
                    }
                }
            }     
        }

        var finallenth = requiredUnfilled.length;       
       
        if (section.name == 'Contact Info' && this.subjectProfile.orgRoles.indexOf("ATH") > -1) {
            this.relationCount = 0;
          //  console.log( this.relationArray.length);
            if(this.relationArray.length==0){
                this.relationCount += 1;
                this.relationerror=true;
            }else{
               this.relationCount = 0; 
               this.relationerror=false;
            }
            this.relationArray.filter(f => {
                if (f.firstName == "" && f.lastName == "") {
                    this.relationCount += 1;
                }
                if (f.email == "" && (f.tel == undefined || f.tel[0] == "" || f.tel.length == 0)) {
                    this.relationCount += 1;
                }
                if (this.relationCount > 1) {
                    this.relationCount = this.relationCount - 1;
                }
            });
            return finallenth + this.relationCount;
        }
        
        if (section.name == 'General Info' && ((this.existingallergiesarry.length == 0 || this.existingMedicalConditionarry.length == 0)
            || ((this.existingallergiesarry.length==1 && this.existingallergiesarry[0]=="") 
            || (this.existingMedicalConditionarry.length==1 && this.existingMedicalConditionarry[0]=="")))) {
            
            if ((this.existingallergiesarry.length==1 && this.existingallergiesarry[0]=="") || this.existingallergiesarry.length==0 && (this.lookupValue("info.specificAllergy") == true || this.lookupValue("info.specificAllergy") == 1)) {
                finallenth = finallenth + 1;
                this.validationErrors["info.specificAllergy"] = true;
            }

            if ((this.existingMedicalConditionarry.length==1 && this.existingMedicalConditionarry[0]=="") || this.existingMedicalConditionarry.length==0 && (this.lookupValue("info.existingMedicalCondition") == true || this.lookupValue("info.existingMedicalCondition") == 1)) {
                finallenth = finallenth + 1;
                this.validationErrors["info.existingMedicalCondition"] = true;
            }

            return finallenth;
        }
        else if (section.name == 'Heart Health' && (this.existinheartProblemsarry.length == 0 
            || (this.existinheartProblemsarry.length==1 && this.existinheartProblemsarry[0]==""))) {
            if ((this.existinheartProblemsarry.length==1 && this.existinheartProblemsarry[0]=="") || (this.existinheartProblemsarry.length==0 && (this.lookupValue("info.anyHeartProblems") == true || this.lookupValue("info.anyHeartProblems") == 1))) {
                finallenth = finallenth + 1;
                this.validationErrors["info.anyHeartProblems"] = true;
            }
            return finallenth;
        }
        else {
            return (requiredUnfilled.length > 0) ? (requiredUnfilled.length) : "";
        }
    }

    canSign() {
        return this.admin && !this.document.originalDescription.staffOnly && this.document.completedDate;
    }

    private handleError(error: any, message: string = null) {
        let parsed = null;
        try {
            parsed = error.json();
        } catch (e) {

        }

        if (parsed && parsed.message) {
            //this.errorMessage = parsed.message;
            location.reload();
            return;
        }

        if (error.message) {
            this.errorMessage = error.message;
            return;
        }

        this.errorMessage = message || 'We encountered an error saving your changes. Try refreshing the page.';
        throw error;
    }

    loadImage(profile: any) {
        return this._userProfiles.getProfileImageUrl(profile).single().toPromise()
            .then(url => {
                this.userprofileImage = url;
            })
            .catch(e => {
                throw e;
            });
    }
    checkboxcomman(showfield, existingarry, mainIdent) {
        var contain = _.contains(existingarry, showfield.name);
        if (showfield.type == 'longText') {
            this.othervalallergies = _.difference(existingarry, mainIdent);
            if(this.destroyCheckValues==false){
                showfield.showIfAll[0].checkvalue = this.othervalallergies[0];
            }else{
                showfield.showIfAll[0].checkvalue = '';
            }
        } else {
            if (contain && this.destroyCheckValues==false) {
                showfield.showIfAll[0].checkvalue = true;
            } else {
                showfield.showIfAll[0].checkvalue = false;
            }
        }
    }
    sectioncheckboxset(section: any, field: any) {
        _.each(this.showIfAllFields(section, field), (showfield: any) => {
            if (field.ident == 'info.specificAllergy') {
                this.checkboxcomman(showfield, this.existingallergiesarry, this.allergiesmainIdent);
            } else if (field.ident == 'info.existingMedicalCondition') {
                this.checkboxcomman(showfield, this.existingMedicalConditionarry, this.medicalmainIdent);
            } else if (field.ident == 'info.anyHeartProblems') {
                this.checkboxcomman(showfield, this.existinheartProblemsarry, this.heartProblemsmainIdent);
            }
        })
    }
    checkboxarraymaintain(documentSections, ngDestroy:boolean) {
        //console.log("destroyCheckValues => "+this.destroyCheckValues);
        if(ngDestroy==true){
            this.destroyCheckValues = true;
        }
        _.each(documentSections, (section: any) => {
            if (section.name == 'General Info') {
                _.each(section.fields, (field: any) => {
                    this.sectioncheckboxset(section, field);
                })
            } else if (section.name == 'Heart Health') {
                _.each(section.fields, (field: any) => {
                    this.sectioncheckboxset(section, field);
                })
            }
        })

    }
    
    loadparentImage()
    {
        return this._userProfiles.getProfileImageUrl(this.profile).single().toPromise()
            .then(url => {
                this.parentImageurl = url;
            })
            .catch(e => {
                console.log('Logo error', e);
                throw e;
            });
    }
    private refresh() {
        this.loading = true;
        let params = this._route.snapshot.params;
        this._documentDescriptionActivity = params['docDescriptionActivityId'];
        this._assignmentId = params['assignmentId'];
        let profileId = params['profileId'];
        this.profileId = params['profileId'];
        this.subjectProfileId = profileId;
        this.packetActivityId = params['packetActivityId'];
        var loadProfile = this._userProfiles.getProfile(profileId).single().toPromise();

        loadProfile.then(p => {
            this.subjectProfile = p;
            
            if (this.subjectProfile.imageUris == undefined) {
                this.subjectProfile['imageUris'] = [];
            } else {
                this.loadImage(this.subjectProfile);
            }
            if (this.subjectProfile.firstName != undefined) {
                this.currentuserFname=this.subjectProfile.firstName;

                this.firstname.push(this.subjectProfile.firstName);
            }
            if (this.subjectProfile.lastName != undefined) {
                this.currentuserLname=this.subjectProfile.lastName;
                this.lastname.push(this.subjectProfile.lastName);
            }

            if (this.subjectProfile.emails != undefined && this.subjectProfile.emails.length > 0) {
                var existingEmails = Array();
                existingEmails[0] = this.subjectProfile.email;
                var i = 1;
                this.subjectProfile.emails.forEach((v, i) => { existingEmails.push(this.subjectProfile.emails[i]) }, i++);
                existingEmails = _.uniq(existingEmails);
                if (existingEmails && existingEmails.length > 0) {
                    existingEmails.forEach(emailVal => this.emailArray.push({ email: emailVal }));
                    this.emailArray.push({ email: "" });
                } else {
                    this.emailArray.push({ email: "" });
                }
            } else {
                var existingEmails = Array();

                existingEmails[0] = this.subjectProfile.email;
                if (existingEmails[0] && existingEmails.length > 0 && existingEmails[0] != null) {
                    existingEmails.forEach(emailVal => this.emailArray.push({ email: emailVal }));
                    this.emailArray.push({ email: "" });
                } else {
                    this.emailArray.push({ email: "" });
                }
            }
            if (this.subjectProfile.tel != undefined && this.subjectProfile.tel.length > 0) {
                var existingPhone = this.subjectProfile.tel;

                if (existingPhone && existingPhone.length > 0) {
                    existingPhone.forEach(phoneVal => this.phoneArray.push({ phone: phoneVal }));
                    this.phoneArray.push({ phone: "" });
                } else {
                    this.phoneArray.push({ phone: "" });
                }
            } else {
                this.phoneArray.push({ phone: "" });
            }

            // get relation parent image & isLinkedAccount check
            if(_.has(this.subjectProfile, 'relations')==true && this.subjectProfile.relations.length!=undefined && this.subjectProfile.relations.length > 0){
                if(this.subjectProfile.relations[0].userProfileId!=undefined){
                    let profileId = this.subjectProfile.relations[0].userProfileId;
                    if(profileId && profileId !== undefined){
                    
                        this._userProfiles.getProfile(profileId).single().toPromise().then((data)=>{
                            this.profile = data;
                            if(this.profile.orgRoles.indexOf("PRN") > -1){
                                this.isLinkedAccount = true;
                            }
                            this.loadparentImage();
                        });
                    }
                }
            }

            if(this.subjectProfile.$amr != undefined && this.subjectProfile.$amr.info != undefined){
                if (_.has(this.subjectProfile.$amr.info, "medicalConditionsList")) {
                this.existingMedicalConditionarry = this.subjectProfile.$amr.info.medicalConditionsList;
                }
                if (_.has(this.subjectProfile.$amr.info, "allergiesList")) {
                    this.existingallergiesarry = this.subjectProfile.$amr.info.allergiesList;
                }
                if (_.has(this.subjectProfile.$amr.info, "heartProblemsList")) {
                    this.existinheartProblemsarry = this.subjectProfile.$amr.info.heartProblemsList;
                }    
            }
            
            if (this.subjectProfile.relations !== undefined) {
                this.relationArray = this.subjectProfile.relations;
            }

            this.admin = !!this._appCtx.myProfiles.find(mp =>
                (mp.org == p.org && !!_.intersection(mp.orgRoles, ['TRN', 'OTRN', 'OADM']).length)
                ||
                (mp.linkedOrgRoles && !!mp.linkedOrgRoles.find(lor => lor.orgId == p.org && !!_.intersection(lor.roles, ['TRN', 'OTRN', 'OADM']).length)));
        });

        this.loadInsuranceCard(profileId);
        if (this.filedSection[1] != undefined && this.filedSection[1].fields != undefined) {
            this.filedSection[1].fields = _.reject(this.filedSection[1].fields, function (objArr: any) { return objArr.ident == "info.insuranceCard"; });
        }
        loadProfile
            .then(p => p.amrId)
            .then(amrId => {
                this._amrId = amrId;
                return this._documents.findOrCreateAmrDocument(
                    amrId).single().toPromise();
            })
            .then(documents => {
                if(documents===undefined || documents.length==0){
                    //console.log("refresh++++++++++++");
                    this.emailArray = [];
                    this.phoneArray = [];
                    return this.refresh();
                }
                if(documents!=undefined && documents.length > 0){
                    this.loading = false;
                }
                // If there were multiple matches, they would all be returned here.
                // We don't have a rule for selecting which one other than we would
                // hope that the last in is the latest.
                //console.log(documents);
                this.document = documents[documents.length - 1];

                var infodata = [];
                var firstname = this.firstname[0];

                var lastname = this.lastname[0];
                var documnentarry = Array();
                    documnentarry = this.document.info;
                    var infoArr = _.each(this.document.info,
                        function (value, key: any, obj) {
                            if (key == 'firstName') {
                                value = firstname;
                            } else {
                                infodata.push(
                                    {
                                        ident: 'info.' + ['firstName'],
                                        value: firstname
                                    })
                            }
                            if (key == 'lastName') {
                                value = lastname;
                            } else {
                                infodata.push(
                                    {
                                        ident: 'info.' + ['lastName'],
                                        value: lastname
                                    })
                            }
                            infodata.push(
                                {
                                    ident: 'info.' + [key],
                                    value: value
                                }
                            )
                        });

                this.document.data = infodata;
                //use for email/phone
                var firstnamedata = _.find(this.document.data, (valget: any) => {
                    if (valget.ident == 'info.firstName') {
                        return true;
                    }
                });
                var phone = _.find(this.document.data, (valget: any) => {
                    if (valget.ident == 'info.tel') {
                        return true;
                    }
                });
                var email = _.find(this.document.data, (valget: any) => {
                    if (valget.ident == 'info.email') {
                        return true;
                    }
                });
                if (firstnamedata == undefined) {
                    this.document.data.push(
                        {
                            ident: 'info.firstName',
                            value: firstname
                        })
                    this.document.data.push(
                        {
                            ident: 'info.lastName',
                            value: lastname
                        })

                }

                if (phone == undefined) {
                    this.document.data.push(
                        {
                            ident: 'info.tel',
                            value: ''
                        })

                }
                if (email == undefined) {
                    this.document.data.push(
                        {
                            ident: 'info.email',
                            value: ''
                        })

                }

                (this.document.data || []).forEach(d => {
                    this.dataCache[d.ident] = d;
                });
                
                this.documentSections = this.filedSection;
                this.applyValidations();

                this._changeSaver.start(this._amrId, this.profileId);
                this.checkboxarraymaintain(this.documentSections, false);

                var docStableId = this.document.documentStableId;
                var username = encodeURIComponent(this._ctx.creds.username);
                var password = encodeURIComponent(this._ctx.creds.password);
                this.pdfUrl = `${window.location.protocol}//${window.location.host}/training/api/documents/${docStableId}/pdf?auth.basic.username=${username}&auth.basic.password=${password}`;
            })
            .catch(error => {
                this.loading = false;
                this.handleError(error);
            });
    }

    // Save data for amr data on change tab
    changeFormTab(e, tab) {
        e.preventDefault();
        window.scrollTo(0, 0);
        this.confirmChangeRoute().then((res: boolean): boolean => {
            return res;
        }).catch(e => {
            this.handleError(e, 'We encountered an error saving your changes. Try refreshing the page.');
            throw e;
        });
    }

    // Save data for amr data on route change only
    confirmChangeRoute(): Promise<boolean> {
        this.isLoader = true;
        return new Promise((resolve, reject) => {
            this._changeSaver.stop();
            this._changeSaver.saveNow().single().toPromise()
                .then(() => {
                    this._changeSaver.start(this._amrId, this.profileId);
                })
                .then(() => {
                    if (this.relationArray !== undefined && this.relationArray.length > 0) {
                        this.relationData.saveData().then((res: boolean) => {
                            if (res == true) {
                                resolve(true);
                            }
                            else {
                                this.isLoader = false;
                                this.handleError(res, 'We encountered an error saving your changes. Please refresh and try again.');
                            }
                        }).catch(e => {
                            throw e;
                        });
                    }
                    else {
                        this.isLoader = false;
                        resolve(true);
                    }
                })
                .catch(error => {
                    this._changeSaver.start(this._amrId, this.profileId);
                    this.isLoader = false;
                    this.handleError(error, 'We encountered an error saving your changes. Please refresh and try again.');
                });
        });
    }

    backButton() {
        window.history.back();
        // console.log(this._router.url);
        // console.log(window.history.back());
        // var backUrl = store.session('BasicMedicalRedirectURL');
        // var route: any[] = [backUrl];
        // route.push({ profileId: this.profileId });
        // this._router.navigate(route);
    }

    refreshInsuranceData(e) {
        this.isLoaderInsurence = true;

        this.filedSection[1].fields = _.reject(this.filedSection[1].fields, function (objArr: any) { return objArr.ident == "info.insuranceCard"; });
        this.loadInsuranceCard(this.profileId);
    }

    loadInsuranceCard(profileId) {

        let insuranceCardList = [];
        let insuranceCardGroupIds = [];
        // this.isShowDocumentGif = true;
        this._userProfiles.getTeamUserDocument(profileId).single().toPromise()
            .then(data => {
                var datarev = data.reverse();
                var infoArr = _.each(datarev,
                    function (value: any, key, obj) {
                        if (value.documentGroup !== undefined) {
                            if (value.documentGroup.type !== undefined && value.documentGroup.type == "insuranceCard") {
                                if (value.documentGroup.documentGroupId !== undefined) {

                                    value.ident = "info.insuranceCard";
                                    value.name = "Insurance Image";
                                    value.type = "image";
                                    value.pclass = "col-xs-6 col-sm-3";

                                    if (_.indexOf(insuranceCardGroupIds, value.documentGroup.documentGroupId) >= 0) {

                                        let documentGroupIdTmp = value.documentGroup.documentGroupId;
                                        // find index of object from existing array, Where we have to put front/back object
                                        let finalIndex = -1;

                                        let findMatchObject = _.find(insuranceCardList, function (itemMain, indexMain) {
                                            let findSubMatch = _.find(itemMain, function (itemSub: any, indexSub) {

                                                if (itemSub.documentGroup.documentGroupId === documentGroupIdTmp) {
                                                    finalIndex = indexMain;
                                                    return false;
                                                }
                                            });
                                        });

                                        if (finalIndex >= 0) {
                                            insuranceCardList[finalIndex].push(value);
                                        }

                                    } else {
                                        insuranceCardList.push([value]);
                                        insuranceCardGroupIds.push(value.documentGroup.documentGroupId);
                                    }
                                }
                            }
                        }
                    });


                /* Add logic for append  remaining front/back object in Array(insuranceCardList) */

                let newInsuranceCardObject = {
                    ident: "info.insuranceCard",
                    name: "Insurance Image",
                    type: "image",
                    pclass: "col-xs-6 col-sm-3",
                    documentGroup: {
                        documentGroupId: "",
                        role: "front",
                        type: "insuranceCard"
                    }
                };

                let finalInsuranceCardList = insuranceCardList;

                _.each(insuranceCardList, function (value: any, key) {
                    if (value.length == 1) {
                        if (value[0].documentGroup.role === "front") {

                            finalInsuranceCardList[key].push({
                                ident: "info.insuranceCard",
                                name: "Insurance Image",
                                type: "image",
                                pclass: "col-xs-6 col-sm-3",
                                documentGroup: {
                                    documentGroupId: value[0].documentGroup.documentGroupId,
                                    role: "back",
                                    type: "insuranceCard"
                                }
                            });
                        } else {
                            finalInsuranceCardList[key].unshift({
                                ident: "info.insuranceCard",
                                name: "Insurance Image",
                                type: "image",
                                pclass: "col-xs-6 col-sm-3",
                                documentGroup: {
                                    documentGroupId: value[0].documentGroup.documentGroupId,
                                    role: "front",
                                    type: "insuranceCard"
                                }
                            });
                        }

                    } else {
                        if (value[0].documentGroup.role === "back") {
                            value.reverse();
                        }
                    }
                });
                let documentGroupIdForLastCard = (new DfObjectId()).toString();
                let finalInsuranceCardCount = finalInsuranceCardList.length;
                finalInsuranceCardList[finalInsuranceCardCount] = [];
                finalInsuranceCardList[finalInsuranceCardCount].push({
                    ident: "info.insuranceCard",
                    name: "Insurance Image",
                    type: "image",
                    pclass: "col-xs-6 col-sm-3",
                    documentGroup: {
                        documentGroupId: documentGroupIdForLastCard,
                        role: "front",
                        type: "insuranceCard"
                    }
                });
                finalInsuranceCardList[finalInsuranceCardCount].push({
                    ident: "info.insuranceCard",
                    name: "Insurance Image",
                    type: "image",
                    pclass: "col-xs-6 col-sm-3",
                    documentGroup: {
                        documentGroupId: documentGroupIdForLastCard,
                        role: "back",
                        type: "insuranceCard"
                    }
                });



                this.filedSection[1].fields.push({
                    ident: "info.insuranceCard",
                    name: "Insurance Image",
                    type: "image",
                    pclass: "col-xs-6 col-sm-3",
                    imageList: finalInsuranceCardList
                });

                this.isLoaderInsurence = false;
            })
            .catch(e => {
                this.isLoaderInsurence = false;
                // this.isShowDocumentGif = false;
                throw e;
            });
    }

}