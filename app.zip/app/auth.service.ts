import {Injectable} from "@angular/core";
import {RegistrationContext} from "./registration_context.service";
import {Http, Response, RequestOptionsArgs, Headers, URLSearchParams} from "@angular/http"
import {Credentials} from "./credentials";

declare var store:any;

@Injectable()
export class AuthService {

    constructor(private _ctx:RegistrationContext, private _http:Http) {

    }

    get redirectUrl()
    {
        return store.session('RedirectURL');
    }

    set redirectUrl(value:string)
    {
        store.session('RedirectURL', value);
    }

    login(username:string, password:string, persistent:boolean=false) {
        let opts:RequestOptionsArgs = {
            headers : new Headers({
                Authorization: 'Basic ' + btoa(`${username}:${password}`)
            })
        };

        if (persistent)
        {
            var search = new URLSearchParams();
            search.set('noExpire', 'true');
            opts.search = search;
        }

        return this._http.get('/training/api/authorization', opts)
            .map((res:Response) => <Credentials>res.json())
            .toPromise()
            .then(creds =>
            {
                this._ctx.persistent = persistent;
                this._ctx.creds = creds;
            });
    }

    logOut() {
         // TODO clear creds and invoke logout on server to disable device creds
    }

    get isLoggedIn() {
        return !!this._ctx.creds;
    }
}