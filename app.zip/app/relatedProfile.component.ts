import {Component, Input, Output, EventEmitter} from "@angular/core";
import {ActivatedRoute, Router} from "@angular/router";
import {UserProfiles, UserProfile} from "./user_profiles.service";
import {MaxAppContext} from "./maxAppContext.service";

@Component({
    selector:'related-profile',
    template:
        `<div class="profilelist">
            <div class="profilelist-img">      
                <img [src]="_user_img" class="img-responsive" />
            </div>
            <div class="profilelist-content">
                <span class="profile-content-name">{{_userProfile.firstName}} {{_userProfile.lastName}}</span><br>
                {{_ctx.currentOrg?.name || '...loading school name...'}}<br>
                <a href="javascript:void(0)" (click)="onChildClick(_userProfile)" >Fill Out Forms</a> | 
                <a href="javascript:void(0)" (click)="goToUpladADocument(_userProfile._id)">Upload a Document</a>
            </div>
        </div>    
         `
})
export class RelatedProfile
{
    private _profileId:string;
    _userProfile:any=[];
    public _user_img:any;


    @Input('userProfile')
    set userProfile(value: any){
        this._userProfile = value;
        this.loadImage(value);
    }

    relatedProfiles:UserProfile[];

    constructor(private _route:ActivatedRoute, private _router:Router, private _profilesSvc:UserProfiles, private _ctx:MaxAppContext)
    {

    }

    loadImage(profile:UserProfile)
    {
        return this._profilesSvc.getProfileImageUrl(profile).single().toPromise()
            .then(url => {
                this._user_img = (url!='' && url!=undefined) ? url : "/maxweb/app/media/athlete-user-img.png";
            })
            .catch(e => {
                console.log('Logo error', e);
                throw e;
            });
    }

    onChildClick(profile:UserProfile)
    {
        var route:any[] = ['/max-forms/packetList'];
        if (profile.orgRoles.indexOf('ATH') > -1)
            route.push({profileId:profile._id});
        this._router.navigate(route);
    }

    goToUpladADocument(id){
        if(id){
            // sessionStorage['numberOfRecords'] = this.skip;
            // sessionStorage['bodyScrollTop'] = this.bodyScrollTop;
            sessionStorage['isCurrentPlayerTab'] = 'documentstab';
            this._router.navigate(['/main/player', id]);
        }
    }
}