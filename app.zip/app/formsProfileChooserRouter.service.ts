import {CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router} from "@angular/router";
import {Observable} from "rxjs";
import {Injectable} from "@angular/core";
import {MaxAppContext} from "./maxAppContext.service";
import {UserProfiles} from "./user_profiles.service";

@Injectable()
export class FormsProfileChooserRouter implements CanActivate
{
    constructor(
        private _router:Router,
        private _ctx:MaxAppContext,
        private _profilesSvc:UserProfiles)
    {

    }

    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean>|Promise<boolean>|boolean
    {
        if (route.params['profileId'])
            return true;

        let orgId = this._ctx.orgId;
        if (!orgId)
            throw new Error('The context org ID must be set before FormsProfileChooserRouter is activated.');

        return this._profilesSvc.getMine().single().toPromise()
            .then(myProfiles =>
            {
                let profile = myProfiles.find(p => p.org == orgId);
                if (!profile)
                {
                    console.log('Profile not found for org.  Profile for context org must be created before reaching FormsProfileChooserRouter.');
                    // NOTE: if you find the need to navigate here, make sure the MaxAppContext has not
                    // already forwarded to OwnProfileCreator.  If you forward arbitrarily here,
                    // you will obliterate the contextual forwarding URL that is used after profile creation.
                    // Ideally this would not even be invoked if the MaxAppContext.initialize guard returns false, but
                    // angular allows guards down the change to proceed if an earlier guard returns a promise.
                    return false;
                }

                if (profile.orgRoles.indexOf('PRN') < 0)
                    this._router.navigate(['/max-forms/packetList', {profileId:profile._id}]);
                else
                    this._router.navigate(['/max-forms/chooseFormsProfile', profile._id]);

                return false;
            });
    }
}