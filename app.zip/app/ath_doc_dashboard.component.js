System.register(['@angular/core', "./assignments.service", "./user_profiles.service", "./document_factory.service", "@angular/router", "./document_loader.service", "./intercomRouterTracker.service"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, assignments_service_1, user_profiles_service_1, document_factory_service_1, router_1, document_loader_service_1, intercomRouterTracker_service_1;
    var AthDocDashboard;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (assignments_service_1_1) {
                assignments_service_1 = assignments_service_1_1;
            },
            function (user_profiles_service_1_1) {
                user_profiles_service_1 = user_profiles_service_1_1;
            },
            function (document_factory_service_1_1) {
                document_factory_service_1 = document_factory_service_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (document_loader_service_1_1) {
                document_loader_service_1 = document_loader_service_1_1;
            },
            function (intercomRouterTracker_service_1_1) {
                intercomRouterTracker_service_1 = intercomRouterTracker_service_1_1;
            }],
        execute: function() {
            AthDocDashboard = (function () {
                function AthDocDashboard(_router, _route, _assignments, _userProfiles, _documents, _docLoader, _intercom) {
                    this._router = _router;
                    this._route = _route;
                    this._assignments = _assignments;
                    this._userProfiles = _userProfiles;
                    this._documents = _documents;
                    this._docLoader = _docLoader;
                    this._intercom = _intercom;
                    this._profileId = null;
                    this.codeRecipientEmails = [];
                }
                AthDocDashboard.prototype.ngOnInit = function () {
                    var activityId = this._route.snapshot.params['activityId'];
                    if (activityId) {
                        this.activityId = activityId;
                        this.showName = true;
                    }
                };
                Object.defineProperty(AthDocDashboard.prototype, "activityId", {
                    set: function (value) {
                        var _this = this;
                        this.submittedDuringThisSession = false;
                        var profileId = this._route.snapshot.params['profileId'];
                        this._profileId = profileId;
                        var activityId = value;
                        this._activityId = activityId;
                        if (!activityId)
                            return;
                        this._userProfiles.getProfile(profileId).single().toPromise()
                            .then(function (p) {
                            // console.log(p);
                            _this.profile = p;
                        });
                        this._assignments.getAssignments(activityId).single().toPromise()
                            .then(function (assignment) {
                            if (assignment.activities[0].type == 'Documentation') {
                                var act = assignment.activities[0];
                                _this.docAct = act;
                                _this.documentDescriptions = act.documentationEventDescription.documents.filter(function (d) { return !d.staffOnly; });
                                _this.assignmentId = assignment._id;
                                _this.confirmationCode = _this.formatCode(assignment.submissionCode);
                            }
                            else {
                                throw new Error('Unexpected assignment format from the server.');
                            }
                            return _this._documents.getDocumentationDocuments(assignment.assignmentStableId, _this._profileId).single().toPromise();
                        })
                            .then(function (documents) {
                            _this.documentDescriptions.forEach(function (dd) {
                                var doc = documents.filter(function (d) { return d.originalDescription._id == dd.activityId; })[0];
                                if (doc) {
                                    dd.instanceExists = true;
                                    dd.completedDate = doc.completedDate;
                                }
                            });
                        });
                    },
                    enumerable: true,
                    configurable: true
                });
                AthDocDashboard.prototype.onClickDoc = function (activityId) {
                    this._router.navigate(['form', this.profile._id, this._activityId, this.assignmentId, activityId], { relativeTo: this._route.parent });
                };
                AthDocDashboard.prototype.canSubmit = function () {
                    if (!this.documentDescriptions)
                        return false;
                    return this.requiredForms().filter(function (dd) { return !!dd.completedDate; }).length == this.requiredDocCount();
                };
                AthDocDashboard.prototype.onSubmit = function () {
                    var _this = this;
                    this.errorMessage = null;
                    this.submitting = true;
                    this._assignments.submit(this.assignmentId, this._profileId).single().toPromise()
                        .then(function (res) {
                        _this.submittedDuringThisSession = true;
                        _this.confirmationCode = _this.formatCode(res.code);
                        if (res.emailRecipient)
                            _this.codeRecipientEmails.push(res.emailRecipient);
                        _this._intercom.track('submitted-forms-packet', { packetName: _this.docAct.documentationEventDescription.eventName });
                    })
                        .catch(function (err) {
                        console.error(err);
                        _this.submitting = false;
                        _this.errorMessage = 'There was an error submitting your packet.  Please try again.';
                    });
                };
                AthDocDashboard.prototype.onSubmitEmailCopy = function () {
                    var _this = this;
                    var email = this.email;
                    if (!email)
                        return;
                    delete this.email;
                    this.errorMessage = null;
                    this.emailingCopy = true;
                    this._assignments.requestConfirmation(this.assignmentId, this._profileId, email).single().toPromise().then(function () {
                        _this.codeRecipientEmails.push(email);
                        _this.emailingCopy = false;
                    }).catch(function (e) {
                        console.error(e);
                        _this.emailingCopy = false;
                        _this.errorMessage = 'There was an error emailing your confirmation.  Please try again.';
                    });
                };
                AthDocDashboard.prototype.percentComplete = function () {
                    if (!this.documentDescriptions)
                        return 0;
                    if (100 * this.completedDocCount() / this.requiredDocCount() == 100) {
                        return (100 * this.completedDocCount() / this.requiredDocCount() - 5);
                    }
                    else {
                        return 100 * this.completedDocCount() / this.requiredDocCount();
                    }
                };
                AthDocDashboard.prototype.completedDocCount = function () {
                    if (!this.documentDescriptions)
                        return 0;
                    return this.documentDescriptions.filter(function (dd) { return dd.required && !!dd.completedDate; }).length;
                };
                AthDocDashboard.prototype.requiredDocCount = function () {
                    if (!this.documentDescriptions)
                        return 0;
                    return this.requiredForms().length;
                };
                AthDocDashboard.prototype.requiredForms = function () {
                    if (!this.documentDescriptions)
                        return [];
                    return this.documentDescriptions.filter(function (dd) { return dd.required; });
                };
                AthDocDashboard.prototype.optionalForms = function () {
                    if (!this.documentDescriptions)
                        return [];
                    return this.documentDescriptions.filter(function (dd) { return !dd.required; });
                };
                AthDocDashboard.prototype.printPacket = function () {
                    var url = "/training/api/assignments/documentation/" + this.assignmentId + "/" + this.profile._id + "/pdf";
                    this._docLoader.requestPdf(window, 'GET', url);
                };
                AthDocDashboard.prototype.formatCode = function (code) {
                    if (!code)
                        return undefined;
                    return code.slice(0, code.length / 2) + '-' + code.slice(code.length / 2);
                };
                __decorate([
                    core_1.Input('activityId'), 
                    __metadata('design:type', String), 
                    __metadata('design:paramtypes', [String])
                ], AthDocDashboard.prototype, "activityId", null);
                AthDocDashboard = __decorate([
                    core_1.Component({
                        selector: 'ath-doc-dashboard',
                        template: "\n            \n            <div [hidden]=\"!errorMessage\" class=\"alert alert-danger\">{{errorMessage}}</div>\n            <div [hidden]=\"!confirmationCode\" class=\"alert alert-success\">\n                <div [hidden]=\"!submittedDuringThisSession\">\n                    <p>Your {{docAct?.documentationEventDescription?.eventName}} packet is submitted! Confirmation code: <strong>{{confirmationCode}}</strong></p>\n                    <p><a href=\"javascript:void(0)\" (click)=\"printPacket()\"><strong>Click here to download a copy.</strong></a> </p>\n                    <div style=\"width:250px; margin: auto; margin-top:10px;\" *ngIf=\"codeRecipientEmails[0]\">\n                        A message with this code was sent to:\n                        <ul style=\"text-align:left; margin-left:10px; font-weight:bold\">\n                            <li *ngFor=\"let email of codeRecipientEmails\">{{email}}</li>\n                        </ul>\n                    </div>\n                    \n                    <form class=\"form-inline\" style=\"margin-top:15px\" (ngSubmit)=\"onSubmitEmailCopy()\">\n                        <p>Enter an email address or mobile # to receive a copy of the confirmation email (optional):</p>\n                        <input [(ngModel)]=\"email\" name=\"email\" type=\"text\"/>\n                        <button [disabled]=\"emailingCopy\" type=\"submit\" class=\"btn btn-default\"><img *ngIf=\"emailingCopy\" src=\"/maxweb/app/media/ajax-loader-white.gif\" /><span *ngIf=\"!emailingCopy\">Send</span></button>\n                    </form>\n                </div>\n                \n                <div [hidden]=\"submittedDuringThisSession\">\n                   <p>Your {{docAct?.documentationEventDescription?.eventName}} packet is already submitted.</p>\n                   <p><a href=\"javascript:void(0)\" (click)=\"printPacket()\"><strong>Click here to download a copy.</strong></a> </p>\n                </div>\n                \n                <h3>Download the app for the full MAX experience!</h3>\n           <get-the-app [columns]=\"true\"></get-the-app>\n                \n                <div style=\"margin-top:30px;\">\n                    <button class=\"btn btn-primary\" [routerLink]=\"['/main']\">Go to home page</button>\n                </div>\n             </div>\n            <div [hidden]=\"confirmationCode\" style=\"margin:auto; max-width:300px;\">\n                <h1 *ngIf=\"showName\">{{profile?.firstName}} {{profile?.lastName}}</h1>\n                <div *ngIf=\"requiredForms().length==0 && profile?.firstName!==''\" style=\"font-style:italic\"> No forms available</div>\n                <div *ngIf=\"requiredForms().length!==0\">\n                <p *ngIf=\"!canSubmit()\" style=\"font-size:18px; font-weight: bold\">{{docAct?.documentationEventDescription?.eventName}}</p>\n                <p style=\"font-style:italic\">{{completedDocCount()}} of {{requiredDocCount()}} Completed <span *ngIf=\"canSubmit()\"><br />Press <strong>Submit Packet</strong> below.</span></p>\n                <div class=\"progress\">\n                    <div [ngClass]=\"{'progress-bar':true, 'progress-bar-success':canSubmit()}\" role=\"progressbar\" [style.width]=\"percentComplete() + '%'\" style=\"min-width:2em\">\n                        {{percentComplete() | number:'1.0-0' }}%\n                    </div>\n                </div>\n                <div style=\"margin-top: -12px;padding-bottom: 13px;\">\n                <button [disabled]=\"submitting\" *ngIf=\"canSubmit()\" (click)=\"onSubmit()\" class=\"btn btn-default\">Submit Packet</button>\n                </div>\n                <div [hidden]=\"!!documentDescriptions\" class=\"alert alert-info\">Loading...</div>\n                <div class=\"list-group\">\n                    <a href=\"javascript:void(0)\" (click)=\"onClickDoc(doc.activityId)\" class=\"list-group-item\" *ngFor=\"let doc of requiredForms()\">\n                        {{doc.name}}\n                        <span *ngIf=\"doc.completedDate\" class=\"badge\" style=\"background:green\"><span class=\"glyphicon glyphicon-ok\"></span></span>\n                        <span *ngIf=\"doc.instanceExists && !doc.completedDate\" class=\"badge\" style=\"background:gold\">&nbsp;</span>\n                    </a>\n                </div>\n                \n                <div *ngIf=\"optionalForms().length\">\n                    <p style=\"font-size:18px; font-weight: bold\">Optional Forms</p>\n                    <div class=\"list-group\">\n                        <a href=\"javascript:void(0)\" (click)=\"onClickDoc(doc.activityId)\" class=\"list-group-item\" *ngFor=\"let doc of optionalForms()\">\n                            {{doc.name}}\n                            <span *ngIf=\"doc.completedDate\" class=\"badge\" style=\"background:green\"><span class=\"glyphicon glyphicon-ok\"></span></span>\n                            <span *ngIf=\"doc.instanceExists && !doc.completedDate\" class=\"badge\" style=\"background:gold\">&nbsp;</span>\n                        </a>\n                    </div>\n                </div>\n                <button [disabled]=\"submitting\" *ngIf=\"canSubmit()\" (click)=\"onSubmit()\" class=\"btn btn-default\">Submit Packet</button>\n            </div></div>\n    "
                    }), 
                    __metadata('design:paramtypes', [router_1.Router, router_1.ActivatedRoute, assignments_service_1.Assignments, user_profiles_service_1.UserProfiles, document_factory_service_1.Documents, document_loader_service_1.DocumentLoader, intercomRouterTracker_service_1.IntercomRouterTracker])
                ], AthDocDashboard);
                return AthDocDashboard;
            }());
            exports_1("AthDocDashboard", AthDocDashboard);
        }
    }
});
//# sourceMappingURL=ath_doc_dashboard.component.js.map