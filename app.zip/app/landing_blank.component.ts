import {Component} from '@angular/core';

@Component({
    selector: 'app-landing-blank',
    template: `
    <div class="container" style="max-width:500px">
        <div class="row">
            <div class="col-md-4">
                <img width="175px" src="app/media/referee-flag-lockout-w.jpg" />
            </div>
            <div class="col-md-8">
                <h1>That's a Penalty!!!</h1>
                <h3>Delay of game, illegal formation....or something....</h3>
                <h3>Now get back in the game!</h3>
                <p>&nbsp;</p>
                <p class="lead">
                    <a class="btn btn-lg btn-default" [routerLink]="['/landing']">Get Started Again</a>
                </p>
                <p>Looks like you took too long and timed out.<br />Email support@dragonflyathletics.com for help.</p>
            </div>
        </div>
    </div>
    `
})

export class LandingComponentBlank {
}
