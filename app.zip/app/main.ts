// import {bootstrap}    from '@angular/platform-browser-dynamic'
// import {AppComponent} from './app.component'
// import {HTTP_PROVIDERS} from '@angular/http';
// import {provide} from "@angular/core";
// import {AppBaseRequestOptions} from "./app_base_request_options";
// import {RequestOptions} from "@angular/http";
// import {AppErrorHandler} from "./app_error_handler.service";
//
// bootstrap(AppComponent, [
//     HTTP_PROVIDERS,
//     provide(RequestOptions, {useClass:AppBaseRequestOptions}),
//
//     // I have tried and tried to use an OpaqueToken like in examples but I get a cryptic error.
//     provide('AppErrorHandler', {useClass:AppErrorHandler})
// ]);

import {platformBrowserDynamic} from '@angular/platform-browser-dynamic';

import {AppModule} from './app.module';

import {enableProdMode} from '@angular/core';

enableProdMode();
platformBrowserDynamic().bootstrapModule(AppModule);