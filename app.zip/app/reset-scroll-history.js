System.register(['@angular/core', "@angular/router"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, router_1;
    var ResetScrollHistory;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            }],
        execute: function() {
            ResetScrollHistory = (function () {
                function ResetScrollHistory(_router) {
                    this._router = _router;
                }
                ResetScrollHistory.prototype.canActivate = function () {
                    var prevUrl = this._router.url;
                    var urlSplitted = prevUrl.split("/");
                    if (urlSplitted.length > 0) {
                        if (urlSplitted[1] !== "player" && urlSplitted[2] !== "player") {
                            console.log("Reset");
                            sessionStorage['numberOfRecords'] = null;
                            sessionStorage['bodyScrollTop'] = 0;
                            sessionStorage['roleview'] = null;
                            sessionStorage['sortview'] = null;
                            sessionStorage['filterview'] = null;
                            sessionStorage['sortorderview'] = null;
                        }
                        else {
                        }
                    }
                    return true;
                };
                ResetScrollHistory = __decorate([
                    core_1.Injectable(), 
                    __metadata('design:paramtypes', [router_1.Router])
                ], ResetScrollHistory);
                return ResetScrollHistory;
            }());
            exports_1("ResetScrollHistory", ResetScrollHistory);
        }
    }
});
//# sourceMappingURL=reset-scroll-history.js.map