import {Injectable} from "@angular/core";

@Injectable() 
export class Helper {

    basicMedicalFiledSection: any = [];

    constructor() {

        this.basicMedicalFiledSection = [
            {
                name: "Contact Info",
                icon: "user-icon1",
                image: '/maxweb/app/media/athlete-user-img.png',
                tabClass: 'col-xs-12 col-sm-10 col-md-11',
                fields: [
                    { ident: "info.firstName", name: "First Name *", type: "text", required: true, pclass: "col-xs-12 col-sm-6" },
                    { ident: "info.lastName", name: "Last Name *", type: "text", required: true, pclass: "col-xs-12 col-sm-6" },
                    { ident: "info.addressStreet", name: "Address *", type: "text", required: true, pclass: "col-xs-12" },
                    { ident: "info.addressCity", name: "City *", type: "text", required: true, pclass: "col-xs-12 col-sm-6 col-lg-4" },
                    { ident: "info.addressState", name: "State *", type: "dropdown", required: true, pclass: "col-xs-12 col-sm-6 col-lg-4" },
                    { ident: "info.addressZip", name: "Zip *", type: "text", required: true, pclass: "col-xs-12 col-sm-4 col-lg-2" },
                    { ident: "info.gradYear", name: "Grad Year *", type: "gradYear", required: true, pclass: "col-xs-12 col-sm-4 col-lg-2" },
                    { ident: "info.gender", name: "Gender *", type: "selectOne", options: ["Male", "Female"], required: true, pclass: "col-xs-12 col-sm-4 col-lg-6 " },
                    { ident: "info.dob", name: "DOB *", type: "date", required: true, pclass: "col-xs-12 col-sm-12 col-lg-6 selcetdob" },
                    { ident: "info.tel", name: "Phone *", type: "phone", required: true, pclass: "col-xs-12 col-sm-6 col-lg-4" },
                    { ident: "info.email", name: "Email *", type: "email", required: true, pclass: "col-xs-12 col-sm-6 col-lg-4" },
                ]
            },
            {
                name: "Insurance",
                icon: "user-icon2",
                tabClass: 'col-xs-12',
                fields: [
                    { ident: "info.insUninsured", name: "No Medical Insurance", type: "singleCheckbox", pclass: "col-xs-12" },
                    { ident: "info.insCompany", name: "Insurance Company", type: "text", requireIfAll: [{ ident: "info.insUninsured", value: false }], showIfAll: [{ ident: "info.insUninsured", value: false, fieldsCount: 0 }], pclass: "col-xs-12 col-sm-6" },
                    { ident: "info.insPolicyNumber", name: "Policy Number", type: "text", requireIfAll: [{ ident: "info.insUninsured", value: false }], showIfAll: [{ ident: "info.insUninsured", value: false, fieldsCount: 0 }], pclass: "col-xs-12 col-sm-6" },
                    { ident: "info.insGroupNumber", name: "Group Number", type: "text", requireIfAll: [{ ident: "info.insUninsured", value: false }], showIfAll: [{ ident: "info.insUninsured", value: false, fieldsCount: 0 }], pclass: "col-xs-12 col-sm-6" },
                    { ident: "info.insCardholder", name: "Primary Card Holder", type: "text", requireIfAll: [{ ident: "info.insUninsured", value: false }], showIfAll: [{ ident: "info.insUninsured", value: false, fieldsCount: 0 }], pclass: "col-xs-12 col-sm-6" },
                ]
            },
            {
                name: "General Info",
                icon: "user-icon3",
                tabClass: 'col-xs-12',
                fields: [

                    { ident: "info.takesMedicines", name: "Are you currently taking any prescription or over-the-counter medicines and supplements (herbal and nutritional)?", type: "switch", required: true, explanationRequired: true, explanationPrompt: 'What medicines or supplements?' },

                    { ident: "info.specificAllergy", name: "Do you have any allergies?", type: "switch", required: true, requirePrompt: 'Please identify the specific types of allergies you have (e.g., specific medicines, specific foods, pollens, stinging insects)' },
                    { ident: "info.hasMedicines", name: "Medicines", type: "selectCheckbox", showIfAll: [{ ident: "info.specificAllergy", value: true, checkvalue: false, fieldsCount: 4, mainIdent: "info.allergiesList" }] },
                    { ident: "info.hasPollens", name: "Pollens", type: "selectCheckbox", showIfAll: [{ ident: "info.specificAllergy", value: true, checkvalue: false, fieldsCount: 4, mainIdent: "info.allergiesList" }] },
                    { ident: "info.hasFood", name: "Food", type: "selectCheckbox", showIfAll: [{ ident: "info.specificAllergy", value: true, checkvalue: false, fieldsCount: 4, mainIdent: "info.allergiesList" }] },
                    { ident: "info.hasStingingInsects", name: "Stinging Insects", type: "selectCheckbox", showIfAll: [{ ident: "info.specificAllergy", value: true, checkvalue: false, fieldsCount: 4, mainIdent: "info.allergiesList" }] },
                    { ident: "info.otherAllergy_explanation", name: "Specific allergies", type: "longText", showIfAll: [{ ident: "info.specificAllergy", value: true, checkvalue: '', fieldsCount: 4, mainIdent: "info.allergiesList" }] },
                    { ident: "info.allergiesList", name: "Allergies" },
                    
                    { ident: "info.deniedParticipationInSports", name: "Has a doctor ever denied or restricted your participation in sports for any reason ?", type: "switch", required: true, explanationRequired: true, explanationPrompt: 'Why was participation denied?' },
                    { ident: "info.existingMedicalCondition", name: "Do you have any ongoing medical conditions ?", type: "switch", required: true, requirePrompt: 'Please identify below' },
                    { ident: "info.hasAsthma", name: "Asthma", type: "selectCheckbox", showIfAll: [{ ident: "info.existingMedicalCondition", value: true, checkvalue: false, fieldsCount: 4, mainIdent: "info.medicalConditionsList" }] },
                    { ident: "info.hasAnemia", name: "Anemia", type: "selectCheckbox", showIfAll: [{ ident: "info.existingMedicalCondition", value: true, checkvalue: false, fieldsCount: 4, mainIdent: "info.medicalConditionsList" }] },
                    { ident: "info.hasDiabetes", name: "Diabetes", type: "selectCheckbox", showIfAll: [{ ident: "info.existingMedicalCondition", value: true, checkvalue: false, fieldsCount: 4, mainIdent: "info.medicalConditionsList" }] },
                    { ident: "info.hasInfections", name: "Infections", type: "selectCheckbox", showIfAll: [{ ident: "info.existingMedicalCondition", value: true, checkvalue: false, fieldsCount: 4, mainIdent: "info.medicalConditionsList" }] },
                    { ident: "info.otherMedicalCondition_explanation", name: "Other", type: "longText", showIfAll: [{ ident: "info.existingMedicalCondition", value: true, checkvalue: '', fieldsCount: 4, mainIdent: "info.medicalConditionsList" }] },
                    { ident: "info.medicalConditionsList", name: "Medical" },
                    { ident: "info.nightSpentInHospital", name: "Have you ever spent the night in hospital?", type: "switch", required: true, explanationRequired: true, explanationPrompt: 'Why did you spend the night in the hospital?' },
                    { ident: "info.surgery", name: "Have you ever had surgery?", type: "switch", required: true, explanationRequired: true, explanationPrompt: 'What surgery did you have ?' },
                    { ident: "info.menstrualPeriod", name: "Have you ever had a menstrual period ?", type: "switch", requireIfAll: [{ ident: "info.gender", value: 'Female' }], showIfAll: [{ ident: "info.gender", value: 'Female' }] },
                    { ident: "info.ageAtFirstMenstrualPeriod", name: "How old were you when you had your first menstrual period?", type: "integer", requireIfAll: [{ ident: "info.menstrualPeriod", value: true }, { ident: "info.gender", value: 'Female' }], showIfAll: [{ ident: "info.menstrualPeriod", value: true, fieldsCount: 0 }, { ident: "info.gender", value: 'Female' }] },
                    { ident: "info.numberOfMenstrualPeriods", name: "How many periods have you had in the last 12 months?", type: "integer", requireIfAll: [{ ident: "info.menstrualPeriod", value: true }, { ident: "info.gender", value: 'Female' }], showIfAll: [{ ident: "info.menstrualPeriod", value: true, fieldsCount: 0 }, { ident: "info.gender", value: 'Female' }] },

                    { ident: "info.lastPhysicalDate", name: "Date of Last Physical", type: "date", required: true, pclass: "col-xs-12 col-sm-12 col-lg-6 selcetdob", sectionClass:"panel panel-default qus-and-ans" },
                        
                ]
            },
            {
                name: "Heart Health",
                icon: "user-icon4",
                tabClass: 'col-xs-12',
                fields: [
                    { ident: "info.passedOutDuringExcercise", name: "Have you ever passed out or nearly passed out DURING or AFTER exercise?", type: "switch", required: true, explanationRequired: true, explanationPrompt: 'When?' },
                    { ident: "info.discomfortInChestDuringExcercise", name: "Have you ever had discomfort, pain, tightness, or pressure in your chest during exercise?", type: "switch", required: true, explanationRequired: true, explanationPrompt: 'When?' },
                    { ident: "info.skipHeartBeatsDuringExcercise", name: "Does your heart ever race or skip beats (irregular beats) during exercise?", type: "switch", required: true, explanationRequired: true, explanationPrompt: 'How often?' },
                    { ident: "info.anyHeartProblems", name: "Has a doctor ever told you that you have any heart problems?", type: "switch", required: true, requirePrompt: 'Check all that apply' },
                    { ident: "info.hasHighBloodPressure", name: "High blood pressure", type: "selectCheckbox", showIfAll: [{ ident: "info.anyHeartProblems", value: true, fieldsCount: 5, mainIdent: "info.heartProblemsList" }] },
                    { ident: "info.hasHeartMurmur", name: "A heart murmur", type: "selectCheckbox", showIfAll: [{ ident: "info.anyHeartProblems", value: true, checkvalue: false, fieldsCount: 5, mainIdent: "info.heartProblemsList" }] },
                    { ident: "info.hasHighCholesterol", name: "High cholesterol", type: "selectCheckbox", showIfAll: [{ ident: "info.anyHeartProblems", value: true, checkvalue: false, fieldsCount: 5, mainIdent: "info.heartProblemsList" }] },
                    { ident: "info.hasHeartInfection", name: "A heart infection", type: "selectCheckbox", showIfAll: [{ ident: "info.anyHeartProblems", value: true, checkvalue: false, fieldsCount: 5, mainIdent: "info.heartProblemsList" }] },
                    { ident: "info.hasKawasakiDisease", name: "Kawasaki disease", type: "selectCheckbox", showIfAll: [{ ident: "info.anyHeartProblems", value: true, checkvalue: false, fieldsCount: 5, mainIdent: "info.heartProblemsList" }] },
                    { ident: "info.otherHeartProblems_explanation", name: "Other", type: "longText", showIfAll: [{ ident: "info.anyHeartProblems", value: true, checkvalue: '', fieldsCount: 5, mainIdent: "info.heartProblemsList" }] },
                    { ident: "info.heartProblemsList", name: "Heart" },
                    { ident: "info.orderedToTestHeart", name: "Has a doctor ever ordered a test for your heart? (For example, ECG/EKG, echocardiogram)", type: "switch", required: true, explanationRequired: true, explanationPrompt: 'When did you receive the testing?' },
                    { ident: "info.lightHeadedDuringExcercise", name: "Do you get lightheaded or feel more short of breath than expected during exercise?", type: "switch", required: true, explanationRequired: true, explanationPrompt: '' },
                    { ident: "info.unexplainedSeizure", name: "Have you ever had an unexplained seizure?", type: "switch", required: true, explanationRequired: true, explanationPrompt: 'When?' },
                    { ident: "info.breatheQuicklyDuringExcercise", name: "Do you get more tired or short of breath more quickly than your friends during exercise?", type: "switch", required: true, explanationRequired: true, explanationPrompt: '' },                    
                    { ident: "info.unexplainedSuddenDeath", name: "Has any family member or relative died of heart problems or had an unexpected or unexplained sudden death before 50 (including drowning unexplained car accident, or sudden infant death syndrome)?", type: "switch", required: true, explanationRequired: true, explanationPrompt: 'Which family member ?' },
                    { ident: "info.hypertrophicCardiomyopathy", name: "Does anyone in your family have hypertrophic cardiomyopathy, Marfan syndrome, arrhythmogenic right ventricular cardiomyopathy, long QT syndrome, short QT syndrome, Brugada syndrome, or catecholaminergic polymorphic ventricular tachycardia?", type: "switch", required: true, explanationRequired: true, explanationPrompt: 'Which family member ?' },
                    { ident: "info.paceMakerInHeart", name: "Does anyone in your family have a heart problem, pacemaker, or implanted defibrillator?", type: "switch", required: true, explanationRequired: true, explanationPrompt: 'Which family member ?' },
                    { ident: "info.unexplainedFainting", name: "Has anyone in your family had unexplained fainting, unexplained seizures, or near drowning?", type: "switch", required: true, explanationRequired: true, explanationPrompt: 'Which family member ?' },


                ]
            },
            {
                // Bone And Joint Tab
                name: "Bone And Joint",
                icon: "user-icon5",
                tabClass: 'col-xs-12',
                fields: [
                    { ident: "info.boneInjuryMissedActivity", name: "Have you ever had an injury to a bone, muscle, ligament, or tendon that caused you to miss a practice or a game?", type: "switch", required: true, explanationRequired: true, explanationPrompt: 'Which body part?' },
                    { ident: "info.brokenJoints", name: "Have you ever had any broken or fractured bones or dislocated joints?", type: "switch", required: true, explanationRequired: true, explanationPrompt: 'Which body part?' },
                    { ident: "info.injuryWithRequiredXray", name: "Have you ever had an injury that required x-rays, MRI, CT scan, injections, therapy, a brace, a cast, or crutches?", type: "switch", required: true, explanationRequired: true, explanationPrompt: '' },
                    { ident: "info.stressFracture", name: "Have you ever had a stress fracture?", type: "switch", required: true, explanationRequired: true, explanationPrompt: 'What was the injury?' },
                    { ident: "info.xrayForNeckInstability", name: "Have you ever been told that you have or have you had an x-ray for neck instability or atlantoaxial instability? (Down syndrome or dwarfism)", type: "switch", required: true, explanationRequired: true, explanationPrompt: '' },
                    { ident: "info.regularAssitiveDeviceUse", name: "Do you regularly use a brace, orthotics, or other assistive device?", type: "switch", required: true, explanationRequired: true, explanationPrompt: '' },
                    { ident: "info.boneInjury", name: "Do you have a bone, muscle, or joint injury that bothers you?", type: "switch", required: true, explanationRequired: true, explanationPrompt: 'Which body part?' },
                    { ident: "info.painfulJoints", name: "Do any of your joints become painful, swollen, feel warm, or look red?", type: "switch", required: true, explanationRequired: true, explanationPrompt: 'Which body part?' },
                    { ident: "info.historyOfJuvenileArthritis", name: "Do you have any history of juvenile arthritis or connective tissue disease?", type: "switch", required: true, explanationRequired: true, explanationPrompt: '' },
                ]
            },
            {
                // Other Medical Tab
                name: "Medical Questions",
                icon: "user-icon6",
                tabClass: 'col-xs-12',
                fields: [
                    { ident: "info.coughDuringExcercise", name: "Do you cough, wheeze, or have difficulty breathing during or after exercise?", type: "switch", required: true, explanationRequired: true, explanationPrompt: '' },
                    { ident: "info.takenAsthmaMedicine", name: "Have you ever used an inhaler or taken asthma medicine?", type: "switch", required: true, explanationRequired: true, explanationPrompt: '' },
                    { ident: "info.familyHasAsthma", name: "Is there anyone in your family who has asthma?", type: "switch", required: true, explanationRequired: true, explanationPrompt: '' },
                    { ident: "info.bornWithoutOrgan", name: "Were you born without or are you missing a kidney, an eye, a testicle (males), your spleen, or any other organ?", type: "switch", required: true, explanationRequired: true, explanationPrompt: 'Which organ?' },
                    { ident: "info.painfulGroinArea", name: "Do you have groin pain or a painful bulge or hernia in the groin area?", type: "switch", required: true, explanationRequired: true, explanationPrompt: '' },
                    { ident: "info.infectiousMononucleosis", name: "Have you had infectious mononucleosis (mono) within the last month?", type: "switch", required: true, explanationRequired: true, explanationPrompt: '' },
                    { ident: "info.rashesOnSkin", name: "Do you have any rashes, pressure sores, or other skin problems?", type: "switch", required: true, explanationRequired: true, explanationPrompt: '' },
                    { ident: "info.herpesSkinInfection", name: "Have you had a herpes or MRSA skin infection?", type: "switch", required: true, explanationRequired: true, explanationPrompt: '' },
                    { ident: "info.headInjury", name: "Have you ever had a head injury or concussion?", type: "switch", required: true, explanationRequired: true, explanationPrompt: 'When was the head injury?' },
                    { ident: "info.memoryProblemsByHitOnHead", name: "Have you ever had a hit or blow to the head that caused confusion, prolonged headache, or memory problems?", type: "switch", required: true, explanationRequired: true, explanationPrompt: 'When?' },
                    { ident: "info.historyOfSeizure", name: "Do you have a history of seizure disorder?", type: "switch", required: true, explanationRequired: true, explanationPrompt: '' },
                    { ident: "info.headachesWithExcercise", name: "Do you have headaches with exercise?", type: "switch", required: true, explanationRequired: true, explanationPrompt: '' },
                    { ident: "info.numbnessAfterFalling", name: "Have you ever had numbness, tingling, or weakness in your arms or legs after being hit or falling?", type: "switch", required: true, explanationRequired: true, explanationPrompt: '' },
                    { ident: "info.unableToMoveArmsAfterFalling", name: "Have you ever been unable to move your arms or legs after being hit or falling?", type: "switch", required: true, explanationRequired: true, explanationPrompt: '' },
                    { ident: "info.illDuringExcerciseInHeat", name: "Have you ever become ill while exercising in the heat?", type: "switch", required: true, explanationRequired: true, explanationPrompt: '' },
                    { ident: "info.muscleCrampDuringExcercise", name: "Do you get frequent muscle cramps when exercising?", type: "switch", required: true, explanationRequired: true, explanationPrompt: '' },
                    { ident: "info.sickleCellDisease", name: "Do you or someone in your family have sickle cell trait or disease?", type: "switch", required: true, explanationRequired: true, explanationPrompt: 'Who?' },
                    { ident: "info.problemsWithEyes", name: "Have you had any problems with your eyes or vision?", type: "switch", required: true, explanationRequired: true, explanationPrompt: '' },
                    { ident: "info.eyeInjuries", name: "Have you had any eye injuries?", type: "switch", required: true, explanationRequired: true, explanationPrompt: '' },
                    { ident: "info.wearGlasses", name: "Do you wear glasses or contact lenses?", type: "switch", required: true, explanationRequired: true, explanationPrompt: '' },
                    { ident: "info.wearProtectiveEyewear", name: "Do you wear protective eyewear, such as goggles or a face shield?", type: "switch", required: true, explanationRequired: true, explanationPrompt: '' },
                    { ident: "info.worryAboutWeight", name: "Do you worry about your weight?", type: "switch", required: true, explanationRequired: true, explanationPrompt: '' },
                    { ident: "info.recommendationToGainWeight", name: "Are you trying to or has anyone recommended that you gain or lose weight?", type: "switch", required: true, explanationRequired: true, explanationPrompt: '' },
                    { ident: "info.avoidCertainTypesOfFood", name: "Are you on a special diet or do you avoid certain types of foods?", type: "switch", required: true, explanationRequired: true, explanationPrompt: '' },
                    { ident: "info.hadEatingDisorder", name: "Have you ever had an eating disorder?", type: "switch", required: true, explanationRequired: true, explanationPrompt: '' },
                    { ident: "info.discussWithDoctor", name: "Do you have any concerns that you would like to discuss with a doctor?", type: "switch", required: true, explanationRequired: true, explanationPrompt: 'What would you like to discuss?' },
                ]
            },
        ];
    }

    validatePassword(password: string): boolean {
        // var errors = [];
        if (password.length >= 15) { // Password length is equal or greater then 15 character then no check any validation
            return true;
        }

        var errors_count = 0;
        if (password.length < 8) {
            errors_count = errors_count + 1;
            // errors.push("Your password must be at least 8 characters");
        }
        if (password.search(/(?=.*[!@#$%^&*])/i) < 0) {
            errors_count = errors_count + 1;
        }
        if (password.search(/(?=.*[0-9])/) < 0) {
            errors_count = errors_count + 1;
        }
        if (password.search(/(?=.*[a-z])/) < 0) {
            errors_count = errors_count + 1;
        }
        if (password.search(/(?=.*[A-Z])/) < 0) {
            errors_count = errors_count + 1;
        }
        if (errors_count > 1) {
            return false;
        }
        return true;
    }







}