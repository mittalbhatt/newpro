System.register(['@angular/core', '@angular/router', "./AthleteRegistrationResult", "./activity_auth.service", "../registration_context.service"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, router_1, AthleteRegistrationResult_1, activity_auth_service_1, registration_context_service_1;
    var AthleteRegistration;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (AthleteRegistrationResult_1_1) {
                AthleteRegistrationResult_1 = AthleteRegistrationResult_1_1;
            },
            function (activity_auth_service_1_1) {
                activity_auth_service_1 = activity_auth_service_1_1;
            },
            function (registration_context_service_1_1) {
                registration_context_service_1 = registration_context_service_1_1;
            }],
        execute: function() {
            // NOTE: I know that the built in validation for angular2 could be utilized here,
            // but I am running very short on time for this task.
            AthleteRegistration = (function () {
                function AthleteRegistration(_ctx, _router, _authorizer) {
                    this._ctx = _ctx;
                    this._router = _router;
                    this._authorizer = _authorizer;
                    this.now = new Date();
                    this.dt = new Date();
                    this.submitting = false;
                    this.registration = new AthleteRegistrationResult_1.AthleteRegistrationResult();
                }
                AthleteRegistration.prototype.onChange = function () {
                    this.errorMessage = null;
                };
                AthleteRegistration.prototype.onSubmit = function () {
                    var _this = this;
                    if (!this.registration.firstName || !this.registration.lastName) {
                        this.errorMessage = 'Please provide a first and last name.';
                    }
                    else if (!this.registration.dob) {
                        this.errorMessage = 'Please provide a date of birth.';
                    }
                    else if (this.registration.email && (this.registration.email.toLowerCase() != (this.registration.confirmEmail || '').toLowerCase())) {
                        this.errorMessage = 'Email fields must match.';
                    }
                    else {
                        this.submitting = true;
                        this._authorizer.auth(this._ctx.docAct._id, this.registration)
                            .single()
                            .subscribe(function (result) {
                            _this._ctx.creds = result;
                            _this._router.navigate(['/athDashboard']);
                        }, function (error) {
                            _this.submitting = false;
                            _this.errorMessage = error.json().message || 'Error';
                            console.error(_this.errorMessage);
                            window.scroll(0, 0);
                        }, function () {
                            _this.submitting = false;
                        });
                    }
                    if (this.errorMessage)
                        window.scroll(0, 0);
                };
                AthleteRegistration.prototype.ngOnInit = function () {
                    if (!this._ctx.docAct) {
                        this._router.navigate(['/TODO need target in registration']);
                        return;
                    }
                };
                AthleteRegistration = __decorate([
                    core_1.Component({
                        selector: 'athlete-registration',
                        template: "\n<h1>ATTENTION!! ATTENTION!! From here forward has not been updated yet and will not work.</h1>\n        <div style=\"margin-top:100px;\">\n            <div>\n                <registration-heading [doc-act]=\"_ctx.docAct\"></registration-heading>\n                <div style=\"max-width:300px; margin:auto\">\n                <div [hidden]=\"!errorMessage\" class=\"alert alert-danger\">{{errorMessage}}</div>\n                <form [hidden]=\"submitting\" style=\"margin-bottom:50px; margin-top:20px;\" (ngSubmit)=\"onSubmit()\">\n                    <h3>Enter Athlete's Information:</h3>\n                        <div class=\"form-group\">\n                            <label for=\"inputFirstName\">First name</label>\n                            <input id=\"inputFirstName\" \n                                ngControl=\"inputFirstName\"\n                                (ngModelChange)=\"onChange()\"\n                                class=\"form-control\" \n                                placeholder=\"First Name\" \n                                maxlength=\"50\" \n                                [(ngModel)]=\"registration.firstName\" \n                                autofocus />\n                        </div>\n                        <div class=\"form-group\">\n                            <label for=\"inputFirstName\">Last name</label>\n                            <input id=\"inputLastName\" \n                            ngControl=\"inputLastName\"\n                            (ngModelChange)=\"onChange()\"\n                            class=\"form-control\" \n                            placeholder=\"Last Name\"\n                            maxlength=\"50\" \n                            [(ngModel)]=\"registration.lastName\" />\n                        </div>\n                        <div class=\"form-group\">\n                            <label for=\"inputPhone\">Phone</label>\n                            <input id=\"inputPhone\" \n                            ngControl=\"inputPhone\"\n                            (ngModelChange)=\"onChange()\"\n                            class=\"form-control\" \n                            placeholder=\"Phone\"\n                            maxlength=\"50\" \n                            name=\"Phone\"\n                            type=\"tel\"\n                            [(ngModel)]=\"registration.tel\" />\n                        </div>\n                        <div class=\"form-group\">\n                            <label for=\"inputEmail\">Email</label>\n                            <input id=\"inputEmail\" \n                            ngControl=\"inputEmail\"\n                            (ngModelChange)=\"onChange()\"\n                            class=\"form-control\" \n                            placeholder=\"Email\"\n                            maxlength=\"50\" \n                            name=\"Email\"\n                            type=\"email\"\n                            [(ngModel)]=\"registration.email\" />\n                        </div>\n                        <div class=\"form-group\">\n                            <label for=\"inputEmail\">Confirm Email</label>\n                            <input id=\"inputEmail\" \n                            ngControl=\"inputEmail\"\n                            (ngModelChange)=\"onChange()\"\n                            class=\"form-control\" \n                            placeholder=\"Confirm Email\"\n                            maxlength=\"50\" \n                            name=\"Email\"\n                            type=\"email\"\n                            [(ngModel)]=\"registration.confirmEmail\" />\n                        </div>\n                        <div class=\"form-group\">\n                             <label>Date of birth:</label>\n                             <combo-date (selectedDateChange)=\"onChange()\" (selectedDate)=\"registration.dob\"></combo-date>\n                        </div>\n                        \n                        <h4 style=\"text-align:left; margin-top:25px;\">Mailing Address:</h4>\n                        <div class=\"form-group\">\n                            <div class=\"form-group\">\n                                <label for=\"inputStreet\">Street or PO Box</label>\n                                <input id=\"inputStreet\" \n                                       ngControl=\"inputStreet\"\n                                       (ngModelChange)=\"onChange()\"\n                                       class=\"form-control\"\n                                       placeholder=\"Street\"\n                                       maxlength=\"100\"\n                                       name=\"Address\"\n                                       [(ngModel)]=\"registration.addressStreet\" />\n                            </div>\n                            <label for=\"inputCity\">City</label>\n                            <input id=\"inputCity\" \n                                   ngControl=\"inputCity\"\n                                   (ngModelChange)=\"onChange()\"\n                                   class=\"form-control\"\n                                   placeholder=\"City\"\n                                   maxlength=\"100\"\n                                   name=\"City\"\n                                   [(ngModel)]=\"registration.addressCity\" />\n                        </div>\n                        <div class=\"form-group\">\n                            <label for=\"inputState\">State</label>\n                            <input id=\"inputState\" \n                                   ngControl=\"inputState\"\n                                   (ngModelChange)=\"onChange()\"\n                                   class=\"form-control\"\n                                   placeholder=\"State\"\n                                   maxlength=\"100\"\n                                   name=\"State\"\n                                   [(ngModel)]=\"registration.addressState\" />\n                        </div>\n                        <div class=\"form-group\">\n                            <label for=\"inputZip\">Zip</label>\n                            <input id=\"inputState\" \n                                   ngControl=\"inputZip\"\n                                   (ngModelChange)=\"onChange()\"\n                                   class=\"form-control\"\n                                   placeholder=\"Zip\"\n                                   maxlength=\"10\"\n                                   name=\"Zip\"\n                                   [(ngModel)]=\"registration.addressZip\" />\n                        </div>\n                        <div class=\"form-group\" style=\"display:block; height:25px;\">\n                            <button type=\"submit\" class=\"btn btn-primary\">Continue</button>\n                        </div>\n                </form>\n                <div [hidden]=\"!submitting\" class=\"alert alert-info\">Submitting...</div>\n                </div>\n            </div>\n        </div>\n",
                        styles: [
                            'combo-date { width:100%; text-align:left; display:block; }',
                            'button[type=submit] { float:right; }'
                        ]
                    }), 
                    __metadata('design:paramtypes', [registration_context_service_1.RegistrationContext, router_1.Router, activity_auth_service_1.ActivityAuthorizer])
                ], AthleteRegistration);
                return AthleteRegistration;
            }());
            exports_1("AthleteRegistration", AthleteRegistration);
        }
    }
});
//# sourceMappingURL=athlete_registration.component.js.map