import {Component, OnInit, Optional, Inject} from '@angular/core';
import {ComboDayPicker} from "./combo_day_picker";
import {Router} from '@angular/router';
import {RegistrationHeading} from "../registration_heading.component";
import {AthleteRegistrationResult} from "./AthleteRegistrationResult";
import {ActivityAuthorizer} from "./activity_auth.service";
import {RegistrationContext} from "../registration_context.service";

// NOTE: I know that the built in validation for angular2 could be utilized here,
// but I am running very short on time for this task.

@Component({
    selector: 'athlete-registration',
    template:
        `
<h1>ATTENTION!! ATTENTION!! From here forward has not been updated yet and will not work.</h1>
        <div style="margin-top:100px;">
            <div>
                <registration-heading [doc-act]="_ctx.docAct"></registration-heading>
                <div style="max-width:300px; margin:auto">
                <div [hidden]="!errorMessage" class="alert alert-danger">{{errorMessage}}</div>
                <form [hidden]="submitting" style="margin-bottom:50px; margin-top:20px;" (ngSubmit)="onSubmit()">
                    <h3>Enter Athlete's Information:</h3>
                        <div class="form-group">
                            <label for="inputFirstName">First name</label>
                            <input id="inputFirstName" 
                                ngControl="inputFirstName"
                                (ngModelChange)="onChange()"
                                class="form-control" 
                                placeholder="First Name" 
                                maxlength="50" 
                                [(ngModel)]="registration.firstName" 
                                autofocus />
                        </div>
                        <div class="form-group">
                            <label for="inputFirstName">Last name</label>
                            <input id="inputLastName" 
                            ngControl="inputLastName"
                            (ngModelChange)="onChange()"
                            class="form-control" 
                            placeholder="Last Name"
                            maxlength="50" 
                            [(ngModel)]="registration.lastName" />
                        </div>
                        <div class="form-group">
                            <label for="inputPhone">Phone</label>
                            <input id="inputPhone" 
                            ngControl="inputPhone"
                            (ngModelChange)="onChange()"
                            class="form-control" 
                            placeholder="Phone"
                            maxlength="50" 
                            name="Phone"
                            type="tel"
                            [(ngModel)]="registration.tel" />
                        </div>
                        <div class="form-group">
                            <label for="inputEmail">Email</label>
                            <input id="inputEmail" 
                            ngControl="inputEmail"
                            (ngModelChange)="onChange()"
                            class="form-control" 
                            placeholder="Email"
                            maxlength="50" 
                            name="Email"
                            type="email"
                            [(ngModel)]="registration.email" />
                        </div>
                        <div class="form-group">
                            <label for="inputEmail">Confirm Email</label>
                            <input id="inputEmail" 
                            ngControl="inputEmail"
                            (ngModelChange)="onChange()"
                            class="form-control" 
                            placeholder="Confirm Email"
                            maxlength="50" 
                            name="Email"
                            type="email"
                            [(ngModel)]="registration.confirmEmail" />
                        </div>
                        <div class="form-group">
                             <label>Date of birth:</label>
                             <combo-date (selectedDateChange)="onChange()" (selectedDate)="registration.dob"></combo-date>
                        </div>
                        
                        <h4 style="text-align:left; margin-top:25px;">Mailing Address:</h4>
                        <div class="form-group">
                            <div class="form-group">
                                <label for="inputStreet">Street or PO Box</label>
                                <input id="inputStreet" 
                                       ngControl="inputStreet"
                                       (ngModelChange)="onChange()"
                                       class="form-control"
                                       placeholder="Street"
                                       maxlength="100"
                                       name="Address"
                                       [(ngModel)]="registration.addressStreet" />
                            </div>
                            <label for="inputCity">City</label>
                            <input id="inputCity" 
                                   ngControl="inputCity"
                                   (ngModelChange)="onChange()"
                                   class="form-control"
                                   placeholder="City"
                                   maxlength="100"
                                   name="City"
                                   [(ngModel)]="registration.addressCity" />
                        </div>
                        <div class="form-group">
                            <label for="inputState">State</label>
                            <input id="inputState" 
                                   ngControl="inputState"
                                   (ngModelChange)="onChange()"
                                   class="form-control"
                                   placeholder="State"
                                   maxlength="100"
                                   name="State"
                                   [(ngModel)]="registration.addressState" />
                        </div>
                        <div class="form-group">
                            <label for="inputZip">Zip</label>
                            <input id="inputState" 
                                   ngControl="inputZip"
                                   (ngModelChange)="onChange()"
                                   class="form-control"
                                   placeholder="Zip"
                                   maxlength="10"
                                   name="Zip"
                                   [(ngModel)]="registration.addressZip" />
                        </div>
                        <div class="form-group" style="display:block; height:25px;">
                            <button type="submit" class="btn btn-primary">Continue</button>
                        </div>
                </form>
                <div [hidden]="!submitting" class="alert alert-info">Submitting...</div>
                </div>
            </div>
        </div>
`,
    styles: [
        'combo-date { width:100%; text-align:left; display:block; }',
        'button[type=submit] { float:right; }'
    ]
})
export class AthleteRegistration implements OnInit {
    registration: AthleteRegistrationResult;
    now:Date = new Date();
    dt:Date = new Date();
    submitting = false;

    errorMessage:string;

    constructor(
        private _ctx:RegistrationContext,
        private _router:Router,
        private _authorizer:ActivityAuthorizer)
    {
        this.registration = new AthleteRegistrationResult();
    }

    onChange() {
        this.errorMessage = null;
    }

    onSubmit() {
        if (!this.registration.firstName || !this.registration.lastName)
        {
            this.errorMessage = 'Please provide a first and last name.';
        }
        else if (!this.registration.dob)
        {
            this.errorMessage = 'Please provide a date of birth.';
        }
        else if (this.registration.email && (this.registration.email.toLowerCase() != (this.registration.confirmEmail || '').toLowerCase()))
        {
            this.errorMessage = 'Email fields must match.';
        }
        else
        {
            this.submitting = true;
            this._authorizer.auth(this._ctx.docAct._id, this.registration)
                .single()
                .subscribe(result =>
                {
                    this._ctx.creds = result;
                    this._router.navigate(['/athDashboard']);
                },
                error =>
                {
                    this.submitting = false;
                    this.errorMessage = error.json().message || 'Error';
                    console.error(this.errorMessage);
                    window.scroll(0,0);
                },
                () =>
                {
                    this.submitting = false;
                });
        }

        if (this.errorMessage)
            window.scroll(0,0);
    }

    ngOnInit(){
        if (!this._ctx.docAct)
        {
            this._router.navigate(['/TODO need target in registration']);
            return;
        }
    }
}
