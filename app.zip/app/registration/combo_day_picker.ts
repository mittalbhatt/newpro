/// <reference path="../../typings/underscore/underscore.d.ts" />
/// <reference path="../../typings/moment/moment.d.ts" />

import {Component, Output, EventEmitter, Input} from "@angular/core";
import * as moment_ from 'moment';
const moment:moment.MomentStatic = (<any>moment_)['default'] || moment_;
import * as _ from "underscore";

@Component({
    selector: 'combo-date',
    template:`
        <select class="form-control dropdown-select" (change)="onYearChange($event.target.value)">
            <option>Year</option>
            <option [selected]="year == _selectedYear" *ngFor="let year of _years">{{year}}</option>
        </select>
        <select class="form-control dropdown-select" (change)="onMonthChange($event.target.value)">
            <option>Month</option>
            <option [selected]="month == _selectedMonth" *ngFor="let month of _months">{{month}}</option>
        </select>
        <select class="form-control dropdown-select" (change)="onDayChange($event.target.value)">
            <option>Day</option>
            <option [selected]="day == _selectedDay" *ngFor="let day of _days">{{day}}</option>
        </select>
    `
})
export class ComboDayPicker {
    @Output() selectedDateChange = new EventEmitter<string>();

    private _years:number[];
    private _selectedYear:number;
    private _months:string[];
    private _selectedMonth:string;
    private _days:number[];
    private _selectedDay:number;

    constructor() {
        var year = (new Date()).getFullYear();
        this._years = _.range(40).map(i => year - i);
        this._months = moment.months();
    }

    private onYearChange(value, suppressEvent=false)
    {
        this._selectedYear = value ? parseInt(value) : value;
        this.updateSelectedDate(suppressEvent);
    }

    private onMonthChange(value, suppressEvent=false)
    {
        this._selectedMonth = value;
        this.updateSelectedDate(suppressEvent);
    }

    private onDayChange(value, suppressEvent=false)
    {
        this._selectedDay = value ? parseInt(value) : value;
        this.updateSelectedDate(suppressEvent);
    }

    private updateSelectedDate(suppressEvent=false)
    {
        var selectedMoment = moment();

        var emitter = suppressEvent ? new EventEmitter<string>() : this.selectedDateChange;

        if (this._selectedYear)
            selectedMoment.year(this._selectedYear);
        else {
            emitter.emit(null);
            return;
        }

        if (this._selectedMonth)
            selectedMoment.month(this._selectedMonth);
        else {
            emitter.emit(null);
            return;
        }

        this._days = _.range(selectedMoment.daysInMonth()).map(i => (i+1));
        if (this._days.indexOf(this._selectedDay) > -1)
            selectedMoment.date(this._selectedDay);
        else {
            emitter.emit(null);
            return;
        }

        emitter.emit(selectedMoment.format('YYYY-MM-DD'));
    }

    @Input('date-as-string') set dateAsString(value:string) {
        if (value)
        {
            var parts = value.split('-');
            if (parts.length == 3) {
                this.onYearChange(parts[0], true);
                this.onMonthChange(moment.months()[parseInt(parts[1]) - 1], true);
                this.onDayChange(parts[2], true);
            }
        }
    }
}