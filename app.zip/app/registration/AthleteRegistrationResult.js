System.register([], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var AthleteRegistrationResult;
    return {
        setters:[],
        execute: function() {
            AthleteRegistrationResult = (function () {
                function AthleteRegistrationResult() {
                }
                return AthleteRegistrationResult;
            }());
            exports_1("AthleteRegistrationResult", AthleteRegistrationResult);
        }
    }
});
//# sourceMappingURL=AthleteRegistrationResult.js.map