// import { ICustomModal, ICustomModalComponent } from '../lib/angular2-modal/models/ICustomModal';
//
// import { Component } from "@angular/core";
// import {FORM_DIRECTIVES} from '@angular/common';
// import {DatePicker} from 'ng2-datepicker';
// import { ModalDialogInstance } from "../lib/angular2-modal/models/ModalDialogInstance";
//
// export class ModalAthleteRegistrationResult
// {
//     firstName:string;
//     lastName:string;
//     dob:Date;
// }
//
// /**
//  * A 2 state bootstrap modal window, representing 2 possible answer, true/false.
//  */
// @Component({
//     selector: 'modal-content',
//     template:
//         `<div class="modal-header">
//         <h3 class="modal-title">Athlete Information</h3>
//         </div>
//         <form name="athleteRegistrationForm">
//             <div class="modal-body">
//                 <div class="form-group">
//                     <label for="inputFirstName">First name</label>
//                     <input id="inputLastName" class="form-control" placeholder="First Name" maxlength="50" [(ngModel)]="context.firstName" autofocus />
//                 </div>
//                 <div class="form-group">
//                     <label for="inputFirstName">Last name</label>
//                     <input id="inputLastName" class="form-control" placeholder="Last Name" maxlength="50" [(ngModel)]="context.lastName" />
//                 </div>
//                 <div class="form-group">
//                     <label>Date of birth: <span style="font-weight: normal;">{{context.dob}}</span></label>
//                     <p class="info">choose DOB:</p>
//                     <datepicker static="true" [(ngModel)]="context.dob" view-format="MM.DD.YYYY" model-format="MM.DD.YYYY"></datepicker>
//                 </div>
//             </div>
//             <div class="modal-footer">
//                 <button type="button" class="btn btn-default" (click)="cancel()">Cancel</button>
//                 <button type="button" class="btn btn-primary" (click)="ok()">Continue</button>
//             </div>
//         </form>
// `,
//     styles:[`
//          p.info {
//             text-align: left;
//             font-size:10px;
//             padding:0px;
//             margin:0px;
//          }
//
//          modal-content {
//          height:1000px;
//          }
//     `],
//     directives: [DatePicker, FORM_DIRECTIVES]
// })
// export class ModalAthleteRegistration implements ICustomModalComponent {
//     dialog: ModalDialogInstance;
//     context: ModalAthleteRegistrationResult;
//
//     constructor(dialog: ModalDialogInstance) {
//         this.dialog = dialog;
//         this.context = new ModalAthleteRegistrationResult();
//     }
//
//     ok() {
//         this.dialog.close(this.context);
//     }
//
//     cancel() {
//         this.dialog.close(false);
//     }
// }
