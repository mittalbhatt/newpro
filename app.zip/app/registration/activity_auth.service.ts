import {Http, Response, Headers, URLSearchParams} from "@angular/http";
import {Inject, Injectable} from "@angular/core";
import {AthleteRegistrationResult} from "./AthleteRegistrationResult";

@Injectable()
export class ActivityAuthorizer {
    constructor(private _http:Http){}
    
    auth(activityId:string, registration:AthleteRegistrationResult){
        let params: URLSearchParams = new URLSearchParams();
        params.set('firstName', registration.firstName);
        params.set('lastName', registration.lastName);
        params.set('dob', registration.dob);

        if (registration.tel)
            params.set('tel', registration.tel);
        if (registration.email)
            params.set('email', registration.email);
        if (registration.addressCity)
            params.set('addressCity', registration.addressCity);
        if (registration.addressState)
            params.set('addressState', registration.addressState);
        if (registration.addressZip)
            params.set('addressZip', registration.addressZip);
        if (registration.addressStreet)
            params.set('addressStreet', registration.addressStreet);

        return this._http.get('/training/api/activities/'+activityId+'/authorizationFactory', {search:params})
            .map((res:Response) => res.json());
    }
}