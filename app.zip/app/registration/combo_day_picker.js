/// <reference path="../../typings/underscore/underscore.d.ts" />
/// <reference path="../../typings/moment/moment.d.ts" />
System.register(["@angular/core", 'moment', "underscore"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, moment_, _;
    var moment, ComboDayPicker;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (moment_1) {
                moment_ = moment_1;
            },
            function (_1) {
                _ = _1;
            }],
        execute: function() {
            moment = moment_['default'] || moment_;
            ComboDayPicker = (function () {
                function ComboDayPicker() {
                    this.selectedDateChange = new core_1.EventEmitter();
                    var year = (new Date()).getFullYear();
                    this._years = _.range(40).map(function (i) { return year - i; });
                    this._months = moment.months();
                }
                ComboDayPicker.prototype.onYearChange = function (value, suppressEvent) {
                    if (suppressEvent === void 0) { suppressEvent = false; }
                    this._selectedYear = value ? parseInt(value) : value;
                    this.updateSelectedDate(suppressEvent);
                };
                ComboDayPicker.prototype.onMonthChange = function (value, suppressEvent) {
                    if (suppressEvent === void 0) { suppressEvent = false; }
                    this._selectedMonth = value;
                    this.updateSelectedDate(suppressEvent);
                };
                ComboDayPicker.prototype.onDayChange = function (value, suppressEvent) {
                    if (suppressEvent === void 0) { suppressEvent = false; }
                    this._selectedDay = value ? parseInt(value) : value;
                    this.updateSelectedDate(suppressEvent);
                };
                ComboDayPicker.prototype.updateSelectedDate = function (suppressEvent) {
                    if (suppressEvent === void 0) { suppressEvent = false; }
                    var selectedMoment = moment();
                    var emitter = suppressEvent ? new core_1.EventEmitter() : this.selectedDateChange;
                    if (this._selectedYear)
                        selectedMoment.year(this._selectedYear);
                    else {
                        emitter.emit(null);
                        return;
                    }
                    if (this._selectedMonth)
                        selectedMoment.month(this._selectedMonth);
                    else {
                        emitter.emit(null);
                        return;
                    }
                    this._days = _.range(selectedMoment.daysInMonth()).map(function (i) { return (i + 1); });
                    if (this._days.indexOf(this._selectedDay) > -1)
                        selectedMoment.date(this._selectedDay);
                    else {
                        emitter.emit(null);
                        return;
                    }
                    emitter.emit(selectedMoment.format('YYYY-MM-DD'));
                };
                Object.defineProperty(ComboDayPicker.prototype, "dateAsString", {
                    set: function (value) {
                        if (value) {
                            var parts = value.split('-');
                            if (parts.length == 3) {
                                this.onYearChange(parts[0], true);
                                this.onMonthChange(moment.months()[parseInt(parts[1]) - 1], true);
                                this.onDayChange(parts[2], true);
                            }
                        }
                    },
                    enumerable: true,
                    configurable: true
                });
                __decorate([
                    core_1.Output(), 
                    __metadata('design:type', Object)
                ], ComboDayPicker.prototype, "selectedDateChange", void 0);
                __decorate([
                    core_1.Input('date-as-string'), 
                    __metadata('design:type', String), 
                    __metadata('design:paramtypes', [String])
                ], ComboDayPicker.prototype, "dateAsString", null);
                ComboDayPicker = __decorate([
                    core_1.Component({
                        selector: 'combo-date',
                        template: "\n        <select class=\"form-control dropdown-select\" (change)=\"onYearChange($event.target.value)\">\n            <option>Year</option>\n            <option [selected]=\"year == _selectedYear\" *ngFor=\"let year of _years\">{{year}}</option>\n        </select>\n        <select class=\"form-control dropdown-select\" (change)=\"onMonthChange($event.target.value)\">\n            <option>Month</option>\n            <option [selected]=\"month == _selectedMonth\" *ngFor=\"let month of _months\">{{month}}</option>\n        </select>\n        <select class=\"form-control dropdown-select\" (change)=\"onDayChange($event.target.value)\">\n            <option>Day</option>\n            <option [selected]=\"day == _selectedDay\" *ngFor=\"let day of _days\">{{day}}</option>\n        </select>\n    "
                    }), 
                    __metadata('design:paramtypes', [])
                ], ComboDayPicker);
                return ComboDayPicker;
            }());
            exports_1("ComboDayPicker", ComboDayPicker);
        }
    }
});
//# sourceMappingURL=combo_day_picker.js.map