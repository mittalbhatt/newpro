export class AthleteRegistrationResult
{
    firstName:string;
    lastName:string;
    tel:string;
    email:string;
    confirmEmail:string;
    addressCity:string;
    addressState:string;
    addressZip:string;
    addressStreet:string;

    // Store as a string to avoid timezone issues.
    dob:string;
}