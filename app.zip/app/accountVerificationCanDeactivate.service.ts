import {Injectable} from "@angular/core";
import {AccountVerificationComponent} from "./verifyAccount.component";
import {CanDeactivate, RouterStateSnapshot, ActivatedRouteSnapshot} from "@angular/router";

@Injectable()
export class AccountVerificationCanDeactivate implements CanDeactivate<AccountVerificationComponent>
{
    canDeactivate(component:AccountVerificationComponent, route:ActivatedRouteSnapshot, state: RouterStateSnapshot):any
    {
        console.log('can deactivate - ' +  component.done);
        return component.done;
    }
}