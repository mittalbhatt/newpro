import {Component, OnInit, Output} from "@angular/core";
import {MaxAppContext} from "./maxAppContext.service";
import {Organizations, Organization} from "./organizations.service";

@Component({
    selector:'org-heading',
    template:`
<div>
<img *ngIf="org?.logoUrl" [src]="org?.logoUrl" style="max-width:200px; max-height:200px;" />
<h2 *ngIf="!org?.logoUrl && org?.name">{{org?.name}}</h2>
<h5 *ngIf="org?.logoUrl && org?.name" style="margin-bottom:0px;">{{org?.name}}</h5>
</div>
        `
})
export class OrgHeadingComponent implements OnInit
{
    org:Organization;

    constructor(
        private _organizations:Organizations,
        private _ctx:MaxAppContext){}

    ngOnInit()
    {
        var currentId = this.org ? this.org._id : null;
        if (this._ctx.orgId && currentId != this._ctx.orgId)
        {
            this._organizations.getOrgFromDirectory(this._ctx.orgId).single().toPromise()
                .then(o => this.org = o);
        }
    }
}