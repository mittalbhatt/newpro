import {Component, OnInit, Inject, ViewContainerRef} from '@angular/core';
import {
    AthleteDocumentationFormStatusSummary, AthleteDocumentationFormStatusItem
} from "./athlete_form_status";
import * as _ from 'underscore';
import {DocumentationDocDescriptionReference} from './documentation_activity';
import {DocumentLoader} from './document_loader.service';
import {RegistrationContext} from './registration_context.service';
import {DocumentationActivitySummaries} from "./documentation_activity_summaries.service";
import {Assignments} from "./assignments.service";
import {AdminFormPrintModal, AdminFormPrintModalData} from "./admin_form_print_modal";
import {DfUuidGen} from "./df_uuid_gen";
import {Organizations} from "./organizations.service";
import {Overlay, overlayConfigFactory} from 'angular2-modal';
import {Modal, BSModalContext} from 'angular2-modal/plugins/bootstrap';
import {ActivatedRoute, Router} from "@angular/router";
import {UserProfileCreationModalPrompt} from "./userProfileCreationModalPrompt.component";
import {AccessRequestApprovalModal, AccessRequestApprovalData} from "./accessRequestApprovalModal.component";
import {UserProfiles, UserProfile} from "./user_profiles.service";
import {DfObjectId} from "./DfObjectId";

declare var plupload;

@Component({
    selector:'admin-event-view',
    providers:[DocumentationActivitySummaries, Assignments, Organizations, RegistrationContext, DocumentLoader],
    template:`
    <div *ngIf="errorMessage" class="alert alert-danger">{{errorMessage}}</div>
    <h1 *ngIf="loading">Loading...</h1>
    <div *ngIf="!loading" (click)="openDropdown = undefined" style="text-align:left;">
        <div style="max-width:800px; margin:0 auto">
                <div class="hidden-xs">
                    <a href="javascript:void(0)" style="float:right" class="btn btn-default" (click)="refresh()"><span class="glyphicon glyphicon-refresh"></span></a>
                    <a href="javascript:void(0)" style="float:right; margin-right:5px;" class="btn btn-default" (click)="addAthlete()"><span class="glyphicon glyphicon-plus"></span> Add Athlete</a>
                    <button style="margin-right:5px; float:right" type="button" class="btn btn-primary" (click)="onOpenPrintWindow()">
                        <span *ngIf="!printing" class="glyphicon glyphicon-print"></span><img [hidden]="!printing" src="/maxweb/app/media/ajax-loader-white.gif" /> Print
                    </button>
                </div>
                
                <div class="visible-xs" style="text-align:center; margin-bottom:10px;">
                    <button style="margin-right:5px;" type="button" class="btn btn-primary" (click)="onOpenPrintWindow()">
                        <span *ngIf="!printing" class="glyphicon glyphicon-print"></span><img [hidden]="!printing" src="/maxweb/app/media/ajax-loader-white.gif" /> Print
                    </button>
                    
                    <a href="javascript:void(0)" style="margin-right:5px;" class="btn btn-default" (click)="addAthlete()"><span class="glyphicon glyphicon-plus"></span> Add Athlete</a>
                    
                    <a href="javascript:void(0)" class="btn btn-default" (click)="refresh()"><span class="glyphicon glyphicon-refresh"></span></a>
                </div>
        
                <div style="text-align:center; width:150px; min-height:110px; float:left; margin-right:10px; cursor:pointer;" df-pl-upload-host [targetTooltip]="'Team Logo'" [uploadSettings]="logoUploadSettings" [uploadStateChanged]="_orgLogoUploadStateChange">
                    <img style="max-width:150px; max-height:100px;" [src]="(logoImageUrl && !logoUploading) ? logoImageUrl : '/maxweb/app/media/placeholder.png'" />       
                    <p [hidden]="logoImageUrl || logoUploading" style="margin-top:-60px; text-align:center; font-size:12px; color:#428bca;">Click to upload team logo</p>
                    <p *ngIf="logoUploading" style="margin-top:-60px; text-align:center; color:#428bca">Uploading logo...</p>
                    <!--<img [hidden]="!logoUploading" src="/mgmt/app/img/ajax-loader-white.gif" />-->
                </div>
                <div style="text-align:left">
                    <h3 style="font-weight:normal; margin-left:20px; margin-bottom:0px">{{eventName}}</h3>
                    <h4 style="font-weight:bolder; margin-top:2px; color:#808080">{{statusSummary.org.name}}</h4>
                </div>
                <table>
                    <tr><td style="font-weight:bold; text-align:right">Your School Code</td><td style="padding-left:30px; font-weight:bold; color:#3f48cc">{{statusSummary.org.shortCode}}</td></tr>
                    <tr><td style="font-weight:bold; text-align:right">Forms Link</td><td style="padding-left:30px;">{{athleteUrl}}</td></tr>
                </table>
                <br />
         </div>
        <table class="table table-hover" style="max-width:800px; margin:0 auto">
            <tr>
                <th width="20"></th>
                <th width="20"><input #chk type="checkbox" (click)="toggleSelectAllItems($event, chk.checked)" /></th>
                <th width="*">
                    <a href="javascript:void(0)" (click)="sortField = 'athleteDisplayName'">
                    Name
                    <span *ngIf="(sortField == 'athleteDisplayName') && sortDescending" class="glyphicon glyphicon-circle-arrow-down"></span>
                    <span *ngIf="(sortField == 'athleteDisplayName') && !sortDescending" class="glyphicon glyphicon-circle-arrow-up"></span>
                    </a>
                </th>
                <th width="100">
                    <a href="javascript:void(0)" (click)="sortField = 'alerts'">
                        <span style="color:red; font-size:20px;" class="glyphicon glyphicon-exclamation-sign"></span>
                        <span *ngIf="(sortField == 'alerts') && sortDescending" class="glyphicon glyphicon-circle-arrow-down"></span>
                        <span *ngIf="(sortField == 'alerts') && !sortDescending" class="glyphicon glyphicon-circle-arrow-up"></span>
                    </a>
                </th>
                <th width="150">
                    <a href="javascript:void(0)" (click)="sortField = 'athleteDob'">
                    DOB
                    <span *ngIf="(sortField == 'athleteDob') && sortDescending" class="glyphicon glyphicon-circle-arrow-down"></span>
                    <span *ngIf="(sortField == 'athleteDob') && !sortDescending" class="glyphicon glyphicon-circle-arrow-up"></span>
                    </a>
                </th>
                <th width="100">
                    <a href="javascript:void(0)" (click)="sortField = 'accepted'">
                    Cleared
                    <span *ngIf="(sortField == 'accepted') && sortDescending" class="glyphicon glyphicon-circle-arrow-down"></span>
                    <span *ngIf="(sortField == 'accepted') && !sortDescending" class="glyphicon glyphicon-circle-arrow-up"></span>
                    </a>
                </th>
            </tr>
            <tr style="cursor:pointer" *ngFor="let item of statusItems; let i = index" (click)="toggleDropdown($event,'row'+i)">
                <td><strong>{{i+1}}</strong></td>
                <td>
                    <input type="checkbox" (click)="toggleSelectItem($event, item)" [checked]="itemIsSelected(item)" />
                </td>
                <td>
                    {{item.athleteDisplayName}}
                     <div dropdown autoClose="outsideClick" [isOpen]="openDropdown == 'row'+i">
                         <ul class="dropdown-menu">
                            <li role="menuitem" *ngFor="let docDesc of statusSummary.documentationActivity.documentationEventDescription.documents">
                                <a href="javascript:void(0)" (click)="openForm(item, docDesc)" class="dropdown-item">
                                    <span *ngIf="!docIsComplete(item, docDesc)" class="glyphicon glyphicon-unchecked"></span>
                                    <span *ngIf="docIsComplete(item, docDesc)" style="color:green" class="glyphicon glyphicon-check"></span>
                                    {{docDesc.name}}
                                    <span *ngIf="docAlertCount(item, docDesc)" [style.background]="docAlertCount(item, docDesc) > 0 ? 'red' : 'grey'" class="badge">{{docAlertCount(item, docDesc)}}</span>
                                </a>
                            </li>
                        </ul>
                    </div>
                </td>
                <td>
                      <span [style.background]="itemAlertCount(item) > 0 ? 'red' : 'grey'" class="badge">{{itemAlertCount(item)}}</span>              
                </td>
                <td>{{item.athleteDob?.substr(0,10)}}</td>
                <td style="text-align:center" [ngSwitch]="item.summaryValues.physicalFormClearedStatus">
                    <template ngSwitchDefault>
                        <span class="glyphicon glyphicon-unchecked"></span>
                    </template>
                    <template [ngSwitchCase]="'a_cleared'">
                        <span class="glyphicon glyphicon-check" style="color:green"></span>
                    </template>
                    <template [ngSwitchCase]="'b_clearedWithEval'">
                        <span style="color:gold">*</span>&nbsp;<span class="glyphicon glyphicon-check" style="color:gold"></span>
                    </template>
                    <template [ngSwitchCase]="'c_notCleared'">
                        <span class="glyphicon glyphicon-ban-circle" style="color:red"></span>
                    </template>
                </td>
            </tr>
        </table>
    </div>
    `
})

export class AdminEventView implements OnInit {
    eventName:string;
    eventId:string;
    statusSummary:AthleteDocumentationFormStatusSummary;
    statusItems:AthleteDocumentationFormStatusItem[];
    selectedStatusItems:AthleteDocumentationFormStatusItem[];
    selectedPrintForms:DocumentationDocDescriptionReference[];
    openDropdown:string;
    printing:boolean;
    loading:boolean;
    athleteUrl:string;
    logoUploading:boolean;
    logoImageUrl:string;

    sortDescending:boolean;

    errorMessage:string;
    
    logoUploadSettings:any;

    private _sortField:string;

    private _orgLogoUploadStateChange:(state:any, fromUploaderEvent:boolean, resultUrl:string) => void;
    
    constructor(
        private _router:Router,
        private _route:ActivatedRoute,
        private _modal:Modal,
        private _assignments:Assignments,
        private _summaries:DocumentationActivitySummaries,
        private _ctx:RegistrationContext,
        private _docLoader:DocumentLoader,
        private _organizations:Organizations,
        private _userProfiles:UserProfiles
    ){
        this.selectedStatusItems = [];
        this.selectedPrintForms = [];

        this._orgLogoUploadStateChange = (s,f,r) => this.orgLogoUploadStateChanged(s,f,r);
    }

    ngOnInit(){
        //this.statusSummary = new AthleteDocumentationFormStatusSummary();
        // this.statusSummary.documentationActivity = {
        //     _id:"56c7a4e00d8de000bf5bb527",
        //     type:"Documentation",
        //     documentationEventDescription:{
        //         eventName:"2016 Physicals Day",
        //         coordinatorName:"Hughston Clinic",
        //         documents:[]
        //     }
        // };

        this.refresh();
    }

    set sortField(value)
    {
        this.sortDescending = !this.sortDescending;
        this._sortField = value;

        var select;
        switch(value)
        {
            case 'athleteDisplayName':
                select = (item:AthleteDocumentationFormStatusItem) => item.athleteDisplayName;
                break;
            case 'athleteDob':
                select = (item:AthleteDocumentationFormStatusItem) => item.athleteDob;
                break;
            case 'alerts':
                select = (item:AthleteDocumentationFormStatusItem) => this.itemAlertCount(item);
                break;
            case 'accepted':
                select = (item:AthleteDocumentationFormStatusItem) => item.summaryValues.physicalFormClearedStatus;
                break;
            case 'processed':
                select = (item:AthleteDocumentationFormStatusItem) => !!item.processedDate;
                break;
        }

        this.statusItems.sort((x,y) =>
        {
            var valueX = select(x);
            var valueY = select(y);
            if (valueX !== valueY)
            {
                let ret = 0;
                if (valueX === undefined)
                    return 1;
                else if (valueY === undefined)
                    return -1;
                else if (typeof valueX == 'string')
                    ret = valueX.localeCompare(valueY);
                else
                    ret = valueX > valueY ? 1 : -1;

                ret = ret * (this.sortDescending ? -1 : 1);
                return ret;
            }

            if (x.athleteDisplayName != y.athleteDisplayName)
                return x.athleteDisplayName.localeCompare(y.athleteDisplayName);
            else if(x.athleteDob != y.athleteDob && x.athleteDob)
                return x.athleteDob.localeCompare(y.athleteDob);
            else return 0;
        });
    }

    get sortField()
    {
        return this._sortField;
    }

    itemAlertCount(item:AthleteDocumentationFormStatusItem)
    {
        return _.chain(item.statuses).map(s => s.fieldsWithAlerts).flatten().value().length;
    }

    docAlertCount(item:AthleteDocumentationFormStatusItem, docDesc:DocumentationDocDescriptionReference)
    {
        var doc = _.find(item.statuses, s =>
        {
            return docDesc.activityId == s.documentDescriptionActivityId;
        });

        if (!doc)
            return 0;

        return doc.fieldsWithAlerts.length;
    }

    itemHasProgress(item:AthleteDocumentationFormStatusItem)
    {
        return !!_.chain(item.statuses)
            .filter(d => !!d.completedDate)
            .map(d => d.documentDescriptionActivityId)
            .intersection(_.pluck(this.statusSummary.documentationActivity.documentationEventDescription.documents, 'activityId'))
            .value()
            .length;
    }

    docIsComplete(item:AthleteDocumentationFormStatusItem, docDesc:DocumentationDocDescriptionReference)
    {
        return !!_.find(item.statuses, s =>
        {
            return (!!s.completedDate) && docDesc.activityId == s.documentDescriptionActivityId;
        });
    }

    toggleDropdown($event:MouseEvent, rowId):void {
        $event.preventDefault();
        $event.stopPropagation();

        if (this.openDropdown == rowId)
            delete this.openDropdown;
        else
            this.openDropdown = rowId;
    }

    itemIsSelected(item:AthleteDocumentationFormStatusItem)
    {
        return !!_.find(this.selectedStatusItems, i => i == item);
    }

    toggleSelectAllForms($event:MouseEvent, checked:boolean)
    {
        $event.stopPropagation();

        this.selectedPrintForms = checked ? this.statusSummary.documentationActivity.documentationEventDescription.documents.concat() : [];
    }

    toggleSelectAllItems($event:MouseEvent, checked:boolean)
    {
        $event.stopPropagation();

        this.selectedStatusItems = checked ? this.statusItems.concat() : [];
    }

    toggleSelectItem($event:MouseEvent, item:AthleteDocumentationFormStatusItem)
    {
        $event.stopPropagation();

        this.selectedStatusItems = this.toggleSelect(item, this.selectedStatusItems);
    }
    
    openForm(item:AthleteDocumentationFormStatusItem, docDesc:DocumentationDocDescriptionReference)
    {
        this._router.navigate(['/max-forms/form', item.profileId, this.eventId, item.assignmentId, docDesc.activityId]);
        // this.$location.path('/dashboard/form/' + this.eventId + '/' + item.profileId + '/' + item.assignmentId + '/' + docDesc.activityId);
    }
    
    addAthlete()
    {
        let profileId = (new DfObjectId()).toString();
        let config = overlayConfigFactory(new BSModalContext(), BSModalContext);
        this._modal.open(UserProfileCreationModalPrompt, config)
            .then(result => result.result)
            .then(result =>
            {
                if (!result)
                    throw 'Canceled';

                let profileTemplate = {
                    _id:profileId,
                    tags:undefined,
                    email:undefined,
                    createdDate:(new Date()).toISOString(),
                    tel:undefined,
                    pendingSports:undefined,
                    state:undefined,
                    org:this.statusSummary.org._id,
                    firstName:result.firstName,
                    sortFirstName:(result.firstName || '').toLowerCase(),
                    sortLastName:(result.lastName || '').toLowerCase(),
                    lastName:result.lastName,
                    orgRoles:['MGA','SUB', 'ATH'],
                    createdByAdminForForms:true
                };

                let profile = new UserProfile(profileTemplate);
                let save = () => this._userProfiles.createProfile(profile).single().toPromise();
                config = overlayConfigFactory({pendingProfile: profile, save:save}, AccessRequestApprovalData);
                return this._modal.open(AccessRequestApprovalModal, config);
            })
            .then(result => result.result)
            .then(result =>
            {
                return result ? this._assignments.submitAdministratively(this.statusSummary.documentationAssignment._id, this.statusSummary.documentationActivity._id, profileId).single().toPromise() : null;
            })
            .then(result =>
            {
                if (result)
                    this.refresh();
            })
            .catch(e => console.log(e));
    }

    onOpenPrintWindow()
    {
        let adminFormPrintModalData = new AdminFormPrintModalData(this.statusSummary.documentationActivity.documentationEventDescription.documents, this.selectedStatusItems.concat(), this.statusItems);
        let config = overlayConfigFactory(adminFormPrintModalData, AdminFormPrintModalData);
        this._modal.open(AdminFormPrintModal, config)
            .then(dialogRef =>
            {
                dialogRef.result.then(ids => {
                    if (ids)
                        this.onPrint(ids)
                });
            });
    }

    onPrint(ids)
    {
        this.printing = true;
        this.errorMessage = '';

        if (ids.length < 1)
        {
            this.printing = false;
            this.errorMessage = 'The selected athlete(s) have not filled out any of the selected forms.';
            return;
        }

        this._docLoader.openBulkPdf(ids, window).then(() =>
        {
            this.printing = false;
            console.log('success');
        }).catch(error =>
        {
            this.printing = false;
            console.error(error);
            this.errorMessage = 'We encountered an error printing.  Please try again.';
        });
    }

    onClickPrintDocRow($event:MouseEvent, doc:DocumentationDocDescriptionReference)
    {
        this.selectedPrintForms = this.toggleSelect(doc, this.selectedPrintForms);
    }

    formIsPrintSelected(doc:DocumentationDocDescriptionReference)
    {
        return !!_.find(this.selectedPrintForms, d => d == doc);
    }

    orgLogoUploadStateChanged(state, fromUploaderEvent, resultUrl)
    {
        if (state === plupload.DONE)
        {
            console.log('UPLOAD DONE');
           

            this._organizations.getLogoUrl(this.statusSummary.org).single().toPromise()
                .then(url =>{
                    this.logoImageUrl = url;
                    this.logoUploading = false;
                })
                .catch(e => {
                    console.log('Logo error - ' + e.message);
                    this.errorMessage = 'An error was encountered showing the image.';
                    this.logoUploading = false;
                });
        }
        else if (state === plupload.FAILED)
        {
            this.logoUploading = false;
            this.errorMessage = 'An error was encountered while uploading your image.  Refresh the page and try again.';

            // Don't leave a bad image ref in the profile.
            //UserProfileUpdate.save({ profileId: userProfileId }, { $set: { images: [] } });
        }
        else
        {
            this.logoUploading = true;
        }
    };

    private toggleSelect<T>(item:T, items:T[])
    {
        var match = _.find(items, i => i == item);
        if (!match)
            items.push(item);
        else
            items = items.filter(i => i != item);

        return items;
    }

    private refresh()
    {
        this.loading = true;
        this.eventId = this._route.snapshot.params['eventId'];
        this._summaries.getSummary(this.eventId)
            .single()
            .subscribe(summary =>
            {
                this.loading = false;
                this.statusSummary = summary;
                this.eventName = this.statusSummary.documentationActivity.documentationEventDescription.eventName;
                this.statusItems = this.statusSummary.items;
                this.selectedStatusItems = [];

                var baseUrl = 'http://dragonflymax.com/forms/';
                this.athleteUrl = baseUrl + (summary.org.formsShortcut || summary.org.shortCode);

                this.sortDescending = true; // will be reversed in the sortField setter
                this.sortField = 'athleteDisplayName';

                this._ctx.docAct = this.statusSummary.documentationActivity;

                this.logoUploadSettings = {
                    getFileParams: (file) =>
                    {
                        var fileId = DfUuidGen.newUuid();
                        var logoMedia = this._organizations.getLogoMedia(this.statusSummary.org, true);

                        logoMedia.createdDate = new Date();
                        logoMedia.contentType = file.type;
                        logoMedia.mediaId = fileId;

                        return this._organizations.update(this.statusSummary.org._id, {$set:{media:this.statusSummary.org.media}}).single().toPromise()
                            .then(() => {
                                return {
                                    fileId: fileId,
                                    orgId: this.statusSummary.org._id,
                                    paramsUrl: `/training/api/organizations/${this.statusSummary.org._id}/media/${encodeURIComponent(fileId)}`
                                };
                            });
                    },
                    dfUploadTag: 'org-logo-' + this.statusSummary.org._id,
                    uploaderSettings: {
                        filters: {
                            max_file_size: '10mb',
                            mime_types: [
                                { title: "Image files", extensions: "jpeg,jpg,gif,png" }
                            ]
                        },
                        resize: {
                            width: 600,
                            height: 600
                        }
                    }
                };

                console.log(this.statusSummary.org);
                this._organizations.getLogoUrl(this.statusSummary.org).single().toPromise()
                    .then(url =>{
                        this.logoImageUrl = url;
                    })
                    .catch(e => {
                        console.log(e);
                        this.errorMessage = 'An error was encountered showing the org logo.';
                    });
            }, error =>
            {
                console.log(error);
                this.loading = false;
                this.errorMessage = 'An error occurred.  Please refresh the page. (' + (<any>error).status + ')';
                throw error;
            });
    }
}
