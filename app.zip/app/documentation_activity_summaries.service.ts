import {Http} from "@angular/http";
import {Injectable} from "@angular/core";
import {AthleteDocumentationFormStatusSummary} from "./athlete_form_status";

@Injectable()
export class DocumentationActivitySummaries {
    constructor(private _http:Http) {

    }

    getSummary(assignmentId:string){
        return this._http.get(`/training/api/assignments/${assignmentId}/documentationSummary`)
            .map(response => <AthleteDocumentationFormStatusSummary>response.json())
            .map(summary => {
                (summary.org.media || []).forEach(media =>
                {
                    media.mediaId = media.mediaId;
                });
                return summary;
            })
    }
}