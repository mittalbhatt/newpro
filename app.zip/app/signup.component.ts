import {Component, ElementRef, ViewChild} from "@angular/core";
import {Router, ActivatedRoute} from "@angular/router";
import {ReCaptchaComponent} from "angular2-recaptcha/angular2-recaptcha";
import {UserAccountService, UserAccount, Username} from "./userAccount.service";
import {MaxAppContext} from "./maxAppContext.service";
import {Helper} from "./helper.service";

declare var grecaptcha:any;

@Component({
    selector: 'max-signup',
    template:`
<div [style.display]="errorMessage ? 'block' : 'none'" style="max-width:500px; margin:20px auto; padding:10px" [class]="'alert alert-danger animated shake'"><span [innerHTML]="errorMessage" class="error-msg"></span></div>
<div [style.display]="duplicateLoginMessage ? 'block' : 'none'" style="max-width:500px; margin:20px auto;"  [class]="'alert alert-warning animated shake'">{{duplicateLoginMessage}} <a href="javascript:void(0)" routerLink="/max-cover/login/{{encodedUsername}}">Click here to log in.</a></div>
    <div id="signup-form">
        <div>
            <org-heading #heading></org-heading>
            <img *ngIf="!heading.org" class="max-wordmark-logo" src="app/media/hurricane-100.png"/>
            <span *ngIf="!heading.org" class="max-wordmark-text">DragonFly MAX</span>
            <a style="font-size:10px;" href="javascript:void(0)" (click)="reset()" *ngIf="heading.org">Not part of {{heading.org.name}}? Click here.</a>
        </div>
        <h3>Sign Up</h3>
        <p>or <a [routerLink]="['../login']" style="color:#6495ed;">sign in</a></p>
        <form #loginForm="ngForm" (ngSubmit)="onSubmit()" novalidate>
          
          <div class="form-group">
            <label for="firstName">First Name</label>
            <input [(ngModel)]="firstName" type="text" class="form-control" id="firstName" name="firstName" placeholder="First Name" required autofocus>
          </div>
          
          <div class="form-group">
            <label for="lastName">Last Name</label>
            <input [(ngModel)]="lastName" type="text" class="form-control" id="lastName" name="lastName" placeholder="Last Name" required>
          </div>
          
          <div class="form-group">
            <label for="username">Email or Phone</label>
            <input [(ngModel)]="username"  autocorrect="off" autocapitalize="off" spellcheck="false" type="text" class="form-control" id="username" name="username" placeholder="Mobile # or email address" required >
          </div>

          <div *ngIf="!passwordShow" class="form-group">
              <label for="password">Password</label>
              <div class="input-group">
                <input [(ngModel)]="password" type="password" class="form-control" id="password" name="password" placeholder="Password" required>
                <span class="input-group-btn">
                    <button class="btn btn-primary" type="button" (click)="passwordShow = true">Show</button>
                </span>
              </div>
          </div>
          
          <div *ngIf="passwordShow" class="form-group">
              <label for="password">Password</label>
              <div class="input-group">
                <input [(ngModel)]="password" type="text" class="form-control" id="password-text" name="password-text" placeholder="Password" required>
                <span class="input-group-btn">
                    <button class="btn btn-primary" type="button" (click)="passwordShow = false">Hide</button>
                </span>
              </div>
          </div>
          
          <re-captcha (captchaResponse)="handleCorrectCaptcha($event)"  site_key="6LcSeAoTAAAAAHgFTscddzSarG8IuNP2hQCGBer6"></re-captcha>
          <br />
          <div style="height:40px;">
            <button style="float:left" class="btn btn-danger" [routerLink]="['../login']">Cancel</button>
            <button style="float:right" type="submit" class="btn btn-default" (click)="clickOnSubmit()">Submit</button>
          </div>
        </form>
    </div>
`
})
export class SignupComponent {

    errorMessage:string=null;
    duplicateLoginMessage:string=null;
    passwordShow:boolean;

    username:string;
    password:string;
    firstName:string;
    lastName:string;
    submitting:boolean;
    persistent:boolean;

    recaptchaResponse:any;

    constructor(
        private _userAccountService:UserAccountService,
        private _router:Router,
        private _route:ActivatedRoute,
        private _helper:Helper,
        private _ctx:MaxAppContext)
    {
        if (this._route.snapshot.params['errorMessage'])
            this.errorMessage = this._route.snapshot.params['errorMessage'];

        this.username = this._route.snapshot.params['username'];
        if (this.username == 'undefined')
            delete this.username;

        if (this._userAccountService.cachedPendingAccount)
        {
            this.username = this._userAccountService.cachedPendingAccount.usernames[0].username.trim();
            this.firstName = this._userAccountService.cachedPendingAccount.firstName;
            this.lastName = this._userAccountService.cachedPendingAccount.lastName;
        }
    }

    clickOnSubmit(){
        this.errorMessage = this.duplicateLoginMessage = null;
    }

    onSubmit()
    {
        if (this.submitting)
            return;

        //var password_valid = this.validatePassword(this.password);
        var password_valid = this._helper.validatePassword(this.password.trim());
        this.submitting = true;
        this.errorMessage = this.duplicateLoginMessage = null;

        if (!this.username.trim() || !this.password.trim() || !this.firstName || !this.lastName)
        {
            this.errorMessage = 'All fields are required.';
            this.submitting = false;
            return;
        }

        if(!password_valid){
            this.errorMessage = "Your password must be at least 8 characters long and must contain at least 3 of the following:";
            this.errorMessage += "<ul>";
            this.errorMessage += "<li> a symbol (like: !@#$%^&*) </li>";
            this.errorMessage += "<li> a number. </li>";
            this.errorMessage += "<li> a lower case letter. </li>";
            this.errorMessage += "<li> an upper case letter. </li>";
            this.errorMessage += "</ul>"

            this.submitting = false;
            return;
        }

        if (!this.recaptchaResponse)
        {
            this.errorMessage = 'Please complete the reCaptcha.';
            this.submitting = false;
            return;
        }

        var account = new UserAccount();
        account.password = this.password.trim();
        account.usernames = [new Username()];
        account.usernames[0].username = this.username.trim();
        account.usernames[0].type = this.username.indexOf('@') > -1 ? 'email' : 'mobile';
        account.firstName = this.firstName;
        account.lastName = this.lastName;
        this._userAccountService.cachedPendingAccount = account;

        this._userAccountService.saveAccount(account, this.recaptchaResponse)
            .then(() =>
            {
                this._userAccountService.cachedPassword = this.password.trim();
                return this._router.navigate(['/max-cover/verify-account', this.username.trim()]);
            })
            .catch(err =>
            {
                this.submitting = false;
                grecaptcha.reset();
                delete this.recaptchaResponse;

                console.log(err);

                window.scrollTo(0,35);

                if (err.status == 409)
                {
                    this.duplicateLoginMessage = this.username.trim() + ' is already in use.';
                }
                else if (err.status == 400 && err.json)
                {
                    this.errorMessage = err.json().message || 'We encountered an unexpected error.';
                }
                else
                {
                    this.errorMessage = 'We encountered an unexpected error.';
                }
            });
    }

    validatePassword(password): boolean {
        var errors = [];
        var errors_count=0;
        if (password.length < 8) {
            errors_count = errors_count+1;
            errors.push("Your password must be at least 8 characters");
        }
        if (password.search(/(?=.*[!@#$%^&*])/i) < 0) { 
            errors_count = errors_count+1;
        }
        if (password.search(/(?=.*[0-9])/) < 0) {
            errors_count = errors_count+1;
        }
        if (password.search(/(?=.*[a-z])/) < 0) {
            errors_count = errors_count+1;
        }
        if (password.search(/(?=.*[A-Z])/) < 0) {
            errors_count = errors_count+1;
        }
        if (errors_count > 1) {
            return false;
        }
        return true;
    }

    handleCorrectCaptcha(captcha:any)
    {
        this.recaptchaResponse = captcha;
    }

    get encodedUsername()
    {
        return encodeURIComponent(this.username);
    }

    reset()
    {
        this._ctx.logout(false);
        window.location.reload();
    }
}