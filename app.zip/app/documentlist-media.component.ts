import {Component, Input, Output, EventEmitter} from "@angular/core";
import {Router} from "@angular/router";
import { SiteSearch } from "./site-search.service";
import {Organizations} from "./organizations.service";
import {Modal, BSModalContext} from 'angular2-modal/plugins/bootstrap';
import {RequestOptions} from "@angular/http";
import {BasicMedicalSaver} from "./basic_medical_saver.service";

@Component({
    selector: 'documentlist-media',
    template: `
  
    <a href="javascript:void(0)" *ngIf="_user_img && documentlist.media && documentlist.media[0].thumbnailId!=undefined" (click)="onApprove(documentlist.media[0].mediaId,documentlist._id,documentlist.media[0].thumbnailId)">
     <img  *ngIf="_user_img && documentlist.media" [src]="_user_img" style="max-width:100px; max-height:100px; width:100px">
     <div class="playpause"></div>
    </a>
    <a href="javascript:void(0)" *ngIf="_user_img && documentlist.media && documentlist.media[0].thumbnailId==undefined" (click)="onApprove(documentlist.media[0].mediaId,documentlist._id,documentlist.media[0].thumbnailId)">
     <img  *ngIf="_user_img && documentlist.media && !isShowDocumentGif" [src]="_user_img" style="max-width:100px; max-height:100px; width:100px">
     <div *ngIf="isShowDocumentGif" style="text-align: center">
                            <img style="max-width:30px; max-height:30px; width:30px" src="/maxweb/app/media/ajax-loader.gif" /> 
             </div>
     </a> 
      <span *ngIf="_user_img && documentlist.media && !isShowDocumentGif && documentlist.$canEdit==true" class="deletimgbtndoc">
                <i  (click)="removeDocumentImage()" class="glyphicon glyphicon-remove-circle"></i>
    </span>                  
    `,

})
export class DocumentlistMediaComponent{

    public documentlist:any;
    private otherdocuments:any=[];
    private groupyearotherdocuments:any=[];
    private alldoc:any=[];
    private _user_img:any;
    private thumbidvideo:any;
    public isShowDocumentGif:boolean=false;
    errorMessage:string;
    @Output() chkResult: EventEmitter<any> = new EventEmitter();
  
    
    constructor(
        private _router:Router,
        private _organizations:Organizations,
        private _modal:Modal,
         private _changeSaver: BasicMedicalSaver
    ){


    }
     
    @Input('documentmedia') 
    set documentmedia(value){
   
       this.documentlist = value;
      
       if(this.documentlist.media !== undefined){
          // this.isShowDocumentGif=true;
            this.loadImage();
        }
       
    }
    removeDocumentImage(){
         this._modal.confirm()
            .size('sm').isBlocking(true).showClose(false).keyboard(27)
            .body("Are you sure you want to remove this document  image?")
            .headerClass("hide")
            .okBtnClass("btn btn-danger")
            .okBtn("Remove")
            .cancelBtn("Cancel").cancelBtnClass("btn btn-primary")
            .open().then((dialog : any ) => {
                return dialog.result;
            }).then(result =>{
                this.isShowDocumentGif=true;
                if(result==true) {
                        this._changeSaver.removeInsuranceDocument(this.documentlist._id)
                            .single().toPromise().then((data) =>
                        {
                           
                            if(data.ok==true){
                                 //this.documentlist.splice(this.documentlist._id, 1); 
                            this.chkResult.emit({
                              value: this.documentlist._id
                            })
                            }
                           
                        })
                        .catch(e =>
                        {
                            this.errorMessage = 'We encountered an unexpected error. Refresh the page and try again.';
                            throw e;
                        })

                }
            }).catch((e:any)=>{

            });
        
    }

    loadImage()
    {

         var xhr = new XMLHttpRequest();
        return this._organizations.getLogoUrldocumentmedia(this.documentlist).single().toPromise()
            .then(url => {     
                this._user_img = url;
            })
            .catch(e => {
                this.isShowDocumentGif=false;
                console.log('Logo error', e);
                throw e;
            });
    }
    UploaddocumentImage(){
        alert('here');
        var logoMedia: any = {};
       
   
    }
    onApprove(curmediaid,curid,thumbid)
    {
        this.thumbidvideo=thumbid;
  
        return this._organizations.getLogoUrldocumentmediapopup(curmediaid,curid).single().toPromise()
            .then(url => {
                this._user_img = url;
               
                if (this.thumbidvideo!=undefined){
                 var mediadetail=`
                   <video width="868px" height="570px" controls>
                   <source src="${this._user_img}" type="video/mp4">
                   </video>

                `; 
                }else{
                  var mediadetail=`
                   <img src="${this._user_img}" width="100%">
                   `; 
                }
                
                this._modal.alert()
                .size('lg')
                .body(mediadetail)
                .showClose(true)
                .okBtn('close')
                .okBtnClass('modal-btn-hide')
                // .footerClass('modal-footer')
                .open().then(result => { result.result.then(() => {
                    
                }, () => {this.loadImage()}); });

            })
            .catch(e => {
                
                throw e;
            });
           
    }
    
}