
import {Component, Input,Injectable,ViewChild, HostListener} from "@angular/core";
import { UserProfiles, UserProfile } from "./user_profiles.service";
import {Router, ActivatedRoute} from "@angular/router";
import { SiteSearch } from "./site-search.service";
import {MaxAppContext} from "./maxAppContext.service";
import {Modal} from 'angular2-modal/plugins/bootstrap';
import { Documents } from "./document_factory.service";

@Component({
    selector: 'teams-players-box',
    templateUrl: '/maxweb/app/app/teams-players-box.component.html'
})
export class TeamsPlayersBoxComponent {

    public _userProfile:UserProfile;
    public _user_img:any;
    public _box_class:string="about-team teams-blockbox";
    public fullname:string;
    public firstname:string;
    public lastname:string;
    public currentAcademicYear:string = "";
    eligibilitychecktrue:boolean=true;
    public currentOrgDetails:any;
      cardview:string;
   roleview:string;


    constructor(
        public ctx:  MaxAppContext,
        public _userProfilesSvc: UserProfiles,
        public _router:Router,
        public _documents: Documents
    ){ }

    @Input('selectedOrgDetails')
    set selectedOrgDetails(value: any){
      this.currentOrgDetails = value;
    }

    @Input('userProfile')
    set userProfile(value: any){

        if (_.has(this.currentOrgDetails,'currentAcademicYear')) {
          this.currentAcademicYear = this.currentOrgDetails.currentAcademicYear;
        }

        if(value.$eligibilityStatuses.length == 0) {
            value.$eligibilityStatuses = [{
                status: {
                    academicallyCleared: false,
                    medicallyCleared: false,
                    medicalClearanceSubmitted:false,
                    trainerCleared: false,
                    formsSubmitted: false
                },
                key: {
                  eligibilityDefinitionKey: {
                    academicYear: this.currentAcademicYear
                  }
                }
            }];
        }
        // value.phone=[];
       
        if(sessionStorage['roleview']='Eligibility' && value.orgRoles!==undefined && value.orgRoles[0]=='CCH' &&  value.orgRoles.length==1){
            
        }else{
             this._userProfile = new UserProfile(value);
        }
        
        if(_.intersection(this.ctx.currentProfile.orgRoles, ['OADM']).length!==0 || _.intersection(this.ctx.currentProfile.orgRoles, ['UADM']).length!==0 ){
                    this.eligibilitychecktrue=false;
        }
        
        this.loadAmrDetails();
        this.loadImage();
    }
   

    @Input('userId')
    set userId(data:SiteSearch){
        this._box_class = "about-team";

        this.firstname = (data._source.firstName) ? data._source.firstName: "";
        this.lastname = (data._source.lastName) ? data._source.lastName: "";
        this.fullname = this.firstname+" "+this.lastname;
        //this._userProfile.athleteTitleName = firstname+" "+lastname;

        if(data._id){
            this._userProfilesSvc.getProfile(data._id).toPromise().then(data =>{
                this._userProfile = new UserProfile(data);
                this.loadAmrDetails();
                this.loadImage();
            }).catch(e =>{
                console.log('Logo error', e);
                throw e;
            });
        }
    }

    loadAmrDetails() {
      this._userProfile.specificAllergyShow = this._userProfile.getSpecificAllergyShow(this._userProfile);
      this._userProfile.displayAllergy = this._userProfile.getSpecificAllergy(this._userProfile);
      this._userProfile.existingMedicalConditionShow = this._userProfile.getExistingMedicalConditionShow(this._userProfile);
      this._userProfile.displayexistingMedicalCondition = this._userProfile.getExistingMedicalCondition(this._userProfile);
      this._userProfile.displayGradYear = this._userProfile.getGradYear(this._userProfile);
    }

    loadImage()
    {
        return this._userProfilesSvc.getProfileImageUrl(this._userProfile).single().toPromise()
            .then(url => {
                this._user_img = url;
            })
            .catch(e => {
                console.log('Logo error', e);
                throw e;
            });
    }

    goToDetails(id){
        if(id)
        this._router.navigate(['main/player', id]);
    }

    @HostListener('window:resize', ['$event'])
    onResize(event) {
        if(sessionStorage['cardview']=='List'){
          this.loadFixedHeaderFunction('top-tr-head-list','List');
        }
        else if(sessionStorage['cardview']=='Eligibility'){
          this.loadFixedHeaderFunction('top-tr-head-eligi','Eligibility');  
        }
        
    }

    loadFixedHeaderFunction(classname:string,view:any)
    {
        var count = 0;
        if(view=='List'){
          count = 9;
        }else if(view=='Eligibility'){
          count = 8;
        }
        var corresponding_th_height = document.querySelector('.'+classname).clientHeight;

        for (var index = 1; index < count ; index++) {
            if(document.querySelector('.'+classname)!=null){
              var corresponding_th_width = document.querySelector('.'+classname+' th:nth-child(' + (index) + ')').clientWidth;
              //console.log(corresponding_th_width);
              if(index==3 && corresponding_th_width < 85 && view=='List' && corresponding_th_height < 50){
                corresponding_th_width = corresponding_th_width +10;
              }

              document.querySelector('.'+classname+'-div span:nth-child(' + (index) + ')').setAttribute('style','width:'+corresponding_th_width+'px; height:'+corresponding_th_height+'px;');
            }
            
        }
    }
}
@Component({
    selector: '[teams-players-list]',
    templateUrl: '/maxweb/app/app/teams-players-list.component.html'
})
export class TeamsPlayersListComponent extends TeamsPlayersBoxComponent{

    constructor ( public ctx:  MaxAppContext,public _userProfilesSvc: UserProfiles,
            public _router:Router, public _documents: Documents) {
            super(ctx,_userProfilesSvc,_router, _documents);

    }

    
    ngAfterViewInit() {
        this.loadFixedHeaderFunction('top-tr-head-list','List');
    }    
}

@Component({

    selector: '[teams-players-eligibility]',
    templateUrl: '/maxweb/app/app/teams-players-eligibility.component.html',
})

export class TeamsPlayersEligibilityComponent extends TeamsPlayersBoxComponent{
   eligibilityobj:any;
   isAutoloading:any={academicYearloading:false,FormsSubmittedloading:false,MedicalClearanceloading:false,MedicallyClearedloading:false};
   academicYear:any = "";
 

    constructor (public ctx:  MaxAppContext,public _userProfilesSvc: UserProfiles,
            public _router:Router, public _model:Modal, public _documents: Documents) {
            super(ctx,_userProfilesSvc,_router, _documents);
            this.cardview=sessionStorage['cardview'];
            this.roleview=sessionStorage['roleview'];
            
        }

        ngAfterViewInit() {
            this.loadFixedHeaderFunction('top-tr-head-eligi','Eligibility');
        }
        //Use for eligibility cekbox functionality
        eligibilityStatusescheck(ischecked,currentid,type,status) {

            if(status.$eligibilityStatuses[0].key.eligibilityDefinitionKey.academicYear) {
              this.academicYear = status.$eligibilityStatuses[0].key.eligibilityDefinitionKey.academicYear;
            } else {
              if(_.has(this.currentOrgDetails,'currentAcademicYear')) {
                this.academicYear = this.currentOrgDetails.currentAcademicYear;
              }
            }
  
           //this.isAutoloading= true;
                  this.eligibilityobj =
                  {
                    userProfileId: currentid,
                    key: {
                        type:"sportYearUserSpecified",
                        eligibilityDefinitionKey: { "academicYear": this.academicYear }
                    },
                    $update: {
                        $set: {
                           "status.academicallyCleared":false,
                             "status.medicallyCleared":false,
                             "status.medicalClearanceSubmitted":false,
                             "status.trainerCleared":false
                        }
                    }
                  };
                 if(type=='Academically Cleared'){
                        this.isAutoloading.academicYearloading = true;
                       this.eligibilityobj.$update.$set['status.academicallyCleared']=ischecked;
                       if(status!==undefined){
                          this.eligibilityobj.$update.$set['status.formsSubmitted']=status.$eligibilityStatuses[0].status.formsSubmitted;
                          this.eligibilityobj.$update.$set['status.medicalClearanceSubmitted']=status.$eligibilityStatuses[0].status.formsSubmitted;
                          this.eligibilityobj.$update.$set['status.medicallyCleared']=status.$eligibilityStatuses[0].status.medicallyCleared;
                       }

                }else if(type=='Forms Submitted'){
                         this.isAutoloading.FormsSubmittedloading = true;
                      this.eligibilityobj.$update.$set['status.formsSubmitted']=ischecked;

                        if(status!==undefined){
                               this.eligibilityobj.$update.$set['status.academicallyCleared']=status.$eligibilityStatuses[0].status.academicallyCleared;
                               this.eligibilityobj.$update.$set['status.medicallyCleared']=status.$eligibilityStatuses[0].status.medicallyCleared;
                               this.eligibilityobj.$update.$set['status.medicalClearanceSubmitted']=status.$eligibilityStatuses[0].status.formsSubmitted;
                        }
                }else if(type=='Medical Clearance Submitted'){
                         this.isAutoloading.MedicalClearanceloading = true;
                      this.eligibilityobj.$update.$set['status.medicalClearanceSubmitted']=ischecked;

                        if(status!==undefined){
                            this.eligibilityobj.$update.$set['status.formsSubmitted']=status.$eligibilityStatuses[0].status.formsSubmitted;
                            this.eligibilityobj.$update.$set['status.academicallyCleared']=status.$eligibilityStatuses[0].status.academicallyCleared;
                            this.eligibilityobj.$update.$set['status.medicallyCleared']=status.$eligibilityStatuses[0].status.medicallyCleared;
                        }
                }
                else if(type=='Medically Cleared'){
                    this.isAutoloading.MedicallyClearedloading = true;
                      this.eligibilityobj.$update.$set['status.medicallyCleared']=ischecked;
                       if(status!==undefined){
                            this.eligibilityobj.$update.$set['status.formsSubmitted']=status.$eligibilityStatuses[0].status.formsSubmitted;
                            this.eligibilityobj.$update.$set['status.academicallyCleared']=status.$eligibilityStatuses[0].status.academicallyCleared;
                            this.eligibilityobj.$update.$set['status.medicalClearanceSubmitted']=status.$eligibilityStatuses[0].status.formsSubmitted;
                       }

                }


                  this._userProfilesSvc.checkeligibilityStatuses(this.eligibilityobj).single().toPromise().then((resdata:any)=>{
                      if(resdata!==undefined){
                            this.isAutoloading.academicYearloading=false;
                            this.isAutoloading.FormsSubmittedloading=false;
                            this.isAutoloading.MedicalClearanceloading = false;
                            this.isAutoloading.MedicallyClearedloading = false;
                      
                      }else{
                       this.isAutoloading= true;
                      }
                       //this._userProfile = new UserProfile(d.status.academicallyCleared);

                    }).catch(e=>{
                         var msgstr=`We encountered an error saving your changes. Please refresh and try again.`
                        this._model.confirm()
                                    .size('sm').isBlocking(true).showClose(false).keyboard(27)
                                    .body(msgstr)
                                    .headerClass("hide")
                                    .okBtnClass("hide")
                                    .cancelBtn("Close").cancelBtnClass("btn btn-primary")
                                    .open().then((dialog : any ) => {
                                        return dialog.result;
                                    }).then(result =>{

                                    }).catch((e:any)=>{

                                    });
                        throw e;
                    });
        }
}