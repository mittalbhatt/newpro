System.register(["@angular/core", "angular2-modal"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, angular2_modal_1;
    var UserProfileCreationModalPrompt;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (angular2_modal_1_1) {
                angular2_modal_1 = angular2_modal_1_1;
            }],
        execute: function() {
            UserProfileCreationModalPrompt = (function () {
                function UserProfileCreationModalPrompt(dialog) {
                    this.dialog = dialog;
                }
                UserProfileCreationModalPrompt.prototype.onCancel = function () {
                    this.dialog.close(false);
                };
                UserProfileCreationModalPrompt.prototype.onContinue = function () {
                    this.dialog.close({ firstName: this.firstName, lastName: this.lastName });
                };
                UserProfileCreationModalPrompt = __decorate([
                    core_1.Component({
                        selector: 'user-profile-creation-modal-prompt',
                        template: "\n<div class=\"modal-content\" style=\"text-align:left\">\n    <div class=\"modal-header\">\n        <button (click)=\"onCancel()\" type=\"button\" class=\"close\" aria-label=\"Close\" style=\"float:right\"><span aria-hidden=\"true\">&times;</span></button>\n        <h3 class=\"modal-title\" style=\"text-align:center\">Specify the athlete's name:</h3>\n    </div>\n<div class=\"modal-body\">\n    <form #nameForm=\"ngForm\">\n        <div class=\"form-group\">\n            <label for=\"username\">First Name</label>\n            <input [(ngModel)]=\"firstName\" type=\"text\" class=\"form-control\" id=\"firstName\" name=\"firstName\" placeholder=\"First Name\" required>\n          </div>\n          \n          <div class=\"form-group\">\n            <label for=\"username\">Last Name</label>\n            <input [(ngModel)]=\"lastName\" type=\"text\" class=\"form-control\" id=\"lastName\" name=\"lastName\" placeholder=\"Last Name\" required>\n          </div>\n    </form>\n</div>\n<div class=\"modal-footer\">\n    <button [disabled]=\"!nameForm.form.valid\" (click)=\"onContinue()\" type=\"button\" class=\"btn btn-primary\" style=\"float:right;\">Continue</button>\n    <button (click)=\"onCancel()\" type=\"button\" class=\"btn btn-danger\" style=\"float:right; margin-right:10px;\">Cancel</button>\n</div>\n\n</div>\n"
                    }), 
                    __metadata('design:paramtypes', [angular2_modal_1.DialogRef])
                ], UserProfileCreationModalPrompt);
                return UserProfileCreationModalPrompt;
            }());
            exports_1("UserProfileCreationModalPrompt", UserProfileCreationModalPrompt);
        }
    }
});
//# sourceMappingURL=userProfileCreationModalPrompt.component.js.map