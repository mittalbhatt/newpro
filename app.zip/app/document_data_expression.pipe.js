System.register(["@angular/core", "./document_expression_evaluator", "./document_doc_context"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var __param = (this && this.__param) || function (paramIndex, decorator) {
        return function (target, key) { decorator(target, key, paramIndex); }
    };
    var core_1, document_expression_evaluator_1, document_doc_context_1;
    var DocumentDataExpressionPipe;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (document_expression_evaluator_1_1) {
                document_expression_evaluator_1 = document_expression_evaluator_1_1;
            },
            function (document_doc_context_1_1) {
                document_doc_context_1 = document_doc_context_1_1;
            }],
        execute: function() {
            DocumentDataExpressionPipe = (function () {
                function DocumentDataExpressionPipe(_evaluator) {
                    this._evaluator = _evaluator;
                }
                DocumentDataExpressionPipe.prototype.transform = function (value, expression) {
                    var ctx = new document_doc_context_1.DocumentDocContext(value);
                    return this._evaluator.evaluateExpression(expression, ctx, '*****', 'strong');
                };
                DocumentDataExpressionPipe = __decorate([
                    core_1.Pipe({ name: 'documentDataExpression', pure: false }),
                    __param(0, core_1.Inject(document_expression_evaluator_1.DocumentExpressionEvaluator)), 
                    __metadata('design:paramtypes', [document_expression_evaluator_1.DocumentExpressionEvaluator])
                ], DocumentDataExpressionPipe);
                return DocumentDataExpressionPipe;
            }());
            exports_1("DocumentDataExpressionPipe", DocumentDataExpressionPipe);
        }
    }
});
//# sourceMappingURL=document_data_expression.pipe.js.map