export interface IDocumentExpressionContext {
    evaluateDefaultValue(expression:string, fallbackValue?:string, htmlWrapper?:string):any;
}