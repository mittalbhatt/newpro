import {Component, EventEmitter, Output} from "@angular/core";

export interface ProfileType
{
    name:string;
    code:string;
    description:string;
    sentenceSubject:string;
}

@Component({
    selector:'profile-type-chooser',
    template:
`
<div>
    <div class="profile-types-container">
        <div (click)="onSelected(type)" (mouseover)="onMouseOver(type)" (mouseout)="onMouseOut()" [ngClass]="{'profile-type-choice':true, 'profile-type-choice-selected':isSelected(type)}" *ngFor="let type of types; let lastType = last">
            <h1>{{type.name}}</h1>
        </div>
    </div>
    <div style="margin-top:-20px;">&nbsp;{{description}}&nbsp;</div>
</div>
`
})
export class ProfileTypeChooser
{
    private types:ProfileType[];
    private description:string;
    private selectedType:ProfileType;

    @Output() typeSelected:EventEmitter<ProfileType> = new EventEmitter<ProfileType>();

    constructor()
    {
        this.types = [
            {name:'Parent', sentenceSubject:'a Parent', code:'PRN', description:'Parent, Guardian, or Responsible Party for an Athlete or Athletes'},
            {name:'Athlete', sentenceSubject:'an Athlete', code:'ATH', description:'You are a member of the team'},
            {name:'Athletic Trainer', sentenceSubject:'an Athletic Trainer', code:'TRN', description:'Certified Athletic Trainer or other skilled Health Care Professional'},
            {name:'Coach', code:'CCH', sentenceSubject:'a Coach', description:'Head Coach, Assistant Coach, Leader of the Team/Athletes'},
            {name:'Administrator', code:'ADM', sentenceSubject:'an Administrator', description:'Athletic Director, Principal, Headmaster, other School Administrator'},
           // {name:'Other', code:'OTH', sentenceSubject:'other', description:'Doctors, researchers, rehab providers and others'}
        ];
    }

    onMouseOver(type)
    {
        this.description = type.description;
    }

    onMouseOut()
    {
        this.description = null;
    }

    onSelected(type)
    {
        this.selectedType = type;
        delete this.description;
        this.typeSelected.emit(type);
    }

    selectByCode(code:string) : ProfileType
    {
        let res = this.types.find(t => t.code == code);
        this.selectedType = res;
        return res;
    }

    isSelected(type:ProfileType)
    {
        return this.selectedType == type;
    }
}