import {Injectable, Inject, EventEmitter} from "@angular/core";
import {Http, Response, RequestOptions, URLSearchParams} from "@angular/http";
import {PagedDataUtil} from "./pagedDataUtil.service";
import {Observable} from "rxjs/Rx";

declare var store:any;

export class UserProfileState {
    pendingApproval:boolean;
}

export class Username {
    username:string;
    type:string;
    verificationStatus:string;
}

export class UserAccount {
    usernames:Username[];
}

export interface IUserProfile {
    _id:string;
    firstName:string;
    sortFirstName:string;
    lastName:string;
    sortLastName:string;
    org:string;
    orgRoles:string[];
    pendingSports:string[];
    tags:string[];
    email:string;
    state:UserProfileState;
    createdDate:string;
    tel:string[];

}

export class medicalDocumentsData{
    ident: string;
    value: string;
}

export class designationCondition{
    _id:string;
    bodyPart:string;
    details:string;
    soap: Object;
    type: string;
    name: string;
}

export class userDesignationStatus{

designations:[{
        _id:string,
        clearedToPlay: number,
        clearedToPractice: number,
        conditions:designationCondition[]
    }];
     mostSevereClearedToPractice: any;
     mostSevereClearedToPlay:any;
     mostSevereStatus:any;
     mostDistantClearedToPracticeDate:string;
     mostDistantClearedToPlayDate:string
}

export class UserProfile implements IUserProfile {

    _id:string;
    amrId:string;
    firstName:string;
    sortFirstName:string;
    lastName:string;
    sortLastName:string;
    org:string;
   // phone:any;
    orgRoles:string[];
    pendingSports:string[];
    tags:string[];
    email:string;
    emails:any=[];
    state:UserProfileState;
    createdDate:string;
    tel:string[];
    imageUris:string[];
    $userAccount:UserAccount;
    linkedOrgRoles:{tags:string[], roles:string[], linkId:string, orgId:string}[];
    medicalRecords:{medicalRecordStableDocumentId:string}[];
    medicalDocuments:{_id:string, documentStableId:string, data:[{ ident: string, value: string}]};
    relations:{userProfileId:string; roles:string[], $userProfile:UserProfile}[];
    currentDesignationStatus: userDesignationStatus;
    $eligibilityStatuses: any = [{
        status:{
            academicallyCleared: false,
            medicallyCleared: false,
            trainerCleared: false,
            formsComplete: false
        }

    }];
    specificAllergyShow: boolean;
    displayAllergy: string;
    existingMedicalConditionShow: boolean;
    displayexistingMedicalCondition: string;
    displayDOB: string;
    displayGradYear: string;
    $amr: any;
   

    constructor(src:IUserProfile) {
       // console.log(src);
        for(var k in src)
        {
            this[k] = src[k];
        }
    }

    get athleteDisplayName() : string {
        if (this.lastName && this.firstName)
            return `${this.lastName}, ${this.firstName}`;
        else if (this.lastName)
            return this.lastName;
        else if (this.firstName)
            return this.firstName;
        else if (this.email)
            return this.email;
        else
            return this._id;
    }

    get athleteTitleName() : string {
        if (this.lastName && this.firstName)
            return `${this.firstName} ${this.lastName}`;
        else if (this.lastName)
            return this.lastName;
        else if (this.firstName)
            return this.firstName;
        else if (this.email)
            return this.email;
        else
            return this._id;
    }

    get phone() : any{
        return (this.tel || [])[0];
    }

    get createdDateParsed() : Date {
        return this.createdDate ? new Date(this.createdDate) : null;
    }

    get gradYear() : string{
        if(this.medicalDocuments !== undefined){
            var gYear = null;
           _.find(this.medicalDocuments[0], (o:medicalDocumentsData)=>{
                if(o.ident == "gradYear"){
                    gYear = o.value;
                }
            });
            return gYear;
        }
        return null;
    }

    get borderColor() : string{
        if(this.currentDesignationStatus !== undefined){
            if(this.currentDesignationStatus.mostSevereStatus===0){
                return "red-border";
            }else if(this.currentDesignationStatus.mostSevereStatus===1){
                return "green-border";
            }else if(this.currentDesignationStatus.mostSevereStatus===2){
                return "yellow-border";
            }
        }
        return null;
    }

    get recentInjury(): string{
        if(this.currentDesignationStatus !== undefined){
            if(this.currentDesignationStatus.designations[0] !== undefined){
                if(this.currentDesignationStatus.designations[0].conditions[0].bodyPart &&
                this.currentDesignationStatus.designations[0].conditions[0].name
                ){
                    return this.currentDesignationStatus.designations[0].conditions[0].bodyPart + " - "+ this.currentDesignationStatus.designations[0].conditions[0].name;
                }else if(this.currentDesignationStatus.designations[0].conditions[0].name){
                    return this.currentDesignationStatus.designations[0].conditions[0].name;
                }
            }
        }
        return null;
    }

    get clearedToPlayBadge(): Object{
        if(this.currentDesignationStatus !== undefined){
            var date = (this.currentDesignationStatus.mostDistantClearedToPlayDate) ? this.currentDesignationStatus.mostDistantClearedToPlayDate : null;
            if(this.currentDesignationStatus.mostSevereClearedToPlay===0){
                return {color:"date red", date: date};
            }else if(this.currentDesignationStatus.mostSevereClearedToPlay===1){
                return {color:"date green", date: "cleared"};
            }else if(this.currentDesignationStatus.mostSevereClearedToPlay===2){
                return {color:"date yellow", date: date};
            }
        }
        return null;
    }

    get practiceBadge(): Object{
        if(this.currentDesignationStatus !== undefined){
            var date = (this.currentDesignationStatus.mostDistantClearedToPracticeDate) ? this.currentDesignationStatus.mostDistantClearedToPracticeDate : null;
            if(this.currentDesignationStatus.mostSevereClearedToPractice===0){
                return {color:"date red", date: date};
            }else if(this.currentDesignationStatus.mostSevereClearedToPractice===1){
                return {color:"date green", date: date};
            }else if(this.currentDesignationStatus.mostSevereClearedToPractice===2){
                return {color:"date yellow", date: date};
            }
        }
        return null;
    }

    get medicalCondition() : string{
        var medicalcondition = null;
         if(this.medicalDocuments !== undefined && this.medicalDocuments[0] !== undefined){
            _.find(this.medicalDocuments[0].data, (o:medicalDocumentsData)=>{
                 if(o.ident == "conditions"){
                     medicalcondition = o.value;
                 }
             });
         }
         return medicalcondition;
     }

     get medicalAllergies() : string{
         var medicalAllergies = null;
         if(this.medicalDocuments !== undefined && this.medicalDocuments[0] !== undefined){
            _.find(this.medicalDocuments[0].data, (o:medicalDocumentsData)=>{
                 if(o.ident == "allergies"){
                     medicalAllergies = o.value;
                 }
             });
         }
         return medicalAllergies;
     }

    get roleDisplayTitle() : string {
        var lookup = {
            'ATH': 'Athlete',
            'TRN': 'Athletic Trainer',
            'PRN': 'Parent',
            'CCH': 'Coach',
            'ADM': 'Administrator',
            'MED': 'Physician or Medical Staff'
        };

        let r = (this.orgRoles || []).find(r => lookup[r]);
        return lookup[r] || 'Unknown';
    }

    getDOB(_userProfile) {
        let finalDOBStr = "";
       // let specificAllergy = [{keyType: 'hasMedicines', name: 'Medicines' }, {keyType: 'hasFood', name: 'Food' }, {keyType: 'hasPollens', name: 'Pollens' }, {keyType: 'hasStingingInsects', name: 'Stinging Insects' }];
        if(_.has(_userProfile, '$amr')) {
            if(_.has(_userProfile.$amr, 'info')) {
                if(_.has(_userProfile.$amr.info, "dob")) {
                   // if(_userProfile.$amr.info.specificAllergy === 1) {
                       let dobVal = _userProfile.$amr.info.dob;
                       var dobunique=_.uniq(dobVal);
                        if(_userProfile.$amr.info.dob!=undefined) {
                            finalDOBStr =  dobVal.slice(0,10);
                        }
                }
            }
        }
        return finalDOBStr;
    }

    getGradYear(_userProfile) {
        let finalGradYearStr = "";
       // let specificAllergy = [{keyType: 'hasMedicines', name: 'Medicines' }, {keyType: 'hasFood', name: 'Food' }, {keyType: 'hasPollens', name: 'Pollens' }, {keyType: 'hasStingingInsects', name: 'Stinging Insects' }];
        if(_.has(_userProfile, '$amr')) {
            if(_.has(_userProfile.$amr, 'info')) {
                if(_.has(_userProfile.$amr.info, "gradYear")) {
                   // if(_userProfile.$amr.info.specificAllergy === 1) {
                       let gradYearVal = _userProfile.$amr.info.gradYear;
                       var gradYearunique=_.uniq(gradYearVal);
                        if(_userProfile.$amr.info.gradYear!=undefined) {
                            finalGradYearStr =  gradYearVal;                              
                        }
                }
            }
        }
        return finalGradYearStr;
    }

    getSpecificAllergyShow(_userProfile) {
        let finalAllergybool = false;
       // let specificAllergy = [{keyType: 'hasMedicines', name: 'Medicines' }, {keyType: 'hasFood', name: 'Food' }, {keyType: 'hasPollens', name: 'Pollens' }, {keyType: 'hasStingingInsects', name: 'Stinging Insects' }];
        if(_.has(_userProfile, '$amr')) {
            if(_.has(_userProfile.$amr, 'info')) {
                if(_.has(_userProfile.$amr.info, "specificAllergy")) {
                       // if(_userProfile.$amr.info.specificAllergy === 1) {
                        let specificAllergy = _userProfile.$amr.info.specificAllergy;
                        var specificAllergyunique=_.uniq(specificAllergy);
                        if(_userProfile.$amr.info.specificAllergy!=undefined) {
                            finalAllergybool = _userProfile.$amr.info.specificAllergy;
                        }
                }
            }
        }
        return finalAllergybool;
    }

    getSpecificAllergy(_userProfile) {
        let finalAllergyStr = [];
       // let specificAllergy = [{keyType: 'hasMedicines', name: 'Medicines' }, {keyType: 'hasFood', name: 'Food' }, {keyType: 'hasPollens', name: 'Pollens' }, {keyType: 'hasStingingInsects', name: 'Stinging Insects' }];
        if(_.has(_userProfile, '$amr')) {
            if(_.has(_userProfile.$amr, 'info')) {
                if(_.has(_userProfile.$amr.info, "allergiesList")) {
                   // if(_userProfile.$amr.info.specificAllergy === 1) {
                       let specificAllergy = _userProfile.$amr.info.allergiesList;
                       var specificAllergyunique=_.uniq(specificAllergy);
                         if(_userProfile.$amr.info.allergiesList!=undefined) {
                        
                                 if(specificAllergyunique.length>0){
                                    _.each(specificAllergyunique, (o:any)=>{
                                    
                                            finalAllergyStr.push(o);
                                    
                                    });
                                 }
                         }
                }
            }
        }
        return finalAllergyStr.join(', ');
    }

    getExistingMedicalConditionShow(_userProfile) {
        let finalexistingMedicalConditionbool = false;
       // let specificAllergy = [{keyType: 'hasMedicines', name: 'Medicines' }, {keyType: 'hasFood', name: 'Food' }, {keyType: 'hasPollens', name: 'Pollens' }, {keyType: 'hasStingingInsects', name: 'Stinging Insects' }];
        if(_.has(_userProfile, '$amr')) {
            if(_.has(_userProfile.$amr, 'info')) {
                if(_.has(_userProfile.$amr.info, "existingMedicalCondition")) {
                       // if(_userProfile.$amr.info.specificAllergy === 1) {
                        let specificAllergy = _userProfile.$amr.info.existingMedicalCondition;
                        if(_userProfile.$amr.info.existingMedicalCondition!=undefined) {
                            finalexistingMedicalConditionbool = _userProfile.$amr.info.existingMedicalCondition;
                        }
                }
            }
        }
        return finalexistingMedicalConditionbool;
    }

    getExistingMedicalCondition(_userProfile) {
        let finalexistingMedicalConditionStr = [];
      
        if(_.has(_userProfile, '$amr')) {
            if(_.has(_userProfile.$amr, 'info')) {
                if(_.has(_userProfile.$amr.info, 'medicalConditionsList')) {
                     let existingMedicalCondition = _userProfile.$amr.info.medicalConditionsList;
                     var existingMedicalConditionunique=_.uniq(existingMedicalCondition);
                  
                         if(_userProfile.$amr.info.medicalConditionsList!=undefined) {
                                if(existingMedicalConditionunique.length>0){
                                        _.each(existingMedicalConditionunique, (o:any)=>{
                                        
                                                finalexistingMedicalConditionStr.push(o);
                                        
                                            });
                                }
                         }
                }
            }
        }
        return finalexistingMedicalConditionStr.join(', ');
    }
}

export class UserInjuryDetails{
    _id:string;
    appliedByIpAddress:string;
    appliedByUserProfileId:string;
    appliedDate:string;
    audience:[{
        userProfileId:string
    }];
    category:string;
    clearedToPlay:number;
    clearedToPractice:number;
    conditions:[
        {
            _id:string;
            type:string;
            name:string;
            bodyPart:string;
            details:string;
            soap:{
                s:string;
                o:string;
                a:string;
                p:string;
            };
            treatments:string[];
        }
    ];
    creatorOrgId:string;
    designationStableId:string;
    expectedClearedToPlayDate:string;
    expectedClearedToPracticeDate:string;
    lastModifiedDate:string;
    orgId:string;
    pti:boolean;
    referrals:any;
    medReferrals:[
        {
            userInfo:{
                name:string
            }
        }
    ];
    rehabInstructions:[{
        date:string;
        content:string;
    }];
    physicianNotes:[{
        date:string;
        content:string;
    }];
    participationInstructions:[{
        date:string;
        content:string;
    }];
    startDate:string;
    type:string;
    userProfile:{
        email:string;
        firstName:string;
        lastName:string;
        org:string;
        tags:string[];
    };
    userProfileId:string;

    constructor(data:any){
        for(var k in data)
        {
            this[k] = data[k];
        }
    }

    get injuryName():string{
        if(this.conditions[0].name){
            return this.conditions[0].name;
        }
        return null;
    }

    get injuryDetails():string{
        if(this.conditions[0] && this.conditions[0].details){
            return this.conditions[0].details;
        }
        return null;
    }

    get subjectiveDetail():string{
        if(this.conditions[0] && this.conditions[0].soap && this.conditions[0].soap.s){
            return this.conditions[0].soap.s;
        }
        return null;
    }

    get objectiveDetail():string{
        if(this.conditions[0] && this.conditions[0].soap && this.conditions[0].soap.o){
            return this.conditions[0].soap.o;
        }
        return null;
    }

    get aessementDetail():string{
        if(this.conditions[0] && this.conditions[0].soap && this.conditions[0].soap.a){
            return this.conditions[0].soap.a;
        }
        return null;
    }

    get planDetail():string{
        if(this.conditions[0] && this.conditions[0].soap && this.conditions[0].soap.p){
            return this.conditions[0].soap.p;
        }
        return null;
    }

    get doi():string{
        if(this.startDate){
            return this.startDate;
        }
        return null;
    }

    get treatments():string{
        if(this.conditions[0] && this.conditions[0].treatments){
            var treatments_str = null;
            this.conditions[0].treatments.forEach((t)=>{
                if(treatments_str == null){
                    treatments_str = t;
                }else{
                    treatments_str += ", " + t;
                }
            });

            return treatments_str;
        }
        return null;
    }

    get playBadge(): Object{
        if(this.clearedToPlay !== undefined){

            var date = (this.expectedClearedToPlayDate) ? this.expectedClearedToPlayDate: null;
            if(this.clearedToPlay==0){
                return {color:"date red", date: date};
                //return "date red";
            }else if(this.clearedToPlay==1){
                return {color:"date green", date: "CLEARED" };
                //return "date green";
            }else if(this.clearedToPlay==2){
                return {color:"date yellow", date: date};
                //return "date yellow";
            }
        }
        return null;
    }

    get practiceBadge(): Object{


        if(this.clearedToPractice !== undefined){
             var date = (this.expectedClearedToPracticeDate) ? this.expectedClearedToPracticeDate : null;
            if(this.clearedToPractice==0){
                return {color:"date red", date: date};
                //return "date red";
            }else if(this.clearedToPractice==1){
                return {color:"date green", date: "CLEARED"};
                //return "date green";
            }else if(this.clearedToPractice==2){
                return {color:"date yellow", date: date};
                //return "date yellow";
            }
        }
        return null;
    }

    get particePlayInstructions(): string{
        if(this.participationInstructions && this.participationInstructions[0] && this.participationInstructions[0].content){
            return this.participationInstructions[0].content;
        }
        return null;
    }

    get bodyPart():string{
        if(this.conditions[0] && this.conditions[0].bodyPart){
            return this.conditions[0].bodyPart;
        }
        return null;
    }

    get doctor():string{
        if(this.medReferrals && this.medReferrals[0] && this.medReferrals[0].userInfo && this.medReferrals[0].userInfo.name){
            return this.medReferrals[0].userInfo.name;
        }
        return null;
    }
}

@Injectable()
export class UserProfiles {
    public updateRelativeData = new EventEmitter();
    public getProfileData = new EventEmitter();
    constructor(
        private _http:Http,
        @Inject(RequestOptions) private _requestOps:RequestOptions
    ) { }

    getMine() {
        return this._http.get('/training/api/userProfiles/mine?skip=0&limit=100')
            .map((res:Response) => <UserProfile[]>res.json());
    }

    getProfile(id:string) {
        return this._http.get(`/training/api/userProfiles/${id}`)
            .map((res:Response) => <UserProfile>res.json());
    }

    getProfiles(skip:number=0, take:number=100, pendingAllowed=false) {
        var args = new RequestOptions();
        args.search = new URLSearchParams();
        args.search.append('skip', skip.toString());
        args.search.append('limit', take.toString());
        args.search.append('sortBy', 'sortlastName,sortFirstName');
        args.search.append('pendingAllowed', pendingAllowed.toString());
        return this._http.get(`/training/api/userProfiles`, args)
            .map((res:Response) => <UserProfile[]>res.json());
    }

    getAllProfiles() {
        return PagedDataUtil.getAllPages((s,t) => this.getProfiles(s, t, true));
    }

    getProfilesToCheck(skip:number=0, take:number=100) {
        var args = new RequestOptions();
        args.search = new URLSearchParams();
        args.search.append('skip', skip.toString());
        args.search.append('limit', take.toString());
        return this._http.get(`/training/api/userProfiles`, args)
            .map((res:Response) => <UserProfile[]>res.json());
    }
    
    getAllProfilesToCheck() {
        return PagedDataUtil.getAllPages((s,t) => this.getProfilesToCheck(s, t));
    }

    createProfile(profile:IUserProfile)
    {
        return this._http.post('/training/api/userProfiles', profile);
    }

    updateProfile(profileId:string, update:any)
    {
        return this._http.post(`/training/api/userProfiles/${profileId}/update`, update);
    }

    set createProfileRedirectUrl(value:string)
    {
        store.session('createProfileRedirect', value);
    }

    get createProfileRedirectUrl()
    {
        return store.session('createProfileRedirect');
    }

    getPendingProfiles() {
        return this._http.get('/training/api/userProfiles/pending?excludeRoles[]=PRN')
            .map(response => (<UserProfile[]>response.json()).map(p => new UserProfile(p)));
    }

    approveProfile(profile:IUserProfile, setTags=false) {
        var updatePromise = Promise.resolve(null);
        if (setTags)
        {
            var update = {$set: {tags: profile.tags}};
            updatePromise = this._http.put(`/training/api/userProfiles/${profile._id}/update`, update).single().toPromise();
        }


        return updatePromise.then(() => this._http.put(`/training/api/userProfiles/${profile._id}/approve`, {}).single().toPromise().then(result => {
            //console.log('From Promise:', result);
            this.getProfileData.emit({data:result,action:"approve"});
        }));
    }

    disapproveProfile(profile:IUserProfile)
    {
        return this._http.put(`/training/api/userProfiles/${profile._id}/disapprove`, {}).single().toPromise().then(result => {
            //console.log('From Promise:', result);
            this.getProfileData.emit({data:result,action:"disapprove"});

        });
    }

    deleteProfile(profile:IUserProfile) {
        return this._http.delete(`/training/api/userProfiles/${profile._id}`);
    }

    getProfileImageUrl(profile:UserProfile) {
        return Observable.create(observer=>{
            let url = profile.imageUris[0];
            if (!url)
            {
                observer.next(null);
                observer.complete();
                return;
            }

            let req = new XMLHttpRequest();
            req.open('get',url);
            req.onreadystatechange = () => {
                if (req.readyState == 4 && req.status == 200)
                {
                    var loc = req.getResponseHeader('location');
                    observer.next(loc);
                    observer.complete();
                }
                else if (req.readyState == 4)
                {
                    observer.error(new Error(req.responseText));
                }
            };

            req.setRequestHeader('Authorization', this._requestOps.headers.get('Authorization'));
            req.send();
        });
    }

    getPendingUserCount() {
        return this._http.head('/training/api/userProfiles/pending?excludeRoles[]=PRN')
            .map((res:Response) => parseInt(res.headers.get('df-list-count') || '0'));
    }

    getTeamUserProfiles(skip:number=0, take:number=10, pendingAllowed=false, sortingParameter="", sortingOrderParameter="", filterParameter) {

        var args = new RequestOptions();
        args.search = new URLSearchParams();
        args.search.append('skip', skip.toString());
        args.search.append('limit', take.toString());

        args.search.append('sortBy', sortingOrderParameter+sortingParameter.toString());
        if(filterParameter.orgId){
          args.search.append('$filter.0.org', `ObjectId(${filterParameter.orgId})`);
        }
        if(filterParameter.teamId){
          args.search.append('$filter.1.tags', `,${filterParameter.teamId},`);
        }
        if(filterParameter.orgRoles){
          args.search.append('$filter.1.orgRoles', `${filterParameter.orgRoles}`);
        }
        if(filterParameter.injured !== undefined && filterParameter.injured !== null  && filterParameter.injured != 'null'){
          args.search.append('$filter.0.currentDesignationStatus.injured', `${filterParameter.injured}`);
        }

        //args.search.append('$filter.0.org', `ObjectId(5641ce010c2191d838521e0d)`);
        //args.search.append('$filter.1.tags', `,MBA:,`);

        args.search.append('pendingAllowed', pendingAllowed.toString());
        return this._http.get(`/training/api/userProfiles`, args)
            .map((res:Response) => <UserProfile[]>res.json());
    }

    getUserInjuryStatus(skip:number=0, take:number=10, filterParameter){
        var args = new RequestOptions();
        args.search = new URLSearchParams();
        args.search.append('skip', skip.toString());
        args.search.append('limit', take.toString());
        args.search.append('$filter.0.type', `Injury`);

        return this._http.get(`/training/api/designations/byUser/${filterParameter.user}/startOnOrBefore/9999-12-31`, args)
            .map((res:Response) => <UserInjuryDetails[]>res.json());
    }
     getTeamUserDocument(profileId:string) {

            return this._http.get(`/training/api/userProfiles/${profileId}/documents`).map((res:Response) => res.json());
    }
    checkeligibilityStatuses(eligibilityobj:any){
           return this._http.put('/training/api/eligibilityStatuses/updates', eligibilityobj).map((res:Response) => <any[]>res.json());
    }
    inviterelation(inviteobj:any){
        return this._http.put('/training/api/registrations?suppressDelivery=true', inviteobj).map((res:Response) => <any[]>res.json());
    }
    texttoinvite(inviteobj:any){
        return this._http.put('/training/api/registrations?suppressDelivery=false', inviteobj).map((res:Response) => <any[]>res.json());
    }
   

}