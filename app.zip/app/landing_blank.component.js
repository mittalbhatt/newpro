System.register(['@angular/core'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1;
    var LandingComponentBlank;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            }],
        execute: function() {
            LandingComponentBlank = (function () {
                function LandingComponentBlank() {
                }
                LandingComponentBlank = __decorate([
                    core_1.Component({
                        selector: 'app-landing-blank',
                        template: "\n    <div class=\"container\" style=\"max-width:500px\">\n        <div class=\"row\">\n            <div class=\"col-md-4\">\n                <img width=\"175px\" src=\"app/media/referee-flag-lockout-w.jpg\" />\n            </div>\n            <div class=\"col-md-8\">\n                <h1>That's a Penalty!!!</h1>\n                <h3>Delay of game, illegal formation....or something....</h3>\n                <h3>Now get back in the game!</h3>\n                <p>&nbsp;</p>\n                <p class=\"lead\">\n                    <a class=\"btn btn-lg btn-default\" [routerLink]=\"['/landing']\">Get Started Again</a>\n                </p>\n                <p>Looks like you took too long and timed out.<br />Email support@dragonflyathletics.com for help.</p>\n            </div>\n        </div>\n    </div>\n    "
                    }), 
                    __metadata('design:paramtypes', [])
                ], LandingComponentBlank);
                return LandingComponentBlank;
            }());
            exports_1("LandingComponentBlank", LandingComponentBlank);
        }
    }
});
//# sourceMappingURL=landing_blank.component.js.map