System.register(["@angular/core", "@angular/router", "./userAccount.service", "./maxAppContext.service", "./helper.service"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, router_1, userAccount_service_1, maxAppContext_service_1, helper_service_1;
    var SignupComponent;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (userAccount_service_1_1) {
                userAccount_service_1 = userAccount_service_1_1;
            },
            function (maxAppContext_service_1_1) {
                maxAppContext_service_1 = maxAppContext_service_1_1;
            },
            function (helper_service_1_1) {
                helper_service_1 = helper_service_1_1;
            }],
        execute: function() {
            SignupComponent = (function () {
                function SignupComponent(_userAccountService, _router, _route, _helper, _ctx) {
                    this._userAccountService = _userAccountService;
                    this._router = _router;
                    this._route = _route;
                    this._helper = _helper;
                    this._ctx = _ctx;
                    this.errorMessage = null;
                    this.duplicateLoginMessage = null;
                    if (this._route.snapshot.params['errorMessage'])
                        this.errorMessage = this._route.snapshot.params['errorMessage'];
                    this.username = this._route.snapshot.params['username'];
                    if (this.username == 'undefined')
                        delete this.username;
                    if (this._userAccountService.cachedPendingAccount) {
                        this.username = this._userAccountService.cachedPendingAccount.usernames[0].username.trim();
                        this.firstName = this._userAccountService.cachedPendingAccount.firstName;
                        this.lastName = this._userAccountService.cachedPendingAccount.lastName;
                    }
                }
                SignupComponent.prototype.clickOnSubmit = function () {
                    this.errorMessage = this.duplicateLoginMessage = null;
                };
                SignupComponent.prototype.onSubmit = function () {
                    var _this = this;
                    if (this.submitting)
                        return;
                    //var password_valid = this.validatePassword(this.password);
                    var password_valid = this._helper.validatePassword(this.password.trim());
                    this.submitting = true;
                    this.errorMessage = this.duplicateLoginMessage = null;
                    if (!this.username.trim() || !this.password.trim() || !this.firstName || !this.lastName) {
                        this.errorMessage = 'All fields are required.';
                        this.submitting = false;
                        return;
                    }
                    if (!password_valid) {
                        this.errorMessage = "Your password must be at least 8 characters long and must contain at least 3 of the following:";
                        this.errorMessage += "<ul>";
                        this.errorMessage += "<li> a symbol (like: !@#$%^&*) </li>";
                        this.errorMessage += "<li> a number. </li>";
                        this.errorMessage += "<li> a lower case letter. </li>";
                        this.errorMessage += "<li> an upper case letter. </li>";
                        this.errorMessage += "</ul>";
                        this.submitting = false;
                        return;
                    }
                    if (!this.recaptchaResponse) {
                        this.errorMessage = 'Please complete the reCaptcha.';
                        this.submitting = false;
                        return;
                    }
                    var account = new userAccount_service_1.UserAccount();
                    account.password = this.password.trim();
                    account.usernames = [new userAccount_service_1.Username()];
                    account.usernames[0].username = this.username.trim();
                    account.usernames[0].type = this.username.indexOf('@') > -1 ? 'email' : 'mobile';
                    account.firstName = this.firstName;
                    account.lastName = this.lastName;
                    this._userAccountService.cachedPendingAccount = account;
                    this._userAccountService.saveAccount(account, this.recaptchaResponse)
                        .then(function () {
                        _this._userAccountService.cachedPassword = _this.password.trim();
                        return _this._router.navigate(['/max-cover/verify-account', _this.username.trim()]);
                    })
                        .catch(function (err) {
                        _this.submitting = false;
                        grecaptcha.reset();
                        delete _this.recaptchaResponse;
                        console.log(err);
                        window.scrollTo(0, 35);
                        if (err.status == 409) {
                            _this.duplicateLoginMessage = _this.username.trim() + ' is already in use.';
                        }
                        else if (err.status == 400 && err.json) {
                            _this.errorMessage = err.json().message || 'We encountered an unexpected error.';
                        }
                        else {
                            _this.errorMessage = 'We encountered an unexpected error.';
                        }
                    });
                };
                SignupComponent.prototype.validatePassword = function (password) {
                    var errors = [];
                    var errors_count = 0;
                    if (password.length < 8) {
                        errors_count = errors_count + 1;
                        errors.push("Your password must be at least 8 characters");
                    }
                    if (password.search(/(?=.*[!@#$%^&*])/i) < 0) {
                        errors_count = errors_count + 1;
                    }
                    if (password.search(/(?=.*[0-9])/) < 0) {
                        errors_count = errors_count + 1;
                    }
                    if (password.search(/(?=.*[a-z])/) < 0) {
                        errors_count = errors_count + 1;
                    }
                    if (password.search(/(?=.*[A-Z])/) < 0) {
                        errors_count = errors_count + 1;
                    }
                    if (errors_count > 1) {
                        return false;
                    }
                    return true;
                };
                SignupComponent.prototype.handleCorrectCaptcha = function (captcha) {
                    this.recaptchaResponse = captcha;
                };
                Object.defineProperty(SignupComponent.prototype, "encodedUsername", {
                    get: function () {
                        return encodeURIComponent(this.username);
                    },
                    enumerable: true,
                    configurable: true
                });
                SignupComponent.prototype.reset = function () {
                    this._ctx.logout(false);
                    window.location.reload();
                };
                SignupComponent = __decorate([
                    core_1.Component({
                        selector: 'max-signup',
                        template: "\n<div [style.display]=\"errorMessage ? 'block' : 'none'\" style=\"max-width:500px; margin:20px auto; padding:10px\" [class]=\"'alert alert-danger animated shake'\"><span [innerHTML]=\"errorMessage\" class=\"error-msg\"></span></div>\n<div [style.display]=\"duplicateLoginMessage ? 'block' : 'none'\" style=\"max-width:500px; margin:20px auto;\"  [class]=\"'alert alert-warning animated shake'\">{{duplicateLoginMessage}} <a href=\"javascript:void(0)\" routerLink=\"/max-cover/login/{{encodedUsername}}\">Click here to log in.</a></div>\n    <div id=\"signup-form\">\n        <div>\n            <org-heading #heading></org-heading>\n            <img *ngIf=\"!heading.org\" class=\"max-wordmark-logo\" src=\"app/media/hurricane-100.png\"/>\n            <span *ngIf=\"!heading.org\" class=\"max-wordmark-text\">DragonFly MAX</span>\n            <a style=\"font-size:10px;\" href=\"javascript:void(0)\" (click)=\"reset()\" *ngIf=\"heading.org\">Not part of {{heading.org.name}}? Click here.</a>\n        </div>\n        <h3>Sign Up</h3>\n        <p>or <a [routerLink]=\"['../login']\" style=\"color:#6495ed;\">sign in</a></p>\n        <form #loginForm=\"ngForm\" (ngSubmit)=\"onSubmit()\" novalidate>\n          \n          <div class=\"form-group\">\n            <label for=\"firstName\">First Name</label>\n            <input [(ngModel)]=\"firstName\" type=\"text\" class=\"form-control\" id=\"firstName\" name=\"firstName\" placeholder=\"First Name\" required autofocus>\n          </div>\n          \n          <div class=\"form-group\">\n            <label for=\"lastName\">Last Name</label>\n            <input [(ngModel)]=\"lastName\" type=\"text\" class=\"form-control\" id=\"lastName\" name=\"lastName\" placeholder=\"Last Name\" required>\n          </div>\n          \n          <div class=\"form-group\">\n            <label for=\"username\">Email or Phone</label>\n            <input [(ngModel)]=\"username\"  autocorrect=\"off\" autocapitalize=\"off\" spellcheck=\"false\" type=\"text\" class=\"form-control\" id=\"username\" name=\"username\" placeholder=\"Mobile # or email address\" required >\n          </div>\n\n          <div *ngIf=\"!passwordShow\" class=\"form-group\">\n              <label for=\"password\">Password</label>\n              <div class=\"input-group\">\n                <input [(ngModel)]=\"password\" type=\"password\" class=\"form-control\" id=\"password\" name=\"password\" placeholder=\"Password\" required>\n                <span class=\"input-group-btn\">\n                    <button class=\"btn btn-primary\" type=\"button\" (click)=\"passwordShow = true\">Show</button>\n                </span>\n              </div>\n          </div>\n          \n          <div *ngIf=\"passwordShow\" class=\"form-group\">\n              <label for=\"password\">Password</label>\n              <div class=\"input-group\">\n                <input [(ngModel)]=\"password\" type=\"text\" class=\"form-control\" id=\"password-text\" name=\"password-text\" placeholder=\"Password\" required>\n                <span class=\"input-group-btn\">\n                    <button class=\"btn btn-primary\" type=\"button\" (click)=\"passwordShow = false\">Hide</button>\n                </span>\n              </div>\n          </div>\n          \n          <re-captcha (captchaResponse)=\"handleCorrectCaptcha($event)\"  site_key=\"6LcSeAoTAAAAAHgFTscddzSarG8IuNP2hQCGBer6\"></re-captcha>\n          <br />\n          <div style=\"height:40px;\">\n            <button style=\"float:left\" class=\"btn btn-danger\" [routerLink]=\"['../login']\">Cancel</button>\n            <button style=\"float:right\" type=\"submit\" class=\"btn btn-default\" (click)=\"clickOnSubmit()\">Submit</button>\n          </div>\n        </form>\n    </div>\n"
                    }), 
                    __metadata('design:paramtypes', [userAccount_service_1.UserAccountService, router_1.Router, router_1.ActivatedRoute, helper_service_1.Helper, maxAppContext_service_1.MaxAppContext])
                ], SignupComponent);
                return SignupComponent;
            }());
            exports_1("SignupComponent", SignupComponent);
        }
    }
});
//# sourceMappingURL=signup.component.js.map