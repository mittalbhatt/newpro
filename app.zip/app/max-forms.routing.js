System.register(["./ath_doc_dashboard.component", "./landing_blank.component", "./ownProfileCreator.component", "./parentChildFormsContextChooser.component", "./formsProfileChooserRouter.service", "./relatedProfileCreator.component", "./formsProfileEditor.component", "./packetList.component", "./admin_event_view.component"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var ath_doc_dashboard_component_1, landing_blank_component_1, ownProfileCreator_component_1, parentChildFormsContextChooser_component_1, formsProfileChooserRouter_service_1, relatedProfileCreator_component_1, formsProfileEditor_component_1, packetList_component_1, admin_event_view_component_1;
    var formsRoutes, formsProviders;
    return {
        setters:[
            function (ath_doc_dashboard_component_1_1) {
                ath_doc_dashboard_component_1 = ath_doc_dashboard_component_1_1;
            },
            function (landing_blank_component_1_1) {
                landing_blank_component_1 = landing_blank_component_1_1;
            },
            function (ownProfileCreator_component_1_1) {
                ownProfileCreator_component_1 = ownProfileCreator_component_1_1;
            },
            function (parentChildFormsContextChooser_component_1_1) {
                parentChildFormsContextChooser_component_1 = parentChildFormsContextChooser_component_1_1;
            },
            function (formsProfileChooserRouter_service_1_1) {
                formsProfileChooserRouter_service_1 = formsProfileChooserRouter_service_1_1;
            },
            function (relatedProfileCreator_component_1_1) {
                relatedProfileCreator_component_1 = relatedProfileCreator_component_1_1;
            },
            function (formsProfileEditor_component_1_1) {
                formsProfileEditor_component_1 = formsProfileEditor_component_1_1;
            },
            function (packetList_component_1_1) {
                packetList_component_1 = packetList_component_1_1;
            },
            function (admin_event_view_component_1_1) {
                admin_event_view_component_1 = admin_event_view_component_1_1;
            }],
        execute: function() {
            exports_1("formsRoutes", formsRoutes = [
                {
                    path: 'blank',
                    data: { title: 'LandingBlank' },
                    component: landing_blank_component_1.LandingComponentBlank
                },
                {
                    path: 'packetList',
                    component: packetList_component_1.PacketList,
                    canActivate: [formsProfileChooserRouter_service_1.FormsProfileChooserRouter]
                },
                {
                    path: 'athDocDashboard/:activityId/:profileId',
                    component: ath_doc_dashboard_component_1.AthDocDashboard
                },
                {
                    path: 'create-own-profile',
                    component: ownProfileCreator_component_1.OwnProfileCreator
                },
                {
                    path: 'chooseFormsProfile/:profileId',
                    component: parentChildFormsContextChooser_component_1.ParentChildFormsContextChooser
                },
                {
                    path: 'chooseFormsProfile/:profileId/create',
                    component: relatedProfileCreator_component_1.RelatedProfileCreator
                },
                {
                    path: 'editFormsProfile/:profileId',
                    component: formsProfileEditor_component_1.FormsProfileEditor
                },
                {
                    path: 'admin/event/:eventId',
                    component: admin_event_view_component_1.AdminEventView
                }
            ]);
            exports_1("formsProviders", formsProviders = [
                formsProfileChooserRouter_service_1.FormsProfileChooserRouter
            ]);
        }
    }
});
//# sourceMappingURL=max-forms.routing.js.map