System.register(["@angular/core", "./user_profiles.service", "@angular/router", "./site-search.service", "./maxAppContext.service", 'angular2-modal/plugins/bootstrap', "./document_factory.service"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __extends = (this && this.__extends) || function (d, b) {
        for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, user_profiles_service_1, router_1, site_search_service_1, maxAppContext_service_1, bootstrap_1, document_factory_service_1;
    var TeamsPlayersBoxComponent, TeamsPlayersListComponent, TeamsPlayersEligibilityComponent;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (user_profiles_service_1_1) {
                user_profiles_service_1 = user_profiles_service_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (site_search_service_1_1) {
                site_search_service_1 = site_search_service_1_1;
            },
            function (maxAppContext_service_1_1) {
                maxAppContext_service_1 = maxAppContext_service_1_1;
            },
            function (bootstrap_1_1) {
                bootstrap_1 = bootstrap_1_1;
            },
            function (document_factory_service_1_1) {
                document_factory_service_1 = document_factory_service_1_1;
            }],
        execute: function() {
            TeamsPlayersBoxComponent = (function () {
                function TeamsPlayersBoxComponent(ctx, _userProfilesSvc, _router, _documents) {
                    this.ctx = ctx;
                    this._userProfilesSvc = _userProfilesSvc;
                    this._router = _router;
                    this._documents = _documents;
                    this._box_class = "about-team teams-blockbox";
                    this.currentAcademicYear = "";
                    this.eligibilitychecktrue = true;
                }
                Object.defineProperty(TeamsPlayersBoxComponent.prototype, "selectedOrgDetails", {
                    set: function (value) {
                        this.currentOrgDetails = value;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(TeamsPlayersBoxComponent.prototype, "userProfile", {
                    set: function (value) {
                        if (_.has(this.currentOrgDetails, 'currentAcademicYear')) {
                            this.currentAcademicYear = this.currentOrgDetails.currentAcademicYear;
                        }
                        if (value.$eligibilityStatuses.length == 0) {
                            value.$eligibilityStatuses = [{
                                    status: {
                                        academicallyCleared: false,
                                        medicallyCleared: false,
                                        medicalClearanceSubmitted: false,
                                        trainerCleared: false,
                                        formsSubmitted: false
                                    },
                                    key: {
                                        eligibilityDefinitionKey: {
                                            academicYear: this.currentAcademicYear
                                        }
                                    }
                                }];
                        }
                        // value.phone=[];
                        if (sessionStorage['roleview'] = 'Eligibility' && value.orgRoles !== undefined && value.orgRoles[0] == 'CCH' && value.orgRoles.length == 1) {
                        }
                        else {
                            this._userProfile = new user_profiles_service_1.UserProfile(value);
                        }
                        if (_.intersection(this.ctx.currentProfile.orgRoles, ['OADM']).length !== 0 || _.intersection(this.ctx.currentProfile.orgRoles, ['UADM']).length !== 0) {
                            this.eligibilitychecktrue = false;
                        }
                        this.loadAmrDetails();
                        this.loadImage();
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(TeamsPlayersBoxComponent.prototype, "userId", {
                    set: function (data) {
                        var _this = this;
                        this._box_class = "about-team";
                        this.firstname = (data._source.firstName) ? data._source.firstName : "";
                        this.lastname = (data._source.lastName) ? data._source.lastName : "";
                        this.fullname = this.firstname + " " + this.lastname;
                        //this._userProfile.athleteTitleName = firstname+" "+lastname;
                        if (data._id) {
                            this._userProfilesSvc.getProfile(data._id).toPromise().then(function (data) {
                                _this._userProfile = new user_profiles_service_1.UserProfile(data);
                                _this.loadAmrDetails();
                                _this.loadImage();
                            }).catch(function (e) {
                                console.log('Logo error', e);
                                throw e;
                            });
                        }
                    },
                    enumerable: true,
                    configurable: true
                });
                TeamsPlayersBoxComponent.prototype.loadAmrDetails = function () {
                    this._userProfile.specificAllergyShow = this._userProfile.getSpecificAllergyShow(this._userProfile);
                    this._userProfile.displayAllergy = this._userProfile.getSpecificAllergy(this._userProfile);
                    this._userProfile.existingMedicalConditionShow = this._userProfile.getExistingMedicalConditionShow(this._userProfile);
                    this._userProfile.displayexistingMedicalCondition = this._userProfile.getExistingMedicalCondition(this._userProfile);
                    this._userProfile.displayGradYear = this._userProfile.getGradYear(this._userProfile);
                };
                TeamsPlayersBoxComponent.prototype.loadImage = function () {
                    var _this = this;
                    return this._userProfilesSvc.getProfileImageUrl(this._userProfile).single().toPromise()
                        .then(function (url) {
                        _this._user_img = url;
                    })
                        .catch(function (e) {
                        console.log('Logo error', e);
                        throw e;
                    });
                };
                TeamsPlayersBoxComponent.prototype.goToDetails = function (id) {
                    if (id)
                        this._router.navigate(['main/player', id]);
                };
                TeamsPlayersBoxComponent.prototype.onResize = function (event) {
                    if (sessionStorage['cardview'] == 'List') {
                        this.loadFixedHeaderFunction('top-tr-head-list', 'List');
                    }
                    else if (sessionStorage['cardview'] == 'Eligibility') {
                        this.loadFixedHeaderFunction('top-tr-head-eligi', 'Eligibility');
                    }
                };
                TeamsPlayersBoxComponent.prototype.loadFixedHeaderFunction = function (classname, view) {
                    var count = 0;
                    if (view == 'List') {
                        count = 9;
                    }
                    else if (view == 'Eligibility') {
                        count = 8;
                    }
                    var corresponding_th_height = document.querySelector('.' + classname).clientHeight;
                    for (var index = 1; index < count; index++) {
                        if (document.querySelector('.' + classname) != null) {
                            var corresponding_th_width = document.querySelector('.' + classname + ' th:nth-child(' + (index) + ')').clientWidth;
                            //console.log(corresponding_th_width);
                            if (index == 3 && corresponding_th_width < 85 && view == 'List' && corresponding_th_height < 50) {
                                corresponding_th_width = corresponding_th_width + 10;
                            }
                            document.querySelector('.' + classname + '-div span:nth-child(' + (index) + ')').setAttribute('style', 'width:' + corresponding_th_width + 'px; height:' + corresponding_th_height + 'px;');
                        }
                    }
                };
                __decorate([
                    core_1.Input('selectedOrgDetails'), 
                    __metadata('design:type', Object), 
                    __metadata('design:paramtypes', [Object])
                ], TeamsPlayersBoxComponent.prototype, "selectedOrgDetails", null);
                __decorate([
                    core_1.Input('userProfile'), 
                    __metadata('design:type', Object), 
                    __metadata('design:paramtypes', [Object])
                ], TeamsPlayersBoxComponent.prototype, "userProfile", null);
                __decorate([
                    core_1.Input('userId'), 
                    __metadata('design:type', site_search_service_1.SiteSearch), 
                    __metadata('design:paramtypes', [site_search_service_1.SiteSearch])
                ], TeamsPlayersBoxComponent.prototype, "userId", null);
                __decorate([
                    core_1.HostListener('window:resize', ['$event']), 
                    __metadata('design:type', Function), 
                    __metadata('design:paramtypes', [Object]), 
                    __metadata('design:returntype', void 0)
                ], TeamsPlayersBoxComponent.prototype, "onResize", null);
                TeamsPlayersBoxComponent = __decorate([
                    core_1.Component({
                        selector: 'teams-players-box',
                        templateUrl: '/maxweb/app/app/teams-players-box.component.html'
                    }), 
                    __metadata('design:paramtypes', [maxAppContext_service_1.MaxAppContext, user_profiles_service_1.UserProfiles, router_1.Router, document_factory_service_1.Documents])
                ], TeamsPlayersBoxComponent);
                return TeamsPlayersBoxComponent;
            }());
            exports_1("TeamsPlayersBoxComponent", TeamsPlayersBoxComponent);
            TeamsPlayersListComponent = (function (_super) {
                __extends(TeamsPlayersListComponent, _super);
                function TeamsPlayersListComponent(ctx, _userProfilesSvc, _router, _documents) {
                    _super.call(this, ctx, _userProfilesSvc, _router, _documents);
                    this.ctx = ctx;
                    this._userProfilesSvc = _userProfilesSvc;
                    this._router = _router;
                    this._documents = _documents;
                }
                TeamsPlayersListComponent.prototype.ngAfterViewInit = function () {
                    this.loadFixedHeaderFunction('top-tr-head-list', 'List');
                };
                TeamsPlayersListComponent = __decorate([
                    core_1.Component({
                        selector: '[teams-players-list]',
                        templateUrl: '/maxweb/app/app/teams-players-list.component.html'
                    }), 
                    __metadata('design:paramtypes', [maxAppContext_service_1.MaxAppContext, user_profiles_service_1.UserProfiles, router_1.Router, document_factory_service_1.Documents])
                ], TeamsPlayersListComponent);
                return TeamsPlayersListComponent;
            }(TeamsPlayersBoxComponent));
            exports_1("TeamsPlayersListComponent", TeamsPlayersListComponent);
            TeamsPlayersEligibilityComponent = (function (_super) {
                __extends(TeamsPlayersEligibilityComponent, _super);
                function TeamsPlayersEligibilityComponent(ctx, _userProfilesSvc, _router, _model, _documents) {
                    _super.call(this, ctx, _userProfilesSvc, _router, _documents);
                    this.ctx = ctx;
                    this._userProfilesSvc = _userProfilesSvc;
                    this._router = _router;
                    this._model = _model;
                    this._documents = _documents;
                    this.isAutoloading = { academicYearloading: false, FormsSubmittedloading: false, MedicalClearanceloading: false, MedicallyClearedloading: false };
                    this.academicYear = "";
                    this.cardview = sessionStorage['cardview'];
                    this.roleview = sessionStorage['roleview'];
                }
                TeamsPlayersEligibilityComponent.prototype.ngAfterViewInit = function () {
                    this.loadFixedHeaderFunction('top-tr-head-eligi', 'Eligibility');
                };
                //Use for eligibility cekbox functionality
                TeamsPlayersEligibilityComponent.prototype.eligibilityStatusescheck = function (ischecked, currentid, type, status) {
                    var _this = this;
                    if (status.$eligibilityStatuses[0].key.eligibilityDefinitionKey.academicYear) {
                        this.academicYear = status.$eligibilityStatuses[0].key.eligibilityDefinitionKey.academicYear;
                    }
                    else {
                        if (_.has(this.currentOrgDetails, 'currentAcademicYear')) {
                            this.academicYear = this.currentOrgDetails.currentAcademicYear;
                        }
                    }
                    //this.isAutoloading= true;
                    this.eligibilityobj =
                        {
                            userProfileId: currentid,
                            key: {
                                type: "sportYearUserSpecified",
                                eligibilityDefinitionKey: { "academicYear": this.academicYear }
                            },
                            $update: {
                                $set: {
                                    "status.academicallyCleared": false,
                                    "status.medicallyCleared": false,
                                    "status.medicalClearanceSubmitted": false,
                                    "status.trainerCleared": false
                                }
                            }
                        };
                    if (type == 'Academically Cleared') {
                        this.isAutoloading.academicYearloading = true;
                        this.eligibilityobj.$update.$set['status.academicallyCleared'] = ischecked;
                        if (status !== undefined) {
                            this.eligibilityobj.$update.$set['status.formsSubmitted'] = status.$eligibilityStatuses[0].status.formsSubmitted;
                            this.eligibilityobj.$update.$set['status.medicalClearanceSubmitted'] = status.$eligibilityStatuses[0].status.formsSubmitted;
                            this.eligibilityobj.$update.$set['status.medicallyCleared'] = status.$eligibilityStatuses[0].status.medicallyCleared;
                        }
                    }
                    else if (type == 'Forms Submitted') {
                        this.isAutoloading.FormsSubmittedloading = true;
                        this.eligibilityobj.$update.$set['status.formsSubmitted'] = ischecked;
                        if (status !== undefined) {
                            this.eligibilityobj.$update.$set['status.academicallyCleared'] = status.$eligibilityStatuses[0].status.academicallyCleared;
                            this.eligibilityobj.$update.$set['status.medicallyCleared'] = status.$eligibilityStatuses[0].status.medicallyCleared;
                            this.eligibilityobj.$update.$set['status.medicalClearanceSubmitted'] = status.$eligibilityStatuses[0].status.formsSubmitted;
                        }
                    }
                    else if (type == 'Medical Clearance Submitted') {
                        this.isAutoloading.MedicalClearanceloading = true;
                        this.eligibilityobj.$update.$set['status.medicalClearanceSubmitted'] = ischecked;
                        if (status !== undefined) {
                            this.eligibilityobj.$update.$set['status.formsSubmitted'] = status.$eligibilityStatuses[0].status.formsSubmitted;
                            this.eligibilityobj.$update.$set['status.academicallyCleared'] = status.$eligibilityStatuses[0].status.academicallyCleared;
                            this.eligibilityobj.$update.$set['status.medicallyCleared'] = status.$eligibilityStatuses[0].status.medicallyCleared;
                        }
                    }
                    else if (type == 'Medically Cleared') {
                        this.isAutoloading.MedicallyClearedloading = true;
                        this.eligibilityobj.$update.$set['status.medicallyCleared'] = ischecked;
                        if (status !== undefined) {
                            this.eligibilityobj.$update.$set['status.formsSubmitted'] = status.$eligibilityStatuses[0].status.formsSubmitted;
                            this.eligibilityobj.$update.$set['status.academicallyCleared'] = status.$eligibilityStatuses[0].status.academicallyCleared;
                            this.eligibilityobj.$update.$set['status.medicalClearanceSubmitted'] = status.$eligibilityStatuses[0].status.formsSubmitted;
                        }
                    }
                    this._userProfilesSvc.checkeligibilityStatuses(this.eligibilityobj).single().toPromise().then(function (resdata) {
                        if (resdata !== undefined) {
                            _this.isAutoloading.academicYearloading = false;
                            _this.isAutoloading.FormsSubmittedloading = false;
                            _this.isAutoloading.MedicalClearanceloading = false;
                            _this.isAutoloading.MedicallyClearedloading = false;
                        }
                        else {
                            _this.isAutoloading = true;
                        }
                        //this._userProfile = new UserProfile(d.status.academicallyCleared);
                    }).catch(function (e) {
                        var msgstr = "We encountered an error saving your changes. Please refresh and try again.";
                        _this._model.confirm()
                            .size('sm').isBlocking(true).showClose(false).keyboard(27)
                            .body(msgstr)
                            .headerClass("hide")
                            .okBtnClass("hide")
                            .cancelBtn("Close").cancelBtnClass("btn btn-primary")
                            .open().then(function (dialog) {
                            return dialog.result;
                        }).then(function (result) {
                        }).catch(function (e) {
                        });
                        throw e;
                    });
                };
                TeamsPlayersEligibilityComponent = __decorate([
                    core_1.Component({
                        selector: '[teams-players-eligibility]',
                        templateUrl: '/maxweb/app/app/teams-players-eligibility.component.html',
                    }), 
                    __metadata('design:paramtypes', [maxAppContext_service_1.MaxAppContext, user_profiles_service_1.UserProfiles, router_1.Router, bootstrap_1.Modal, document_factory_service_1.Documents])
                ], TeamsPlayersEligibilityComponent);
                return TeamsPlayersEligibilityComponent;
            }(TeamsPlayersBoxComponent));
            exports_1("TeamsPlayersEligibilityComponent", TeamsPlayersEligibilityComponent);
        }
    }
});
//# sourceMappingURL=teams-players-box.component.js.map