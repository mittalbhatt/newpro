System.register(["@angular/core", "@angular/http", "./pagedDataUtil.service", "rxjs/Rx"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var __param = (this && this.__param) || function (paramIndex, decorator) {
        return function (target, key) { decorator(target, key, paramIndex); }
    };
    var core_1, http_1, pagedDataUtil_service_1, Rx_1;
    var UserProfileState, Username, UserAccount, medicalDocumentsData, designationCondition, userDesignationStatus, UserProfile, UserInjuryDetails, UserProfiles;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (http_1_1) {
                http_1 = http_1_1;
            },
            function (pagedDataUtil_service_1_1) {
                pagedDataUtil_service_1 = pagedDataUtil_service_1_1;
            },
            function (Rx_1_1) {
                Rx_1 = Rx_1_1;
            }],
        execute: function() {
            UserProfileState = (function () {
                function UserProfileState() {
                }
                return UserProfileState;
            }());
            exports_1("UserProfileState", UserProfileState);
            Username = (function () {
                function Username() {
                }
                return Username;
            }());
            exports_1("Username", Username);
            UserAccount = (function () {
                function UserAccount() {
                }
                return UserAccount;
            }());
            exports_1("UserAccount", UserAccount);
            medicalDocumentsData = (function () {
                function medicalDocumentsData() {
                }
                return medicalDocumentsData;
            }());
            exports_1("medicalDocumentsData", medicalDocumentsData);
            designationCondition = (function () {
                function designationCondition() {
                }
                return designationCondition;
            }());
            exports_1("designationCondition", designationCondition);
            userDesignationStatus = (function () {
                function userDesignationStatus() {
                }
                return userDesignationStatus;
            }());
            exports_1("userDesignationStatus", userDesignationStatus);
            UserProfile = (function () {
                function UserProfile(src) {
                    this.emails = [];
                    this.$eligibilityStatuses = [{
                            status: {
                                academicallyCleared: false,
                                medicallyCleared: false,
                                trainerCleared: false,
                                formsComplete: false
                            }
                        }];
                    // console.log(src);
                    for (var k in src) {
                        this[k] = src[k];
                    }
                }
                Object.defineProperty(UserProfile.prototype, "athleteDisplayName", {
                    get: function () {
                        if (this.lastName && this.firstName)
                            return this.lastName + ", " + this.firstName;
                        else if (this.lastName)
                            return this.lastName;
                        else if (this.firstName)
                            return this.firstName;
                        else if (this.email)
                            return this.email;
                        else
                            return this._id;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(UserProfile.prototype, "athleteTitleName", {
                    get: function () {
                        if (this.lastName && this.firstName)
                            return this.firstName + " " + this.lastName;
                        else if (this.lastName)
                            return this.lastName;
                        else if (this.firstName)
                            return this.firstName;
                        else if (this.email)
                            return this.email;
                        else
                            return this._id;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(UserProfile.prototype, "phone", {
                    get: function () {
                        return (this.tel || [])[0];
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(UserProfile.prototype, "createdDateParsed", {
                    get: function () {
                        return this.createdDate ? new Date(this.createdDate) : null;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(UserProfile.prototype, "gradYear", {
                    get: function () {
                        if (this.medicalDocuments !== undefined) {
                            var gYear = null;
                            _.find(this.medicalDocuments[0], function (o) {
                                if (o.ident == "gradYear") {
                                    gYear = o.value;
                                }
                            });
                            return gYear;
                        }
                        return null;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(UserProfile.prototype, "borderColor", {
                    get: function () {
                        if (this.currentDesignationStatus !== undefined) {
                            if (this.currentDesignationStatus.mostSevereStatus === 0) {
                                return "red-border";
                            }
                            else if (this.currentDesignationStatus.mostSevereStatus === 1) {
                                return "green-border";
                            }
                            else if (this.currentDesignationStatus.mostSevereStatus === 2) {
                                return "yellow-border";
                            }
                        }
                        return null;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(UserProfile.prototype, "recentInjury", {
                    get: function () {
                        if (this.currentDesignationStatus !== undefined) {
                            if (this.currentDesignationStatus.designations[0] !== undefined) {
                                if (this.currentDesignationStatus.designations[0].conditions[0].bodyPart &&
                                    this.currentDesignationStatus.designations[0].conditions[0].name) {
                                    return this.currentDesignationStatus.designations[0].conditions[0].bodyPart + " - " + this.currentDesignationStatus.designations[0].conditions[0].name;
                                }
                                else if (this.currentDesignationStatus.designations[0].conditions[0].name) {
                                    return this.currentDesignationStatus.designations[0].conditions[0].name;
                                }
                            }
                        }
                        return null;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(UserProfile.prototype, "clearedToPlayBadge", {
                    get: function () {
                        if (this.currentDesignationStatus !== undefined) {
                            var date = (this.currentDesignationStatus.mostDistantClearedToPlayDate) ? this.currentDesignationStatus.mostDistantClearedToPlayDate : null;
                            if (this.currentDesignationStatus.mostSevereClearedToPlay === 0) {
                                return { color: "date red", date: date };
                            }
                            else if (this.currentDesignationStatus.mostSevereClearedToPlay === 1) {
                                return { color: "date green", date: "cleared" };
                            }
                            else if (this.currentDesignationStatus.mostSevereClearedToPlay === 2) {
                                return { color: "date yellow", date: date };
                            }
                        }
                        return null;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(UserProfile.prototype, "practiceBadge", {
                    get: function () {
                        if (this.currentDesignationStatus !== undefined) {
                            var date = (this.currentDesignationStatus.mostDistantClearedToPracticeDate) ? this.currentDesignationStatus.mostDistantClearedToPracticeDate : null;
                            if (this.currentDesignationStatus.mostSevereClearedToPractice === 0) {
                                return { color: "date red", date: date };
                            }
                            else if (this.currentDesignationStatus.mostSevereClearedToPractice === 1) {
                                return { color: "date green", date: date };
                            }
                            else if (this.currentDesignationStatus.mostSevereClearedToPractice === 2) {
                                return { color: "date yellow", date: date };
                            }
                        }
                        return null;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(UserProfile.prototype, "medicalCondition", {
                    get: function () {
                        var medicalcondition = null;
                        if (this.medicalDocuments !== undefined && this.medicalDocuments[0] !== undefined) {
                            _.find(this.medicalDocuments[0].data, function (o) {
                                if (o.ident == "conditions") {
                                    medicalcondition = o.value;
                                }
                            });
                        }
                        return medicalcondition;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(UserProfile.prototype, "medicalAllergies", {
                    get: function () {
                        var medicalAllergies = null;
                        if (this.medicalDocuments !== undefined && this.medicalDocuments[0] !== undefined) {
                            _.find(this.medicalDocuments[0].data, function (o) {
                                if (o.ident == "allergies") {
                                    medicalAllergies = o.value;
                                }
                            });
                        }
                        return medicalAllergies;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(UserProfile.prototype, "roleDisplayTitle", {
                    get: function () {
                        var lookup = {
                            'ATH': 'Athlete',
                            'TRN': 'Athletic Trainer',
                            'PRN': 'Parent',
                            'CCH': 'Coach',
                            'ADM': 'Administrator',
                            'MED': 'Physician or Medical Staff'
                        };
                        var r = (this.orgRoles || []).find(function (r) { return lookup[r]; });
                        return lookup[r] || 'Unknown';
                    },
                    enumerable: true,
                    configurable: true
                });
                UserProfile.prototype.getDOB = function (_userProfile) {
                    var finalDOBStr = "";
                    // let specificAllergy = [{keyType: 'hasMedicines', name: 'Medicines' }, {keyType: 'hasFood', name: 'Food' }, {keyType: 'hasPollens', name: 'Pollens' }, {keyType: 'hasStingingInsects', name: 'Stinging Insects' }];
                    if (_.has(_userProfile, '$amr')) {
                        if (_.has(_userProfile.$amr, 'info')) {
                            if (_.has(_userProfile.$amr.info, "dob")) {
                                // if(_userProfile.$amr.info.specificAllergy === 1) {
                                var dobVal = _userProfile.$amr.info.dob;
                                var dobunique = _.uniq(dobVal);
                                if (_userProfile.$amr.info.dob != undefined) {
                                    finalDOBStr = dobVal.slice(0, 10);
                                }
                            }
                        }
                    }
                    return finalDOBStr;
                };
                UserProfile.prototype.getGradYear = function (_userProfile) {
                    var finalGradYearStr = "";
                    // let specificAllergy = [{keyType: 'hasMedicines', name: 'Medicines' }, {keyType: 'hasFood', name: 'Food' }, {keyType: 'hasPollens', name: 'Pollens' }, {keyType: 'hasStingingInsects', name: 'Stinging Insects' }];
                    if (_.has(_userProfile, '$amr')) {
                        if (_.has(_userProfile.$amr, 'info')) {
                            if (_.has(_userProfile.$amr.info, "gradYear")) {
                                // if(_userProfile.$amr.info.specificAllergy === 1) {
                                var gradYearVal = _userProfile.$amr.info.gradYear;
                                var gradYearunique = _.uniq(gradYearVal);
                                if (_userProfile.$amr.info.gradYear != undefined) {
                                    finalGradYearStr = gradYearVal;
                                }
                            }
                        }
                    }
                    return finalGradYearStr;
                };
                UserProfile.prototype.getSpecificAllergyShow = function (_userProfile) {
                    var finalAllergybool = false;
                    // let specificAllergy = [{keyType: 'hasMedicines', name: 'Medicines' }, {keyType: 'hasFood', name: 'Food' }, {keyType: 'hasPollens', name: 'Pollens' }, {keyType: 'hasStingingInsects', name: 'Stinging Insects' }];
                    if (_.has(_userProfile, '$amr')) {
                        if (_.has(_userProfile.$amr, 'info')) {
                            if (_.has(_userProfile.$amr.info, "specificAllergy")) {
                                // if(_userProfile.$amr.info.specificAllergy === 1) {
                                var specificAllergy = _userProfile.$amr.info.specificAllergy;
                                var specificAllergyunique = _.uniq(specificAllergy);
                                if (_userProfile.$amr.info.specificAllergy != undefined) {
                                    finalAllergybool = _userProfile.$amr.info.specificAllergy;
                                }
                            }
                        }
                    }
                    return finalAllergybool;
                };
                UserProfile.prototype.getSpecificAllergy = function (_userProfile) {
                    var finalAllergyStr = [];
                    // let specificAllergy = [{keyType: 'hasMedicines', name: 'Medicines' }, {keyType: 'hasFood', name: 'Food' }, {keyType: 'hasPollens', name: 'Pollens' }, {keyType: 'hasStingingInsects', name: 'Stinging Insects' }];
                    if (_.has(_userProfile, '$amr')) {
                        if (_.has(_userProfile.$amr, 'info')) {
                            if (_.has(_userProfile.$amr.info, "allergiesList")) {
                                // if(_userProfile.$amr.info.specificAllergy === 1) {
                                var specificAllergy = _userProfile.$amr.info.allergiesList;
                                var specificAllergyunique = _.uniq(specificAllergy);
                                if (_userProfile.$amr.info.allergiesList != undefined) {
                                    if (specificAllergyunique.length > 0) {
                                        _.each(specificAllergyunique, function (o) {
                                            finalAllergyStr.push(o);
                                        });
                                    }
                                }
                            }
                        }
                    }
                    return finalAllergyStr.join(', ');
                };
                UserProfile.prototype.getExistingMedicalConditionShow = function (_userProfile) {
                    var finalexistingMedicalConditionbool = false;
                    // let specificAllergy = [{keyType: 'hasMedicines', name: 'Medicines' }, {keyType: 'hasFood', name: 'Food' }, {keyType: 'hasPollens', name: 'Pollens' }, {keyType: 'hasStingingInsects', name: 'Stinging Insects' }];
                    if (_.has(_userProfile, '$amr')) {
                        if (_.has(_userProfile.$amr, 'info')) {
                            if (_.has(_userProfile.$amr.info, "existingMedicalCondition")) {
                                // if(_userProfile.$amr.info.specificAllergy === 1) {
                                var specificAllergy = _userProfile.$amr.info.existingMedicalCondition;
                                if (_userProfile.$amr.info.existingMedicalCondition != undefined) {
                                    finalexistingMedicalConditionbool = _userProfile.$amr.info.existingMedicalCondition;
                                }
                            }
                        }
                    }
                    return finalexistingMedicalConditionbool;
                };
                UserProfile.prototype.getExistingMedicalCondition = function (_userProfile) {
                    var finalexistingMedicalConditionStr = [];
                    if (_.has(_userProfile, '$amr')) {
                        if (_.has(_userProfile.$amr, 'info')) {
                            if (_.has(_userProfile.$amr.info, 'medicalConditionsList')) {
                                var existingMedicalCondition = _userProfile.$amr.info.medicalConditionsList;
                                var existingMedicalConditionunique = _.uniq(existingMedicalCondition);
                                if (_userProfile.$amr.info.medicalConditionsList != undefined) {
                                    if (existingMedicalConditionunique.length > 0) {
                                        _.each(existingMedicalConditionunique, function (o) {
                                            finalexistingMedicalConditionStr.push(o);
                                        });
                                    }
                                }
                            }
                        }
                    }
                    return finalexistingMedicalConditionStr.join(', ');
                };
                return UserProfile;
            }());
            exports_1("UserProfile", UserProfile);
            UserInjuryDetails = (function () {
                function UserInjuryDetails(data) {
                    for (var k in data) {
                        this[k] = data[k];
                    }
                }
                Object.defineProperty(UserInjuryDetails.prototype, "injuryName", {
                    get: function () {
                        if (this.conditions[0].name) {
                            return this.conditions[0].name;
                        }
                        return null;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(UserInjuryDetails.prototype, "injuryDetails", {
                    get: function () {
                        if (this.conditions[0] && this.conditions[0].details) {
                            return this.conditions[0].details;
                        }
                        return null;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(UserInjuryDetails.prototype, "subjectiveDetail", {
                    get: function () {
                        if (this.conditions[0] && this.conditions[0].soap && this.conditions[0].soap.s) {
                            return this.conditions[0].soap.s;
                        }
                        return null;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(UserInjuryDetails.prototype, "objectiveDetail", {
                    get: function () {
                        if (this.conditions[0] && this.conditions[0].soap && this.conditions[0].soap.o) {
                            return this.conditions[0].soap.o;
                        }
                        return null;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(UserInjuryDetails.prototype, "aessementDetail", {
                    get: function () {
                        if (this.conditions[0] && this.conditions[0].soap && this.conditions[0].soap.a) {
                            return this.conditions[0].soap.a;
                        }
                        return null;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(UserInjuryDetails.prototype, "planDetail", {
                    get: function () {
                        if (this.conditions[0] && this.conditions[0].soap && this.conditions[0].soap.p) {
                            return this.conditions[0].soap.p;
                        }
                        return null;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(UserInjuryDetails.prototype, "doi", {
                    get: function () {
                        if (this.startDate) {
                            return this.startDate;
                        }
                        return null;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(UserInjuryDetails.prototype, "treatments", {
                    get: function () {
                        if (this.conditions[0] && this.conditions[0].treatments) {
                            var treatments_str = null;
                            this.conditions[0].treatments.forEach(function (t) {
                                if (treatments_str == null) {
                                    treatments_str = t;
                                }
                                else {
                                    treatments_str += ", " + t;
                                }
                            });
                            return treatments_str;
                        }
                        return null;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(UserInjuryDetails.prototype, "playBadge", {
                    get: function () {
                        if (this.clearedToPlay !== undefined) {
                            var date = (this.expectedClearedToPlayDate) ? this.expectedClearedToPlayDate : null;
                            if (this.clearedToPlay == 0) {
                                return { color: "date red", date: date };
                            }
                            else if (this.clearedToPlay == 1) {
                                return { color: "date green", date: "CLEARED" };
                            }
                            else if (this.clearedToPlay == 2) {
                                return { color: "date yellow", date: date };
                            }
                        }
                        return null;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(UserInjuryDetails.prototype, "practiceBadge", {
                    get: function () {
                        if (this.clearedToPractice !== undefined) {
                            var date = (this.expectedClearedToPracticeDate) ? this.expectedClearedToPracticeDate : null;
                            if (this.clearedToPractice == 0) {
                                return { color: "date red", date: date };
                            }
                            else if (this.clearedToPractice == 1) {
                                return { color: "date green", date: "CLEARED" };
                            }
                            else if (this.clearedToPractice == 2) {
                                return { color: "date yellow", date: date };
                            }
                        }
                        return null;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(UserInjuryDetails.prototype, "particePlayInstructions", {
                    get: function () {
                        if (this.participationInstructions && this.participationInstructions[0] && this.participationInstructions[0].content) {
                            return this.participationInstructions[0].content;
                        }
                        return null;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(UserInjuryDetails.prototype, "bodyPart", {
                    get: function () {
                        if (this.conditions[0] && this.conditions[0].bodyPart) {
                            return this.conditions[0].bodyPart;
                        }
                        return null;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(UserInjuryDetails.prototype, "doctor", {
                    get: function () {
                        if (this.medReferrals && this.medReferrals[0] && this.medReferrals[0].userInfo && this.medReferrals[0].userInfo.name) {
                            return this.medReferrals[0].userInfo.name;
                        }
                        return null;
                    },
                    enumerable: true,
                    configurable: true
                });
                return UserInjuryDetails;
            }());
            exports_1("UserInjuryDetails", UserInjuryDetails);
            UserProfiles = (function () {
                function UserProfiles(_http, _requestOps) {
                    this._http = _http;
                    this._requestOps = _requestOps;
                    this.updateRelativeData = new core_1.EventEmitter();
                    this.getProfileData = new core_1.EventEmitter();
                }
                UserProfiles.prototype.getMine = function () {
                    return this._http.get('/training/api/userProfiles/mine?skip=0&limit=100')
                        .map(function (res) { return res.json(); });
                };
                UserProfiles.prototype.getProfile = function (id) {
                    return this._http.get("/training/api/userProfiles/" + id)
                        .map(function (res) { return res.json(); });
                };
                UserProfiles.prototype.getProfiles = function (skip, take, pendingAllowed) {
                    if (skip === void 0) { skip = 0; }
                    if (take === void 0) { take = 100; }
                    if (pendingAllowed === void 0) { pendingAllowed = false; }
                    var args = new http_1.RequestOptions();
                    args.search = new http_1.URLSearchParams();
                    args.search.append('skip', skip.toString());
                    args.search.append('limit', take.toString());
                    args.search.append('sortBy', 'sortlastName,sortFirstName');
                    args.search.append('pendingAllowed', pendingAllowed.toString());
                    return this._http.get("/training/api/userProfiles", args)
                        .map(function (res) { return res.json(); });
                };
                UserProfiles.prototype.getAllProfiles = function () {
                    var _this = this;
                    return pagedDataUtil_service_1.PagedDataUtil.getAllPages(function (s, t) { return _this.getProfiles(s, t, true); });
                };
                UserProfiles.prototype.getProfilesToCheck = function (skip, take) {
                    if (skip === void 0) { skip = 0; }
                    if (take === void 0) { take = 100; }
                    var args = new http_1.RequestOptions();
                    args.search = new http_1.URLSearchParams();
                    args.search.append('skip', skip.toString());
                    args.search.append('limit', take.toString());
                    return this._http.get("/training/api/userProfiles", args)
                        .map(function (res) { return res.json(); });
                };
                UserProfiles.prototype.getAllProfilesToCheck = function () {
                    var _this = this;
                    return pagedDataUtil_service_1.PagedDataUtil.getAllPages(function (s, t) { return _this.getProfilesToCheck(s, t); });
                };
                UserProfiles.prototype.createProfile = function (profile) {
                    return this._http.post('/training/api/userProfiles', profile);
                };
                UserProfiles.prototype.updateProfile = function (profileId, update) {
                    return this._http.post("/training/api/userProfiles/" + profileId + "/update", update);
                };
                Object.defineProperty(UserProfiles.prototype, "createProfileRedirectUrl", {
                    get: function () {
                        return store.session('createProfileRedirect');
                    },
                    set: function (value) {
                        store.session('createProfileRedirect', value);
                    },
                    enumerable: true,
                    configurable: true
                });
                UserProfiles.prototype.getPendingProfiles = function () {
                    return this._http.get('/training/api/userProfiles/pending?excludeRoles[]=PRN')
                        .map(function (response) { return response.json().map(function (p) { return new UserProfile(p); }); });
                };
                UserProfiles.prototype.approveProfile = function (profile, setTags) {
                    var _this = this;
                    if (setTags === void 0) { setTags = false; }
                    var updatePromise = Promise.resolve(null);
                    if (setTags) {
                        var update = { $set: { tags: profile.tags } };
                        updatePromise = this._http.put("/training/api/userProfiles/" + profile._id + "/update", update).single().toPromise();
                    }
                    return updatePromise.then(function () { return _this._http.put("/training/api/userProfiles/" + profile._id + "/approve", {}).single().toPromise().then(function (result) {
                        //console.log('From Promise:', result);
                        _this.getProfileData.emit({ data: result, action: "approve" });
                    }); });
                };
                UserProfiles.prototype.disapproveProfile = function (profile) {
                    var _this = this;
                    return this._http.put("/training/api/userProfiles/" + profile._id + "/disapprove", {}).single().toPromise().then(function (result) {
                        //console.log('From Promise:', result);
                        _this.getProfileData.emit({ data: result, action: "disapprove" });
                    });
                };
                UserProfiles.prototype.deleteProfile = function (profile) {
                    return this._http.delete("/training/api/userProfiles/" + profile._id);
                };
                UserProfiles.prototype.getProfileImageUrl = function (profile) {
                    var _this = this;
                    return Rx_1.Observable.create(function (observer) {
                        var url = profile.imageUris[0];
                        if (!url) {
                            observer.next(null);
                            observer.complete();
                            return;
                        }
                        var req = new XMLHttpRequest();
                        req.open('get', url);
                        req.onreadystatechange = function () {
                            if (req.readyState == 4 && req.status == 200) {
                                var loc = req.getResponseHeader('location');
                                observer.next(loc);
                                observer.complete();
                            }
                            else if (req.readyState == 4) {
                                observer.error(new Error(req.responseText));
                            }
                        };
                        req.setRequestHeader('Authorization', _this._requestOps.headers.get('Authorization'));
                        req.send();
                    });
                };
                UserProfiles.prototype.getPendingUserCount = function () {
                    return this._http.head('/training/api/userProfiles/pending?excludeRoles[]=PRN')
                        .map(function (res) { return parseInt(res.headers.get('df-list-count') || '0'); });
                };
                UserProfiles.prototype.getTeamUserProfiles = function (skip, take, pendingAllowed, sortingParameter, sortingOrderParameter, filterParameter) {
                    if (skip === void 0) { skip = 0; }
                    if (take === void 0) { take = 10; }
                    if (pendingAllowed === void 0) { pendingAllowed = false; }
                    if (sortingParameter === void 0) { sortingParameter = ""; }
                    if (sortingOrderParameter === void 0) { sortingOrderParameter = ""; }
                    var args = new http_1.RequestOptions();
                    args.search = new http_1.URLSearchParams();
                    args.search.append('skip', skip.toString());
                    args.search.append('limit', take.toString());
                    args.search.append('sortBy', sortingOrderParameter + sortingParameter.toString());
                    if (filterParameter.orgId) {
                        args.search.append('$filter.0.org', "ObjectId(" + filterParameter.orgId + ")");
                    }
                    if (filterParameter.teamId) {
                        args.search.append('$filter.1.tags', "," + filterParameter.teamId + ",");
                    }
                    if (filterParameter.orgRoles) {
                        args.search.append('$filter.1.orgRoles', "" + filterParameter.orgRoles);
                    }
                    if (filterParameter.injured !== undefined && filterParameter.injured !== null && filterParameter.injured != 'null') {
                        args.search.append('$filter.0.currentDesignationStatus.injured', "" + filterParameter.injured);
                    }
                    //args.search.append('$filter.0.org', `ObjectId(5641ce010c2191d838521e0d)`);
                    //args.search.append('$filter.1.tags', `,MBA:,`);
                    args.search.append('pendingAllowed', pendingAllowed.toString());
                    return this._http.get("/training/api/userProfiles", args)
                        .map(function (res) { return res.json(); });
                };
                UserProfiles.prototype.getUserInjuryStatus = function (skip, take, filterParameter) {
                    if (skip === void 0) { skip = 0; }
                    if (take === void 0) { take = 10; }
                    var args = new http_1.RequestOptions();
                    args.search = new http_1.URLSearchParams();
                    args.search.append('skip', skip.toString());
                    args.search.append('limit', take.toString());
                    args.search.append('$filter.0.type', "Injury");
                    return this._http.get("/training/api/designations/byUser/" + filterParameter.user + "/startOnOrBefore/9999-12-31", args)
                        .map(function (res) { return res.json(); });
                };
                UserProfiles.prototype.getTeamUserDocument = function (profileId) {
                    return this._http.get("/training/api/userProfiles/" + profileId + "/documents").map(function (res) { return res.json(); });
                };
                UserProfiles.prototype.checkeligibilityStatuses = function (eligibilityobj) {
                    return this._http.put('/training/api/eligibilityStatuses/updates', eligibilityobj).map(function (res) { return res.json(); });
                };
                UserProfiles.prototype.inviterelation = function (inviteobj) {
                    return this._http.put('/training/api/registrations?suppressDelivery=true', inviteobj).map(function (res) { return res.json(); });
                };
                UserProfiles.prototype.texttoinvite = function (inviteobj) {
                    return this._http.put('/training/api/registrations?suppressDelivery=false', inviteobj).map(function (res) { return res.json(); });
                };
                UserProfiles = __decorate([
                    core_1.Injectable(),
                    __param(1, core_1.Inject(http_1.RequestOptions)), 
                    __metadata('design:paramtypes', [http_1.Http, http_1.RequestOptions])
                ], UserProfiles);
                return UserProfiles;
            }());
            exports_1("UserProfiles", UserProfiles);
        }
    }
});
//# sourceMappingURL=user_profiles.service.js.map