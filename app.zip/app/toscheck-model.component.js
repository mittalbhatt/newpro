System.register(["@angular/core", "./userAccount.service", "@angular/router", "angular2-modal", 'angular2-modal/plugins/bootstrap', "./maxAppContext.service"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __extends = (this && this.__extends) || function (d, b) {
        for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, userAccount_service_1, router_1, angular2_modal_1, bootstrap_1, maxAppContext_service_1;
    var TosModalContext, TosCheckModal;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (userAccount_service_1_1) {
                userAccount_service_1 = userAccount_service_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (angular2_modal_1_1) {
                angular2_modal_1 = angular2_modal_1_1;
            },
            function (bootstrap_1_1) {
                bootstrap_1 = bootstrap_1_1;
            },
            function (maxAppContext_service_1_1) {
                maxAppContext_service_1 = maxAppContext_service_1_1;
            }],
        execute: function() {
            TosModalContext = (function (_super) {
                __extends(TosModalContext, _super);
                function TosModalContext(d) {
                    _super.call(this);
                    this.d = d;
                    this.data = d;
                    this.size = "lg";
                }
                return TosModalContext;
            }(bootstrap_1.BSModalContext));
            exports_1("TosModalContext", TosModalContext);
            TosCheckModal = (function () {
                function TosCheckModal(dialog, ctx, _modal, _router, _accounts) {
                    this.dialog = dialog;
                    this.ctx = ctx;
                    this._modal = _modal;
                    this._router = _router;
                    this._accounts = _accounts;
                    this.contentdata = this.dialog.context.data.body;
                    this.versionnumber = this.dialog.context.data.versionnumberget;
                }
                TosCheckModal.prototype.saveToseVersion = function () {
                    var _this = this;
                    var versiondata = { version: this.versionnumber };
                    this._accounts.updattosversion(versiondata).single().toPromise().then(function (d) {
                        _this.dialog.close(false);
                        localStorage["tosPopupData"] = JSON.stringify({ isShow: false, version: _this.versionnumber });
                    });
                };
                TosCheckModal.prototype.onCancel = function () {
                    this.dialog.close(false);
                    this.ctx.logout();
                };
                TosCheckModal = __decorate([
                    core_1.Component({
                        selector: 'tos-form-modal-prompt',
                        template: "\n        <div class=\"modal-content\" style=\"text-align:center;\">\n        <div class=\"modal-header\">\n        <h4> Terms of Service </h4>\n        </div>\n        <div class=\"modal-body\" style=\"text-align:left;height:600px;padding-left: 25px;overflow-y: auto;\">\n        <div [innerHTML]=\"this.contentdata\"></div>\n        </div>\n        <div *ngIf=\"!this.contentdata\" class=\"modal-body\">\n        <img src=\"/maxweb/app/media/ajax-loader.gif\" />\n        Processing...    \n        </div>\n        <div class=\"modal-footer\">\n        <button (click)=\"saveToseVersion()\" type=\"button\" class=\"btn btn-primary\" style=\"float:right; margin-right:10px;\">Accept</button>\n        <button (click)=\"onCancel()\" type=\"button\" class=\"btn btn-danger\" style=\"float:right; margin-right:10px;\">Do Not Accept</button>\n        </div>\n        </div>\n        "
                    }), 
                    __metadata('design:paramtypes', [angular2_modal_1.DialogRef, maxAppContext_service_1.MaxAppContext, bootstrap_1.Modal, router_1.Router, userAccount_service_1.UserAccountService])
                ], TosCheckModal);
                return TosCheckModal;
            }());
            exports_1("TosCheckModal", TosCheckModal);
        }
    }
});
//# sourceMappingURL=toscheck-model.component.js.map