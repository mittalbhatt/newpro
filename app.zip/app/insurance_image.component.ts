import { OnInit, Component, Output, Input, Injectable, ViewChild, EventEmitter } from "@angular/core";
import { UserProfiles, UserProfile } from "./user_profiles.service";
import { Router,ActivatedRoute } from "@angular/router";
import {Base64Encoder} from "./base64Encoder";

import { MaxAppContext } from "./maxAppContext.service";
import { Modal, BSModalContext} from 'angular2-modal/plugins/bootstrap';

import {DfObjectId} from "./DfObjectId";
import {DfUuidGen} from "./df_uuid_gen";

import {BasicMedicalSaver} from "./basic_medical_saver.service";
import {Organizations} from "./organizations.service";

 declare var plupload;

@Component({
    selector: 'insurance-image-box',
    templateUrl:'/maxweb/app/app/insurance_image.component.html',
    styles: [`input[type=file] { cursor: pointer !important; }`]

})
export class InsuranceImageBoxComponent implements OnInit {

    @Output() changeData = new EventEmitter();
    imageItemObj:any = {};
    indexre:string;
    errorMessage:string;
    @Output() chkResult: EventEmitter<any> = new EventEmitter();

    logoUploadSettings:any;
    
    private _orgLogoUploadStateChange:(state:any, fromUploaderEvent:boolean, resultUrl:string) => void;
    logoUploading:boolean;
    private logoImageUrl:string;
    documentDataList: any = [];
    isShowDocumentGif: boolean = false;
    _amrId:any="";
    frontLogoImageUrl:any="";
    backLogoImageUrl:any="";
    documentGroupId:any="";
    logoMedia:any={}

    constructor(
        private _userProfiles: UserProfiles,
        private _route: ActivatedRoute,
        private _appCtx: MaxAppContext,
        public _model:Modal,
        private _changeSaver: BasicMedicalSaver,
        private _base64Encoder: Base64Encoder,
        private _organizations:Organizations
    ){
          this._orgLogoUploadStateChange = (s,f,r) => this.orgLogoUploadStateChanged(s,f,r);
    }

  /*  ngOnInit() {

    }*/

    ngOnInit() {
        // var mediaId = DfUuidGen.newUuid();
        // var mediaId_base64 = 'dB1evQq8TgiULgAADhipqg';

        //var _media_id = (new DfObjectId()).toString();
        // var documentStableId = (new DfObjectId()).toString();

        // Conditioally
        // var documentGroupId = (new DfObjectId()).toString();


        var uuid = DfUuidGen.newUuid();

        var mediaId = uuid;

        if(this.imageItemObj.documentGroup !== undefined) {
            if(this.imageItemObj.documentGroup.documentGroupId !== undefined && this.imageItemObj.documentGroup.documentGroupId != "") {
                this.documentGroupId = this.imageItemObj.documentGroup.documentGroupId;
            } else {
                this.documentGroupId = (new DfObjectId()).toString();
            }
        } else {
            this.documentGroupId = (new DfObjectId()).toString();
        }

       // console.log(this.documentGroupId);


        var documentGroupRole = "front";
        if(this.imageItemObj.documentGroup.role == "back") {
            documentGroupRole = "back";
        }

        var logoMedia: any = {};
       
        this.logoUploadSettings = {
            getFileParams: (file) =>
            {
                var fileId = DfUuidGen.newUuid();
 
                logoMedia = {
                    _id: (new DfObjectId()).toString(),
                    type: 'Media',
                    documentStableId: (new DfObjectId()).toString(),
                    name: "Insurance Card",
                    createdDate: new Date(),
                    subjects: [
                    {
                        amrId: this._amrId
                    }
                    ],
                    media: [
                    {
                        contentType: file.type, // "image/jpeg"
                        mediaId: mediaId
                    }
                    ],
                    documentGroup: {
                        documentGroupId: this.documentGroupId,
                        role: documentGroupRole, // front/back
                        type: "insuranceCard"
                    },
                    suppressNotifications: true,
                    lastModifiedDate: new Date()
                };
             
               this.logoMedia=logoMedia;
            this.imageItemObj['logoUploading']=true;
               if(this.imageItemObj._id!=undefined){
                 
                 this._changeSaver.removeInsuranceDocument(this.imageItemObj._id)
                            .single().toPromise().then(() =>
                        {
                            
                            // this.chkResult.emit({
                            //   value: "test123"
                            // })
                        })
                        .catch(e =>
                        {
                            this.errorMessage = 'We encountered an unexpected error. Refresh the page and try again.';
                            throw e;
                        })
               }
              
               console.log(this.imageItemObj);
                return this._changeSaver.update(logoMedia).single().toPromise()
                .then((data) => {
                   this.logoUploading=false;
                     return {
                                   
                                    paramsUrl: `/training/api/documents/${logoMedia._id}/media/${encodeURIComponent(mediaId)}`
                                };
                   // return logoMedia;
                });
            },
            dfUploadTag: mediaId,
            uploaderSettings: {
                filters: {
                    max_file_size: '10mb',
                    mime_types: [
                    { title: "Image files", extensions: "jpeg,jpg,gif,png" }
                    ]
                },
                resize: {
                    width: 600,
                    height: 600
                }
            },
            
        };
         
         this.logoMedia=logoMedia;
           this._changeSaver.getLogoUrldocumentmedia(logoMedia).single().toPromise()
         .then((data) => {
            
        console.log(data);
                if(this.imageItemObj.documentGroup.role == "front") {
                    this.frontLogoImageUrl = data;
                } else {
                    this.backLogoImageUrl = data;
                }

            }).catch(e => {
                // console.log('Logo error - ' + e.message);
                // this.logoUploading = false;
                // throw e;
            });
         
      
    }
      orgLogoUploadStateChanged(state, fromUploaderEvent, resultUrl)
    {
        if (state === plupload.DONE)
        {
            
            

            this._changeSaver.getLogoUrldocumentmedia(this.imageItemObj).single().toPromise()
                .then(url =>{
                     if(this.imageItemObj.documentGroup.role == "front") {
                      
                    this.frontLogoImageUrl = url;
                      

                } else {
                    
                    this.backLogoImageUrl = url;
                   
                     
                    
                }
                
                })
                .catch(e => {
                    console.log('Logo error - ' + e.message);
                    this.errorMessage = 'An error was encountered showing the image.';
                    this.logoUploading = false;
                });
                 setTimeout(() => this.chkResult.emit({
                              value: "test123"
                            }), 2000);
        }
        else if (state === plupload.FAILED)
        {
            this.logoUploading = false;
            this.errorMessage = 'An error was encountered while uploading your image.  Refresh the page and try again.';

            // Don't leave a bad image ref in the profile.
            //UserProfileUpdate.save({ profileId: userProfileId }, { $set: { images: [] } });
        }
        else
        {
            this.logoUploading = true;
        }
    };
    documentImageUploadStateChanged(state=0, fromUploaderEvent=true, resultUrl="")
    {
       

        this._changeSaver.getLogoUrldocumentmedia(this.logoMedia).single().toPromise()
         .then((data) => {
              console.log("In documentImageUploadStateChanged");
        console.log(data);
                if(this.imageItemObj.documentGroup.role == "front") {
                    this.frontLogoImageUrl = data;
                } else {
                    this.backLogoImageUrl = data;
                }

            }).catch(e => {
                // console.log('Logo error - ' + e.message);
                // this.logoUploading = false;
                // throw e;
            });
        
        
    }

    @Input('imageItem')
    set imageItem(value: any){
        this.imageItemObj = value;
        if(this.imageItemObj.media !== undefined) {
             this.imageItemObj['logoUploading']=false;
            this._changeSaver.getLogoUrldocumentmedia(this.imageItemObj).single().toPromise()
            .then((data) => {
                if(this.imageItemObj.documentGroup.role == "front") {
                    this.frontLogoImageUrl = data;
                } else {
                    this.backLogoImageUrl = data;
                }

            }).catch(e => {
                // console.log('Logo error - ' + e.message);
                // this.logoUploading = false;
                // throw e;
            });
        }

    }

    @Input('index')
    set index(value: any){
        this.indexre = value;
    }

    @Input('amrId')
    set amrId(value: any){
        this._amrId = value;
    }

    testfun() {
         this.chkResult.emit({
          value: "test123"
        })
        console.log("test");
        return false;
    }

    removeInsuranceImage() {

        this._model.confirm()
            .size('sm').isBlocking(true).showClose(false).keyboard(27)
            .body("Are you sure you want to remove this insurace card image?")
            .headerClass("hide")
            .okBtnClass("btn btn-danger")
            .okBtn("Remove")
            .cancelBtn("Cancel").cancelBtnClass("btn btn-primary")
            .open().then((dialog : any ) => {
                return dialog.result;
            }).then(result =>{
                if(result==true) {
                        this._changeSaver.removeInsuranceDocument(this.imageItemObj._id)
                            .single().toPromise().then(() =>
                        {
                            this.chkResult.emit({
                              value: "test123"
                            })
                        })
                        .catch(e =>
                        {
                            this.errorMessage = 'We encountered an unexpected error. Refresh the page and try again.';
                            throw e;
                        })

                }
            }).catch((e:any)=>{

            });
    }

}

/*
=================================================================
 */



@Component({
    selector: 'insurance-image-set',
    template:`
        <div *ngFor="let imageItemSub of imageItemMain; let j = index;" class="{{imageItemSub.pclass}} insurance-imgbox-mobile">
            <insurance-image-box
            [imageItem]="imageItemSub"
            [amrId]="_amrId"
            (chkResult)="companyCheckedResult($event.value)"
            [index]="j" style="display:block;"></insurance-image-box>
        </div>
    `
})
export class InsuranceImageSetComponent implements OnInit {

    @Output() changeData = new EventEmitter();
    imageItemMain:any = [];
    indexre:string;
    _amrId:any="";

    constructor(
        private _userProfiles: UserProfiles,
        private _route: ActivatedRoute,
        private _appCtx: MaxAppContext
    ){

    }

    companyCheckedResult(e){
        this.changeData.emit({
          value: "test123"
        })
         console.log(e);
         console.log('test');
         return false;
    }
    ngOnInit() {

    }

    @Input('imageItemMainArray')
    set imageItemMainArray(value: any){
        this.imageItemMain = value;
        console.log(this.imageItemMain);

    }

    @Input('index')
    set index(value: any){
        this.indexre = value;
    }

    @Input('amrId')
    set amrId(value: any){
        this._amrId = value;
    }

}

