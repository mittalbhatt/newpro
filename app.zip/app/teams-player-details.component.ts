import {Component, Input, Pipe, PipeTransform} from "@angular/core";
import {Router, ActivatedRoute, NavigationEnd} from "@angular/router";
import {Location} from '@angular/common';
import { UserProfiles, UserProfile, UserInjuryDetails } from "./user_profiles.service";
import {TeamInfo, TeamInfoEntry} from "./teamInfo.service";
import {SportCodes} from "./sportCodes";
import {MaxAppContext} from "./maxAppContext.service";
import {PendingProfilesView, PendingProfileModel} from "./pending_profile_approval.component";
import {Organization, Organizations} from "./organizations.service";
import {Overlay, Modal, overlayConfigFactory} from "angular2-modal";
import {Observable} from "rxjs/Rx";

@Pipe({name: 'keys'})
export class KeysPipe implements PipeTransform {
  transform(value, args:string[]) : any {
    if (!value) {
      return value;
    }

    let keys = [];
    for (let key in value) {
      keys.push({key: key, value: value[key]});
    }
    return keys;
  }
}

@Component({
    selector: 'teams-player-details',
    templateUrl: '/maxweb/app/app/teams-player-details.component.html'
})
export class TeamsPlayerDetailsComponent extends PendingProfilesView {

    private playerId: string;
    private _userProfile: UserProfile=null;
    private _userProfileModel: PendingProfileModel[];
    private _user_img:any;
    private isShowGif:boolean=false;
    private teamInfoValues:TeamInfoEntry[];
    private userTags:any=[];
    private sportName:string="";
    private injuryDetails:UserInjuryDetails[]=[];
    private isShowInjuryGif:boolean=true;
    public documentDataList:any=[];
    public isShowDocumentGif:boolean=true;
    public pendingApproval:boolean=true;
    public errorMessage:string;
    public isShowApproveRemove:boolean=false;
    public isCurrentPlayerTab:string="injuriestab";
    userdata:any=[];

    private groupedGroup:any=null;
    previousUrl:string;
    medicalDocumentActivityId:string;
    showMedicalDemoInfoButton: boolean = false;
    isShowDeleteButton:boolean = false;
    istrashshow:boolean=false;
    hasAccountText:string;
    hasAccount:boolean=false;
    parentHasAccount:boolean=false;
    phoneImage:any;

    constructor(
        public _profilesSvc:UserProfiles,
        public _orgsSvc:Organizations,
        public _modal:Modal,
        public _route: ActivatedRoute,
        public router: Router,
        public _location: Location,
        public _teamInfoSvc:TeamInfo,
        public _ctx:MaxAppContext,
        public _userProfilesSvc: UserProfiles,

    ){
        super(_profilesSvc,_orgsSvc,_modal,router,_route);

        this._profilesSvc.getProfileData.subscribe(res=> {
            if(res.action=="approve"){
                //console.log("EventEmitter Call: "+this.playerId);
                this.isShowApproveRemove = false;
                this.refreshProfile();
            }else if(res.action=="disapprove"){
                //console.log("EventEmitter Call: Remove");
                this.router.navigate(['/main/admin/access-requests']);
            }
            else if(res.action=="delete"){
                //console.log("EventEmitter Call: Delete "+sessionStorage['redirectUrl']);
                //this.router.navigate([sessionStorage['redirectUrl']]);
                window.history.back();

            }
        }, error => {
            console.log("Error");
            throw error;

        });
    }

    ngOnInit(){
        this.refreshProfile();
        if(sessionStorage['isCurrentPlayerTab']!="" && sessionStorage['isCurrentPlayerTab'] !== undefined){
            this.isCurrentPlayerTab = sessionStorage['isCurrentPlayerTab'];
        }
    }

    ngOnDestroy(){
        sessionStorage['isCurrentPlayerTab'] = "";
    }

    private refreshProfile(clearError:boolean = true){

        if (clearError)
            this.errorMessage = null;

        this._route.params.subscribe(params =>
        {

            this.playerId = params['id'];
            this.isShowGif =true;
            this.getHasAnAccountText(this.playerId);

            this._userProfilesSvc.getProfile(this.playerId).toPromise().then(data =>{
                this.userdata=data;
                //console.log(this.userdata);
                this.sportName ="";
                this._userProfile = new UserProfile(data);
                this._userProfile.specificAllergyShow = this._userProfile.getSpecificAllergyShow(this._userProfile);
                this._userProfile.displayAllergy = this._userProfile.getSpecificAllergy(this._userProfile);
                this._userProfile.existingMedicalConditionShow = this._userProfile.getExistingMedicalConditionShow(this._userProfile);
                this._userProfile.displayexistingMedicalCondition = this._userProfile.getExistingMedicalCondition(this._userProfile);
                this._userProfile.displayDOB = this._userProfile.getDOB(this._userProfile);
                this._userProfile.displayGradYear = this._userProfile.getGradYear(this._userProfile);

                let targetProfileOrg = this._ctx.availableOrganizations.find(o => o._id == this._userProfile.org);

                let medicalDocActivityId = (targetProfileOrg.defaultDocuments.find(d => d.form == 'medical' && d.context == 'userProfile') || { activityId: undefined }).activityId;
                this.medicalDocumentActivityId = medicalDocActivityId;
                if(_.has(this._userProfile,'orgRoles')){
                  if(this._userProfile.orgRoles.indexOf("ATH") > -1 || this._userProfile.orgRoles.indexOf("CCH") > -1){
                    this.showMedicalDemoInfoButton = true;
                }
                }
                
                let viewerProfile = this._ctx.myProfiles.find(p => p.org === this._userProfile.org || !!(p.linkedOrgRoles || []).find(lor => lor.orgId === this._userProfile.org));
                if(viewerProfile.orgRoles.indexOf("OADM") > -1 || viewerProfile.orgRoles.indexOf("UADM") > -1){
                    this.istrashshow = true;
                }

                this.userTags=[];
                this.getInjuryStatus();
                this.loadImage();
                if(this._userProfile.tags){
                    this.userTags = this._userProfile.tags;
                }

                this._teamInfoSvc.getAllTeamInfoEntries()
                .then(teamInfoValues =>
                {
                    this.teamInfoValues = teamInfoValues;
                    //this.isShowGif =false;
                    // console.log(this.teamInfoValues);
                    this.userTags.forEach(code =>
                    {
                        let sport = this.nameForSportCode(code);
                        if(this.sportName == ""){
                            this.sportName += sport;
                        }else{
                            this.sportName += ", " + sport;
                        }
                    });
                })
                .catch(e =>
                {
                    //this.errorMessage = 'We encountered an unexpected error.  Please try again.';
                    throw e;
                });

                //console.log("Profile User Roles:---------------------");
                //console.log(this._userProfile.orgRoles);
                //console.log(this._userProfile.state);

                // added for userprofileModel object pass in onAprove method
                var profiles = this._profilesSvc.getPendingProfiles();
                profiles.single().subscribe(p => {
                    this.isShowGif =false;
                    let profileModels = p.map(p => new PendingProfileModel(p));
                    this._userProfileModel = profileModels.filter(po => po.profile._id == this.playerId);
                    if(this._userProfileModel.length > 0){
                        if(this._userProfileModel[0].profile.state.pendingApproval===true && (this._ctx.currentProfile.orgRoles.indexOf("OADM") > -1 || this._ctx.currentProfile.orgRoles.indexOf("UADM") > -1)){
                            //console.log("test1");
                            this.isShowApproveRemove = true;
                        }
                    }
                }, error =>
                {
                    console.log('Something went wrong', error);
                    throw error;
                });

                if(this._userProfile.state!=undefined && this._userProfile.state.pendingApproval!=undefined && this._userProfile.state.pendingApproval===true && _.intersection(this._userProfile.orgRoles, ['CCH','TRN','OTRN','OADM','UADM']).length==0){
                    this.isShowDeleteButton = true;
                }
                //console.log('isShowApproveRemove=============isShowDeleteButton');
                //console.log(this.isShowApproveRemove+"============="+this.isShowDeleteButton);

            }).catch(e =>{
                console.log('Logo error', e);
                throw e;
           });
        });
    }

    getHasAnAccountText(playerId){
        this._profilesSvc.getAllProfilesToCheck()
            .then(profiles =>
            {    
                this.phoneImage = '/maxweb/app/media/icons8-SMS-50.png';
                let userAccount = profiles.filter(p => p._id == playerId).map( p => new UserProfile(p));
                if(_.has(userAccount[0],'$userAccount') || (this._userProfile.state!=undefined && this._userProfile.state.pendingApproval!=undefined && this._userProfile.state.pendingApproval==true)){
                    //console.log("Has an Account");
                    this.hasAccount = true;
                }
                let relatedProfiles = [];
                
                if(_.has(userAccount[0], 'relations')){
                    relatedProfiles = profiles.filter(p => userAccount[0].relations!=undefined && userAccount[0].relations.find(r => r.userProfileId == p._id ));
                }
                
                if(relatedProfiles!=undefined && relatedProfiles.length!=0){
                    //console.log("Parent has an Account");
                    this.parentHasAccount = true;
                }

                if(this.hasAccount==true && this.parentHasAccount==true){
                    this.hasAccountText = 'Athlete and parent both have accounts';
                } else if(this.hasAccount==true){
                    this.hasAccountText = 'Has an account';
                } else if(this.parentHasAccount==true){
                    this.hasAccountText = 'Parent has an account';
                }
                else{
                    this.hasAccountText = 'No Account';
                    this.phoneImage = '/maxweb/app/media/no-account-icons.png';
                }
                
            })
            .catch(e =>
            {
                console.log(e);
                this.errorMessage = 'We encountered an unexpected error. Refresh the page and try again.';
                throw e;
            });
    }

    getOrgStateCity(org:string=""){
        let stateCityStr="";
        if(org){
            let currentOrgDetails = this._ctx.availableOrganizations.find(o => {
                return o._id === org;
            });

            if(currentOrgDetails !== undefined){
                if(currentOrgDetails.city !== undefined && currentOrgDetails.city != ""  && currentOrgDetails.city != null){
                    stateCityStr = currentOrgDetails.city;
                }

                if(currentOrgDetails.stateCode !== undefined && currentOrgDetails.stateCode != ""  && currentOrgDetails.stateCode != null){
                    if(stateCityStr == ""){
                        stateCityStr = currentOrgDetails.stateCode;
                    }else{
                        stateCityStr += " - " + currentOrgDetails.stateCode;
                    }
                }
            }
        }
        return stateCityStr;
    }

    // nameForSportCode(code:string)
    // {
    //     if(this.teamInfoValues){
    //         code = code.replace(",","").replace(",","").replace(",","");
    //         let sport = this.teamInfoValues.find(tc => tc.value.code == code);
    //         return sport ? sport.value.name : 'UNKNOWN';
    //     }
    //     return "";

    // }

    nameForSportCode(code:string)
    {
        //console.log(code);
        code = code.replace(",","");
        var code_arr = code.split(":");
        code_arr = code_arr[0].split(",");
        // console.log(code_arr[0]);
        let sport = SportCodes.find(sc => sc.code == code_arr[0]);
        return sport ? sport.name : code_arr[0];
    }

    backClicked() {
        this._location.back();
    }

    loadImage()
    {
        return this._userProfilesSvc.getProfileImageUrl(this._userProfile).single().toPromise()
            .then(url => {
                this._user_img = url
            })
            .catch(e => {
                console.log('Logo error', e);
                throw e;
            });
    }

    getInjuryStatus(){
        this.injuryDetails =[];
        sessionStorage['isCurrentPlayerTab'] = 'injuriestab';
        this.isShowInjuryGif = true;
        var filterParameter = {user:this.playerId}
        this._userProfilesSvc.getUserInjuryStatus(0,100,filterParameter).toPromise().then(data =>{
            this.injuryDetails = data; //new UserInjuryDetails(data);
            this.isShowInjuryGif = false;
        }).catch((err)=>{
            this.isShowInjuryGif = false;
            throw err;
        })
    }
    selectdocumentdata(documentid){
        this.documentDataList =[];
        sessionStorage['isCurrentPlayerTab'] = 'documentstab';
        this.isShowDocumentGif = true;
        this._userProfilesSvc.getTeamUserDocument(documentid).single().toPromise()
            .then(data => {
            this.isShowDocumentGif = false;
                this.documentDataList = data;
            })
            .catch(e => {
             this.isShowDocumentGif = false;

                throw e;
            });

    }

    onClickMedicalDemoInfoDoc() {
        this._router.navigate(['/main/basicmedicalForm', this._userProfile._id, this.medicalDocumentActivityId], { relativeTo: this._route.parent });
    }
}