import {Observable} from "rxjs";

export class PagedDataUtil
{
    static getAllPages<T>(getPage:(skip:number, take:number)=>Observable<T[]>)
    {
        return this.getAllPagesInternal([], getPage);
    }

    private static getAllPagesInternal<T>(accumulation:T[], getPage:(skip:number, take:number)=>Observable<T[]>)
    {
        let pageSize = 1000;
        return getPage(accumulation.length, pageSize).single().toPromise()
            .then(results =>
            {
                var concat = accumulation.concat(results);
                if (results.length < pageSize)
                    return concat;

                return this.getAllPagesInternal(concat, getPage);
            });
    }
}