System.register(["@angular/core", "angular2-modal/plugins/bootstrap", "./user_profiles.service", "angular2-modal", "./teamInfo.service", "./sportCodes", "./DfObjectId"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __extends = (this && this.__extends) || function (d, b) {
        for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, bootstrap_1, user_profiles_service_1, angular2_modal_1, teamInfo_service_1, sportCodes_1, DfObjectId_1;
    var AccessRequestApprovalData, AccessRequestApprovalModal;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (bootstrap_1_1) {
                bootstrap_1 = bootstrap_1_1;
            },
            function (user_profiles_service_1_1) {
                user_profiles_service_1 = user_profiles_service_1_1;
            },
            function (angular2_modal_1_1) {
                angular2_modal_1 = angular2_modal_1_1;
            },
            function (teamInfo_service_1_1) {
                teamInfo_service_1 = teamInfo_service_1_1;
            },
            function (sportCodes_1_1) {
                sportCodes_1 = sportCodes_1_1;
            },
            function (DfObjectId_1_1) {
                DfObjectId_1 = DfObjectId_1_1;
            }],
        execute: function() {
            AccessRequestApprovalData = (function (_super) {
                __extends(AccessRequestApprovalData, _super);
                function AccessRequestApprovalData() {
                    _super.apply(this, arguments);
                }
                return AccessRequestApprovalData;
            }(bootstrap_1.BSModalContext));
            exports_1("AccessRequestApprovalData", AccessRequestApprovalData);
            AccessRequestApprovalModal = (function () {
                function AccessRequestApprovalModal(dialog, _profilesSvc, _teamInfoSvc) {
                    this.dialog = dialog;
                    this._profilesSvc = _profilesSvc;
                    this._teamInfoSvc = _teamInfoSvc;
                    this.selectedTeamInfoValues = [];
                }
                AccessRequestApprovalModal.prototype.ngOnInit = function () {
                    var _this = this;
                    this._teamInfoSvc.getAllTeamInfoEntries()
                        .then(function (teamInfoValues) {
                        _this.teamInfoValues = teamInfoValues.filter(function (tiv) { return tiv.orgId == _this.dialog.context.pendingProfile.org; });
                        // The following is supposed to add in the teams that teamInfo doesn't already exist for. However, most
                        // teamInfo codes end up with the format "X:..." in practice, so this mapping doesn't work.
                        // SportCodes.filter(sc => !teamInfoValues.find(tiv => tiv.value.code && tiv.value.code.split(':')[0] == sc.code))
                        //     .forEach(sc =>
                        //     {
                        //         teamInfoValues.push({orgId:this.dialog.context.pendingProfile.org, value:{name:sc.name, code:sc.code + ':' + (new DfObjectId()).toString()}});
                        //     });
                        //
                        // this.teamInfoValues = teamInfoValues;
                        //
                        // let mappedPending = (this.dialog.context.pendingProfile.pendingSports || []).map(ps =>
                        // {
                        //     var teamInfoMatch = teamInfoValues.find(ti => (ti.code || '').split(':')[0] == ps);
                        //     return {pendingCode:ps, teamInfoMatch: teamInfoMatch}
                        // });
                        //
                        // this.selectedTeamInfoValues = mappedPending.map(mp =>
                        //     mp.teamInfoMatch ? mp.teamInfoMatch : {orgId:this.dialog.context.pendingProfile.org, value:{name:this.nameForSportCode(mp.pendingCode), code:mp.pendingCode}});
                    })
                        .catch(function (e) {
                        _this.errorMessage = 'We encountered an unexpected error.  Please try again.';
                        throw e;
                    });
                };
                AccessRequestApprovalModal.prototype.nameForSportCode = function (code) {
                    var sport = sportCodes_1.SportCodes.find(function (sc) { return sc.code == code; });
                    return sport ? sport.name : 'UNKNOWN';
                };
                AccessRequestApprovalModal.prototype.onRemoveTeam = function (idx) {
                    this.selectedTeamInfoValues.splice(idx, 1);
                };
                AccessRequestApprovalModal.prototype.onSelectNewTeam = function (e) {
                    this.addTeamLevel = e.item.value.level;
                };
                AccessRequestApprovalModal.prototype.onAddTeam = function () {
                    var level = this.addTeamLevel;
                    var name = this.addTeamValue;
                    delete this.addTeamLevel;
                    delete this.addTeamValue;
                    var match = this.teamInfoValues.find(function (tiv) { return tiv.value.name.toLowerCase() == name.toLowerCase() && tiv.value.level == level; });
                    var code = '';
                    if (!match) {
                        var sportCode = sportCodes_1.SportCodes.find(function (sc) { return sc.name.toLowerCase() == name.toLowerCase(); });
                        code = (sportCode ? sportCode.code : 'X') + ':';
                    }
                    match = match || { _id: undefined, orgId: this.dialog.context.pendingProfile.org, value: { name: name, level: level, code: code + (new DfObjectId_1.DfObjectId()).toString() } };
                    this.selectedTeamInfoValues.push(match);
                };
                AccessRequestApprovalModal.prototype.onCancel = function () {
                    this.dialog.close(false);
                };
                AccessRequestApprovalModal.prototype.onApprove = function () {
                    var _this = this;
                    this.errorMessage = "";
                    if (this.selectedTeamInfoValues.length === 0 &&
                        this.dialog.context.pendingProfile.roleDisplayTitle !== undefined && this.dialog.context.pendingProfile.roleDisplayTitle.toLowerCase() == "athlete" &&
                        this.dialog.context.pendingProfile.roleDisplayTitle.toLowerCase() == "coach") {
                        if (this.dialog.context.pendingProfile.roleDisplayTitle) {
                            if (this.dialog.context.pendingProfile.roleDisplayTitle.toLowerCase() == "athlete")
                                this.errorMessage = 'Please put the athlete in at least one sport.';
                            if (this.dialog.context.pendingProfile.roleDisplayTitle.toLowerCase() == "coach")
                                this.errorMessage = 'Please put the coach in at least one sport.';
                        }
                        else {
                            this.errorMessage = 'Please put at least one sport.';
                        }
                        return false;
                    }
                    this.saving = true;
                    var infosToSave = this.selectedTeamInfoValues.filter(function (v) { return !v._id; });
                    var saves = infosToSave.map(function (v) {
                        v._id = (new DfObjectId_1.DfObjectId()).toString();
                        _this._teamInfoSvc.createTeamInfoEntry(v).single().toPromise();
                    });
                    Promise.all(saves)
                        .then(function () {
                        var pendingProfile = _this.dialog.context.pendingProfile;
                        pendingProfile.tags = [];
                        _this.selectedTeamInfoValues.forEach(function (v) { return pendingProfile.tags.push("," + v.value.code + ","); });
                        return _this.dialog.context.save();
                    })
                        .then(function () { return _this.dialog.close(true); })
                        .catch(function (e) {
                        infosToSave.forEach(function (v) {
                            delete v._id;
                        });
                        _this.saving = false;
                        _this.errorMessage = 'We encountered an unexpected error.';
                        throw e;
                    });
                };
                AccessRequestApprovalModal = __decorate([
                    core_1.Component({
                        selector: 'access-request-approval-modal-content',
                        template: "\n<div class=\"modal-content\" style=\"text-align:left;\">\n    <div class=\"modal-header\">\n        <button (click)=\"onCancel()\" type=\"button\" class=\"close\" aria-label=\"Close\" style=\"float:right\"><span aria-hidden=\"true\">&times;</span></button>\n     <h3 class=\"modal-title\" style=\"text-align:center\">{{dialog.context.pendingProfile.athleteTitleName}}</h3>\n    </div>\n\n    <div *ngIf=\"saving\" class=\"modal-body\">\n        <img src=\"/maxweb/app/media/ajax-loader.gif\" />\n        Saving...    \n    </div>\n    <div *ngIf=\"!saving\" class=\"modal-body container-fluid\">\n        <div class=\"row\">\n            <div class=\"col-sm-12\">\n                <div *ngIf=\"errorMessage\" class=\"alert alert-danger\">{{errorMessage}}</div> \n            </div>\n        </div>\n        <div class=\"row\">\n            <div class=\"col-sm-6\" style=\"border-right:1px solid gray\">\n                <!-- teamInfo list - not currently used.  It gets too long and it's better to let the user type. -->\n                <!--<div style=\"margin-bottom:25px;\">-->\n                    <!--<h4>Available Teams</h4>-->\n                    <!--<ul>-->\n                        <!--<li *ngFor=\"let teamInfo of teamInfoValues\">-->\n                            <!--{{teamInfo.value.name}}{{teamInfo.value.level ? ' (' + teamInfo.value.level + ')' : ''}}-->\n                            <!--<a href=\"javascript:void(0)\" tooltip=\"Add to approved teams\"><span style=\"color:green\" class=\"glyphicon glyphicon-circle-arrow-right\"></span></a>-->\n                        <!--</li>-->\n                    <!--</ul>-->\n                <!--</div>-->\n                \n                <h4>Add new team</h4>\n                <form (ngSubmit)=\"onAddTeam()\">\n                    <div class=\"form-group\">\n                      <template #typeaheadTemplate let-model=\"item\">\n                        <h5>{{model.value.name}} <em>{{model.value.level}}</em></h5>\n                      </template>\n                        <label for=\"name\">Name</label>\n                        <input name=\"name\" class=\"form-control\" [(ngModel)]=\"addTeamValue\"\n                            [typeahead]=\"teamInfoValues\"\n                            [typeaheadItemTemplate]=\"typeaheadTemplate\"\n                            [typeaheadOptionField]=\"'value.name'\"\n                            (typeaheadOnSelect)=\"onSelectNewTeam($event)\"\n                            autocomplete=\"off\"\n                            placeholder=\"Team Name\">\n                        <!--<input [(ngModel)]=\"addTeamName\" type=\"text\" class=\"form-control\" name=\"name\" id=\"name\" placeholder=\"Team Name\" />-->\n                    </div>\n                    <div class=\"form-group\">\n                        <label for=\"level\">Competition Level (optional)</label>\n                        <input [(ngModel)]=\"addTeamLevel\" type=\"text\" class=\"form-control\" name=\"level\" id=\"level\" placeholder=\"Level (Varsity, JV, etc.)\" />\n                    </div>\n                    <button [disabled]=\"!addTeamValue\" type=\"submit\" class=\"btn btn-default\">Add Team</button>\n                </form>\n            </div>\n            \n            <div class=\"col-sm-6\">\n                <div *ngIf=\"dialog.context.pendingProfile.pendingSports?.length\">\n                    <p style=\"font-weight:bold\">User selected these teams:</p>\n                    <ul>\n                        <li *ngFor=\"let sportCode of dialog.context.pendingProfile.pendingSports\">{{nameForSportCode(sportCode)}}</li>\n                    </ul>\n                </div>\n                <!--<div *ngIf=\"!dialog.context.pendingProfile.pendingSports?.length\">-->\n                    <!--<em>The user did not select any teams.</em>-->\n                <!--</div>-->\n                <div style=\"background: rgba(242, 242, 242, 0.75);  padding:5px; margin-top:20px; border-radius: 5px; -moz-border-radius: 5px; -webkit-border-radius: 5px;\">\n                    <p style=\"font-weight:bold\">Approved teams:</p>\n                    <ul>\n                        <li *ngFor=\"let teamInfo of selectedTeamInfoValues; let index = index;\">\n                            {{teamInfo.value.name}} <span *ngIf=\"teamInfo.value.level\">({{teamInfo.value.level}})</span>\n                            <a href=\"javascript:void(0)\" (click)=\"onRemoveTeam(index)\" tooltip=\"Remove\"><span style=\"color:red\" class=\"glyphicon glyphicon-remove-circle\"></span></a>\n                        </li>\n                    </ul>\n                    <div *ngIf=\"!selectedTeamInfoValues?.length\">\n                        <em>You have not selected any teams.</em>\n                    </div>\n                </div>\n            </div>\n        </div>\n    </div> <!-- modal-body -->\n    <div class=\"modal-footer\">\n        <button (click)=\"onApprove()\" type=\"button\" class=\"btn btn-primary\" style=\"float:right;\">Approve</button>\n        <button (click)=\"onCancel()\" type=\"button\" class=\"btn btn-danger\" style=\"float:right; margin-right:10px;\">Cancel</button>\n    </div>\n</div>\n"
                    }), 
                    __metadata('design:paramtypes', [angular2_modal_1.DialogRef, user_profiles_service_1.UserProfiles, teamInfo_service_1.TeamInfo])
                ], AccessRequestApprovalModal);
                return AccessRequestApprovalModal;
            }());
            exports_1("AccessRequestApprovalModal", AccessRequestApprovalModal);
        }
    }
});
//# sourceMappingURL=accessRequestApprovalModal.component.js.map