import {CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router, ActivatedRoute, NavigationEnd} from "@angular/router";
import {Observable} from "rxjs";
import {Injectable} from "@angular/core";
import {UserAccount, UserAccountService} from "./userAccount.service";
import {UserProfiles} from "./user_profiles.service";
import {Overlay, overlayConfigFactory} from 'angular2-modal';
import {Modal, BSModalContext} from 'angular2-modal/plugins/bootstrap';
import {AuthService} from "./auth.service";
import {TosCheckModal, TosModalContext} from "./toscheck-model.component";
import 'rxjs/add/operator/pairwise';

@Injectable()
export class Tosaccept implements CanActivate
{
    currentAccount:UserAccount;
    count:any;
    private isShow:boolean=true;
    constructor(
        private _router:Router,
        private routenew: ActivatedRoute,
        private _accounts:UserAccountService,
        private _modal:Modal,
        private _auth:AuthService
    ){
       this._router.events.subscribe((event) => {
            if(event instanceof NavigationEnd) {
                //console.log("NavigationEnd");
                this.isShow = true;
            }
        });
    }

    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot)
    {  
        //console.log("canActivate");
        return this.initialize();
    }

    initialize()
    {
       // console.log(localStorage["tosPopupData"]);
       // if(localStorage["tosPopupData"] === undefined){
            this._accounts.getMyUserAccount()
            .then(account =>
            {   
                //console.log(account);
                this.currentAccount=account;
                if(account['tos']){
                if(account['tos']['acceptances']!= undefined){
                let currentAccountArr = _.filter(account['tos']['acceptances'], (o:any)=>{
                     //account['$requiredTermsOfService']=4; 
                    if(o['version']==account['$requiredTermsOfService']){
                        return o;
                    } 
                });
               
                if(currentAccountArr.length<=0){
                    //console.log('openpopup');
                     //  localStorage["tosPopupData"] = JSON.stringify({isShow: true, version: account['$requiredTermsOfService']});
                    this.openTospopup(account['$requiredTermsOfService']);
                    
                    
                }else{
                   // localStorage["tosPopupData"] = JSON.stringify({isShow: false, version: account['$requiredTermsOfService']});
                }
            }
                }else{
                 this.openTospopup(account['$requiredTermsOfService']);   
                }
               
            });

        return true;
    }

    openTospopup(vesionnumber){
        console.log("isShow: ",this.isShow);
        
        if(this.isShow){
            this.isShow = false;
            this._accounts.getTosData(vesionnumber)
            .then(tosdata =>
            {
                if(tosdata != undefined && tosdata != ''){
                    var body = tosdata.content.html;
                }else{
                    var body = tosdata.content.plainText;
                }
                let customModalData = new TosModalContext({body:body,versionnumberget:vesionnumber});
            let config = overlayConfigFactory(customModalData, BSModalContext);
            this._modal.open(TosCheckModal, config).then(result =>{
            })
            .catch(e => console.log(e));
               
            }); 
        }
    }
}
