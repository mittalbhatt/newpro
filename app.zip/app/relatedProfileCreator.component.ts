import {Component} from "@angular/core";
import {ActivatedRoute} from "@angular/router";
import {SportCode} from "./sportCodes";
import {UserProfiles} from "./user_profiles.service";
import {DfObjectId} from "./DfObjectId";

@Component({
    selector:'related-profile-creator',
    template:
`
<div *ngIf="errorMessage" style="max-width:400px; margin:auto;" class="alert alert-danger">{{errorMessage}}</div>
<h3>Create a new athlete:</h3>
<div style="max-width:500px; margin:auto;">
    <form>
        <div class="form-group">
            <label for="username">First Name</label>
            <input [(ngModel)]="firstName" type="text" class="form-control" id="firstName" name="firstName" placeholder="First Name" required>
          </div>
          
          <div class="form-group">
            <label for="username">Last Name</label>
            <input [(ngModel)]="lastName" type="text" class="form-control" id="lastName" name="lastName" placeholder="Last Name" required>
          </div>
    </form>
    <label>Sports</label>
    <default-sport-chooser (sportsSelected)="onSelectedSportsChange($event)"></default-sport-chooser>
    <div style="height:100px;">
        <button style="float:right;" class="btn btn-default" [disabled]="saving" (click)="onSave()">Save</button>
        <button style="float:right; margin-right:10px;" class="btn btn-danger" [disabled]="saving" (click)="onCancel()">Cancel</button>
    </div>
</div>
`
})
export class RelatedProfileCreator
{
    errorMessage:string;
    saving:boolean;
    relationProfileId:string;

    firstName:string;
    lastName:string;
    selectedSports:SportCode[];

    constructor(
        route:ActivatedRoute,
        private _userProfiles:UserProfiles
        )
    {
        this.relationProfileId = route.snapshot.params['profileId'];
    }

    onSelectedSportsChange(value)
    {
        this.selectedSports = value;
    }

    onSave()
    {
        if (!this.firstName || !this.lastName)
        {
            this.errorMessage = 'All fields are required.';
            window.scrollTo(0,0);
            return;
        }

        this.saving = true;

        this._userProfiles.getProfile(this.relationProfileId).single().toPromise()
            .then(ctxProfile =>
            {
                let amrId = (new DfObjectId()).toString();
                let profile = {
                    _id:undefined,
                    amrId: amrId, 
                    tags:undefined,
                    email:undefined,
                    createdDate:(new Date()).toISOString(),
                    tel:undefined,
                    org:ctxProfile.org,
                    firstName:this.firstName,
                    lastName:this.lastName,
                    sortFirstName:(this.firstName || '').toLowerCase(),
                    sortLastName:(this.lastName || '').toLowerCase(),
                    state:{pendingApproval:true},
                    pendingSports:this.selectedSports ? this.selectedSports.map(s => s.code) : undefined,
                    orgRoles:['MGA','SUB', 'ATH'],
                    relations:[
                        {
                            firstName : ctxProfile.firstName,
                            lastName : ctxProfile.lastName,
                            userProfileId : ctxProfile._id,
                            roles:['PRN']
                        }
                    ],
                    $amr: {
                        _id: amrId,
                        info: {
                            firstName:this.firstName,
                            lastName:this.lastName
                        }
                    },
                    createdByRelatedProfileCreator:true
                };

                return this._userProfiles.createProfile(profile).single().toPromise();
            })
            .then(() =>
            {
                this.saving = false;
                window.history.back();
            })
            .catch(e =>
            {
                this.saving = false;
                this.errorMessage = 'An unexpected error has occurred.';
                throw e;
            });
    }

    onCancel()
    {
        window.history.back();
    }
}