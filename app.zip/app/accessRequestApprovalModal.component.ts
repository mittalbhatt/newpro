import {Component} from "@angular/core";
import {BSModalContext} from "angular2-modal/plugins/bootstrap";
import {UserProfile, UserProfiles} from "./user_profiles.service";
import {DialogRef, ModalComponent} from "angular2-modal";
import {TeamInfo, TeamInfoEntry} from "./teamInfo.service";
import {OnInit} from "@angular/core";
import {SportCodes} from "./sportCodes";
import {DfObjectId} from "./DfObjectId";

export class AccessRequestApprovalData extends BSModalContext
{
    pendingProfile:UserProfile;
    save:() => Promise<boolean>;
}

@Component({
    selector:'access-request-approval-modal-content',
    template:`
<div class="modal-content" style="text-align:left;">
    <div class="modal-header">
        <button (click)="onCancel()" type="button" class="close" aria-label="Close" style="float:right"><span aria-hidden="true">&times;</span></button>
     <h3 class="modal-title" style="text-align:center">{{dialog.context.pendingProfile.athleteTitleName}}</h3>
    </div>

    <div *ngIf="saving" class="modal-body">
        <img src="/maxweb/app/media/ajax-loader.gif" />
        Saving...    
    </div>
    <div *ngIf="!saving" class="modal-body container-fluid">
        <div class="row">
            <div class="col-sm-12">
                <div *ngIf="errorMessage" class="alert alert-danger">{{errorMessage}}</div> 
            </div>
        </div>
        <div class="row">
            <div class="col-sm-6" style="border-right:1px solid gray">
                <!-- teamInfo list - not currently used.  It gets too long and it's better to let the user type. -->
                <!--<div style="margin-bottom:25px;">-->
                    <!--<h4>Available Teams</h4>-->
                    <!--<ul>-->
                        <!--<li *ngFor="let teamInfo of teamInfoValues">-->
                            <!--{{teamInfo.value.name}}{{teamInfo.value.level ? ' (' + teamInfo.value.level + ')' : ''}}-->
                            <!--<a href="javascript:void(0)" tooltip="Add to approved teams"><span style="color:green" class="glyphicon glyphicon-circle-arrow-right"></span></a>-->
                        <!--</li>-->
                    <!--</ul>-->
                <!--</div>-->
                
                <h4>Add new team</h4>
                <form (ngSubmit)="onAddTeam()">
                    <div class="form-group">
                      <template #typeaheadTemplate let-model="item">
                        <h5>{{model.value.name}} <em>{{model.value.level}}</em></h5>
                      </template>
                        <label for="name">Name</label>
                        <input name="name" class="form-control" [(ngModel)]="addTeamValue"
                            [typeahead]="teamInfoValues"
                            [typeaheadItemTemplate]="typeaheadTemplate"
                            [typeaheadOptionField]="'value.name'"
                            (typeaheadOnSelect)="onSelectNewTeam($event)"
                            autocomplete="off"
                            placeholder="Team Name">
                        <!--<input [(ngModel)]="addTeamName" type="text" class="form-control" name="name" id="name" placeholder="Team Name" />-->
                    </div>
                    <div class="form-group">
                        <label for="level">Competition Level (optional)</label>
                        <input [(ngModel)]="addTeamLevel" type="text" class="form-control" name="level" id="level" placeholder="Level (Varsity, JV, etc.)" />
                    </div>
                    <button [disabled]="!addTeamValue" type="submit" class="btn btn-default">Add Team</button>
                </form>
            </div>
            
            <div class="col-sm-6">
                <div *ngIf="dialog.context.pendingProfile.pendingSports?.length">
                    <p style="font-weight:bold">User selected these teams:</p>
                    <ul>
                        <li *ngFor="let sportCode of dialog.context.pendingProfile.pendingSports">{{nameForSportCode(sportCode)}}</li>
                    </ul>
                </div>
                <!--<div *ngIf="!dialog.context.pendingProfile.pendingSports?.length">-->
                    <!--<em>The user did not select any teams.</em>-->
                <!--</div>-->
                <div style="background: rgba(242, 242, 242, 0.75);  padding:5px; margin-top:20px; border-radius: 5px; -moz-border-radius: 5px; -webkit-border-radius: 5px;">
                    <p style="font-weight:bold">Approved teams:</p>
                    <ul>
                        <li *ngFor="let teamInfo of selectedTeamInfoValues; let index = index;">
                            {{teamInfo.value.name}} <span *ngIf="teamInfo.value.level">({{teamInfo.value.level}})</span>
                            <a href="javascript:void(0)" (click)="onRemoveTeam(index)" tooltip="Remove"><span style="color:red" class="glyphicon glyphicon-remove-circle"></span></a>
                        </li>
                    </ul>
                    <div *ngIf="!selectedTeamInfoValues?.length">
                        <em>You have not selected any teams.</em>
                    </div>
                </div>
            </div>
        </div>
    </div> <!-- modal-body -->
    <div class="modal-footer">
        <button (click)="onApprove()" type="button" class="btn btn-primary" style="float:right;">Approve</button>
        <button (click)="onCancel()" type="button" class="btn btn-danger" style="float:right; margin-right:10px;">Cancel</button>
    </div>
</div>
`
})
export class AccessRequestApprovalModal implements OnInit, ModalComponent<AccessRequestApprovalData>
{
    errorMessage:string;
    saving:boolean;

    teamInfoValues:TeamInfoEntry[];

    selectedTeamInfoValues:TeamInfoEntry[]=[];

    addTeamValue:any;
    addTeamLevel:string;

    constructor(
        public dialog:DialogRef<AccessRequestApprovalData>,
        private _profilesSvc:UserProfiles,
        private _teamInfoSvc:TeamInfo)
    {
        
    }

    ngOnInit()
    {
        this._teamInfoSvc.getAllTeamInfoEntries()
            .then(teamInfoValues =>
            {
                this.teamInfoValues = teamInfoValues.filter(tiv => tiv.orgId == this.dialog.context.pendingProfile.org);

                // The following is supposed to add in the teams that teamInfo doesn't already exist for. However, most
                // teamInfo codes end up with the format "X:..." in practice, so this mapping doesn't work.
                // SportCodes.filter(sc => !teamInfoValues.find(tiv => tiv.value.code && tiv.value.code.split(':')[0] == sc.code))
                //     .forEach(sc =>
                //     {
                //         teamInfoValues.push({orgId:this.dialog.context.pendingProfile.org, value:{name:sc.name, code:sc.code + ':' + (new DfObjectId()).toString()}});
                //     });
                //
                // this.teamInfoValues = teamInfoValues;
                //
                // let mappedPending = (this.dialog.context.pendingProfile.pendingSports || []).map(ps =>
                // {
                //     var teamInfoMatch = teamInfoValues.find(ti => (ti.code || '').split(':')[0] == ps);
                //     return {pendingCode:ps, teamInfoMatch: teamInfoMatch}
                // });
                //
                // this.selectedTeamInfoValues = mappedPending.map(mp =>
                //     mp.teamInfoMatch ? mp.teamInfoMatch : {orgId:this.dialog.context.pendingProfile.org, value:{name:this.nameForSportCode(mp.pendingCode), code:mp.pendingCode}});
            })
            .catch(e =>
            {
                this.errorMessage = 'We encountered an unexpected error.  Please try again.';
                throw e;
            });
    }

    nameForSportCode(code:string)
    {
        let sport = SportCodes.find(sc => sc.code == code);
        return sport ? sport.name : 'UNKNOWN';
    }

    private onRemoveTeam(idx:number)
    {
        this.selectedTeamInfoValues.splice(idx, 1);
    }
    
    private onSelectNewTeam(e:{item:TeamInfoEntry})
    {
        this.addTeamLevel = e.item.value.level;
    }

    private onAddTeam()
    {
        let level = this.addTeamLevel;
        let name = this.addTeamValue;
        delete this.addTeamLevel;
        delete this.addTeamValue;

        let match = this.teamInfoValues.find(tiv => tiv.value.name.toLowerCase() == name.toLowerCase() && tiv.value.level == level);
        let code = '';
        if (!match)
        {
            let sportCode = SportCodes.find(sc => sc.name.toLowerCase() == name.toLowerCase());
            code = (sportCode ? sportCode.code : 'X') + ':';
        }

        match = match || {_id:undefined, orgId:this.dialog.context.pendingProfile.org, value:{name:name, level:level, code:code+(new DfObjectId()).toString()}};
        this.selectedTeamInfoValues.push(match);
    }

    private onCancel()
    {
        this.dialog.close(false);
    }

    private onApprove()
    {
        this.errorMessage = "";
        if(this.selectedTeamInfoValues.length === 0 && 
        this.dialog.context.pendingProfile.roleDisplayTitle !== undefined && this.dialog.context.pendingProfile.roleDisplayTitle.toLowerCase() == "athlete" && 
        this.dialog.context.pendingProfile.roleDisplayTitle.toLowerCase() == "coach"
        ){
            if(this.dialog.context.pendingProfile.roleDisplayTitle){
                if(this.dialog.context.pendingProfile.roleDisplayTitle.toLowerCase() == "athlete")
                    this.errorMessage = 'Please put the athlete in at least one sport.';

                if(this.dialog.context.pendingProfile.roleDisplayTitle.toLowerCase() == "coach")
                    this.errorMessage = 'Please put the coach in at least one sport.';
            }else{
                this.errorMessage = 'Please put at least one sport.';
            }
            return false;
        }
        
        this.saving = true;
        let infosToSave = this.selectedTeamInfoValues.filter(v => !v._id);
        let saves = infosToSave.map(v =>
        {
            v._id = (new DfObjectId()).toString();
            this._teamInfoSvc.createTeamInfoEntry(v).single().toPromise()
        });
        Promise.all(saves)
            .then(() =>
            {
                let pendingProfile = this.dialog.context.pendingProfile;
                pendingProfile.tags = [];
                this.selectedTeamInfoValues.forEach(v => pendingProfile.tags.push(`,${v.value.code},`));
                return this.dialog.context.save();
            })
            .then(() => this.dialog.close(true))
            .catch(e =>
            {
                infosToSave.forEach(function(v)
                {
                    delete v._id;
                });
                
                this.saving = false;
                this.errorMessage = 'We encountered an unexpected error.';
                throw e;
            })
    }
}