System.register(["@angular/router", "@angular/core", "./maxAppContext.service", "./user_profiles.service"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var router_1, core_1, maxAppContext_service_1, user_profiles_service_1;
    var FormsProfileChooserRouter;
    return {
        setters:[
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (maxAppContext_service_1_1) {
                maxAppContext_service_1 = maxAppContext_service_1_1;
            },
            function (user_profiles_service_1_1) {
                user_profiles_service_1 = user_profiles_service_1_1;
            }],
        execute: function() {
            FormsProfileChooserRouter = (function () {
                function FormsProfileChooserRouter(_router, _ctx, _profilesSvc) {
                    this._router = _router;
                    this._ctx = _ctx;
                    this._profilesSvc = _profilesSvc;
                }
                FormsProfileChooserRouter.prototype.canActivate = function (route, state) {
                    var _this = this;
                    if (route.params['profileId'])
                        return true;
                    var orgId = this._ctx.orgId;
                    if (!orgId)
                        throw new Error('The context org ID must be set before FormsProfileChooserRouter is activated.');
                    return this._profilesSvc.getMine().single().toPromise()
                        .then(function (myProfiles) {
                        var profile = myProfiles.find(function (p) { return p.org == orgId; });
                        if (!profile) {
                            console.log('Profile not found for org.  Profile for context org must be created before reaching FormsProfileChooserRouter.');
                            // NOTE: if you find the need to navigate here, make sure the MaxAppContext has not
                            // already forwarded to OwnProfileCreator.  If you forward arbitrarily here,
                            // you will obliterate the contextual forwarding URL that is used after profile creation.
                            // Ideally this would not even be invoked if the MaxAppContext.initialize guard returns false, but
                            // angular allows guards down the change to proceed if an earlier guard returns a promise.
                            return false;
                        }
                        if (profile.orgRoles.indexOf('PRN') < 0)
                            _this._router.navigate(['/max-forms/packetList', { profileId: profile._id }]);
                        else
                            _this._router.navigate(['/max-forms/chooseFormsProfile', profile._id]);
                        return false;
                    });
                };
                FormsProfileChooserRouter = __decorate([
                    core_1.Injectable(), 
                    __metadata('design:paramtypes', [router_1.Router, maxAppContext_service_1.MaxAppContext, user_profiles_service_1.UserProfiles])
                ], FormsProfileChooserRouter);
                return FormsProfileChooserRouter;
            }());
            exports_1("FormsProfileChooserRouter", FormsProfileChooserRouter);
        }
    }
});
//# sourceMappingURL=formsProfileChooserRouter.service.js.map