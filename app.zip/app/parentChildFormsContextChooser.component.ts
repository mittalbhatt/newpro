import {Component, ViewChild} from "@angular/core";
import {ActivatedRoute, Router} from "@angular/router";
import {UserProfile, UserProfiles} from "./user_profiles.service";
import {MaxAppContext} from "./maxAppContext.service";
import {ProfileUtil} from "./confirmProfileDelete";
import {RelatedProfilesList} from "./relatedProfilesList.component";

@Component({
    selector:'parent-child-forms-context-chooser',
    template:`
<div style="min-height:300px; max-width:500px; padding:20px; margin: 30px auto auto;">
    <h3>Who are you filling out forms for?</h3>
    <div *ngIf="errorMessage" class="alert alert-danger">{{errorMessage}}</div>
    <img *ngIf="loading" src="/maxweb/app/media/ajax-loader.gif" />
    <related-profiles-list [style.display]="loading ? 'none' : 'block'" [profileId]="profileId" [relationRoles]="['PRN']" (itemDeleteClicked)="deleteProfile($event)" (itemEditClicked)="editProfile($event)" (itemClicked)="startForms($event)"></related-profiles-list>
    <div class="list-group">
        <button type="button" class="list-group-item" (click)="onAddNew()">Add new athlete in {{ctx.currentOrg?.name || '...loading school name...'}} <span style="float:right; color:green;" class="glyphicon glyphicon-plus"></span></button>    
    </div>
    <p style="font-style: italic;">Have children in other schools? Log in via that school's forms link.</p>
</div>
`
})
export class ParentChildFormsContextChooser
{
    profileId:string;
    loading:boolean;
    errorMessage:string;
    @ViewChild(RelatedProfilesList) relatedProfilesList:RelatedProfilesList;

    constructor(
        private _route:ActivatedRoute,
        private _router:Router,
        private _profileSvc:UserProfiles,
        private _profileUtil:ProfileUtil,
        public ctx:MaxAppContext)
    {
        this.profileId = this._route.snapshot.params['profileId'];
    }

    onAddNew()
    {
        this._router.navigate(['chooseFormsProfile', this.profileId, 'create'], {relativeTo:this._route.parent});
    }

    editProfile(profile:UserProfile)
    {
        this._router.navigate(['editFormsProfile', profile._id], {relativeTo:this._route.parent});
    }

    deleteProfile(profile:UserProfile)
    {
        this._profileUtil.confirmProfileDelete(profile, () =>
        {
            this.loading = true;
            this._profileSvc.deleteProfile(profile)
                .single().toPromise().then(() =>
            {
                this.relatedProfilesList.clear(profile);
                this.loading = false;
            })
            .catch(e =>
            {
                this.loading = false;
                this.errorMessage = 'We encountered an unexpected error. Refresh the page and try again.';
                throw e;
            })
        });
    }

    startForms(profile:UserProfile)
    {
        this._router.navigate(['packetList', {profileId:profile._id}], {relativeTo:this._route.parent});
    }
}