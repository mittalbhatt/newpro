System.register(['@angular/router', "./login.routing", "./max-forms-shell.component", "./max-forms.routing", "./cover.component", "./maxAppContext.service", "./auth-guard.service", "./landing.component", "./userProfile.component", "./contextProfileRouteGuard.service", "./pending_profile_approval.component", "./getTheApp.component", "./formsOrgChooser.component", "./teams.component", "./teams-players.component", "./teams.resolve", "./teams-player-details.component", "./athlete_doc_form.component", "./basic_medical_form.component", "./save-form-guard", "./tosaccept.service", "./select-form.component", './reset-scroll-history', "./basic_medical_saver.service"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var router_1, login_routing_1, max_forms_shell_component_1, max_forms_routing_1, cover_component_1, maxAppContext_service_1, auth_guard_service_1, landing_component_1, userProfile_component_1, contextProfileRouteGuard_service_1, pending_profile_approval_component_1, getTheApp_component_1, formsOrgChooser_component_1, teams_component_1, teams_players_component_1, teams_resolve_1, teams_player_details_component_1, athlete_doc_form_component_1, basic_medical_form_component_1, save_form_guard_1, tosaccept_service_1, select_form_component_1, reset_scroll_history_1, basic_medical_saver_service_1;
    var appRoutes, routingProviders, routing;
    return {
        setters:[
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (login_routing_1_1) {
                login_routing_1 = login_routing_1_1;
            },
            function (max_forms_shell_component_1_1) {
                max_forms_shell_component_1 = max_forms_shell_component_1_1;
            },
            function (max_forms_routing_1_1) {
                max_forms_routing_1 = max_forms_routing_1_1;
            },
            function (cover_component_1_1) {
                cover_component_1 = cover_component_1_1;
            },
            function (maxAppContext_service_1_1) {
                maxAppContext_service_1 = maxAppContext_service_1_1;
            },
            function (auth_guard_service_1_1) {
                auth_guard_service_1 = auth_guard_service_1_1;
            },
            function (landing_component_1_1) {
                landing_component_1 = landing_component_1_1;
            },
            function (userProfile_component_1_1) {
                userProfile_component_1 = userProfile_component_1_1;
            },
            function (contextProfileRouteGuard_service_1_1) {
                contextProfileRouteGuard_service_1 = contextProfileRouteGuard_service_1_1;
            },
            function (pending_profile_approval_component_1_1) {
                pending_profile_approval_component_1 = pending_profile_approval_component_1_1;
            },
            function (getTheApp_component_1_1) {
                getTheApp_component_1 = getTheApp_component_1_1;
            },
            function (formsOrgChooser_component_1_1) {
                formsOrgChooser_component_1 = formsOrgChooser_component_1_1;
            },
            function (teams_component_1_1) {
                teams_component_1 = teams_component_1_1;
            },
            function (teams_players_component_1_1) {
                teams_players_component_1 = teams_players_component_1_1;
            },
            function (teams_resolve_1_1) {
                teams_resolve_1 = teams_resolve_1_1;
            },
            function (teams_player_details_component_1_1) {
                teams_player_details_component_1 = teams_player_details_component_1_1;
            },
            function (athlete_doc_form_component_1_1) {
                athlete_doc_form_component_1 = athlete_doc_form_component_1_1;
            },
            function (basic_medical_form_component_1_1) {
                basic_medical_form_component_1 = basic_medical_form_component_1_1;
            },
            function (save_form_guard_1_1) {
                save_form_guard_1 = save_form_guard_1_1;
            },
            function (tosaccept_service_1_1) {
                tosaccept_service_1 = tosaccept_service_1_1;
            },
            function (select_form_component_1_1) {
                select_form_component_1 = select_form_component_1_1;
            },
            function (reset_scroll_history_1_1) {
                reset_scroll_history_1 = reset_scroll_history_1_1;
            },
            function (basic_medical_saver_service_1_1) {
                basic_medical_saver_service_1 = basic_medical_saver_service_1_1;
            }],
        execute: function() {
            appRoutes = [
                {
                    path: '',
                    pathMatch: 'full',
                    redirectTo: 'main'
                },
                {
                    path: 'max-forms',
                    component: max_forms_shell_component_1.MaxFormsShell,
                    children: max_forms_routing_1.formsRoutes.slice(),
                    canActivate: [auth_guard_service_1.AuthGuard, maxAppContext_service_1.MaxAppContext, tosaccept_service_1.Tosaccept]
                },
                {
                    path: 'max-forms',
                    children: [
                        {
                            path: 'form/:profileId/:packetActivityId/:assignmentId/:docDescriptionActivityId',
                            component: athlete_doc_form_component_1.AthleteDocumentationForm,
                            canActivate: [auth_guard_service_1.AuthGuard, maxAppContext_service_1.MaxAppContext, tosaccept_service_1.Tosaccept]
                        },
                        {
                            path: 'singleForm/:profileId/:docDescriptionActivityId',
                            component: athlete_doc_form_component_1.AthleteDocumentationForm,
                            canActivate: [auth_guard_service_1.AuthGuard, maxAppContext_service_1.MaxAppContext, tosaccept_service_1.Tosaccept]
                        },
                        {
                            path: 'create-form/:currentorgId',
                            component: select_form_component_1.SelectFormComponent,
                            data: { type: "create-form" },
                            canActivate: [auth_guard_service_1.AuthGuard, maxAppContext_service_1.MaxAppContext, tosaccept_service_1.Tosaccept]
                        },
                        {
                            path: 'edit-form/:currentorgId/:formId',
                            component: select_form_component_1.SelectFormComponent,
                            data: { type: "edit-form" },
                            canActivate: [auth_guard_service_1.AuthGuard, maxAppContext_service_1.MaxAppContext, tosaccept_service_1.Tosaccept]
                        }
                    ]
                },
                {
                    path: 'main',
                    component: max_forms_shell_component_1.MaxFormsShell,
                    children: [
                        {
                            path: '',
                            pathMatch: 'full',
                            component: userProfile_component_1.UserProfileComponent,
                            canActivate: [contextProfileRouteGuard_service_1.ContextProfileRouteGuard]
                        },
                        {
                            path: 'profile/:userProfileId',
                            component: userProfile_component_1.UserProfileComponent,
                            canActivate: [tosaccept_service_1.Tosaccept]
                        },
                        {
                            path: 'admin/access-requests',
                            component: pending_profile_approval_component_1.PendingProfilesView,
                            canActivate: [tosaccept_service_1.Tosaccept]
                        },
                        {
                            path: 'teams',
                            component: teams_component_1.TeamsComponent,
                            // canActivate:[Tosaccept, ResetScrollHistory],
                            resolve: {
                                _orgStructureData: teams_resolve_1.OrganizationStructureResolve
                            },
                            children: [
                                {
                                    path: '',
                                    component: teams_players_component_1.TeamsPlayersComponent,
                                    canActivate: [tosaccept_service_1.Tosaccept, reset_scroll_history_1.ResetScrollHistory]
                                },
                                {
                                    path: ':orgId',
                                    component: teams_players_component_1.TeamsPlayersComponent,
                                    canDeactivate: [save_form_guard_1.SaveFormGuard],
                                    canActivate: [tosaccept_service_1.Tosaccept, reset_scroll_history_1.ResetScrollHistory]
                                },
                                {
                                    path: ':orgId/:teamId',
                                    component: teams_players_component_1.TeamsPlayersComponent,
                                    canDeactivate: [save_form_guard_1.SaveFormGuard],
                                    canActivate: [tosaccept_service_1.Tosaccept, reset_scroll_history_1.ResetScrollHistory]
                                }
                            ]
                        },
                        {
                            path: 'player/:id',
                            component: teams_player_details_component_1.TeamsPlayerDetailsComponent,
                            canActivate: [tosaccept_service_1.Tosaccept],
                        },
                        {
                            path: 'basicmedicalForm/:profileId/:docDescriptionActivityId',
                            component: basic_medical_form_component_1.BasicMedicalForm,
                            canDeactivate: [basic_medical_saver_service_1.BasicMedicalSaver],
                            canActivate: [auth_guard_service_1.AuthGuard, maxAppContext_service_1.MaxAppContext, tosaccept_service_1.Tosaccept]
                        }
                    ],
                    canActivate: [auth_guard_service_1.AuthGuard, maxAppContext_service_1.MaxAppContext]
                },
                {
                    path: 'max-cover',
                    component: cover_component_1.CoverShell,
                    children: [
                        {
                            path: 'landing',
                            component: landing_component_1.LandingComponent
                        },
                        {
                            path: 'landing/:id',
                            component: landing_component_1.LandingComponent
                        },
                        {
                            path: 'get-the-app',
                            component: getTheApp_component_1.GetTheAppComponent
                        },
                        {
                            path: 'choose-org',
                            component: formsOrgChooser_component_1.FormsOrgChooserComponent
                        }
                    ].concat(login_routing_1.loginRoutes)
                }
            ].concat(login_routing_1.loginRoutes);
            exports_1("routingProviders", routingProviders = login_routing_1.authProviders.concat(max_forms_routing_1.formsProviders, [
                contextProfileRouteGuard_service_1.ContextProfileRouteGuard
            ]));
            exports_1("routing", routing = router_1.RouterModule.forRoot(appRoutes));
        }
    }
});
//# sourceMappingURL=app.routing.js.map