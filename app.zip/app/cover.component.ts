import {Component, OnInit, OnDestroy} from "@angular/core";
import {Router} from "@angular/router";
import {Subscription} from "rxjs";

@Component({
    selector:'max-cover',
    template:`
<header class="header">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-12">
                <div class="header-logo hidden-xs">
                    <div class="navbar-header">
                        <a class="navbar-brand" href="http://www.dragonflymax.com/"><img style="height:auto; max-width:100%" class="logo" alt="Dragonfly Max" src=" app/media/headerLogo.png "></a>
                    </div>
                </div>
            </div>
            <div class="col-md-10 col-sm-9">
                <div class="nav-wrap">
                    <div class="nav-container">
                        <a class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar" (click)="menuIsOpen = !menuIsOpen">
                            <span></span>
                            <span></span>
                            <span></span>
                        </a>
                        <nav class="navbar">
                            <div id="navbar" class="navbar-collapse" [ngClass]="{collapse:!menuIsOpen, open:menuIsOpen}" aria-expanded="false" >
                                <ul id="mainMenu" class="nav navbar-nav"><li id="menu-item-84" class="menu-item menu-item-type-post_type menu-item-object-page current-menu-item page_item page-item-2 current_page_item menu-item-84"><a href="http://www.dragonflymax.com/">Home</a></li>
<li id="mainDropdown" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-88 dropdown"><a href="http://www.dragonflymax.com/features/">Features</a></li>
<li id="menu-item-87" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-87"><a href="http://www.dragonflymax.com/download/">Download</a></li>
<li id="menu-item-85" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-85"><a href="http://www.dragonflymax.com/about-us/">About Us</a></li>
<li id="menu-item-241" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-241"><a href="http://www.dragonflymax.com/contact/">Contact</a></li>
<li id="menu-item-480" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-480"><a href="/maxweb/max-cover/choose-org">Do My Forms</a></li>
</ul>                            </div><!--/.nav-collapse -->
                        </nav>                                
                    </div>
                </div>                
            </div>
            <div class="col-md-2 col-sm-3">
                <div class="socials">                    
                    <a href="https://www.facebook.com/DragonFlyMAX" class="social-links style-1 fa fa-facebook"></a>
<a href="https://twitter.com/dragonfly_max" class="social-links style-1 fa fa-twitter"></a>
<a href="https://www.youtube.com/embed/0ll35AEHpqk" target="_blank" class="social-links style-1 fa fa-youtube"></a>               </div>
            </div>
        </div>
    </div>
</header>
    <div id="cover-root">
        <router-outlet></router-outlet>
        <div class="container-fluid" style="max-width:400px; margin-top:10px;">
            <!--<div class="row">-->
                <!--<div class="col-md-12">Get the app:</div>-->
            <!--</div>-->
            <div class="row">
                <div class="col-xs-6">
                    <a target="_blank" href="https://itunes.apple.com/us/app/dragonfly-max/id894686415">
                        <img style="width:90%; height:100%; margin:6%" src="app/media/Download_on_the_App_Store_Badge_US-UK_135x40.svg"/>
                    </a>
                </div>
                <div class="col-xs-6">
                    <a target="_blank" href='https://play.google.com/store/apps/details?id=com.dragonfly.max.live&hl=en&utm_source=global_co&utm_medium=prtnr&utm_content=Mar2515&utm_campaign=PartBadge&pcampaignid=MKT-Other-global-all-co-prtnr-py-PartBadge-Mar2515-1'>
                        <img style="width:100%; height:100%" alt='Get it on Google Play' src='https://play.google.com/intl/en_us/badges/images/generic/en_badge_web_generic.png'/>
                    </a>
                </div>
            </div>
        </div>
    </div>
`
})
export class CoverShell implements OnDestroy, OnInit {
    menuIsOpen:boolean;
    subscription:Subscription;

    constructor(private _router:Router)
    {

    }

    ngOnInit()
    {
        this.subscription = this._router.events.subscribe(() => window.scrollTo(0,0));
    }

    ngOnDestroy()
    {
        this.subscription.unsubscribe();
    }
}