System.register(['@angular/core', 'angular2-modal', 'angular2-modal/plugins/bootstrap'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __extends = (this && this.__extends) || function (d, b) {
        for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, angular2_modal_1, bootstrap_1;
    var PRINT_LIMIT, PrintableFormViewModel, AdminFormPrintModalData, AdminFormPrintModal;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (angular2_modal_1_1) {
                angular2_modal_1 = angular2_modal_1_1;
            },
            function (bootstrap_1_1) {
                bootstrap_1 = bootstrap_1_1;
            }],
        execute: function() {
            PRINT_LIMIT = 50;
            PrintableFormViewModel = (function () {
                function PrintableFormViewModel(doc) {
                    this.doc = doc;
                }
                return PrintableFormViewModel;
            }());
            AdminFormPrintModalData = (function (_super) {
                __extends(AdminFormPrintModalData, _super);
                function AdminFormPrintModalData(docs, selectedItems, allItems) {
                    if (docs === void 0) { docs = null; }
                    if (selectedItems === void 0) { selectedItems = null; }
                    if (allItems === void 0) { allItems = null; }
                    _super.call(this);
                    this.selectedItems = selectedItems;
                    this.allItems = allItems;
                    this.selectedItems = this.selectedItems || [];
                    this.forms = (docs || []).map(function (d) { return new PrintableFormViewModel(d); });
                }
                AdminFormPrintModalData.prototype.selectedForms = function () {
                    return this.forms.filter(function (f) { return f.selected; }).map(function (f) { return f.doc; });
                };
                return AdminFormPrintModalData;
            }(bootstrap_1.BSModalContext));
            exports_1("AdminFormPrintModalData", AdminFormPrintModalData);
            AdminFormPrintModal = (function () {
                function AdminFormPrintModal(dialog) {
                    this.dialog = dialog;
                    this.limit = PRINT_LIMIT;
                    this.context = dialog.context;
                    this.printOption = 'selected';
                    console.log(this.context);
                    if (this.context.selectedItems.length > PRINT_LIMIT) {
                        this.printSelectedDisabled = true;
                        this.printOption = 'range';
                        this.selectedItemsMessage = "Select fewer than " + PRINT_LIMIT + " rows to use this option.";
                    }
                    else if (this.context.selectedItems.length < 1) {
                        this.printSelectedDisabled = true;
                        this.printOption = 'range';
                        this.selectedItemsMessage = 'Use the checkboxes on rows to select items.';
                    }
                    this.rangeStart = 1;
                    this.rangeEnd = this.rangeEndMax();
                    this.allSelected = true;
                }
                AdminFormPrintModal.prototype.rangeEndMax = function () {
                    return Math.min(this.rangeStart + this.limit - 1, this.context.allItems.length);
                };
                AdminFormPrintModal.prototype.fixRange = function () {
                    var _this = this;
                    setTimeout(function () {
                        if (_this.rangeStart < 1)
                            _this.rangeStart = 1;
                        if (_this.rangeStart > _this.context.allItems.length)
                            _this.rangeStart = _this.context.allItems.length;
                        if (_this.rangeEnd < _this.rangeStart)
                            _this.rangeEnd = _this.rangeStart;
                        if (_this.rangeEnd > _this.rangeEndMax())
                            _this.rangeEnd = _this.rangeEndMax();
                    }, 1);
                };
                AdminFormPrintModal.prototype.onClose = function () {
                    this.dialog.close();
                };
                AdminFormPrintModal.prototype.onPrint = function () {
                    var _this = this;
                    var selectedPrintFormIds = _.sortBy(this.context.selectedForms(), function (f) { return _this.context.forms.map(function (ff) { return ff.doc; }).indexOf(f); })
                        .map(function (d) { return d.activityId; });
                    var items;
                    if (this.printOption == 'range')
                        items = this.context.allItems.slice(this.rangeStart - 1, this.rangeEnd);
                    else
                        items = this.context.selectedItems;
                    var ids = _.chain(items)
                        .sortBy(function (i) { return _this.context.allItems.indexOf(i); })
                        .map(function (i) { return i.statuses.filter(function (s) { return selectedPrintFormIds.indexOf(s.documentDescriptionActivityId) > -1; }); })
                        .flatten()
                        .map(function (s) { return s.documentInstanceStableId; })
                        .value();
                    this.dialog.close(ids);
                };
                Object.defineProperty(AdminFormPrintModal.prototype, "allSelected", {
                    get: function () {
                        return this._allSelected;
                    },
                    set: function (value) {
                        this._allSelected = value;
                        this.context.forms.forEach(function (d) { return d.selected = value; });
                    },
                    enumerable: true,
                    configurable: true
                });
                AdminFormPrintModal = __decorate([
                    core_1.Component({
                        selector: 'admin-form-print-modal-content',
                        template: "\n                <div class=\"modal-content\">\n                  <div class=\"modal-header\">\n                    <button type=\"button\" class=\"close\" (click)=\"onClose()\">&times;</button>\n                    <h4 class=\"modal-title\">Print</h4>\n                  </div>\n                  <div class=\"modal-body\" style=\"text-align:left\">\n                     <h3>Which Forms?</h3>\n                     <table>\n                        <tr><td><input type=\"checkbox\" [(ngModel)]=\"allSelected\" /></td><td><a href=\"javascript:void(0)\" (click)=\"allSelected = !allSelected\">Toggle All</a></td></tr>\n                        <tr style=\"cursor:pointer\" *ngFor=\"let doc of context.forms\">\n                            <td valign=\"top\">\n                                <input type=\"checkbox\" [(ngModel)]=\"doc.selected\" />\n                            </td>\n                            <td (click)=\"doc.selected = !doc.selected\" style=\"padding-bottom:6px;\">\n                                {{doc.doc.name}}\n                            </td>\n                        </tr>\n                     </table>\n                     <h3>Which Athletes?</h3>\n                    <div class=\"radio\">\n                      <label>\n                        <input type=\"radio\" name=\"optionsRadios\" value=\"selected\" [disabled]=\"printSelectedDisabled\" (click)=\"printOption = 'selected'\" [checked]=\"printOption == 'selected'\">\n                        <span [style.color]=\"selectedItemsMessage ? 'gray' : 'inherit'\">Selected athletes <em>{{selectedItemsMessage}}</em></span>\n                      </label>\n                    </div>\n                    <div class=\"radio\">\n                      <label>\n                        <input type=\"radio\" name=\"optionsRadios\" value=\"range\" (click)=\"printOption = 'range'\" [checked]=\"printOption == 'range'\">\n                        Specified range\n                      </label>\n                    </div>\n                    \n                    <div *ngIf=\"printOption == 'range'\">\n                        Select range (limit {{limit}}):\n                        <input type=\"number\" min=\"1\" [max]=\"context.allItems.length\" [(ngModel)]=\"rangeStart\" (blur)=\"fixRange()\" style=\"width:50px;\" />\n                        to\n                        <input type=\"number\" [min]=\"rangeStart\" [max]=\"rangeEndMax()\" [(ngModel)]=\"rangeEnd\" (blur)=\"fixRange()\" style=\"width:50px;\" />\n                    </div>\n                  </div>\n                  <div class=\"modal-footer\">\n                    <button type=\"button\" class=\"btn btn-danger\" (click)=\"onClose()\">Cancel</button>\n                    <button type=\"button\" class=\"btn btn-default\" (click)=\"onPrint()\">Print</button>\n                  </div>\n                </div>"
                    }), 
                    __metadata('design:paramtypes', [angular2_modal_1.DialogRef])
                ], AdminFormPrintModal);
                return AdminFormPrintModal;
            }());
            exports_1("AdminFormPrintModal", AdminFormPrintModal);
        }
    }
});
//# sourceMappingURL=admin_form_print_modal.js.map