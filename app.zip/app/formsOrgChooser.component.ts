import {Component} from "@angular/core";
import {Router} from "@angular/router";
import {Organization} from "./organizations.service";

@Component({
    selector:'forms-org-chooser',
    template:`
<div id="choose-org-form">
    <img src="/maxweb/app/media/dragonFlyMaxWordmark.png" style="width:85%; max-width:400px" />
    <h2 style="color:red; margin-bottom:20px;">Athletic Medical Forms</h2>
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-6 hidden-xs" style="text-align:left; padding-right:30px;padding-bottom:25px; border-right:1px solid black">
                <div>
                    <h3 style="color:red">Easily Manage Your Team Medical Forms</h3>
                    <p><strong>Lost Paperwork is a Thing of the Past!</strong></p>
                    <p>
                        Enter your school code from your coach or administrator to get started.
                    </p>
                </div>
            </div>
            <div class="col-sm-6 col-xs-12" style="padding-top:35px;">
                <org-context-chooser (orgChosen)="onOrgChosen($event)"></org-context-chooser>
            </div>
        </div>
    </div>
</div>
`
})
export class FormsOrgChooserComponent
{
    constructor(private _router:Router)
    {

    }

    onOrgChosen(org:Organization)
    {
        this._router.navigate(['/max-cover/landing', {orgId:org._id}]);
    }
}