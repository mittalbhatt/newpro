import {Component, OnInit, ViewContainerRef, Injectable} from '@angular/core';
import {UserProfile, UserProfiles, UserAccount} from "./user_profiles.service";
import {Organization, Organizations} from "./organizations.service";
import {Observable} from "rxjs/Rx";
import {SportCodes} from "./sportCodes";
import {Overlay, Modal, overlayConfigFactory} from "angular2-modal";
import {AccessRequestApprovalData, AccessRequestApprovalModal} from "./accessRequestApprovalModal.component";
import {Router, ActivatedRoute} from "@angular/router";
import {LinkedOrgRoleRequest} from "./linkedOrgRoleRequests.service";
import * as _ from "underscore";

export class PendingProfileModel
{
    constructor(public profile:UserProfile)
    {

    }

    requestedRoles:string[];
    requestedRolesDisplayString:string;
    orgName:string;

    set orgsContext(orgs:Organization[])
    {
        var linkedOrgRoleRequests:LinkedOrgRoleRequest[] = this.profile['$linkedOrgRoleRequests'];
        if (linkedOrgRoleRequests.length)
        {
            this.orgName = linkedOrgRoleRequests.map(lorr => lorr.requestedOrg.name).join(', ');
            this.requestedRoles = _.union(_.flatten(linkedOrgRoleRequests.map(lorr => lorr.requestedRoles)));
            this.requestedRolesDisplayString = this.requestedRoles.map(r => r == 'OTRN' ? 'Athletic Trainer' : 'Other').join(', ');
        }
        else
        {
            var orgMatch = orgs.find(o => o._id == this.profile.org);
            if (orgMatch)
                this.orgName = orgMatch.name;

            this.requestedRoles = this.profile.orgRoles;
            this.requestedRolesDisplayString = this.profile.orgRoles.filter(or => ['MGA', 'SUB', 'TRN'].indexOf(or) < 0)
                .map(r => {
                    switch(r)
                    {
                        case 'OTRN':
                            return 'Athletic Trainer';
                        case 'CCH':
                            return 'Coach';
                        case 'PRN':
                            return 'Parent';
                        case 'ATH':
                            return 'Athlete';
                        case 'ADM':
                            return 'Administrator';
                        default:
                            return 'Other';
                    }
                })
                .join(', ');
        }
    }


    get relationsWithAttachedProfile()
    {
        return (this.profile.relations || []).filter(r => !!r.$userProfile);
    }
}

@Component({
    selector:'pending-profiles-view',
    template:`
    <div class="team-page">
        <div class="container-fluid" style="max-width:400px; margin-top:10px;">
            <!--<div class="row">-->
                <!--<div class="col-md-12">Get the app:</div>-->
            <!--</div>-->
            <div class="row">
                <div class="col-xs-6">
                    <a target="_blank" href="https://itunes.apple.com/us/app/dragonfly-max/id894686415">
                        <img style="width:90%; height:100%; margin:6%" src="app/media/Download_on_the_App_Store_Badge_US-UK_135x40.svg"/>
                    </a>
                </div>
                <div class="col-xs-6">
                    <a target="_blank" href='https://play.google.com/store/apps/details?id=com.dragonfly.max.live&hl=en&utm_source=global_co&utm_medium=prtnr&utm_content=Mar2515&utm_campaign=PartBadge&pcampaignid=MKT-Other-global-all-co-prtnr-py-PartBadge-Mar2515-1'>
                        <img style="width:100%; height:100%" alt='Get it on Google Play' src='https://play.google.com/intl/en_us/badges/images/generic/en_badge_web_generic.png'/>
                    </a>
                </div>
            </div>
        </div>
    <div *ngIf="errorMessage" class="alert alert-danger">{{errorMessage}}</div>
    <h1 *ngIf="loading">Loading...</h1>
    </div>
    <div *ngIf="!loading" (click)="openDropdown = undefined">
        <div  class="pendingprofileappoval">
           <h4 style="font-weight:bolder; margin-bottom:0px; text-align:center;">Access Requests</h4>
            <a href="javascript:void(0)" style="float:right" class="btn btn-default" (click)="refresh()"><span class="glyphicon glyphicon-refresh"></span></a>
            <!-- <a href="javascript:void(0)" style="float:right; margin-right:5px;" class="btn btn-default" (click)="onApproveAll()"><span class="glyphicon glyphicon-plus"></span>Approve All</a> -->
        
        <table class="table" style="text-align:left; max-width:1000px; margin:0 auto;">
            <tr>
                <th width="150">
                    <a href="javascript:void(0)" (click)="sortField = 'athleteDisplayName'">
                    Name
                    <span *ngIf="(sortField == 'athleteDisplayName') && sortDescending" class="glyphicon glyphicon-circle-arrow-down"></span>
                    <span *ngIf="(sortField == 'athleteDisplayName') && !sortDescending" class="glyphicon glyphicon-circle-arrow-up"></span>
                    </a>
                </th>
                <th width="150">
                    <a href="javascript:void(0)" (click)="sortField = 'orgName'">
                        Organization
                        <span *ngIf="(sortField == 'orgName') && sortDescending" class="glyphicon glyphicon-circle-arrow-down"></span>
                        <span *ngIf="(sortField == 'orgName') && !sortDescending" class="glyphicon glyphicon-circle-arrow-up"></span>
                    </a>
                </th>
                <th width="150">
                    <a href="javascript:void(0)" (click)="sortField = 'roles'">
                        Roles
                        <span *ngIf="(sortField == 'roles') && sortDescending" class="glyphicon glyphicon-circle-arrow-down"></span>
                        <span *ngIf="(sortField == 'roles') && !sortDescending" class="glyphicon glyphicon-circle-arrow-up"></span>
                    </a>
                </th>
                <th width="100">
                    <a href="javascript:void(0)" (click)="sortField = 'createdDate'">
                    Date Created
                    <span *ngIf="(sortField == 'createdDate') && sortDescending" class="glyphicon glyphicon-circle-arrow-down"></span>
                    <span *ngIf="(sortField == 'createdDate') && !sortDescending" class="glyphicon glyphicon-circle-arrow-up"></span>
                    </a>
                </th>
                <th width="100">
                    <a href="javascript:void(0)" (click)="sortField = 'phone'">
                    Phone
                    <span *ngIf="(sortField == 'phone') && sortDescending" class="glyphicon glyphicon-circle-arrow-down"></span>
                    <span *ngIf="(sortField == 'phone') && !sortDescending" class="glyphicon glyphicon-circle-arrow-up"></span>
                    </a>
                </th>
                <th width="*">
                    <a href="javascript:void(0)" (click)="sortField = 'email'">
                    Email
                    <span *ngIf="(sortField == 'email') && sortDescending" class="glyphicon glyphicon-circle-arrow-down"></span>
                    <span *ngIf="(sortField == 'email') && !sortDescending" class="glyphicon glyphicon-circle-arrow-up"></span>
                    </a>
                </th>
                <th>&nbsp;<!--actions--></th>
            </tr>
            <template ngFor let-item [ngForOf]="profiles" let-even="even">
                <tr [ngClass]="{active:even}" style="cursor:pointer" (click)="onClickProfileRow(item)">
                    <td>
                        <strong>{{item.profile.athleteDisplayName}}</strong>
                    </td>
                    <td>
                        {{item.orgName}}
                    </td>
                    <td>
                        {{item.requestedRolesDisplayString}}
                    </td>
                    <td>
                        {{item.profile.createdDateParsed?.toLocaleDateString()}} <!-- NOTE: there was an extremely bad perf issue with using the formatting pipe | date:shortDate-->
                    </td>
                    <td>
                        {{item.profile.phone | phone}} <span *ngIf="isVerifiedPhone(item, item.profile.phone)" style="color:green" tooltip="Verified Phone Number">&#x2713;</span>
                    </td>
                    <td>
                        {{item.profile.email}} <span *ngIf="isVerifiedEmail(item, item.profile.email)" style="color:green" tooltip="Verified Email Address">&#x2713;</span>
                    </td>
                    <td style="padding-right: 0px;">
                        <button tooltip="Approve" (click)="onApprove(item, $event)"><span style="color:green" class="glyphicon glyphicon-ok"></span></button>
                        <button tooltip="Remove" (click)="onRemove(item, $event)"><span style="color:red" class="glyphicon glyphicon-remove"></span></button>
                    </td>
                </tr>
                <tr *ngFor="let relation of item.profile.relationsWithAttachedProfile" [ngClass]="{active:even}">
                    <td colspan="5" style="border:0px;">
                        <span class="glyphicon glyphicon-minus"></span> {{relation.$userProfile.firstName}} {{relation.$userProfile.lastName}} <em>({{formattedRelationRoles(relation)}})</em>
                    </td>
                    <td colspan="2" style="border:0px">
                    <!--{{relation.$userProfile.$userAccount?.usernames | json}}-->
                        <div *ngFor="let username of relation.$userProfile.$userAccount?.usernames">
                            {{username.username}}
                            <span *ngIf="username.verificationStatus == 'verified'" style="color:green" tooltip="Verified Email Address">&#x2713;</span>
                        </div>
                    </td>
                </tr>
                <tr *ngIf="item.profile.pendingSports?.length" [ngClass]="{active:even}" style="cursor:pointer" (click)="onClickProfileRow(item)">
                    <td colspan="7" style="border:0px">
                     <span class="glyphicon glyphicon-tags"></span>&nbsp; {{formattedSportList(item.profile.pendingSports)}}
                    </td>
                </tr>
            </template>
        </table>
        <p *ngIf="!profiles.length" style="text-align:center; font-style:italic">There are no access requests right now.</p>
        </div>
    </div>
    `
})

export class PendingProfilesView implements OnInit {
    loading:boolean;
    profiles:PendingProfileModel[];
    organizations:Organization[];
    sortDescending:boolean;
    errorMessage:string;

    private _sortField:string = 'athleteDisplayName';

    constructor(
        public _profilesSvc:UserProfiles,
        public _orgsSvc:Organizations,
        public _modal:Modal,
        public _router:Router,
        public _route:ActivatedRoute
    ){
        this.profiles = [];
    }

    ngOnInit(){
        this.refresh();
    }

    set sortField(value)
    {
        this.sortDescending = !this.sortDescending;
        this._sortField = value;

        var select;
        switch(value)
        {
            case 'athleteDisplayName':
                select = (item:PendingProfileModel) => item.profile.athleteDisplayName;
                break;
            case 'createdDate':
                select = (item:PendingProfileModel) => item.profile.createdDate;
                break;
            case 'phone':
                select = (item:PendingProfileModel) => item.profile.phone;
                break;
            case 'email':
                select = (item:PendingProfileModel) => item.profile.email;
                break;
            case 'orgName':
                select = (item:PendingProfileModel) => item.orgName;
                break;
            case 'roles':
                select = (item:PendingProfileModel) => item.requestedRolesDisplayString;
                break;
        }

        this.profiles.sort((x,y) =>
        {
            var valueX = select(x);
            var valueY = select(y);
            if (valueX !== valueY)
            {
                let ret = 0;
                if (valueX === undefined)
                    return 1;
                else if (valueY === undefined)
                    return -1;
                else if (typeof valueX == 'string')
                    ret = valueX.localeCompare(valueY);
                else
                    ret = valueX > valueY ? 1 : -1;

                ret = ret * (this.sortDescending ? -1 : 1);
                return ret;
            }

            if (x.profile.athleteDisplayName != y.profile.athleteDisplayName)
                return x.profile.athleteDisplayName.localeCompare(y.profile.athleteDisplayName);
            else if(x.profile.email && y.profile.email && x.profile.email != y.profile.email)
                return x.profile.email.localeCompare(y.profile.email);
            return x.profile._id.localeCompare(y.profile._id);
        });
    }

    get sortField() {
        return this._sortField;
    }

    // removeItem($event:MouseEvent, item:AthleteDocumentationFormStatusItem)
    // {
    //     $event.stopPropagation();
    //     delete this.openDropdown;
    //
    //     var res = confirm('Are you sure you want to delete the records for ' + item.athleteDisplayName + '?');
    //     if (res)
    //     {
    //         this._assignments.delete(item.assignmentId).subscribe(() =>
    //         {
    //             var idx = this.statusItems.indexOf(item);
    //             this.statusItems.splice(idx, 1);
    //         }, error =>
    //         {
    //             console.log(error);
    //             this.errorMessage = 'We encountered an error deleting ' + item.athleteDisplayName;
    //         });
    //     }
    // }

    public refresh(clearError:boolean = true)
    {
        if (clearError)
            this.errorMessage = null;

        this.loading = true;
        var profiles = this._profilesSvc.getPendingProfiles();
        var organizations = this._orgsSvc.getOrganizations();

        Observable.zip(profiles, organizations, (p, o) =>  ({ profiles:p, orgs:o }))
            .single()
            .subscribe(po =>
            {
                this.loading = false;
                let profileModels = po.profiles.map(p => new PendingProfileModel(p));
                profileModels.forEach(p => p.orgsContext = po.orgs);
                this.profiles = profileModels;
                this.organizations = po.orgs;

                // trigger sort update without changing direction
                this.sortDescending = !this.sortDescending;
                this.sortField = this.sortField;
            }, error =>
            {
                console.log(error);
                this.loading = false;
                this.errorMessage = 'An error occurred.  Please refresh the page. (' + (<any>error).status + ')';

                throw error;
            });
    }

    onApproveAll()
    {
        (<any>this._modal.confirm())
            .size('sm')
            .isBlocking(true)
            .showClose(false)
            .keyboard(27)
            .title('Approve All')
            .body(`WARNING! You are about to approve all users on this list and accept their own team choices. Be aware that anyone in the world can visit your forms page and fill them out to request access.  Be sure you recognize a validated email or phone number for each user.

        Please be sure you have deleted any users you do not want to approve.

Athletic Trainer or Admin requests will not be approved as part of this operation.`)
            .bodyClass('modal-body text-left')
            .okBtn('I understand - proceed')
            .open()
            .then(res =>
            {
                res.result.then(r =>
                {
                    if (r === true)
                    {
                        this.loading = true;
                        var profileApprovals = this.profiles
                            .filter(p => !p.requestedRoles.filter(rr => ['PRN', 'ATH', 'MGA', 'SUB'].indexOf(rr) < 0).length)
                            .map(p => {
                                p.profile.tags = (p.profile.pendingSports || []).map(ps => `,${ps},`);
                                return p;
                            })
                            .map(p => this._profilesSvc.approveProfile(p.profile));

                        Promise.all(profileApprovals).then(() =>
                        {
                            this.refresh();
                        })
                        .catch(e => {
                            this.onError(e);
                            this.refresh(false);
                        });
                    }
                })
                .catch(e =>
                {
                    if (e)
                        throw e;

                    //canceled
                });
            });


    }

    public onApprove(item:PendingProfileModel, $event:MouseEvent)
    {
        $event.stopPropagation();
        var lorRequests:LinkedOrgRoleRequest[] = item.profile['$linkedOrgRoleRequests'];

        if (lorRequests.length || item.profile.roleDisplayTitle.toLowerCase() == "parent")
        {
            (<any>this._modal.confirm())
                .size('sm')
                .isBlocking(true)
                .showClose(false)
                .keyboard(27)
                .title('Approve ' + item.requestedRolesDisplayString)
                .body(`Are you sure you want to approve ${item.profile.athleteTitleName} to have access to all sports?`)
                .bodyClass('modal-body text-left')
                .okBtn('Yes. Approve now.')
                .open()
                .then(res =>
                {
                    res.result.then(r =>
                    {
                        if (r === true)
                        {
                            this.onAction(item, p => this._profilesSvc.approveProfile(p));
                        }
                    })
                        .catch(e =>
                        {
                            if (e)
                                throw e;

                            //canceled
                        });
                });
        }
        else
        {
            let save = () => this._profilesSvc.approveProfile(item.profile, true);
            let config = overlayConfigFactory({pendingProfile: item.profile, save:save}, AccessRequestApprovalData);
            this._modal.open(AccessRequestApprovalModal, config)
                .then(result =>
                {   
                    return result.result;
                })
                .then(result =>
                {
                    if (result)
                        this.profiles = this.profiles.filter(p => p.profile != item.profile);

                })
                .catch(e =>
                {
                    console.log(e);
                });
        }
    }

    public onRemove(item:PendingProfileModel, $event:MouseEvent)
    {
        $event.stopPropagation();

        (<any>this._modal.confirm())
            .size('sm')
            .isBlocking(true)
            .showClose(false)
            .keyboard(27)
            .title('Remove Athlete')
            .body(`Are you sure you want to remove ${item.profile.athleteTitleName}?  This action cannot be undone!!`)
            .bodyClass('modal-body text-left')
            .okBtn('Yes.  Remove now.')
            .open()
            .then(res =>
            {
                res.result.then(r =>
                {
                    if (r === true)
                    {
                        this.onAction(item, p => this._profilesSvc.disapproveProfile(p));
                    }
                })
                    .catch(e =>
                    {
                        if (e)
                            throw e;

                        //canceled
                    });
            });
    }

    public onDelete(item:UserProfile, $event:MouseEvent)
    {
        $event.stopPropagation();

        (<any>this._modal.confirm())
            .size('sm')
            .isBlocking(true)
            .showClose(false)
            .keyboard(27)
            .title('Delete Athlete')
            .body(`Are you sure you want to delete ${item.athleteTitleName}?  This action cannot be undone!!`)
            .bodyClass('modal-body text-left')
            .okBtn('Yes.  Delete now.')
            .open()
            .then(res =>
            {
                res.result.then(r =>
                {
                    if (r === true)
                    {
                            this._profilesSvc.deleteProfile(item)
                            .single().toPromise().then(() =>
                            {
                                 this._profilesSvc.getProfileData.emit({data:item,action:"delete"});
                            }).catch(e =>
                            {
                                this.errorMessage = 'We encountered an unexpected error. Refresh the page and try again.';
                                throw e;
                            })
                    }
                })
                .catch(e =>
                {
                    if (e)
                        throw e;

                    //canceled
                });
            });
    }

    public onAction<T>(item:PendingProfileModel, action:(UserProfile) => Promise<T>)
    {
        this.profiles = this.profiles.filter(p => p.profile != item.profile);
        action(item.profile)
            .catch(error =>
            {
                this.onError(error);
                this.profiles.push(item);
                throw error;
            })
    }

    isVerifiedEmail(item:PendingProfileModel, email:String)
    {
        let profile = item.profile;
        var usernames = (profile.$userAccount || new UserAccount()).usernames || [];

        var emailUsername = usernames.find(u => u.type == "email" && u.verificationStatus == "verified");
        return emailUsername && emailUsername.username === email;
    }

    isVerifiedPhone(item:PendingProfileModel, phone:String)
    {
        let profile = item.profile;
        var usernames = (profile.$userAccount || new UserAccount()).usernames || [];

        var mobileUsername = usernames.find(u => u.type == "mobile" && u.verificationStatus == "verified");
        return mobileUsername && mobileUsername.username === phone;
    }

    private onError(error)
    {
        console.log(error);
        this.errorMessage = `An error occurred. Please try again. (${error.status})`;
    }

    private formattedSportList(pendingSports:string[])
    {
        return (pendingSports || []).map(s => (SportCodes.find(sc => sc.code == s) || {code:s, name:s}).name).join(', ');
    }

    private onClickProfileRow(item:PendingProfileModel)
    {
        this._router.navigate(['player', item.profile._id], {relativeTo:this._route.parent}); 
        // this._router.navigate(['profile', item.profile._id], {relativeTo:this._route.parent});
    }

    private formattedRelationRoles(relation:{roles:string[]})
    {
        return relation.roles.map(r => r == 'PRN' ? 'Parent' : r).join(', ');
    }
}
