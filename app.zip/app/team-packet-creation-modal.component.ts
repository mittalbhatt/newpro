import {Component} from "@angular/core";
import {ModalComponent, DialogRef} from "angular2-modal";
import {BSModalContext} from "angular2-modal/plugins/bootstrap";
import {Assignments, Assignment} from "./assignments.service";

export class AssignmentModalContext extends BSModalContext {
  public data: any;

  constructor(private d:any){
      super();
      this.data = d;
    //   this.size = "sm";
  }
}

@Component({
    selector:'team-packet-creation-modal-prompt',
    template:`
        <div class="modal-content" style="text-align:left">
            <form (ngSubmit)="onAddPacket()">
                <div class="modal-header">
                    <h4 *ngIf="!isNewPack"> Rename Packet </h4>
                     <h4 *ngIf="isNewPack"> Add packet </h4>
                     {{popupTitle}}
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <label for="packetName">Packet Name</label>
                        <input [(ngModel)]="packetName" type="text" class="form-control" id="packetName" name="packetName" placeholder="Packet Name" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-primary" *ngIf="isNewPack" [disabled]="!packetName" type="submit" >Add Packet</button>
                     <button class="btn btn-primary" *ngIf="!isNewPack" [disabled]="!packetName" type="submit" >Ok</button>
                    <button (click)="onCancel()" type="button" class="btn btn-danger" style="float:right; margin-right:10px;">Cancel</button>
                </div>
            </form>
        </div>
    `
})
export class TeamPacketCreationModalPrompt implements ModalComponent<AssignmentModalContext>
{
    packetName:string="";
    isNewPack:boolean=false;
    typepacket:string;
    context: AssignmentModalContext;
    constructor(
        public dialog:DialogRef<AssignmentModalContext>,
        private _assignmentsSvc:Assignments
    ){
       if(this.dialog.context.data !== undefined){
            this.packetName = this.dialog.context.data;
            if(this.dialog.context.data == null || this.dialog.context.data == ''){
                this.isNewPack = true;
            }
       }
    }

    private onCancel()
    {
        this.dialog.close(false);
    }

    private onAddPacket()
    {
        let name = this.packetName;
        this._assignmentsSvc.getPopupData.emit({data:this.packetName,type:"packet",isNew: this.isNewPack});
        this.dialog.close(true);
    }
}
