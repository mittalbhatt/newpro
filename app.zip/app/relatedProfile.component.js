System.register(["@angular/core", "@angular/router", "./user_profiles.service", "./maxAppContext.service"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, router_1, user_profiles_service_1, maxAppContext_service_1;
    var RelatedProfile;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (user_profiles_service_1_1) {
                user_profiles_service_1 = user_profiles_service_1_1;
            },
            function (maxAppContext_service_1_1) {
                maxAppContext_service_1 = maxAppContext_service_1_1;
            }],
        execute: function() {
            RelatedProfile = (function () {
                function RelatedProfile(_route, _router, _profilesSvc, _ctx) {
                    this._route = _route;
                    this._router = _router;
                    this._profilesSvc = _profilesSvc;
                    this._ctx = _ctx;
                    this._userProfile = [];
                }
                Object.defineProperty(RelatedProfile.prototype, "userProfile", {
                    set: function (value) {
                        this._userProfile = value;
                        this.loadImage(value);
                    },
                    enumerable: true,
                    configurable: true
                });
                RelatedProfile.prototype.loadImage = function (profile) {
                    var _this = this;
                    return this._profilesSvc.getProfileImageUrl(profile).single().toPromise()
                        .then(function (url) {
                        _this._user_img = (url != '' && url != undefined) ? url : "/maxweb/app/media/athlete-user-img.png";
                    })
                        .catch(function (e) {
                        console.log('Logo error', e);
                        throw e;
                    });
                };
                RelatedProfile.prototype.onChildClick = function (profile) {
                    var route = ['/max-forms/packetList'];
                    if (profile.orgRoles.indexOf('ATH') > -1)
                        route.push({ profileId: profile._id });
                    this._router.navigate(route);
                };
                RelatedProfile.prototype.goToUpladADocument = function (id) {
                    if (id) {
                        // sessionStorage['numberOfRecords'] = this.skip;
                        // sessionStorage['bodyScrollTop'] = this.bodyScrollTop;
                        sessionStorage['isCurrentPlayerTab'] = 'documentstab';
                        this._router.navigate(['/main/player', id]);
                    }
                };
                __decorate([
                    core_1.Input('userProfile'), 
                    __metadata('design:type', Object), 
                    __metadata('design:paramtypes', [Object])
                ], RelatedProfile.prototype, "userProfile", null);
                RelatedProfile = __decorate([
                    core_1.Component({
                        selector: 'related-profile',
                        template: "<div class=\"profilelist\">\n            <div class=\"profilelist-img\">      \n                <img [src]=\"_user_img\" class=\"img-responsive\" />\n            </div>\n            <div class=\"profilelist-content\">\n                <span class=\"profile-content-name\">{{_userProfile.firstName}} {{_userProfile.lastName}}</span><br>\n                {{_ctx.currentOrg?.name || '...loading school name...'}}<br>\n                <a href=\"javascript:void(0)\" (click)=\"onChildClick(_userProfile)\" >Fill Out Forms</a> | \n                <a href=\"javascript:void(0)\" (click)=\"goToUpladADocument(_userProfile._id)\">Upload a Document</a>\n            </div>\n        </div>    \n         "
                    }), 
                    __metadata('design:paramtypes', [router_1.ActivatedRoute, router_1.Router, user_profiles_service_1.UserProfiles, maxAppContext_service_1.MaxAppContext])
                ], RelatedProfile);
                return RelatedProfile;
            }());
            exports_1("RelatedProfile", RelatedProfile);
        }
    }
});
//# sourceMappingURL=relatedProfile.component.js.map