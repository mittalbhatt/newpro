import {PipeTransform, Pipe, Inject} from "@angular/core";
import {DocumentExpressionEvaluator} from "./document_expression_evaluator";
import {DocumentationDocument} from "./documentation_document";
import {DocumentDocContext} from "./document_doc_context";

@Pipe({name:'documentDataExpression', pure:false})
export class DocumentDataExpressionPipe implements PipeTransform {
    constructor(
        @Inject(DocumentExpressionEvaluator) private _evaluator:DocumentExpressionEvaluator
    ){}

    transform(value:DocumentationDocument, expression:string) : any {
        var ctx = new DocumentDocContext(value);
        return this._evaluator.evaluateExpression(expression, ctx, '*****', 'strong');
    }
}