import {Injectable, NgZone} from "@angular/core";

@Injectable()
export class StatusHandlerRegistry {
    private _handlers:any[];

    constructor(private _zone:NgZone) {
        this._handlers = [];
    }

    addHandler(handler, allSubjects) {
        this._handlers.push(handler);
        allSubjects.forEach(handler);
    }

    removeHandler(handler) {
        for (var i = this._handlers.length - 1; i >= 0; i--) {
            if (this._handlers[i] === handler) {
                this._handlers.splice(i, 1);
                break;
            }
        }
    }

    invokeHandlersForSubject(subject, state) {
        this._handlers.forEach((handler) => {
            this._zone.run(() => handler(subject, state));
        });
    }
}