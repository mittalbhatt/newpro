System.register(["@angular/core", "@angular/router"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, router_1;
    var CoverShell;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            }],
        execute: function() {
            CoverShell = (function () {
                function CoverShell(_router) {
                    this._router = _router;
                }
                CoverShell.prototype.ngOnInit = function () {
                    this.subscription = this._router.events.subscribe(function () { return window.scrollTo(0, 0); });
                };
                CoverShell.prototype.ngOnDestroy = function () {
                    this.subscription.unsubscribe();
                };
                CoverShell = __decorate([
                    core_1.Component({
                        selector: 'max-cover',
                        template: "\n<header class=\"header\">\n    <div class=\"container-fluid\">\n        <div class=\"row\">\n            <div class=\"col-sm-12\">\n                <div class=\"header-logo hidden-xs\">\n                    <div class=\"navbar-header\">\n                        <a class=\"navbar-brand\" href=\"http://www.dragonflymax.com/\"><img style=\"height:auto; max-width:100%\" class=\"logo\" alt=\"Dragonfly Max\" src=\" app/media/headerLogo.png \"></a>\n                    </div>\n                </div>\n            </div>\n            <div class=\"col-md-10 col-sm-9\">\n                <div class=\"nav-wrap\">\n                    <div class=\"nav-container\">\n                        <a class=\"navbar-toggle collapsed\" data-toggle=\"collapse\" data-target=\"#navbar\" aria-expanded=\"false\" aria-controls=\"navbar\" (click)=\"menuIsOpen = !menuIsOpen\">\n                            <span></span>\n                            <span></span>\n                            <span></span>\n                        </a>\n                        <nav class=\"navbar\">\n                            <div id=\"navbar\" class=\"navbar-collapse\" [ngClass]=\"{collapse:!menuIsOpen, open:menuIsOpen}\" aria-expanded=\"false\" >\n                                <ul id=\"mainMenu\" class=\"nav navbar-nav\"><li id=\"menu-item-84\" class=\"menu-item menu-item-type-post_type menu-item-object-page current-menu-item page_item page-item-2 current_page_item menu-item-84\"><a href=\"http://www.dragonflymax.com/\">Home</a></li>\n<li id=\"mainDropdown\" class=\"menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-88 dropdown\"><a href=\"http://www.dragonflymax.com/features/\">Features</a></li>\n<li id=\"menu-item-87\" class=\"menu-item menu-item-type-post_type menu-item-object-page menu-item-87\"><a href=\"http://www.dragonflymax.com/download/\">Download</a></li>\n<li id=\"menu-item-85\" class=\"menu-item menu-item-type-post_type menu-item-object-page menu-item-85\"><a href=\"http://www.dragonflymax.com/about-us/\">About Us</a></li>\n<li id=\"menu-item-241\" class=\"menu-item menu-item-type-post_type menu-item-object-page menu-item-241\"><a href=\"http://www.dragonflymax.com/contact/\">Contact</a></li>\n<li id=\"menu-item-480\" class=\"menu-item menu-item-type-custom menu-item-object-custom menu-item-480\"><a href=\"/maxweb/max-cover/choose-org\">Do My Forms</a></li>\n</ul>                            </div><!--/.nav-collapse -->\n                        </nav>                                \n                    </div>\n                </div>                \n            </div>\n            <div class=\"col-md-2 col-sm-3\">\n                <div class=\"socials\">                    \n                    <a href=\"https://www.facebook.com/DragonFlyMAX\" class=\"social-links style-1 fa fa-facebook\"></a>\n<a href=\"https://twitter.com/dragonfly_max\" class=\"social-links style-1 fa fa-twitter\"></a>\n<a href=\"https://www.youtube.com/embed/0ll35AEHpqk\" target=\"_blank\" class=\"social-links style-1 fa fa-youtube\"></a>               </div>\n            </div>\n        </div>\n    </div>\n</header>\n    <div id=\"cover-root\">\n        <router-outlet></router-outlet>\n        <div class=\"container-fluid\" style=\"max-width:400px; margin-top:10px;\">\n            <!--<div class=\"row\">-->\n                <!--<div class=\"col-md-12\">Get the app:</div>-->\n            <!--</div>-->\n            <div class=\"row\">\n                <div class=\"col-xs-6\">\n                    <a target=\"_blank\" href=\"https://itunes.apple.com/us/app/dragonfly-max/id894686415\">\n                        <img style=\"width:90%; height:100%; margin:6%\" src=\"app/media/Download_on_the_App_Store_Badge_US-UK_135x40.svg\"/>\n                    </a>\n                </div>\n                <div class=\"col-xs-6\">\n                    <a target=\"_blank\" href='https://play.google.com/store/apps/details?id=com.dragonfly.max.live&hl=en&utm_source=global_co&utm_medium=prtnr&utm_content=Mar2515&utm_campaign=PartBadge&pcampaignid=MKT-Other-global-all-co-prtnr-py-PartBadge-Mar2515-1'>\n                        <img style=\"width:100%; height:100%\" alt='Get it on Google Play' src='https://play.google.com/intl/en_us/badges/images/generic/en_badge_web_generic.png'/>\n                    </a>\n                </div>\n            </div>\n        </div>\n    </div>\n"
                    }), 
                    __metadata('design:paramtypes', [router_1.Router])
                ], CoverShell);
                return CoverShell;
            }());
            exports_1("CoverShell", CoverShell);
        }
    }
});
//# sourceMappingURL=cover.component.js.map