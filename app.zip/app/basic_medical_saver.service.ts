import {DocumentationDocumentData} from "./documentation_document";
import {Http, Response, RequestOptions} from "@angular/http";
import {Injectable, EventEmitter} from "@angular/core";
import {Observable} from "rxjs/Observable";
import {MaxAppContext} from "./maxAppContext.service";
import { BasicMedicalForm } from "./basic_medical_form.component";
import { CanDeactivate } from '@angular/router';

export class DocumentChangeSaverStatus {
    constructor(public saved: boolean, public response: Response = null) { }
}

@Injectable()
export class BasicMedicalSaver implements CanDeactivate<BasicMedicalForm>{
    private _documentId: string;
    private _stopped: boolean;
    private _started: boolean;
    private _timeoutHandle: any;
    private _pendingChanges: DocumentationDocumentData[];
    private _currentSavingChanges: DocumentationDocumentData[];

    private _http: Http;
    private _amrId;
    profileId: string;

    status: EventEmitter<DocumentChangeSaverStatus>;

    constructor(http: Http, public _ctx: MaxAppContext, private _requestOps: RequestOptions) {
        this._pendingChanges = [];
        this._http = http;
        this.status = new EventEmitter<DocumentChangeSaverStatus>();
    }

    canDeactivate(component: BasicMedicalForm): any {
        return component.confirmChangeRoute().then((res: boolean): boolean => {
            return res;
        }).catch(e => {
            return false;
        });
    }

    addChange(data: DocumentationDocumentData) {
        var match = this._pendingChanges.filter(d => d.ident == data.ident)[0];
        if (match)
            match.value = data.value;
        else
            this._pendingChanges.push(data);
    }

    start(amrId, profileId) {
        if (!amrId)
            throw new Error('documentId is required');

        if (this._started)
            return;

        this._amrId = amrId;
        this.profileId = profileId;
        this._stopped = false;
        this._started = true;
        this.schedule();
    }

    stop() {
        if (this._timeoutHandle)
            clearTimeout(this._timeoutHandle);

        this._timeoutHandle = null;
        this._stopped = true;
        this._started = false;
    }

    saveNow() {
        if (!this._stopped)
            throw new Error('Saver must be stopped before calling saveNow()');

        return this.savePending();
    }

    private schedule() {
        if (!this._stopped)
            this._timeoutHandle = setTimeout(() => this.savePending(), 2000);
    }

    update(update: any) {
        return this._http.put(`/training/api/documents`, update);
    }

    removeInsuranceDocument(id: string) {
        return this._http.delete(`/training/api/documents/${id}`);
    }

    getLogoUrldocumentmedia(value: any) {
console.log(value);
        return Observable.create(observer => {

            if (value.media[0].thumbnailId) {
                var logoMedia = value.media[0].thumbnailId;
            } else {
                var logoMedia = value.media[0].mediaId;
            }

            if (!logoMedia) {
                observer.next(null);
                observer.complete();
                return;
            }
            let req = new XMLHttpRequest();


            var url = `/training/api/documents/${value._id}/media/${encodeURIComponent(logoMedia)}`;
            req.open('get', url);
            req.onreadystatechange = () => {
                if (req.status == 200) {
                    var loc = req.getResponseHeader('location');
                    observer.next(loc);
                    observer.complete();
                }
                else if (req.readyState == 4) {
                    observer.error(new Error(req.responseText));
                }
            };

            req.setRequestHeader('Authorization', this._requestOps.headers.get('Authorization'));
            req.send();
        });
    }

    private savePending(): Observable<any> {
        this._timeoutHandle = null;

        if (!this._currentSavingChanges) {
            this._currentSavingChanges = this._pendingChanges;
            this._pendingChanges = [];
        }

        if (!this._currentSavingChanges.length) {
            this._currentSavingChanges = null;
            this.schedule();
            return Observable.from([0], null);
        }

        var setObject = [];
        _.each(this._currentSavingChanges,
            function (obj) {

                setObject.push(
                    {
                        [obj.ident]: obj.value
                    }
                )
            });

        var finalSetObject = setObject.reduce(function (acc, x) {
            for (var key in x) acc[key] = x[key];
            return acc;
        }, {});
        var finaluserproObject = setObject.reduce(function (acc, x) {
            for (var key in x) {
                if (key == 'info.firstName' || key == 'info.lastName' || key == 'info.tel' || key == 'info.email') {
                    var keynew = key.split(".")[1];
                    if (key == 'info.email') {
                        keynew = 'emails';
                        if (x[key][0]) {
                            acc['email'] = x[key][0];
                        } else {
                            acc['email'] = null;
                        }

                    }
                    acc[keynew] = x[key];
                }
            }
            return acc;
        }, {});

        var amrObject = {
            "$set": finalSetObject
        };
        var userproObject = {
            "$set": finaluserproObject
        };

        var observableamr = this._http.put('/training/api/amrs/' + this._amrId + '/update', amrObject);

        if (Object.keys(finaluserproObject).length != 0) {
            var observablepro = this._http.put('/training/api/userProfiles/' + this.profileId + '/update', userproObject);

            Observable.forkJoin([observableamr, observablepro]).subscribe(response => {
                this._currentSavingChanges = null;
                this.schedule();
                this.status.emit(new DocumentChangeSaverStatus(true, response[0]));
            }, errorResponse => {
                this.schedule();
                this.status.emit(new DocumentChangeSaverStatus(false, errorResponse));
            });
            return observablepro;
        } else {
            observableamr.subscribe(response => {
                this._currentSavingChanges = null;
                this.schedule();
                this.status.emit(new DocumentChangeSaverStatus(true, response));
            }, errorResponse => {
                this.schedule();
                this.status.emit(new DocumentChangeSaverStatus(false, errorResponse));
            });
            return observableamr;
        }


    }
}