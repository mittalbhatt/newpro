System.register(["@angular/core", "angular2-modal", "angular2-modal/plugins/bootstrap", "./assignments.service"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __extends = (this && this.__extends) || function (d, b) {
        for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, angular2_modal_1, bootstrap_1, assignments_service_1;
    var AssignmentModalContext, TeamPacketCreationModalPrompt;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (angular2_modal_1_1) {
                angular2_modal_1 = angular2_modal_1_1;
            },
            function (bootstrap_1_1) {
                bootstrap_1 = bootstrap_1_1;
            },
            function (assignments_service_1_1) {
                assignments_service_1 = assignments_service_1_1;
            }],
        execute: function() {
            AssignmentModalContext = (function (_super) {
                __extends(AssignmentModalContext, _super);
                function AssignmentModalContext(d) {
                    _super.call(this);
                    this.d = d;
                    this.data = d;
                    //   this.size = "sm";
                }
                return AssignmentModalContext;
            }(bootstrap_1.BSModalContext));
            exports_1("AssignmentModalContext", AssignmentModalContext);
            TeamPacketCreationModalPrompt = (function () {
                function TeamPacketCreationModalPrompt(dialog, _assignmentsSvc) {
                    this.dialog = dialog;
                    this._assignmentsSvc = _assignmentsSvc;
                    this.packetName = "";
                    this.isNewPack = false;
                    if (this.dialog.context.data !== undefined) {
                        this.packetName = this.dialog.context.data;
                        if (this.dialog.context.data == null || this.dialog.context.data == '') {
                            this.isNewPack = true;
                        }
                    }
                }
                TeamPacketCreationModalPrompt.prototype.onCancel = function () {
                    this.dialog.close(false);
                };
                TeamPacketCreationModalPrompt.prototype.onAddPacket = function () {
                    var name = this.packetName;
                    this._assignmentsSvc.getPopupData.emit({ data: this.packetName, type: "packet", isNew: this.isNewPack });
                    this.dialog.close(true);
                };
                TeamPacketCreationModalPrompt = __decorate([
                    core_1.Component({
                        selector: 'team-packet-creation-modal-prompt',
                        template: "\n        <div class=\"modal-content\" style=\"text-align:left\">\n            <form (ngSubmit)=\"onAddPacket()\">\n                <div class=\"modal-header\">\n                    <h4 *ngIf=\"!isNewPack\"> Rename Packet </h4>\n                     <h4 *ngIf=\"isNewPack\"> Add packet </h4>\n                     {{popupTitle}}\n                </div>\n                <div class=\"modal-body\">\n                    <div class=\"form-group\">\n                        <label for=\"packetName\">Packet Name</label>\n                        <input [(ngModel)]=\"packetName\" type=\"text\" class=\"form-control\" id=\"packetName\" name=\"packetName\" placeholder=\"Packet Name\" required>\n                    </div>\n                </div>\n                <div class=\"modal-footer\">\n                    <button class=\"btn btn-primary\" *ngIf=\"isNewPack\" [disabled]=\"!packetName\" type=\"submit\" >Add Packet</button>\n                     <button class=\"btn btn-primary\" *ngIf=\"!isNewPack\" [disabled]=\"!packetName\" type=\"submit\" >Ok</button>\n                    <button (click)=\"onCancel()\" type=\"button\" class=\"btn btn-danger\" style=\"float:right; margin-right:10px;\">Cancel</button>\n                </div>\n            </form>\n        </div>\n    "
                    }), 
                    __metadata('design:paramtypes', [angular2_modal_1.DialogRef, assignments_service_1.Assignments])
                ], TeamPacketCreationModalPrompt);
                return TeamPacketCreationModalPrompt;
            }());
            exports_1("TeamPacketCreationModalPrompt", TeamPacketCreationModalPrompt);
        }
    }
});
//# sourceMappingURL=team-packet-creation-modal.component.js.map