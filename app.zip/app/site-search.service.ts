import {Http, Response, RequestOptions, URLSearchParams, Headers} from "@angular/http";
import {Injectable} from "@angular/core";
import {Observable} from "rxjs/Rx";

import * as _ from "underscore";

declare var store;

export class SiteSearch{
    _id:string;
    _index:string;
    _score:number;
    _source:{
        orgId:string,
        firstName:string,
        lastName:string,
        value:{
            code:string,
            level:string,
            name:string
        }
    };
    _type:string;
    length:number
}

@Injectable()
export class SiteSearchService
{
    constructor(
        private _http:Http,
    ){    }
    
    siteSearch(search_text:string,skip:number=0,limit:number=10) :Observable<SiteSearch>
    {
        var args = new RequestOptions();
        args.search = new URLSearchParams();
        args.search.append('skip', skip.toString());
        args.search.append('limit', limit.toString());
        args.search.append('query', search_text.toString());
        return this._http.get(`/training/api/search`,args)
            .map((res:Response) => <SiteSearch>res.json());
            //.catch((error:any) =>   throw error);
    }
}