import {Component, OnInit} from "@angular/core";
import {UserProfiles} from "./user_profiles.service";
import {MaxAppContext} from "./maxAppContext.service";
import {Organization} from "./organizations.service";
import * as _ from "underscore";
import {Assignments, Packet} from "./assignments.service";

@Component({
    selector:'max-admin-menu',
    template:
`
        <div *ngIf="errorMessage" class="alert alert-danger">{{errorMessage}}</div>
        
        <div *ngIf="loading">
            <img src="/maxweb/app/media/ajax-loader.gif" />
            Loading...
        </div>
        
        <div *ngIf="!loading">
            <div class="list-group">
                <button type="button" class="list-group-item" [routerLink]="['/main/admin/access-requests']">
                    Access Requests <span class="glyphicon glyphicon-chevron-right" style="float:right;"></span> <span
                        style="float:right;" class="badge">{{pendingUserCount}}</span>
                </button>
            </div>
            
            <div *ngFor="let orgAssignments of formsAssignmentsByOrg">
                <p style="text-align:left">{{orgAssignments.org.name}} <strong>({{orgAssignments.org.shortCode}})</strong><span
                        class="glyphicon glyphicon-info-sign"
                        tooltip="{{orgAssignments.org.shortCode}} is the School Code for {{orgAssignments.org.name}}"></span></p>
                <div class="list-group">
                    <button *ngFor="let assignment of orgAssignments.assignments"
                            [routerLink]="['/max-forms/admin/event', assignment._id]" type="button" class="list-group-item"
                            style="vertical-align: middle">
                        <span class="glyphicon glyphicon-chevron-right" style="float:right;"></span>
                        {{assignment.activities[0].documentationEventDescription.eventName}}
                    </button>
                </div>
            </div>
        </div>
    `
})
export class MaxAdminMenuComponent implements OnInit
{
    loading:boolean;
    errorMessage:string;
    pendingUserCount:number;
    formsAssignmentsByOrg:{org:Organization, assignments:Packet[]}[];

    constructor(
        private _userProfilesSvc:UserProfiles,
        private _assignmentsSvc:Assignments,
        private _ctx:MaxAppContext)
    {

    }

    ngOnInit()
    {
        this.loading = true;
        delete this.errorMessage;

        let userCountPromise = this._userProfilesSvc.getPendingUserCount().single().toPromise();
        userCountPromise
            .then(count =>
            {
                this.pendingUserCount = count;
            });

        let packetPromise = this._assignmentsSvc.getAllPackets(false).single().toPromise();
        packetPromise
            .then(assignments =>
            {
                let isAdmin:(roles:string[])=>boolean = roles =>
                {
                    return !!_.intersection(roles, ['CCH', 'ADM', 'OADM', 'TRN', 'OTRN']).length
                };

                let orgs = this._ctx.availableOrganizations.filter(o =>
                {
                    return (o._id === this._ctx.currentProfile.org && isAdmin(this._ctx.currentProfile.orgRoles))
                        ||
                            _.find(this._ctx.currentProfile.linkedOrgRoles, lor => lor.orgId === o._id && isAdmin(lor.roles));
                });

                orgs = _.sortBy(orgs, 'name');

                this.formsAssignmentsByOrg = orgs.map(o =>
                {
                    let orgAssignments = assignments.filter(a =>
                        a.activities[0] && a.activities[0].documentationEventDescription
                        && _.find(a.assignees, aa => aa.orgId === o._id));

                    orgAssignments = _.sortBy(orgAssignments, a => a.activities[0].documentationEventDescription.eventName);
                    return {org:o, assignments:orgAssignments};
                }).filter(oa => !!oa.assignments.length);
            });

        Promise.all<any>([userCountPromise, packetPromise]).then(() => this.loading = false).catch(e =>
        {
            this.loading = false;
            this.errorMessage = 'An error was encountered loading your data. Please refresh to try again.';
            throw e;
        });
    }
}