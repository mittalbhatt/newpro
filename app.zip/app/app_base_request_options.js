System.register(["@angular/http", "@angular/core", "./base64Encoder", "./registration_context.service"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __extends = (this && this.__extends) || function (d, b) {
        for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var http_1, core_1, base64Encoder_1, registration_context_service_1;
    var AppBaseRequestOptions;
    return {
        setters:[
            function (http_1_1) {
                http_1 = http_1_1;
            },
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (base64Encoder_1_1) {
                base64Encoder_1 = base64Encoder_1_1;
            },
            function (registration_context_service_1_1) {
                registration_context_service_1 = registration_context_service_1_1;
            }],
        execute: function() {
            AppBaseRequestOptions = (function (_super) {
                __extends(AppBaseRequestOptions, _super);
                function AppBaseRequestOptions() {
                    _super.apply(this, arguments);
                }
                Object.defineProperty(AppBaseRequestOptions.prototype, "headers", {
                    get: function () {
                        var injector = core_1.ReflectiveInjector.resolveAndCreate([registration_context_service_1.RegistrationContext]);
                        var ctx = injector.get(registration_context_service_1.RegistrationContext);
                        // Use a copy so that the value is not retained across requests
                        // in case the credentials are updated.  The ctor that takes a Headers
                        // instance did not appear to actually  make a deep copy.
                        var headersCopy = new http_1.Headers(this._headers ? this._headers.values() : null);
                        if (this.method != 'GET' && this.method != http_1.RequestMethod.Get)
                            headersCopy.set('Content-Type', 'application/json');
                        if ((!this._headers || !this._headers.has('Authorization')) && ctx.creds) {
                            var auth = core_1.ReflectiveInjector.resolveAndCreate([base64Encoder_1.Base64Encoder]).get(base64Encoder_1.Base64Encoder).encode(ctx.creds.username + ':' + ctx.creds.password);
                            headersCopy.set('Authorization', 'Basic ' + auth);
                        }
                        return headersCopy;
                    },
                    set: function (value) {
                        this._headers = value;
                    },
                    enumerable: true,
                    configurable: true
                });
                AppBaseRequestOptions = __decorate([
                    core_1.Injectable(), 
                    __metadata('design:paramtypes', [])
                ], AppBaseRequestOptions);
                return AppBaseRequestOptions;
            }(http_1.BaseRequestOptions));
            exports_1("AppBaseRequestOptions", AppBaseRequestOptions);
        }
    }
});
//# sourceMappingURL=app_base_request_options.js.map