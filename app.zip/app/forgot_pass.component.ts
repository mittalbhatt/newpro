import {Component} from "@angular/core";
import {Router, ActivatedRoute} from "@angular/router";
import {UserAccountService} from "./userAccount.service";

@Component({
    selector: 'max-forgot-pass',
    template:`
    <div *ngIf="errorMessage" style="max-width:500px; margin:20px auto;" class="alert alert-danger">{{errorMessage}}</div>
    <div id="forgot-pass-form">
        <div>
            <img class="max-wordmark-logo" src="app/media/hurricane-100.png"/>
            <span class="max-wordmark-text">DragonFly MAX</span>
        </div>
        <h3>Reset Password</h3>
        <p>Enter the email address or mobile phone number associated with your MAX account.</p>
        
        <form #forgotPassForm="ngForm" (ngSubmit)="onSubmit()">
          <div class="form-group">
            <label for="username">Login</label>
            <input [(ngModel)]="username"  autocorrect="off" autocapitalize="off" spellcheck="false" type="text" class="form-control" name="username" placeholder="Mobile # or email address" required>
          </div>
          <button type="submit" class="btn btn-default" [disabled]="!forgotPassForm.form.valid">Send Reset Code</button>
        </form>
    </div>
`
})
export class ForgotPassComponent {

    errorMessage:string;

    username:string;

    submitting:boolean;
    persistent:boolean;

    constructor(
        private _acctSvc:UserAccountService,
        private _router:Router,
        private _route:ActivatedRoute)
    {
        let username = this._route.snapshot.params['username'];
        if (username)
            this.username = decodeURIComponent(username);
    }

    onSubmit()
    {
        if (this.submitting)
            return;

        this.submitting = true;
        this.errorMessage = null;

        this._acctSvc.requestPasswordReset(this.username.trim())
            .then((result) =>
            {
                this._router.navigate(['reset-pass', result.userAccountId, this.username.trim()], {relativeTo:this._route.parent});
            })
            .catch(err =>
            {
                this.submitting = false;

                console.log(err);

                this.errorMessage = 'I was unable to send a password reset code.  Did you sign up with a different mobile number or email?';
            });
    }
}