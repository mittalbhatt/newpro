System.register(["@angular/core", "./user_profiles.service", "@angular/router", "./base64Encoder", "./maxAppContext.service", 'angular2-modal/plugins/bootstrap', "./DfObjectId", "./df_uuid_gen", "./basic_medical_saver.service", "./organizations.service"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, user_profiles_service_1, router_1, base64Encoder_1, maxAppContext_service_1, bootstrap_1, DfObjectId_1, df_uuid_gen_1, basic_medical_saver_service_1, organizations_service_1;
    var InsuranceImageBoxComponent, InsuranceImageSetComponent;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (user_profiles_service_1_1) {
                user_profiles_service_1 = user_profiles_service_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (base64Encoder_1_1) {
                base64Encoder_1 = base64Encoder_1_1;
            },
            function (maxAppContext_service_1_1) {
                maxAppContext_service_1 = maxAppContext_service_1_1;
            },
            function (bootstrap_1_1) {
                bootstrap_1 = bootstrap_1_1;
            },
            function (DfObjectId_1_1) {
                DfObjectId_1 = DfObjectId_1_1;
            },
            function (df_uuid_gen_1_1) {
                df_uuid_gen_1 = df_uuid_gen_1_1;
            },
            function (basic_medical_saver_service_1_1) {
                basic_medical_saver_service_1 = basic_medical_saver_service_1_1;
            },
            function (organizations_service_1_1) {
                organizations_service_1 = organizations_service_1_1;
            }],
        execute: function() {
            InsuranceImageBoxComponent = (function () {
                function InsuranceImageBoxComponent(_userProfiles, _route, _appCtx, _model, _changeSaver, _base64Encoder, _organizations) {
                    var _this = this;
                    this._userProfiles = _userProfiles;
                    this._route = _route;
                    this._appCtx = _appCtx;
                    this._model = _model;
                    this._changeSaver = _changeSaver;
                    this._base64Encoder = _base64Encoder;
                    this._organizations = _organizations;
                    this.changeData = new core_1.EventEmitter();
                    this.imageItemObj = {};
                    this.chkResult = new core_1.EventEmitter();
                    this.documentDataList = [];
                    this.isShowDocumentGif = false;
                    this._amrId = "";
                    this.frontLogoImageUrl = "";
                    this.backLogoImageUrl = "";
                    this.documentGroupId = "";
                    this.logoMedia = {};
                    this._orgLogoUploadStateChange = function (s, f, r) { return _this.orgLogoUploadStateChanged(s, f, r); };
                }
                /*  ngOnInit() {
              
                  }*/
                InsuranceImageBoxComponent.prototype.ngOnInit = function () {
                    // var mediaId = DfUuidGen.newUuid();
                    // var mediaId_base64 = 'dB1evQq8TgiULgAADhipqg';
                    var _this = this;
                    //var _media_id = (new DfObjectId()).toString();
                    // var documentStableId = (new DfObjectId()).toString();
                    // Conditioally
                    // var documentGroupId = (new DfObjectId()).toString();
                    var uuid = df_uuid_gen_1.DfUuidGen.newUuid();
                    var mediaId = uuid;
                    if (this.imageItemObj.documentGroup !== undefined) {
                        if (this.imageItemObj.documentGroup.documentGroupId !== undefined && this.imageItemObj.documentGroup.documentGroupId != "") {
                            this.documentGroupId = this.imageItemObj.documentGroup.documentGroupId;
                        }
                        else {
                            this.documentGroupId = (new DfObjectId_1.DfObjectId()).toString();
                        }
                    }
                    else {
                        this.documentGroupId = (new DfObjectId_1.DfObjectId()).toString();
                    }
                    // console.log(this.documentGroupId);
                    var documentGroupRole = "front";
                    if (this.imageItemObj.documentGroup.role == "back") {
                        documentGroupRole = "back";
                    }
                    var logoMedia = {};
                    this.logoUploadSettings = {
                        getFileParams: function (file) {
                            var fileId = df_uuid_gen_1.DfUuidGen.newUuid();
                            logoMedia = {
                                _id: (new DfObjectId_1.DfObjectId()).toString(),
                                type: 'Media',
                                documentStableId: (new DfObjectId_1.DfObjectId()).toString(),
                                name: "Insurance Card",
                                createdDate: new Date(),
                                subjects: [
                                    {
                                        amrId: _this._amrId
                                    }
                                ],
                                media: [
                                    {
                                        contentType: file.type,
                                        mediaId: mediaId
                                    }
                                ],
                                documentGroup: {
                                    documentGroupId: _this.documentGroupId,
                                    role: documentGroupRole,
                                    type: "insuranceCard"
                                },
                                suppressNotifications: true,
                                lastModifiedDate: new Date()
                            };
                            _this.logoMedia = logoMedia;
                            _this.imageItemObj['logoUploading'] = true;
                            if (_this.imageItemObj._id != undefined) {
                                _this._changeSaver.removeInsuranceDocument(_this.imageItemObj._id)
                                    .single().toPromise().then(function () {
                                    // this.chkResult.emit({
                                    //   value: "test123"
                                    // })
                                })
                                    .catch(function (e) {
                                    _this.errorMessage = 'We encountered an unexpected error. Refresh the page and try again.';
                                    throw e;
                                });
                            }
                            console.log(_this.imageItemObj);
                            return _this._changeSaver.update(logoMedia).single().toPromise()
                                .then(function (data) {
                                _this.logoUploading = false;
                                return {
                                    paramsUrl: "/training/api/documents/" + logoMedia._id + "/media/" + encodeURIComponent(mediaId)
                                };
                                // return logoMedia;
                            });
                        },
                        dfUploadTag: mediaId,
                        uploaderSettings: {
                            filters: {
                                max_file_size: '10mb',
                                mime_types: [
                                    { title: "Image files", extensions: "jpeg,jpg,gif,png" }
                                ]
                            },
                            resize: {
                                width: 600,
                                height: 600
                            }
                        },
                    };
                    this.logoMedia = logoMedia;
                    this._changeSaver.getLogoUrldocumentmedia(logoMedia).single().toPromise()
                        .then(function (data) {
                        console.log(data);
                        if (_this.imageItemObj.documentGroup.role == "front") {
                            _this.frontLogoImageUrl = data;
                        }
                        else {
                            _this.backLogoImageUrl = data;
                        }
                    }).catch(function (e) {
                        // console.log('Logo error - ' + e.message);
                        // this.logoUploading = false;
                        // throw e;
                    });
                };
                InsuranceImageBoxComponent.prototype.orgLogoUploadStateChanged = function (state, fromUploaderEvent, resultUrl) {
                    var _this = this;
                    if (state === plupload.DONE) {
                        this._changeSaver.getLogoUrldocumentmedia(this.imageItemObj).single().toPromise()
                            .then(function (url) {
                            if (_this.imageItemObj.documentGroup.role == "front") {
                                _this.frontLogoImageUrl = url;
                            }
                            else {
                                _this.backLogoImageUrl = url;
                            }
                        })
                            .catch(function (e) {
                            console.log('Logo error - ' + e.message);
                            _this.errorMessage = 'An error was encountered showing the image.';
                            _this.logoUploading = false;
                        });
                        setTimeout(function () { return _this.chkResult.emit({
                            value: "test123"
                        }); }, 2000);
                    }
                    else if (state === plupload.FAILED) {
                        this.logoUploading = false;
                        this.errorMessage = 'An error was encountered while uploading your image.  Refresh the page and try again.';
                    }
                    else {
                        this.logoUploading = true;
                    }
                };
                ;
                InsuranceImageBoxComponent.prototype.documentImageUploadStateChanged = function (state, fromUploaderEvent, resultUrl) {
                    var _this = this;
                    if (state === void 0) { state = 0; }
                    if (fromUploaderEvent === void 0) { fromUploaderEvent = true; }
                    if (resultUrl === void 0) { resultUrl = ""; }
                    this._changeSaver.getLogoUrldocumentmedia(this.logoMedia).single().toPromise()
                        .then(function (data) {
                        console.log("In documentImageUploadStateChanged");
                        console.log(data);
                        if (_this.imageItemObj.documentGroup.role == "front") {
                            _this.frontLogoImageUrl = data;
                        }
                        else {
                            _this.backLogoImageUrl = data;
                        }
                    }).catch(function (e) {
                        // console.log('Logo error - ' + e.message);
                        // this.logoUploading = false;
                        // throw e;
                    });
                };
                Object.defineProperty(InsuranceImageBoxComponent.prototype, "imageItem", {
                    set: function (value) {
                        var _this = this;
                        this.imageItemObj = value;
                        if (this.imageItemObj.media !== undefined) {
                            this.imageItemObj['logoUploading'] = false;
                            this._changeSaver.getLogoUrldocumentmedia(this.imageItemObj).single().toPromise()
                                .then(function (data) {
                                if (_this.imageItemObj.documentGroup.role == "front") {
                                    _this.frontLogoImageUrl = data;
                                }
                                else {
                                    _this.backLogoImageUrl = data;
                                }
                            }).catch(function (e) {
                                // console.log('Logo error - ' + e.message);
                                // this.logoUploading = false;
                                // throw e;
                            });
                        }
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(InsuranceImageBoxComponent.prototype, "index", {
                    set: function (value) {
                        this.indexre = value;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(InsuranceImageBoxComponent.prototype, "amrId", {
                    set: function (value) {
                        this._amrId = value;
                    },
                    enumerable: true,
                    configurable: true
                });
                InsuranceImageBoxComponent.prototype.testfun = function () {
                    this.chkResult.emit({
                        value: "test123"
                    });
                    console.log("test");
                    return false;
                };
                InsuranceImageBoxComponent.prototype.removeInsuranceImage = function () {
                    var _this = this;
                    this._model.confirm()
                        .size('sm').isBlocking(true).showClose(false).keyboard(27)
                        .body("Are you sure you want to remove this insurace card image?")
                        .headerClass("hide")
                        .okBtnClass("btn btn-danger")
                        .okBtn("Remove")
                        .cancelBtn("Cancel").cancelBtnClass("btn btn-primary")
                        .open().then(function (dialog) {
                        return dialog.result;
                    }).then(function (result) {
                        if (result == true) {
                            _this._changeSaver.removeInsuranceDocument(_this.imageItemObj._id)
                                .single().toPromise().then(function () {
                                _this.chkResult.emit({
                                    value: "test123"
                                });
                            })
                                .catch(function (e) {
                                _this.errorMessage = 'We encountered an unexpected error. Refresh the page and try again.';
                                throw e;
                            });
                        }
                    }).catch(function (e) {
                    });
                };
                __decorate([
                    core_1.Output(), 
                    __metadata('design:type', Object)
                ], InsuranceImageBoxComponent.prototype, "changeData", void 0);
                __decorate([
                    core_1.Output(), 
                    __metadata('design:type', core_1.EventEmitter)
                ], InsuranceImageBoxComponent.prototype, "chkResult", void 0);
                __decorate([
                    core_1.Input('imageItem'), 
                    __metadata('design:type', Object), 
                    __metadata('design:paramtypes', [Object])
                ], InsuranceImageBoxComponent.prototype, "imageItem", null);
                __decorate([
                    core_1.Input('index'), 
                    __metadata('design:type', Object), 
                    __metadata('design:paramtypes', [Object])
                ], InsuranceImageBoxComponent.prototype, "index", null);
                __decorate([
                    core_1.Input('amrId'), 
                    __metadata('design:type', Object), 
                    __metadata('design:paramtypes', [Object])
                ], InsuranceImageBoxComponent.prototype, "amrId", null);
                InsuranceImageBoxComponent = __decorate([
                    core_1.Component({
                        selector: 'insurance-image-box',
                        templateUrl: '/maxweb/app/app/insurance_image.component.html',
                        styles: ["input[type=file] { cursor: pointer !important; }"]
                    }), 
                    __metadata('design:paramtypes', [user_profiles_service_1.UserProfiles, router_1.ActivatedRoute, maxAppContext_service_1.MaxAppContext, bootstrap_1.Modal, basic_medical_saver_service_1.BasicMedicalSaver, base64Encoder_1.Base64Encoder, organizations_service_1.Organizations])
                ], InsuranceImageBoxComponent);
                return InsuranceImageBoxComponent;
            }());
            exports_1("InsuranceImageBoxComponent", InsuranceImageBoxComponent);
            /*
            =================================================================
             */
            InsuranceImageSetComponent = (function () {
                function InsuranceImageSetComponent(_userProfiles, _route, _appCtx) {
                    this._userProfiles = _userProfiles;
                    this._route = _route;
                    this._appCtx = _appCtx;
                    this.changeData = new core_1.EventEmitter();
                    this.imageItemMain = [];
                    this._amrId = "";
                }
                InsuranceImageSetComponent.prototype.companyCheckedResult = function (e) {
                    this.changeData.emit({
                        value: "test123"
                    });
                    console.log(e);
                    console.log('test');
                    return false;
                };
                InsuranceImageSetComponent.prototype.ngOnInit = function () {
                };
                Object.defineProperty(InsuranceImageSetComponent.prototype, "imageItemMainArray", {
                    set: function (value) {
                        this.imageItemMain = value;
                        console.log(this.imageItemMain);
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(InsuranceImageSetComponent.prototype, "index", {
                    set: function (value) {
                        this.indexre = value;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(InsuranceImageSetComponent.prototype, "amrId", {
                    set: function (value) {
                        this._amrId = value;
                    },
                    enumerable: true,
                    configurable: true
                });
                __decorate([
                    core_1.Output(), 
                    __metadata('design:type', Object)
                ], InsuranceImageSetComponent.prototype, "changeData", void 0);
                __decorate([
                    core_1.Input('imageItemMainArray'), 
                    __metadata('design:type', Object), 
                    __metadata('design:paramtypes', [Object])
                ], InsuranceImageSetComponent.prototype, "imageItemMainArray", null);
                __decorate([
                    core_1.Input('index'), 
                    __metadata('design:type', Object), 
                    __metadata('design:paramtypes', [Object])
                ], InsuranceImageSetComponent.prototype, "index", null);
                __decorate([
                    core_1.Input('amrId'), 
                    __metadata('design:type', Object), 
                    __metadata('design:paramtypes', [Object])
                ], InsuranceImageSetComponent.prototype, "amrId", null);
                InsuranceImageSetComponent = __decorate([
                    core_1.Component({
                        selector: 'insurance-image-set',
                        template: "\n        <div *ngFor=\"let imageItemSub of imageItemMain; let j = index;\" class=\"{{imageItemSub.pclass}} insurance-imgbox-mobile\">\n            <insurance-image-box\n            [imageItem]=\"imageItemSub\"\n            [amrId]=\"_amrId\"\n            (chkResult)=\"companyCheckedResult($event.value)\"\n            [index]=\"j\" style=\"display:block;\"></insurance-image-box>\n        </div>\n    "
                    }), 
                    __metadata('design:paramtypes', [user_profiles_service_1.UserProfiles, router_1.ActivatedRoute, maxAppContext_service_1.MaxAppContext])
                ], InsuranceImageSetComponent);
                return InsuranceImageSetComponent;
            }());
            exports_1("InsuranceImageSetComponent", InsuranceImageSetComponent);
        }
    }
});
//# sourceMappingURL=insurance_image.component.js.map