System.register(["@angular/core", "./registration_context.service", "@angular/http"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, registration_context_service_1, http_1;
    var AuthService;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (registration_context_service_1_1) {
                registration_context_service_1 = registration_context_service_1_1;
            },
            function (http_1_1) {
                http_1 = http_1_1;
            }],
        execute: function() {
            AuthService = (function () {
                function AuthService(_ctx, _http) {
                    this._ctx = _ctx;
                    this._http = _http;
                }
                Object.defineProperty(AuthService.prototype, "redirectUrl", {
                    get: function () {
                        return store.session('RedirectURL');
                    },
                    set: function (value) {
                        store.session('RedirectURL', value);
                    },
                    enumerable: true,
                    configurable: true
                });
                AuthService.prototype.login = function (username, password, persistent) {
                    var _this = this;
                    if (persistent === void 0) { persistent = false; }
                    var opts = {
                        headers: new http_1.Headers({
                            Authorization: 'Basic ' + btoa(username + ":" + password)
                        })
                    };
                    if (persistent) {
                        var search = new http_1.URLSearchParams();
                        search.set('noExpire', 'true');
                        opts.search = search;
                    }
                    return this._http.get('/training/api/authorization', opts)
                        .map(function (res) { return res.json(); })
                        .toPromise()
                        .then(function (creds) {
                        _this._ctx.persistent = persistent;
                        _this._ctx.creds = creds;
                    });
                };
                AuthService.prototype.logOut = function () {
                    // TODO clear creds and invoke logout on server to disable device creds
                };
                Object.defineProperty(AuthService.prototype, "isLoggedIn", {
                    get: function () {
                        return !!this._ctx.creds;
                    },
                    enumerable: true,
                    configurable: true
                });
                AuthService = __decorate([
                    core_1.Injectable(), 
                    __metadata('design:paramtypes', [registration_context_service_1.RegistrationContext, http_1.Http])
                ], AuthService);
                return AuthService;
            }());
            exports_1("AuthService", AuthService);
        }
    }
});
//# sourceMappingURL=auth.service.js.map