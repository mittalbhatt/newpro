System.register(['@angular/core', "./user_profiles.service", "./organizations.service", "rxjs/Rx", "./sportCodes", "angular2-modal", "./accessRequestApprovalModal.component", "@angular/router", "underscore"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, user_profiles_service_1, organizations_service_1, Rx_1, sportCodes_1, angular2_modal_1, accessRequestApprovalModal_component_1, router_1, _;
    var PendingProfileModel, PendingProfilesView;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (user_profiles_service_1_1) {
                user_profiles_service_1 = user_profiles_service_1_1;
            },
            function (organizations_service_1_1) {
                organizations_service_1 = organizations_service_1_1;
            },
            function (Rx_1_1) {
                Rx_1 = Rx_1_1;
            },
            function (sportCodes_1_1) {
                sportCodes_1 = sportCodes_1_1;
            },
            function (angular2_modal_1_1) {
                angular2_modal_1 = angular2_modal_1_1;
            },
            function (accessRequestApprovalModal_component_1_1) {
                accessRequestApprovalModal_component_1 = accessRequestApprovalModal_component_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (_1) {
                _ = _1;
            }],
        execute: function() {
            PendingProfileModel = (function () {
                function PendingProfileModel(profile) {
                    this.profile = profile;
                }
                Object.defineProperty(PendingProfileModel.prototype, "orgsContext", {
                    set: function (orgs) {
                        var _this = this;
                        var linkedOrgRoleRequests = this.profile['$linkedOrgRoleRequests'];
                        if (linkedOrgRoleRequests.length) {
                            this.orgName = linkedOrgRoleRequests.map(function (lorr) { return lorr.requestedOrg.name; }).join(', ');
                            this.requestedRoles = _.union(_.flatten(linkedOrgRoleRequests.map(function (lorr) { return lorr.requestedRoles; })));
                            this.requestedRolesDisplayString = this.requestedRoles.map(function (r) { return r == 'OTRN' ? 'Athletic Trainer' : 'Other'; }).join(', ');
                        }
                        else {
                            var orgMatch = orgs.find(function (o) { return o._id == _this.profile.org; });
                            if (orgMatch)
                                this.orgName = orgMatch.name;
                            this.requestedRoles = this.profile.orgRoles;
                            this.requestedRolesDisplayString = this.profile.orgRoles.filter(function (or) { return ['MGA', 'SUB', 'TRN'].indexOf(or) < 0; })
                                .map(function (r) {
                                switch (r) {
                                    case 'OTRN':
                                        return 'Athletic Trainer';
                                    case 'CCH':
                                        return 'Coach';
                                    case 'PRN':
                                        return 'Parent';
                                    case 'ATH':
                                        return 'Athlete';
                                    case 'ADM':
                                        return 'Administrator';
                                    default:
                                        return 'Other';
                                }
                            })
                                .join(', ');
                        }
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(PendingProfileModel.prototype, "relationsWithAttachedProfile", {
                    get: function () {
                        return (this.profile.relations || []).filter(function (r) { return !!r.$userProfile; });
                    },
                    enumerable: true,
                    configurable: true
                });
                return PendingProfileModel;
            }());
            exports_1("PendingProfileModel", PendingProfileModel);
            PendingProfilesView = (function () {
                function PendingProfilesView(_profilesSvc, _orgsSvc, _modal, _router, _route) {
                    this._profilesSvc = _profilesSvc;
                    this._orgsSvc = _orgsSvc;
                    this._modal = _modal;
                    this._router = _router;
                    this._route = _route;
                    this._sortField = 'athleteDisplayName';
                    this.profiles = [];
                }
                PendingProfilesView.prototype.ngOnInit = function () {
                    this.refresh();
                };
                Object.defineProperty(PendingProfilesView.prototype, "sortField", {
                    get: function () {
                        return this._sortField;
                    },
                    set: function (value) {
                        var _this = this;
                        this.sortDescending = !this.sortDescending;
                        this._sortField = value;
                        var select;
                        switch (value) {
                            case 'athleteDisplayName':
                                select = function (item) { return item.profile.athleteDisplayName; };
                                break;
                            case 'createdDate':
                                select = function (item) { return item.profile.createdDate; };
                                break;
                            case 'phone':
                                select = function (item) { return item.profile.phone; };
                                break;
                            case 'email':
                                select = function (item) { return item.profile.email; };
                                break;
                            case 'orgName':
                                select = function (item) { return item.orgName; };
                                break;
                            case 'roles':
                                select = function (item) { return item.requestedRolesDisplayString; };
                                break;
                        }
                        this.profiles.sort(function (x, y) {
                            var valueX = select(x);
                            var valueY = select(y);
                            if (valueX !== valueY) {
                                var ret = 0;
                                if (valueX === undefined)
                                    return 1;
                                else if (valueY === undefined)
                                    return -1;
                                else if (typeof valueX == 'string')
                                    ret = valueX.localeCompare(valueY);
                                else
                                    ret = valueX > valueY ? 1 : -1;
                                ret = ret * (_this.sortDescending ? -1 : 1);
                                return ret;
                            }
                            if (x.profile.athleteDisplayName != y.profile.athleteDisplayName)
                                return x.profile.athleteDisplayName.localeCompare(y.profile.athleteDisplayName);
                            else if (x.profile.email && y.profile.email && x.profile.email != y.profile.email)
                                return x.profile.email.localeCompare(y.profile.email);
                            return x.profile._id.localeCompare(y.profile._id);
                        });
                    },
                    enumerable: true,
                    configurable: true
                });
                // removeItem($event:MouseEvent, item:AthleteDocumentationFormStatusItem)
                // {
                //     $event.stopPropagation();
                //     delete this.openDropdown;
                //
                //     var res = confirm('Are you sure you want to delete the records for ' + item.athleteDisplayName + '?');
                //     if (res)
                //     {
                //         this._assignments.delete(item.assignmentId).subscribe(() =>
                //         {
                //             var idx = this.statusItems.indexOf(item);
                //             this.statusItems.splice(idx, 1);
                //         }, error =>
                //         {
                //             console.log(error);
                //             this.errorMessage = 'We encountered an error deleting ' + item.athleteDisplayName;
                //         });
                //     }
                // }
                PendingProfilesView.prototype.refresh = function (clearError) {
                    var _this = this;
                    if (clearError === void 0) { clearError = true; }
                    if (clearError)
                        this.errorMessage = null;
                    this.loading = true;
                    var profiles = this._profilesSvc.getPendingProfiles();
                    var organizations = this._orgsSvc.getOrganizations();
                    Rx_1.Observable.zip(profiles, organizations, function (p, o) { return ({ profiles: p, orgs: o }); })
                        .single()
                        .subscribe(function (po) {
                        _this.loading = false;
                        var profileModels = po.profiles.map(function (p) { return new PendingProfileModel(p); });
                        profileModels.forEach(function (p) { return p.orgsContext = po.orgs; });
                        _this.profiles = profileModels;
                        _this.organizations = po.orgs;
                        // trigger sort update without changing direction
                        _this.sortDescending = !_this.sortDescending;
                        _this.sortField = _this.sortField;
                    }, function (error) {
                        console.log(error);
                        _this.loading = false;
                        _this.errorMessage = 'An error occurred.  Please refresh the page. (' + error.status + ')';
                        throw error;
                    });
                };
                PendingProfilesView.prototype.onApproveAll = function () {
                    var _this = this;
                    this._modal.confirm()
                        .size('sm')
                        .isBlocking(true)
                        .showClose(false)
                        .keyboard(27)
                        .title('Approve All')
                        .body("WARNING! You are about to approve all users on this list and accept their own team choices. Be aware that anyone in the world can visit your forms page and fill them out to request access.  Be sure you recognize a validated email or phone number for each user.\n\n        Please be sure you have deleted any users you do not want to approve.\n\nAthletic Trainer or Admin requests will not be approved as part of this operation.")
                        .bodyClass('modal-body text-left')
                        .okBtn('I understand - proceed')
                        .open()
                        .then(function (res) {
                        res.result.then(function (r) {
                            if (r === true) {
                                _this.loading = true;
                                var profileApprovals = _this.profiles
                                    .filter(function (p) { return !p.requestedRoles.filter(function (rr) { return ['PRN', 'ATH', 'MGA', 'SUB'].indexOf(rr) < 0; }).length; })
                                    .map(function (p) {
                                    p.profile.tags = (p.profile.pendingSports || []).map(function (ps) { return ("," + ps + ","); });
                                    return p;
                                })
                                    .map(function (p) { return _this._profilesSvc.approveProfile(p.profile); });
                                Promise.all(profileApprovals).then(function () {
                                    _this.refresh();
                                })
                                    .catch(function (e) {
                                    _this.onError(e);
                                    _this.refresh(false);
                                });
                            }
                        })
                            .catch(function (e) {
                            if (e)
                                throw e;
                            //canceled
                        });
                    });
                };
                PendingProfilesView.prototype.onApprove = function (item, $event) {
                    var _this = this;
                    $event.stopPropagation();
                    var lorRequests = item.profile['$linkedOrgRoleRequests'];
                    if (lorRequests.length || item.profile.roleDisplayTitle.toLowerCase() == "parent") {
                        this._modal.confirm()
                            .size('sm')
                            .isBlocking(true)
                            .showClose(false)
                            .keyboard(27)
                            .title('Approve ' + item.requestedRolesDisplayString)
                            .body("Are you sure you want to approve " + item.profile.athleteTitleName + " to have access to all sports?")
                            .bodyClass('modal-body text-left')
                            .okBtn('Yes. Approve now.')
                            .open()
                            .then(function (res) {
                            res.result.then(function (r) {
                                if (r === true) {
                                    _this.onAction(item, function (p) { return _this._profilesSvc.approveProfile(p); });
                                }
                            })
                                .catch(function (e) {
                                if (e)
                                    throw e;
                                //canceled
                            });
                        });
                    }
                    else {
                        var save = function () { return _this._profilesSvc.approveProfile(item.profile, true); };
                        var config = angular2_modal_1.overlayConfigFactory({ pendingProfile: item.profile, save: save }, accessRequestApprovalModal_component_1.AccessRequestApprovalData);
                        this._modal.open(accessRequestApprovalModal_component_1.AccessRequestApprovalModal, config)
                            .then(function (result) {
                            return result.result;
                        })
                            .then(function (result) {
                            if (result)
                                _this.profiles = _this.profiles.filter(function (p) { return p.profile != item.profile; });
                        })
                            .catch(function (e) {
                            console.log(e);
                        });
                    }
                };
                PendingProfilesView.prototype.onRemove = function (item, $event) {
                    var _this = this;
                    $event.stopPropagation();
                    this._modal.confirm()
                        .size('sm')
                        .isBlocking(true)
                        .showClose(false)
                        .keyboard(27)
                        .title('Remove Athlete')
                        .body("Are you sure you want to remove " + item.profile.athleteTitleName + "?  This action cannot be undone!!")
                        .bodyClass('modal-body text-left')
                        .okBtn('Yes.  Remove now.')
                        .open()
                        .then(function (res) {
                        res.result.then(function (r) {
                            if (r === true) {
                                _this.onAction(item, function (p) { return _this._profilesSvc.disapproveProfile(p); });
                            }
                        })
                            .catch(function (e) {
                            if (e)
                                throw e;
                            //canceled
                        });
                    });
                };
                PendingProfilesView.prototype.onDelete = function (item, $event) {
                    var _this = this;
                    $event.stopPropagation();
                    this._modal.confirm()
                        .size('sm')
                        .isBlocking(true)
                        .showClose(false)
                        .keyboard(27)
                        .title('Delete Athlete')
                        .body("Are you sure you want to delete " + item.athleteTitleName + "?  This action cannot be undone!!")
                        .bodyClass('modal-body text-left')
                        .okBtn('Yes.  Delete now.')
                        .open()
                        .then(function (res) {
                        res.result.then(function (r) {
                            if (r === true) {
                                _this._profilesSvc.deleteProfile(item)
                                    .single().toPromise().then(function () {
                                    _this._profilesSvc.getProfileData.emit({ data: item, action: "delete" });
                                }).catch(function (e) {
                                    _this.errorMessage = 'We encountered an unexpected error. Refresh the page and try again.';
                                    throw e;
                                });
                            }
                        })
                            .catch(function (e) {
                            if (e)
                                throw e;
                            //canceled
                        });
                    });
                };
                PendingProfilesView.prototype.onAction = function (item, action) {
                    var _this = this;
                    this.profiles = this.profiles.filter(function (p) { return p.profile != item.profile; });
                    action(item.profile)
                        .catch(function (error) {
                        _this.onError(error);
                        _this.profiles.push(item);
                        throw error;
                    });
                };
                PendingProfilesView.prototype.isVerifiedEmail = function (item, email) {
                    var profile = item.profile;
                    var usernames = (profile.$userAccount || new user_profiles_service_1.UserAccount()).usernames || [];
                    var emailUsername = usernames.find(function (u) { return u.type == "email" && u.verificationStatus == "verified"; });
                    return emailUsername && emailUsername.username === email;
                };
                PendingProfilesView.prototype.isVerifiedPhone = function (item, phone) {
                    var profile = item.profile;
                    var usernames = (profile.$userAccount || new user_profiles_service_1.UserAccount()).usernames || [];
                    var mobileUsername = usernames.find(function (u) { return u.type == "mobile" && u.verificationStatus == "verified"; });
                    return mobileUsername && mobileUsername.username === phone;
                };
                PendingProfilesView.prototype.onError = function (error) {
                    console.log(error);
                    this.errorMessage = "An error occurred. Please try again. (" + error.status + ")";
                };
                PendingProfilesView.prototype.formattedSportList = function (pendingSports) {
                    return (pendingSports || []).map(function (s) { return (sportCodes_1.SportCodes.find(function (sc) { return sc.code == s; }) || { code: s, name: s }).name; }).join(', ');
                };
                PendingProfilesView.prototype.onClickProfileRow = function (item) {
                    this._router.navigate(['player', item.profile._id], { relativeTo: this._route.parent });
                    // this._router.navigate(['profile', item.profile._id], {relativeTo:this._route.parent});
                };
                PendingProfilesView.prototype.formattedRelationRoles = function (relation) {
                    return relation.roles.map(function (r) { return r == 'PRN' ? 'Parent' : r; }).join(', ');
                };
                PendingProfilesView = __decorate([
                    core_1.Component({
                        selector: 'pending-profiles-view',
                        template: "\n    <div class=\"team-page\">\n        <div class=\"container-fluid\" style=\"max-width:400px; margin-top:10px;\">\n            <!--<div class=\"row\">-->\n                <!--<div class=\"col-md-12\">Get the app:</div>-->\n            <!--</div>-->\n            <div class=\"row\">\n                <div class=\"col-xs-6\">\n                    <a target=\"_blank\" href=\"https://itunes.apple.com/us/app/dragonfly-max/id894686415\">\n                        <img style=\"width:90%; height:100%; margin:6%\" src=\"app/media/Download_on_the_App_Store_Badge_US-UK_135x40.svg\"/>\n                    </a>\n                </div>\n                <div class=\"col-xs-6\">\n                    <a target=\"_blank\" href='https://play.google.com/store/apps/details?id=com.dragonfly.max.live&hl=en&utm_source=global_co&utm_medium=prtnr&utm_content=Mar2515&utm_campaign=PartBadge&pcampaignid=MKT-Other-global-all-co-prtnr-py-PartBadge-Mar2515-1'>\n                        <img style=\"width:100%; height:100%\" alt='Get it on Google Play' src='https://play.google.com/intl/en_us/badges/images/generic/en_badge_web_generic.png'/>\n                    </a>\n                </div>\n            </div>\n        </div>\n    <div *ngIf=\"errorMessage\" class=\"alert alert-danger\">{{errorMessage}}</div>\n    <h1 *ngIf=\"loading\">Loading...</h1>\n    </div>\n    <div *ngIf=\"!loading\" (click)=\"openDropdown = undefined\">\n        <div  class=\"pendingprofileappoval\">\n           <h4 style=\"font-weight:bolder; margin-bottom:0px; text-align:center;\">Access Requests</h4>\n            <a href=\"javascript:void(0)\" style=\"float:right\" class=\"btn btn-default\" (click)=\"refresh()\"><span class=\"glyphicon glyphicon-refresh\"></span></a>\n            <!-- <a href=\"javascript:void(0)\" style=\"float:right; margin-right:5px;\" class=\"btn btn-default\" (click)=\"onApproveAll()\"><span class=\"glyphicon glyphicon-plus\"></span>Approve All</a> -->\n        \n        <table class=\"table\" style=\"text-align:left; max-width:1000px; margin:0 auto;\">\n            <tr>\n                <th width=\"150\">\n                    <a href=\"javascript:void(0)\" (click)=\"sortField = 'athleteDisplayName'\">\n                    Name\n                    <span *ngIf=\"(sortField == 'athleteDisplayName') && sortDescending\" class=\"glyphicon glyphicon-circle-arrow-down\"></span>\n                    <span *ngIf=\"(sortField == 'athleteDisplayName') && !sortDescending\" class=\"glyphicon glyphicon-circle-arrow-up\"></span>\n                    </a>\n                </th>\n                <th width=\"150\">\n                    <a href=\"javascript:void(0)\" (click)=\"sortField = 'orgName'\">\n                        Organization\n                        <span *ngIf=\"(sortField == 'orgName') && sortDescending\" class=\"glyphicon glyphicon-circle-arrow-down\"></span>\n                        <span *ngIf=\"(sortField == 'orgName') && !sortDescending\" class=\"glyphicon glyphicon-circle-arrow-up\"></span>\n                    </a>\n                </th>\n                <th width=\"150\">\n                    <a href=\"javascript:void(0)\" (click)=\"sortField = 'roles'\">\n                        Roles\n                        <span *ngIf=\"(sortField == 'roles') && sortDescending\" class=\"glyphicon glyphicon-circle-arrow-down\"></span>\n                        <span *ngIf=\"(sortField == 'roles') && !sortDescending\" class=\"glyphicon glyphicon-circle-arrow-up\"></span>\n                    </a>\n                </th>\n                <th width=\"100\">\n                    <a href=\"javascript:void(0)\" (click)=\"sortField = 'createdDate'\">\n                    Date Created\n                    <span *ngIf=\"(sortField == 'createdDate') && sortDescending\" class=\"glyphicon glyphicon-circle-arrow-down\"></span>\n                    <span *ngIf=\"(sortField == 'createdDate') && !sortDescending\" class=\"glyphicon glyphicon-circle-arrow-up\"></span>\n                    </a>\n                </th>\n                <th width=\"100\">\n                    <a href=\"javascript:void(0)\" (click)=\"sortField = 'phone'\">\n                    Phone\n                    <span *ngIf=\"(sortField == 'phone') && sortDescending\" class=\"glyphicon glyphicon-circle-arrow-down\"></span>\n                    <span *ngIf=\"(sortField == 'phone') && !sortDescending\" class=\"glyphicon glyphicon-circle-arrow-up\"></span>\n                    </a>\n                </th>\n                <th width=\"*\">\n                    <a href=\"javascript:void(0)\" (click)=\"sortField = 'email'\">\n                    Email\n                    <span *ngIf=\"(sortField == 'email') && sortDescending\" class=\"glyphicon glyphicon-circle-arrow-down\"></span>\n                    <span *ngIf=\"(sortField == 'email') && !sortDescending\" class=\"glyphicon glyphicon-circle-arrow-up\"></span>\n                    </a>\n                </th>\n                <th>&nbsp;<!--actions--></th>\n            </tr>\n            <template ngFor let-item [ngForOf]=\"profiles\" let-even=\"even\">\n                <tr [ngClass]=\"{active:even}\" style=\"cursor:pointer\" (click)=\"onClickProfileRow(item)\">\n                    <td>\n                        <strong>{{item.profile.athleteDisplayName}}</strong>\n                    </td>\n                    <td>\n                        {{item.orgName}}\n                    </td>\n                    <td>\n                        {{item.requestedRolesDisplayString}}\n                    </td>\n                    <td>\n                        {{item.profile.createdDateParsed?.toLocaleDateString()}} <!-- NOTE: there was an extremely bad perf issue with using the formatting pipe | date:shortDate-->\n                    </td>\n                    <td>\n                        {{item.profile.phone | phone}} <span *ngIf=\"isVerifiedPhone(item, item.profile.phone)\" style=\"color:green\" tooltip=\"Verified Phone Number\">&#x2713;</span>\n                    </td>\n                    <td>\n                        {{item.profile.email}} <span *ngIf=\"isVerifiedEmail(item, item.profile.email)\" style=\"color:green\" tooltip=\"Verified Email Address\">&#x2713;</span>\n                    </td>\n                    <td style=\"padding-right: 0px;\">\n                        <button tooltip=\"Approve\" (click)=\"onApprove(item, $event)\"><span style=\"color:green\" class=\"glyphicon glyphicon-ok\"></span></button>\n                        <button tooltip=\"Remove\" (click)=\"onRemove(item, $event)\"><span style=\"color:red\" class=\"glyphicon glyphicon-remove\"></span></button>\n                    </td>\n                </tr>\n                <tr *ngFor=\"let relation of item.profile.relationsWithAttachedProfile\" [ngClass]=\"{active:even}\">\n                    <td colspan=\"5\" style=\"border:0px;\">\n                        <span class=\"glyphicon glyphicon-minus\"></span> {{relation.$userProfile.firstName}} {{relation.$userProfile.lastName}} <em>({{formattedRelationRoles(relation)}})</em>\n                    </td>\n                    <td colspan=\"2\" style=\"border:0px\">\n                    <!--{{relation.$userProfile.$userAccount?.usernames | json}}-->\n                        <div *ngFor=\"let username of relation.$userProfile.$userAccount?.usernames\">\n                            {{username.username}}\n                            <span *ngIf=\"username.verificationStatus == 'verified'\" style=\"color:green\" tooltip=\"Verified Email Address\">&#x2713;</span>\n                        </div>\n                    </td>\n                </tr>\n                <tr *ngIf=\"item.profile.pendingSports?.length\" [ngClass]=\"{active:even}\" style=\"cursor:pointer\" (click)=\"onClickProfileRow(item)\">\n                    <td colspan=\"7\" style=\"border:0px\">\n                     <span class=\"glyphicon glyphicon-tags\"></span>&nbsp; {{formattedSportList(item.profile.pendingSports)}}\n                    </td>\n                </tr>\n            </template>\n        </table>\n        <p *ngIf=\"!profiles.length\" style=\"text-align:center; font-style:italic\">There are no access requests right now.</p>\n        </div>\n    </div>\n    "
                    }), 
                    __metadata('design:paramtypes', [user_profiles_service_1.UserProfiles, organizations_service_1.Organizations, angular2_modal_1.Modal, router_1.Router, router_1.ActivatedRoute])
                ], PendingProfilesView);
                return PendingProfilesView;
            }());
            exports_1("PendingProfilesView", PendingProfilesView);
        }
    }
});
//# sourceMappingURL=pending_profile_approval.component.js.map