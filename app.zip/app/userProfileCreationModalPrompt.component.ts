import {Component} from "@angular/core";
import {ModalComponent, DialogRef} from "angular2-modal";
import {BSModalContext} from "angular2-modal/plugins/bootstrap";

@Component({
    selector:'user-profile-creation-modal-prompt',
    template:`
<div class="modal-content" style="text-align:left">
    <div class="modal-header">
        <button (click)="onCancel()" type="button" class="close" aria-label="Close" style="float:right"><span aria-hidden="true">&times;</span></button>
        <h3 class="modal-title" style="text-align:center">Specify the athlete's name:</h3>
    </div>
<div class="modal-body">
    <form #nameForm="ngForm">
        <div class="form-group">
            <label for="username">First Name</label>
            <input [(ngModel)]="firstName" type="text" class="form-control" id="firstName" name="firstName" placeholder="First Name" required>
          </div>
          
          <div class="form-group">
            <label for="username">Last Name</label>
            <input [(ngModel)]="lastName" type="text" class="form-control" id="lastName" name="lastName" placeholder="Last Name" required>
          </div>
    </form>
</div>
<div class="modal-footer">
    <button [disabled]="!nameForm.form.valid" (click)="onContinue()" type="button" class="btn btn-primary" style="float:right;">Continue</button>
    <button (click)="onCancel()" type="button" class="btn btn-danger" style="float:right; margin-right:10px;">Cancel</button>
</div>

</div>
`
})
export class UserProfileCreationModalPrompt implements ModalComponent<BSModalContext>
{
    firstName:string;
    lastName:string;

    constructor(public dialog:DialogRef<BSModalContext>)
    {

    }

    private onCancel()
    {
        this.dialog.close(false);
    }

    private onContinue()
    {
        this.dialog.close({firstName:this.firstName, lastName:this.lastName});
    }
}