import {Component, Input} from "@angular/core";

@Component({
    selector:'get-the-app',
    template:`
    <div *ngIf="!columns" class="main-cover-element">
        <h2 style="margin-bottom: 30px;">Get DragonFly MAX</h2>
        <div>
            <a href="https://itunes.apple.com/us/app/dragonfly-max/id894686415">
                <img width="280" src="app/media/Download_on_the_App_Store_Badge_US-UK_135x40.svg"/>
            </a>
        </div>
        <div>
            <a href='https://play.google.com/store/apps/details?id=com.dragonfly.max.live&hl=en&utm_source=global_co&utm_medium=prtnr&utm_content=Mar2515&utm_campaign=PartBadge&pcampaignid=MKT-Other-global-all-co-prtnr-py-PartBadge-Mar2515-1'>
                <img style="margin-left:-12px" width="325" alt='Get it on Google Play' src='https://play.google.com/intl/en_us/badges/images/generic/en_badge_web_generic.png'/>
            </a>
        </div>
    </div>
    
         <div *ngIf="columns" class="container-fluid" style="max-width:400px; margin-top:10px;">
            <!--<div class="row">-->
                <!--<div class="col-md-12">Get the app:</div>-->
            <!--</div>-->
            <div class="row">
                <div class="col-xs-6">
                    <a target="_blank" href="https://itunes.apple.com/us/app/dragonfly-max/id894686415">
                        <img style="width:90%; height:100%; margin:6%" src="app/media/Download_on_the_App_Store_Badge_US-UK_135x40.svg"/>
                    </a>
                </div>
                <div class="col-xs-6">
                    <a target="_blank" href='https://play.google.com/store/apps/details?id=com.dragonfly.max.live&hl=en&utm_source=global_co&utm_medium=prtnr&utm_content=Mar2515&utm_campaign=PartBadge&pcampaignid=MKT-Other-global-all-co-prtnr-py-PartBadge-Mar2515-1'>
                        <img style="width:100%; height:100%" alt='Get it on Google Play' src='https://play.google.com/intl/en_us/badges/images/generic/en_badge_web_generic.png'/>
                    </a>
                </div>
            </div>
        </div>
`
})
export class GetTheAppComponent
{
    @Input()columns:boolean;
}