import {Http, Response} from "@angular/http";
import {PagedDataUtil} from "./pagedDataUtil.service";
import {Injectable} from "@angular/core";

export class TeamInfoEntry
{
    _id:string;
    value:{name:string; level:string; code:string;};
    orgId:string;
}

@Injectable()
export class TeamInfo
{
    constructor(private _http:Http)
    {

    }

    getTeamInfoEntries(skip:number=0, take:number=100)
    {
        return this._http.get(`/training/api/lists/teamInfo?skip=${skip}&limit=${take}`)
            .map((res:Response) => <TeamInfoEntry[]>res.json());
    }

    getAllTeamInfoEntries() {
        return PagedDataUtil.getAllPages((s,t) => this.getTeamInfoEntries(s, t));
    }

    createTeamInfoEntry(entry:TeamInfoEntry)
    {
        return this._http.put(`/training/api/lists/teamInfo`, entry);
    }
}