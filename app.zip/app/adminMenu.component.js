System.register(["@angular/core", "./user_profiles.service", "./maxAppContext.service", "underscore", "./assignments.service"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, user_profiles_service_1, maxAppContext_service_1, _, assignments_service_1;
    var MaxAdminMenuComponent;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (user_profiles_service_1_1) {
                user_profiles_service_1 = user_profiles_service_1_1;
            },
            function (maxAppContext_service_1_1) {
                maxAppContext_service_1 = maxAppContext_service_1_1;
            },
            function (_1) {
                _ = _1;
            },
            function (assignments_service_1_1) {
                assignments_service_1 = assignments_service_1_1;
            }],
        execute: function() {
            MaxAdminMenuComponent = (function () {
                function MaxAdminMenuComponent(_userProfilesSvc, _assignmentsSvc, _ctx) {
                    this._userProfilesSvc = _userProfilesSvc;
                    this._assignmentsSvc = _assignmentsSvc;
                    this._ctx = _ctx;
                }
                MaxAdminMenuComponent.prototype.ngOnInit = function () {
                    var _this = this;
                    this.loading = true;
                    delete this.errorMessage;
                    var userCountPromise = this._userProfilesSvc.getPendingUserCount().single().toPromise();
                    userCountPromise
                        .then(function (count) {
                        _this.pendingUserCount = count;
                    });
                    var packetPromise = this._assignmentsSvc.getAllPackets(false).single().toPromise();
                    packetPromise
                        .then(function (assignments) {
                        var isAdmin = function (roles) {
                            return !!_.intersection(roles, ['CCH', 'ADM', 'OADM', 'TRN', 'OTRN']).length;
                        };
                        var orgs = _this._ctx.availableOrganizations.filter(function (o) {
                            return (o._id === _this._ctx.currentProfile.org && isAdmin(_this._ctx.currentProfile.orgRoles))
                                ||
                                    _.find(_this._ctx.currentProfile.linkedOrgRoles, function (lor) { return lor.orgId === o._id && isAdmin(lor.roles); });
                        });
                        orgs = _.sortBy(orgs, 'name');
                        _this.formsAssignmentsByOrg = orgs.map(function (o) {
                            var orgAssignments = assignments.filter(function (a) {
                                return a.activities[0] && a.activities[0].documentationEventDescription
                                    && _.find(a.assignees, function (aa) { return aa.orgId === o._id; });
                            });
                            orgAssignments = _.sortBy(orgAssignments, function (a) { return a.activities[0].documentationEventDescription.eventName; });
                            return { org: o, assignments: orgAssignments };
                        }).filter(function (oa) { return !!oa.assignments.length; });
                    });
                    Promise.all([userCountPromise, packetPromise]).then(function () { return _this.loading = false; }).catch(function (e) {
                        _this.loading = false;
                        _this.errorMessage = 'An error was encountered loading your data. Please refresh to try again.';
                        throw e;
                    });
                };
                MaxAdminMenuComponent = __decorate([
                    core_1.Component({
                        selector: 'max-admin-menu',
                        template: "\n        <div *ngIf=\"errorMessage\" class=\"alert alert-danger\">{{errorMessage}}</div>\n        \n        <div *ngIf=\"loading\">\n            <img src=\"/maxweb/app/media/ajax-loader.gif\" />\n            Loading...\n        </div>\n        \n        <div *ngIf=\"!loading\">\n            <div class=\"list-group\">\n                <button type=\"button\" class=\"list-group-item\" [routerLink]=\"['/main/admin/access-requests']\">\n                    Access Requests <span class=\"glyphicon glyphicon-chevron-right\" style=\"float:right;\"></span> <span\n                        style=\"float:right;\" class=\"badge\">{{pendingUserCount}}</span>\n                </button>\n            </div>\n            \n            <div *ngFor=\"let orgAssignments of formsAssignmentsByOrg\">\n                <p style=\"text-align:left\">{{orgAssignments.org.name}} <strong>({{orgAssignments.org.shortCode}})</strong><span\n                        class=\"glyphicon glyphicon-info-sign\"\n                        tooltip=\"{{orgAssignments.org.shortCode}} is the School Code for {{orgAssignments.org.name}}\"></span></p>\n                <div class=\"list-group\">\n                    <button *ngFor=\"let assignment of orgAssignments.assignments\"\n                            [routerLink]=\"['/max-forms/admin/event', assignment._id]\" type=\"button\" class=\"list-group-item\"\n                            style=\"vertical-align: middle\">\n                        <span class=\"glyphicon glyphicon-chevron-right\" style=\"float:right;\"></span>\n                        {{assignment.activities[0].documentationEventDescription.eventName}}\n                    </button>\n                </div>\n            </div>\n        </div>\n    "
                    }), 
                    __metadata('design:paramtypes', [user_profiles_service_1.UserProfiles, assignments_service_1.Assignments, maxAppContext_service_1.MaxAppContext])
                ], MaxAdminMenuComponent);
                return MaxAdminMenuComponent;
            }());
            exports_1("MaxAdminMenuComponent", MaxAdminMenuComponent);
        }
    }
});
//# sourceMappingURL=adminMenu.component.js.map