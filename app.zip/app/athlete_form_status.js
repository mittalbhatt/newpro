System.register([], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var AthleteDocumentationFormStatus, AthleteDocumentationFormStatusItem, AthleteDocumentationFormStatusSummary;
    return {
        setters:[],
        execute: function() {
            AthleteDocumentationFormStatus = (function () {
                function AthleteDocumentationFormStatus() {
                }
                return AthleteDocumentationFormStatus;
            }());
            exports_1("AthleteDocumentationFormStatus", AthleteDocumentationFormStatus);
            AthleteDocumentationFormStatusItem = (function () {
                function AthleteDocumentationFormStatusItem() {
                }
                return AthleteDocumentationFormStatusItem;
            }());
            exports_1("AthleteDocumentationFormStatusItem", AthleteDocumentationFormStatusItem);
            AthleteDocumentationFormStatusSummary = (function () {
                function AthleteDocumentationFormStatusSummary() {
                }
                return AthleteDocumentationFormStatusSummary;
            }());
            exports_1("AthleteDocumentationFormStatusSummary", AthleteDocumentationFormStatusSummary);
        }
    }
});
//# sourceMappingURL=athlete_form_status.js.map