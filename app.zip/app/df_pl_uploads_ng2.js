System.register(["@angular/core", "./status_handler_registry_ng2", "@angular/http"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var __param = (this && this.__param) || function (paramIndex, decorator) {
        return function (target, key) { decorator(target, key, paramIndex); }
    };
    var core_1, status_handler_registry_ng2_1, http_1;
    var DfPlUploads2;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (status_handler_registry_ng2_1_1) {
                status_handler_registry_ng2_1 = status_handler_registry_ng2_1_1;
            },
            function (http_1_1) {
                http_1 = http_1_1;
            }],
        execute: function() {
            DfPlUploads2 = (function () {
                function DfPlUploads2(_fileStatusHandlerRegistry, _http) {
                    this._fileStatusHandlerRegistry = _fileStatusHandlerRegistry;
                    this._http = _http;
                    this._allFiles = [];
                    this._masterSettings = {
                        runtimes: 'html5',
                        multi_selection: false
                    };
                }
                DfPlUploads2.prototype.createUploader = function (settings) {
                    var _this = this;
                    var uploader = new plupload.Uploader(_.extend({}, this._masterSettings, settings.uploaderSettings));
                    uploader.bind('FilesAdded', function (u, a) { return _this.onFilesAddedHandlerFactory(settings)(u, a); });
                    uploader.bind('UploadComplete', function (u, f) { return _this.onUploaderComplete(u, f); });
                    uploader.bind('Error', function (u, a) { return _this.onPlUploadError(u, a); });
                    return uploader;
                };
                ;
                DfPlUploads2.prototype.addFileStatusHandler = function (handler) {
                    this._fileStatusHandlerRegistry.addHandler(handler, this._allFiles);
                };
                DfPlUploads2.prototype.removeFileStatusHandler = function (handler) {
                    this._fileStatusHandlerRegistry.removeHandler(handler);
                };
                DfPlUploads2.prototype.getUploadParams = function (fileParams, file) {
                    file.paramsUrl = fileParams.paramsUrl;
                    return this._http.put(file.paramsUrl, { contentType: file.type, filename: file.name })
                        .map(function (response) { return response.json(); })
                        .single().toPromise();
                };
                DfPlUploads2.prototype.putCompleteNotification = function (file) {
                    return this._http.put(file.paramsUrl, { complete: true })
                        .map(function (response) { return response.bytesLoaded ? response.json() : null; })
                        .single().toPromise();
                };
                DfPlUploads2.prototype.onFilesAddedHandlerFactory = function (settings) {
                    var _this = this;
                    return function (uploader, addedFiles) {
                        if (uploader.files.length > 1 || addedFiles.length > 1) {
                            // Only 1 file per uploader+droptarget
                            addedFiles.forEach(function (addedFile) {
                                uploader.removeFile(addedFile);
                            });
                            window.alert('You can only upload 1 file at a time.');
                            return;
                        }
                        var file = addedFiles[0];
                        file.dfUploadTag = settings.dfUploadTag;
                        settings.getFileParams(file)
                            .then(function (dfUploadParams) {
                            file.dfUploadParams = dfUploadParams;
                            _this._allFiles.push(file);
                            _this._fileStatusHandlerRegistry.invokeHandlersForSubject(file, true);
                            return _this.getUploadParams(file.dfUploadParams, file);
                        })
                            .then(function (uploadParams) {
                            if (uploadParams && !uploadParams.complete && uploadParams.providerType === 's3multipartform') {
                                uploader.settings.url = uploadParams.uploadUrl;
                                uploader.settings.multipart_params = uploadParams.multipartFormData;
                                uploader.start();
                            }
                            else {
                                throw new Error('No valid upload params found.');
                            }
                        })
                            .catch(function (e) {
                            console.log(e);
                            uploader.removeFile(file);
                            file.status = plupload.FAILED;
                            _this._fileStatusHandlerRegistry.invokeHandlersForSubject(file, false);
                            throw e;
                        });
                        return;
                    };
                };
                DfPlUploads2.prototype.onUploaderComplete = function (uploader, files) {
                    var _this = this;
                    files.forEach(function (file) {
                        uploader.removeFile(file);
                        for (var i = _this._allFiles.length - 1; i >= 0; i--) {
                            if (_this._allFiles[i] === file) {
                                _this._allFiles.splice(i, 1);
                                break;
                            }
                        }
                        if (file.status === plupload.DONE) {
                            //ProfileImageUploadRequest.complete(file.dfUploadParams, null,
                            _this.putCompleteNotification(file).then(function (data) {
                                // success
                                file.dfResultUrl = data ? data.resultUrl : null;
                                _this._fileStatusHandlerRegistry.invokeHandlersForSubject(file, false);
                            })
                                .catch(function (e) {
                                // error
                                console.log(e);
                                file.status = plupload.FAILED;
                                _this._fileStatusHandlerRegistry.invokeHandlersForSubject(file, false);
                            });
                        }
                        else {
                            _this._fileStatusHandlerRegistry.invokeHandlersForSubject(file, true);
                        }
                    });
                    uploader.stop();
                };
                DfPlUploads2.prototype.onPlUploadError = function (uploader, args) {
                    console.log(JSON.stringify({ message: 'Error from plupload.', args: args }));
                    switch (args.code) {
                        case plupload.FILE_SIZE_ERROR:
                            window.alert('That file is too big.  The file must be less than ' + uploader.settings.filters.max_file_size);
                            break;
                        case plupload.FILE_EXTENSION_ERROR:
                            window.alert('You can only upload .jpeg, .jpg, .png, and .gif files.');
                            break;
                        case plupload.IMAGE_DIMENSIONS_ERROR:
                            window.alert('Max can\'t use this picture.  Try a different one.');
                            break;
                        default:
                            window.alert('An upload error has occurred. Please refresh the page and try again.');
                            break;
                    }
                };
                DfPlUploads2 = __decorate([
                    core_1.Injectable(),
                    __param(0, core_1.Inject(status_handler_registry_ng2_1.StatusHandlerRegistry)), 
                    __metadata('design:paramtypes', [status_handler_registry_ng2_1.StatusHandlerRegistry, http_1.Http])
                ], DfPlUploads2);
                return DfPlUploads2;
            }());
            exports_1("DfPlUploads2", DfPlUploads2);
        }
    }
});
//# sourceMappingURL=df_pl_uploads_ng2.js.map