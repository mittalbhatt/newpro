System.register(['@angular/core', "./DfObjectId", "./assignments.service", "./maxAppContext.service", '@angular/router', 'angular2-modal/plugins/bootstrap'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, DfObjectId_1, assignments_service_1, maxAppContext_service_1, router_1, bootstrap_1;
    var SelectFormComponent;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (DfObjectId_1_1) {
                DfObjectId_1 = DfObjectId_1_1;
            },
            function (assignments_service_1_1) {
                assignments_service_1 = assignments_service_1_1;
            },
            function (maxAppContext_service_1_1) {
                maxAppContext_service_1 = maxAppContext_service_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (bootstrap_1_1) {
                bootstrap_1 = bootstrap_1_1;
            }],
        execute: function() {
            SelectFormComponent = (function () {
                function SelectFormComponent(_assignmentsSvc, ctx, route, router, _modal, chgRef) {
                    var _this = this;
                    this._assignmentsSvc = _assignmentsSvc;
                    this.ctx = ctx;
                    this.route = route;
                    this.router = router;
                    this._modal = _modal;
                    this.chgRef = chgRef;
                    this.formFields = [
                        {
                            "name": "",
                            "shortcutName": "",
                            "fields": [],
                        },
                        {
                            "ident": "",
                            "name": "",
                            "hint": "",
                            "type": "text",
                            "required": true,
                            "defaultValue": ""
                        },
                        {
                            "ident": "",
                            "name": "",
                            "type": "selectOne",
                            "options": [
                                "Male",
                                "Female"
                            ],
                            "defaultValue": ""
                        },
                        {
                            "ident": "",
                            "name": "",
                            "hint": "",
                            "type": "date",
                            "required": true,
                            "defaultValue": ""
                        },
                        {
                            "ident": "",
                            "name": "",
                            "hint": "",
                            "type": "shorttext",
                            "required": true,
                            "defaultValue": ""
                        },
                        {
                            "ident": "",
                            "name": "",
                            "hint": "",
                            "type": "longtext",
                            "required": true,
                            "defaultValue": ""
                        }
                    ];
                    this.dynamicForm = [];
                    this.lastTxtSearchVal = "";
                    this.currentorgId = "";
                    this.formId = "";
                    this.hideme = [];
                    this.editformname = false;
                    this.formname = '';
                    this.errorclassfield = [];
                    this.isSubmittFirstTime = false;
                    this.isLoadRecords = false;
                    this.isSave = false;
                    this.route.params.subscribe(function (params) {
                        _this.formId = params['formId'];
                        _this.currentorgId = params['currentorgId'];
                        var urlType = _this.route.snapshot.data['type'];
                        if (urlType == "edit-form") {
                            _this.isLoadRecords = true;
                            _this._assignmentsSvc.getActivities("Document").subscribe(function (data) {
                                if (data) {
                                    var findObj = _.find(data, { _id: _this.formId });
                                    if (findObj !== null && findObj !== undefined) {
                                        _this.formname = findObj.name;
                                        findObj.format.sections.forEach(function (section) {
                                            _this.dynamicForm.push(section);
                                            _this.chgRef.markForCheck();
                                        });
                                    }
                                }
                            }, function (e) { throw e; }, function () { _this.isLoadRecords = false; });
                        }
                    });
                }
                SelectFormComponent.prototype.trackByIndex = function (index, obj) {
                    return index;
                };
                SelectFormComponent.prototype.transferDataSuccess = function ($event) {
                    if ($event.dragData !== undefined && $event.dragData !== null && $event.dragData.fields !== undefined) {
                        var obj = JSON.parse(JSON.stringify($event.dragData));
                        this.dynamicForm.push(obj);
                    }
                };
                SelectFormComponent.prototype.addSectionFields = function ($event, i) {
                    if ($event.dragData !== undefined && $event.dragData !== null && $event.dragData.type !== undefined) {
                        var obj = JSON.parse(JSON.stringify($event.dragData));
                        this.dynamicForm[i].fields.push(obj);
                    }
                };
                SelectFormComponent.prototype.removeField = function (i, type, j) {
                    var _this = this;
                    if (j === void 0) { j = null; }
                    var msg = "Are you sure? you want to delete section!";
                    if (type == "section_field") {
                        msg = "Are you sure? you want to delete field!";
                    }
                    this.areYouSure(msg).then(function (res) {
                        if (res) {
                            if (type == "section_field") {
                                if (_this.dynamicForm[i].fields !== undefined && j !== null) {
                                    _this.dynamicForm[i].fields.splice(j, 1);
                                    _this.chgRef.markForCheck();
                                }
                            }
                            else if (type == "section") {
                                if (_this.dynamicForm !== undefined) {
                                    _this.dynamicForm.splice(i, 1);
                                    _this.chgRef.markForCheck();
                                }
                            }
                        }
                    });
                };
                SelectFormComponent.prototype.changesection = function (item, key) {
                    this.hideme[item] = key;
                };
                SelectFormComponent.prototype.editform = function (index, key) {
                    this.editformname = key;
                };
                SelectFormComponent.prototype.checkerror = function (i, j) {
                    if (i === void 0) { i = null; }
                    if (j === void 0) { j = null; }
                    if (this.isSubmittFirstTime) {
                        if (i !== null && j !== null) {
                            if (this.dynamicForm[i].fields[j].name !== undefined && this.dynamicForm[i].fields[j].name === "") {
                                return true;
                            }
                        }
                        else if (i !== null) {
                            if ((this.dynamicForm[i].name !== undefined) && (this.dynamicForm[i].name === "" || this.dynamicForm[i].fields.length === 0)) {
                                return true;
                            }
                        }
                    }
                    return false;
                };
                SelectFormComponent.prototype.checkErrorBeforeSave = function () {
                    var _this = this;
                    return new Promise(function (resolve, reject) {
                        var i = 0;
                        var isError = false;
                        _this.dynamicForm.forEach(function (section) {
                            var j = 0;
                            if (_this.checkerror(i)) {
                                resolve(true);
                            }
                            section.fields.forEach(function (field) {
                                if (_this.checkerror(i, j)) {
                                    resolve(true);
                                }
                                j++;
                            });
                            i++;
                        });
                        resolve(false);
                    });
                };
                SelectFormComponent.prototype.onAddFormdata = function () {
                    var _this = this;
                    this.isSubmittFirstTime = true;
                    this.checkErrorBeforeSave().then(function (error) {
                        if (!error) {
                            _this.isSave = true;
                            var formId = (new DfObjectId_1.DfObjectId()).toString();
                            var profileId = _this.ctx.currentProfile;
                            _this.forampostdata = {
                                "_id": formId,
                                "type": "Document",
                                "documentType": "documentation",
                                "context": "",
                                "lastModifiedDate": "",
                                "documentAudience": [{
                                        "roles": [
                                            "TRN"
                                        ],
                                        "ofUserProfile": {
                                            "_id": profileId
                                        }
                                    }],
                                "name": _this.formname,
                                "orgId": _this.currentorgId,
                                "format": {
                                    "sections": _this.dynamicForm
                                }
                            };
                            _this._assignmentsSvc.createForm(_this.forampostdata).single().toPromise().then(function (d) {
                                _this.isSave = false;
                                console.log(_this.currentorgId);
                                _this.router.navigateByUrl("/main/teams/" + _this.currentorgId);
                            }).catch(function (e) {
                            });
                        }
                    }).catch(function (e) { console.log(e); });
                };
                SelectFormComponent.prototype.areYouSure = function (msg) {
                    var _this = this;
                    if (msg === void 0) { msg = null; }
                    return new Promise(function (resolve, reject) {
                        _this._modal.confirm()
                            .size('sm').isBlocking(true).showClose(false).keyboard(27)
                            .body("" + msg)
                            .headerClass("hide")
                            .okBtnClass("btn btn-primary")
                            .cancelBtnClass("btn btn-danger")
                            .open().then(function (dialog) {
                            return dialog.result;
                        }).then(function (result) {
                            if (result === true) {
                                resolve(true);
                            }
                            else {
                                resolve(false);
                            }
                        }).catch(function (e) {
                            resolve(e);
                        }).catch(function (e) {
                            resolve(e);
                        });
                    });
                };
                SelectFormComponent = __decorate([
                    core_1.Component({
                        selector: 'app-root',
                        templateUrl: '/maxweb/app/app/select-form.component.html',
                        changeDetection: core_1.ChangeDetectionStrategy.OnPush
                    }), 
                    __metadata('design:paramtypes', [assignments_service_1.Assignments, maxAppContext_service_1.MaxAppContext, router_1.ActivatedRoute, router_1.Router, bootstrap_1.Modal, core_1.ChangeDetectorRef])
                ], SelectFormComponent);
                return SelectFormComponent;
            }());
            exports_1("SelectFormComponent", SelectFormComponent);
        }
    }
});
//# sourceMappingURL=select-form.component.js.map