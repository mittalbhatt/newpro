System.register(["@angular/http", "@angular/core", "underscore", "./DfObjectId"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var http_1, core_1, _, DfObjectId_1;
    var Username, UserAccount, PasswordResetRequestResponse, UserAccountService;
    return {
        setters:[
            function (http_1_1) {
                http_1 = http_1_1;
            },
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (_1) {
                _ = _1;
            },
            function (DfObjectId_1_1) {
                DfObjectId_1 = DfObjectId_1_1;
            }],
        execute: function() {
            Username = (function () {
                function Username() {
                }
                return Username;
            }());
            exports_1("Username", Username);
            UserAccount = (function () {
                function UserAccount(id) {
                    this._id = (new DfObjectId_1.DfObjectId(id)).toString();
                }
                return UserAccount;
            }());
            exports_1("UserAccount", UserAccount);
            PasswordResetRequestResponse = (function () {
                function PasswordResetRequestResponse() {
                }
                return PasswordResetRequestResponse;
            }());
            exports_1("PasswordResetRequestResponse", PasswordResetRequestResponse);
            UserAccountService = (function () {
                function UserAccountService(_http) {
                    this._http = _http;
                    // console.log(this.cachedPendingAccount);
                }
                UserAccountService.prototype.saveAccount = function (acct, recaptchaResponse) {
                    var body = _.extend({ recaptchaResponse: recaptchaResponse }, acct);
                    return this._http.put('/training/api/userAccount', body)
                        .single()
                        .toPromise();
                };
                UserAccountService.prototype.requestVerification = function (username) {
                    if (!this.cachedPassword)
                        throw new Error('A password must be cached prior to requesting verification.');
                    return this._http.post("/training/api/accounts/verify/" + encodeURIComponent(username), null, { headers: new http_1.Headers({ 'Authorization': 'Basic ' + btoa(username + ":" + this.cachedPassword) }) })
                        .single()
                        .toPromise();
                };
                UserAccountService.prototype.fulfillVerification = function (username, code) {
                    return this._http.get("/training/api/accounts/verify/" + username + "?code=" + code)
                        .single()
                        .toPromise();
                };
                UserAccountService.prototype.requestPasswordReset = function (username) {
                    var body = _.extend({}, { username: username });
                    return this._http.post('/training/api/accounts/passwordResets', body)
                        .map(function (res) { return res.json(); })
                        .single()
                        .toPromise();
                };
                UserAccountService.prototype.resetPassword = function (userAccountId, username, password, code) {
                    var body = { password: password };
                    return this._http.post("/training/api/accounts/" + userAccountId + "/passwordUpdates", body, { headers: new http_1.Headers({ 'df-max-auth-confirm-username': username, 'df-max-auth-password-reset-code': code }) })
                        .single()
                        .toPromise();
                };
                UserAccountService.prototype.getMyUserAccount = function () {
                    return this._http.get("/training/api/accounts/mine")
                        .map(function (res) { return res.json(); })
                        .single()
                        .toPromise();
                };
                Object.defineProperty(UserAccountService.prototype, "cachedPassword", {
                    get: function () {
                        return store.session('CachedPassword');
                    },
                    set: function (value) {
                        store.session('CachedPassword', value);
                    },
                    enumerable: true,
                    configurable: true
                });
                UserAccountService.prototype.changePassword = function (userAccountId, password) {
                    userAccountId = (new DfObjectId_1.DfObjectId(userAccountId)).toString();
                    var body = { password: password };
                    // console.log(body);
                    // console.log(userAccountId);
                    return this._http.post("/training/api/accounts/" + userAccountId + "/passwordUpdates", body)
                        .single()
                        .toPromise();
                };
                UserAccountService.prototype.getTosData = function (versionnumber) {
                    return this._http.get("/training/api/tos/" + versionnumber)
                        .map(function (res) { return res.json(); })
                        .single()
                        .toPromise();
                };
                UserAccountService.prototype.updattosversion = function (versionnumberget) {
                    return this._http.put('/training/api/accounts/mine/tos/acceptances', versionnumberget);
                };
                UserAccountService = __decorate([
                    core_1.Injectable(), 
                    __metadata('design:paramtypes', [http_1.Http])
                ], UserAccountService);
                return UserAccountService;
            }());
            exports_1("UserAccountService", UserAccountService);
        }
    }
});
//# sourceMappingURL=userAccount.service.js.map