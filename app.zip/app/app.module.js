System.register(['@angular/core', '@angular/platform-browser', '@angular/forms', "@angular/common", './app.component', './app.routing', "./registration/athlete_registration.component", "./landing.component", "./ath_doc_dashboard.component", "./athlete_doc_form.component", "./basic_medical_form.component", "@angular/http", "./registration_context.service", "./userAccount.service", "./registration_heading.component", "./profileTypeChooser.component", "./user_profiles.service", "./ownProfileCreator.component", "./app_base_request_options", "./defaultSportChooser.component", "./appExceptionHandler.service", "./relatedProfilesList.component", "./relatedProfile.component", "./landing_blank.component", "./max-forms-shell.component", "./parentChildFormsContextChooser.component", "./relatedProfileCreator.component", "./cover.component", "./login.component", "./signup.component", "./verifyAccount.component", "./forgot_pass.component", "./reset_pass.component", "./maxAppContext.service", "./organizations.service", "./packetList.component", "./activities.service", "./assignments.service", "./df_pl_uploader_ng2.directive", "./userProfile.component", "./df_pl_uploads_ng2", "./status_handler_registry_ng2", "./adminMenu.component", "angular2-modal", "angular2-modal/plugins/bootstrap", "./document_data_expression.pipe", "./registration/combo_day_picker", "./document_change_saver.service", "./document_factory.service", "./document_expression_evaluator", "./document_loader.service", "./registration/activity_auth.service", "angular2-recaptcha/angular2-recaptcha", "ng2-bootstrap/ng2-bootstrap", 'ng2-dnd', "./formsProfileEditor.component", "./admin_event_view.component", "./pending_profile_approval.component", "./admin_form_print_modal", "./accessRequestApprovalModal.component", "./teamInfo.service", "./confirmProfileDelete", "./getTheApp.component", "./phoneDisplay.pipe", "./key-value.pipe", "./teams-players.component", "./orgContextChooser.component", "./linkedOrgRoleRequests.service", "./autoCompleteWorkaround", "./userProfileCreationModalPrompt.component", "./team-packet-creation-modal.component", "./orgHeading.component", "./formsOrgChooser.component", "./intercomRouterTracker.service", "./teams.component", "./teams.resolve", "./shared.service", "./teams-players-box.component", "./teams-player-details.component", "./teams-player-details.resolve", "./site-search.service", "./search-popup.component", "./team-organization-box.component", "./teams-player-injury.component", "./documents.component", "./documentlist-media.component", "./change-password.component", "./helper.service", "./teams-form.component", "./packet-form-modal.component", "./usa-map.component", "./assign-form-model.component", "./save-form-guard", 'ngx-swiper-wrapper', './toscheck-model.component', './tosaccept.service', './reset-scroll-history', "./select-form.component", "./basic_medical_saver.service", "./relationdata.component", "./invite-modal.component", "./insurance_image.component", "./base64Encoder"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, platform_browser_1, forms_1, common_1, app_component_1, app_routing_1, athlete_registration_component_1, landing_component_1, ath_doc_dashboard_component_1, athlete_doc_form_component_1, basic_medical_form_component_1, http_1, registration_context_service_1, userAccount_service_1, registration_heading_component_1, profileTypeChooser_component_1, user_profiles_service_1, ownProfileCreator_component_1, app_base_request_options_1, defaultSportChooser_component_1, appExceptionHandler_service_1, relatedProfilesList_component_1, relatedProfile_component_1, landing_blank_component_1, max_forms_shell_component_1, parentChildFormsContextChooser_component_1, relatedProfileCreator_component_1, cover_component_1, login_component_1, signup_component_1, verifyAccount_component_1, forgot_pass_component_1, reset_pass_component_1, maxAppContext_service_1, organizations_service_1, packetList_component_1, activities_service_1, assignments_service_1, df_pl_uploader_ng2_directive_1, userProfile_component_1, df_pl_uploads_ng2_1, status_handler_registry_ng2_1, adminMenu_component_1, angular2_modal_1, bootstrap_1, document_data_expression_pipe_1, combo_day_picker_1, document_change_saver_service_1, document_factory_service_1, document_expression_evaluator_1, document_loader_service_1, activity_auth_service_1, angular2_recaptcha_1, ng2_bootstrap_1, ng2_dnd_1, formsProfileEditor_component_1, admin_event_view_component_1, pending_profile_approval_component_1, admin_form_print_modal_1, accessRequestApprovalModal_component_1, teamInfo_service_1, confirmProfileDelete_1, getTheApp_component_1, phoneDisplay_pipe_1, key_value_pipe_1, teams_players_component_1, orgContextChooser_component_1, linkedOrgRoleRequests_service_1, autoCompleteWorkaround_1, userProfileCreationModalPrompt_component_1, team_packet_creation_modal_component_1, orgHeading_component_1, formsOrgChooser_component_1, intercomRouterTracker_service_1, teams_component_1, teams_players_component_2, teams_resolve_1, shared_service_1, teams_players_box_component_1, teams_player_details_component_1, teams_player_details_resolve_1, site_search_service_1, search_popup_component_1, team_organization_box_component_1, teams_player_injury_component_1, documents_component_1, documents_component_2, documentlist_media_component_1, change_password_component_1, helper_service_1, teams_form_component_1, packet_form_modal_component_1, usa_map_component_1, assign_form_model_component_1, save_form_guard_1, ngx_swiper_wrapper_1, toscheck_model_component_1, tosaccept_service_1, reset_scroll_history_1, select_form_component_1, teams_players_box_component_2, teams_players_box_component_3, basic_medical_saver_service_1, relationdata_component_1, invite_modal_component_1, insurance_image_component_1, base64Encoder_1;
    var SWIPER_CONFIG, AppModule;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (platform_browser_1_1) {
                platform_browser_1 = platform_browser_1_1;
            },
            function (forms_1_1) {
                forms_1 = forms_1_1;
            },
            function (common_1_1) {
                common_1 = common_1_1;
            },
            function (app_component_1_1) {
                app_component_1 = app_component_1_1;
            },
            function (app_routing_1_1) {
                app_routing_1 = app_routing_1_1;
            },
            function (athlete_registration_component_1_1) {
                athlete_registration_component_1 = athlete_registration_component_1_1;
            },
            function (landing_component_1_1) {
                landing_component_1 = landing_component_1_1;
            },
            function (ath_doc_dashboard_component_1_1) {
                ath_doc_dashboard_component_1 = ath_doc_dashboard_component_1_1;
            },
            function (athlete_doc_form_component_1_1) {
                athlete_doc_form_component_1 = athlete_doc_form_component_1_1;
            },
            function (basic_medical_form_component_1_1) {
                basic_medical_form_component_1 = basic_medical_form_component_1_1;
            },
            function (http_1_1) {
                http_1 = http_1_1;
            },
            function (registration_context_service_1_1) {
                registration_context_service_1 = registration_context_service_1_1;
            },
            function (userAccount_service_1_1) {
                userAccount_service_1 = userAccount_service_1_1;
            },
            function (registration_heading_component_1_1) {
                registration_heading_component_1 = registration_heading_component_1_1;
            },
            function (profileTypeChooser_component_1_1) {
                profileTypeChooser_component_1 = profileTypeChooser_component_1_1;
            },
            function (user_profiles_service_1_1) {
                user_profiles_service_1 = user_profiles_service_1_1;
            },
            function (ownProfileCreator_component_1_1) {
                ownProfileCreator_component_1 = ownProfileCreator_component_1_1;
            },
            function (app_base_request_options_1_1) {
                app_base_request_options_1 = app_base_request_options_1_1;
            },
            function (defaultSportChooser_component_1_1) {
                defaultSportChooser_component_1 = defaultSportChooser_component_1_1;
            },
            function (appExceptionHandler_service_1_1) {
                appExceptionHandler_service_1 = appExceptionHandler_service_1_1;
            },
            function (relatedProfilesList_component_1_1) {
                relatedProfilesList_component_1 = relatedProfilesList_component_1_1;
            },
            function (relatedProfile_component_1_1) {
                relatedProfile_component_1 = relatedProfile_component_1_1;
            },
            function (landing_blank_component_1_1) {
                landing_blank_component_1 = landing_blank_component_1_1;
            },
            function (max_forms_shell_component_1_1) {
                max_forms_shell_component_1 = max_forms_shell_component_1_1;
            },
            function (parentChildFormsContextChooser_component_1_1) {
                parentChildFormsContextChooser_component_1 = parentChildFormsContextChooser_component_1_1;
            },
            function (relatedProfileCreator_component_1_1) {
                relatedProfileCreator_component_1 = relatedProfileCreator_component_1_1;
            },
            function (cover_component_1_1) {
                cover_component_1 = cover_component_1_1;
            },
            function (login_component_1_1) {
                login_component_1 = login_component_1_1;
            },
            function (signup_component_1_1) {
                signup_component_1 = signup_component_1_1;
            },
            function (verifyAccount_component_1_1) {
                verifyAccount_component_1 = verifyAccount_component_1_1;
            },
            function (forgot_pass_component_1_1) {
                forgot_pass_component_1 = forgot_pass_component_1_1;
            },
            function (reset_pass_component_1_1) {
                reset_pass_component_1 = reset_pass_component_1_1;
            },
            function (maxAppContext_service_1_1) {
                maxAppContext_service_1 = maxAppContext_service_1_1;
            },
            function (organizations_service_1_1) {
                organizations_service_1 = organizations_service_1_1;
            },
            function (packetList_component_1_1) {
                packetList_component_1 = packetList_component_1_1;
            },
            function (activities_service_1_1) {
                activities_service_1 = activities_service_1_1;
            },
            function (assignments_service_1_1) {
                assignments_service_1 = assignments_service_1_1;
            },
            function (df_pl_uploader_ng2_directive_1_1) {
                df_pl_uploader_ng2_directive_1 = df_pl_uploader_ng2_directive_1_1;
            },
            function (userProfile_component_1_1) {
                userProfile_component_1 = userProfile_component_1_1;
            },
            function (df_pl_uploads_ng2_1_1) {
                df_pl_uploads_ng2_1 = df_pl_uploads_ng2_1_1;
            },
            function (status_handler_registry_ng2_1_1) {
                status_handler_registry_ng2_1 = status_handler_registry_ng2_1_1;
            },
            function (adminMenu_component_1_1) {
                adminMenu_component_1 = adminMenu_component_1_1;
            },
            function (angular2_modal_1_1) {
                angular2_modal_1 = angular2_modal_1_1;
            },
            function (bootstrap_1_1) {
                bootstrap_1 = bootstrap_1_1;
            },
            function (document_data_expression_pipe_1_1) {
                document_data_expression_pipe_1 = document_data_expression_pipe_1_1;
            },
            function (combo_day_picker_1_1) {
                combo_day_picker_1 = combo_day_picker_1_1;
            },
            function (document_change_saver_service_1_1) {
                document_change_saver_service_1 = document_change_saver_service_1_1;
            },
            function (document_factory_service_1_1) {
                document_factory_service_1 = document_factory_service_1_1;
            },
            function (document_expression_evaluator_1_1) {
                document_expression_evaluator_1 = document_expression_evaluator_1_1;
            },
            function (document_loader_service_1_1) {
                document_loader_service_1 = document_loader_service_1_1;
            },
            function (activity_auth_service_1_1) {
                activity_auth_service_1 = activity_auth_service_1_1;
            },
            function (angular2_recaptcha_1_1) {
                angular2_recaptcha_1 = angular2_recaptcha_1_1;
            },
            function (ng2_bootstrap_1_1) {
                ng2_bootstrap_1 = ng2_bootstrap_1_1;
            },
            function (ng2_dnd_1_1) {
                ng2_dnd_1 = ng2_dnd_1_1;
            },
            function (formsProfileEditor_component_1_1) {
                formsProfileEditor_component_1 = formsProfileEditor_component_1_1;
            },
            function (admin_event_view_component_1_1) {
                admin_event_view_component_1 = admin_event_view_component_1_1;
            },
            function (pending_profile_approval_component_1_1) {
                pending_profile_approval_component_1 = pending_profile_approval_component_1_1;
            },
            function (admin_form_print_modal_1_1) {
                admin_form_print_modal_1 = admin_form_print_modal_1_1;
            },
            function (accessRequestApprovalModal_component_1_1) {
                accessRequestApprovalModal_component_1 = accessRequestApprovalModal_component_1_1;
            },
            function (teamInfo_service_1_1) {
                teamInfo_service_1 = teamInfo_service_1_1;
            },
            function (confirmProfileDelete_1_1) {
                confirmProfileDelete_1 = confirmProfileDelete_1_1;
            },
            function (getTheApp_component_1_1) {
                getTheApp_component_1 = getTheApp_component_1_1;
            },
            function (phoneDisplay_pipe_1_1) {
                phoneDisplay_pipe_1 = phoneDisplay_pipe_1_1;
            },
            function (key_value_pipe_1_1) {
                key_value_pipe_1 = key_value_pipe_1_1;
            },
            function (teams_players_component_1_1) {
                teams_players_component_1 = teams_players_component_1_1;
                teams_players_component_2 = teams_players_component_1_1;
            },
            function (orgContextChooser_component_1_1) {
                orgContextChooser_component_1 = orgContextChooser_component_1_1;
            },
            function (linkedOrgRoleRequests_service_1_1) {
                linkedOrgRoleRequests_service_1 = linkedOrgRoleRequests_service_1_1;
            },
            function (autoCompleteWorkaround_1_1) {
                autoCompleteWorkaround_1 = autoCompleteWorkaround_1_1;
            },
            function (userProfileCreationModalPrompt_component_1_1) {
                userProfileCreationModalPrompt_component_1 = userProfileCreationModalPrompt_component_1_1;
            },
            function (team_packet_creation_modal_component_1_1) {
                team_packet_creation_modal_component_1 = team_packet_creation_modal_component_1_1;
            },
            function (orgHeading_component_1_1) {
                orgHeading_component_1 = orgHeading_component_1_1;
            },
            function (formsOrgChooser_component_1_1) {
                formsOrgChooser_component_1 = formsOrgChooser_component_1_1;
            },
            function (intercomRouterTracker_service_1_1) {
                intercomRouterTracker_service_1 = intercomRouterTracker_service_1_1;
            },
            function (teams_component_1_1) {
                teams_component_1 = teams_component_1_1;
            },
            function (teams_resolve_1_1) {
                teams_resolve_1 = teams_resolve_1_1;
            },
            function (shared_service_1_1) {
                shared_service_1 = shared_service_1_1;
            },
            function (teams_players_box_component_1_1) {
                teams_players_box_component_1 = teams_players_box_component_1_1;
                teams_players_box_component_2 = teams_players_box_component_1_1;
                teams_players_box_component_3 = teams_players_box_component_1_1;
            },
            function (teams_player_details_component_1_1) {
                teams_player_details_component_1 = teams_player_details_component_1_1;
            },
            function (teams_player_details_resolve_1_1) {
                teams_player_details_resolve_1 = teams_player_details_resolve_1_1;
            },
            function (site_search_service_1_1) {
                site_search_service_1 = site_search_service_1_1;
            },
            function (search_popup_component_1_1) {
                search_popup_component_1 = search_popup_component_1_1;
            },
            function (team_organization_box_component_1_1) {
                team_organization_box_component_1 = team_organization_box_component_1_1;
            },
            function (teams_player_injury_component_1_1) {
                teams_player_injury_component_1 = teams_player_injury_component_1_1;
            },
            function (documents_component_1_1) {
                documents_component_1 = documents_component_1_1;
                documents_component_2 = documents_component_1_1;
            },
            function (documentlist_media_component_1_1) {
                documentlist_media_component_1 = documentlist_media_component_1_1;
            },
            function (change_password_component_1_1) {
                change_password_component_1 = change_password_component_1_1;
            },
            function (helper_service_1_1) {
                helper_service_1 = helper_service_1_1;
            },
            function (teams_form_component_1_1) {
                teams_form_component_1 = teams_form_component_1_1;
            },
            function (packet_form_modal_component_1_1) {
                packet_form_modal_component_1 = packet_form_modal_component_1_1;
            },
            function (usa_map_component_1_1) {
                usa_map_component_1 = usa_map_component_1_1;
            },
            function (assign_form_model_component_1_1) {
                assign_form_model_component_1 = assign_form_model_component_1_1;
            },
            function (save_form_guard_1_1) {
                save_form_guard_1 = save_form_guard_1_1;
            },
            function (ngx_swiper_wrapper_1_1) {
                ngx_swiper_wrapper_1 = ngx_swiper_wrapper_1_1;
            },
            function (toscheck_model_component_1_1) {
                toscheck_model_component_1 = toscheck_model_component_1_1;
            },
            function (tosaccept_service_1_1) {
                tosaccept_service_1 = tosaccept_service_1_1;
            },
            function (reset_scroll_history_1_1) {
                reset_scroll_history_1 = reset_scroll_history_1_1;
            },
            function (select_form_component_1_1) {
                select_form_component_1 = select_form_component_1_1;
            },
            function (basic_medical_saver_service_1_1) {
                basic_medical_saver_service_1 = basic_medical_saver_service_1_1;
            },
            function (relationdata_component_1_1) {
                relationdata_component_1 = relationdata_component_1_1;
            },
            function (invite_modal_component_1_1) {
                invite_modal_component_1 = invite_modal_component_1_1;
            },
            function (insurance_image_component_1_1) {
                insurance_image_component_1 = insurance_image_component_1_1;
            },
            function (base64Encoder_1_1) {
                base64Encoder_1 = base64Encoder_1_1;
            }],
        execute: function() {
            SWIPER_CONFIG = {
                direction: 'horizontal',
                slidesPerView: 4,
                freeMode: true,
                initialSlide: 1,
                spaceBetween: 0,
                centeredSlides: true,
                observer: true,
                nextButton: '.swiper-button-next',
                prevButton: '.swiper-button-prev',
                pagination: '.swiper-pagination',
            };
            AppModule = (function () {
                function AppModule() {
                }
                AppModule = __decorate([
                    core_1.NgModule({
                        imports: [
                            platform_browser_1.BrowserModule,
                            forms_1.FormsModule,
                            forms_1.ReactiveFormsModule,
                            http_1.HttpModule,
                            http_1.JsonpModule,
                            app_routing_1.routing,
                            angular2_modal_1.ModalModule.forRoot(),
                            bootstrap_1.BootstrapModalModule,
                            ng2_bootstrap_1.Ng2BootstrapModule,
                            ng2_dnd_1.DndModule.forRoot(),
                            ngx_swiper_wrapper_1.SwiperModule.forRoot(SWIPER_CONFIG)
                        ],
                        declarations: [
                            app_component_1.AppComponent,
                            landing_component_1.LandingComponent,
                            athlete_registration_component_1.AthleteRegistration,
                            ath_doc_dashboard_component_1.AthDocDashboard,
                            athlete_doc_form_component_1.AthleteDocumentationForm,
                            registration_heading_component_1.RegistrationHeading,
                            profileTypeChooser_component_1.ProfileTypeChooser,
                            ownProfileCreator_component_1.OwnProfileCreator,
                            defaultSportChooser_component_1.DefaultSportChooser,
                            relatedProfilesList_component_1.RelatedProfilesList,
                            relatedProfile_component_1.RelatedProfile,
                            max_forms_shell_component_1.MaxFormsShell,
                            landing_blank_component_1.LandingComponentBlank,
                            parentChildFormsContextChooser_component_1.ParentChildFormsContextChooser,
                            relatedProfileCreator_component_1.RelatedProfileCreator,
                            cover_component_1.CoverShell,
                            login_component_1.LoginComponent,
                            signup_component_1.SignupComponent,
                            verifyAccount_component_1.AccountVerificationComponent,
                            forgot_pass_component_1.ForgotPassComponent,
                            reset_pass_component_1.ResetPassComponent,
                            packetList_component_1.PacketList,
                            df_pl_uploader_ng2_directive_1.DfPlUploadHost,
                            userProfile_component_1.UserProfileComponent,
                            adminMenu_component_1.MaxAdminMenuComponent,
                            athlete_doc_form_component_1.DataItemPipe,
                            basic_medical_form_component_1.BasicMedicalPipe,
                            document_data_expression_pipe_1.DocumentDataExpressionPipe,
                            combo_day_picker_1.ComboDayPicker,
                            angular2_recaptcha_1.ReCaptchaComponent,
                            formsProfileEditor_component_1.FormsProfileEditor,
                            admin_event_view_component_1.AdminEventView,
                            pending_profile_approval_component_1.PendingProfilesView,
                            admin_form_print_modal_1.AdminFormPrintModal,
                            accessRequestApprovalModal_component_1.AccessRequestApprovalModal,
                            userProfileCreationModalPrompt_component_1.UserProfileCreationModalPrompt,
                            team_packet_creation_modal_component_1.TeamPacketCreationModalPrompt,
                            getTheApp_component_1.GetTheAppComponent,
                            phoneDisplay_pipe_1.PhoneDisplayPipe,
                            key_value_pipe_1.KeysPipe,
                            teams_players_component_1.filterPipe,
                            orgContextChooser_component_1.OrgContextChooser,
                            orgHeading_component_1.OrgHeadingComponent,
                            formsOrgChooser_component_1.FormsOrgChooserComponent,
                            teams_component_1.TeamsComponent,
                            teams_players_component_2.TeamsPlayersComponent,
                            teams_players_box_component_1.TeamsPlayersBoxComponent,
                            teams_player_details_component_1.TeamsPlayerDetailsComponent,
                            search_popup_component_1.SearchPopupComponent,
                            team_organization_box_component_1.TeamOrganizationBoxComponent,
                            teams_player_injury_component_1.TeamsPlayerInjuryComponent,
                            documents_component_1.DocumentsComponent,
                            documents_component_2.hiddenPipe,
                            documentlist_media_component_1.DocumentlistMediaComponent,
                            change_password_component_1.ChangePasswordModal,
                            teams_form_component_1.TeamsFormComponent,
                            packet_form_modal_component_1.PacketFormModal,
                            usa_map_component_1.UsaMapComponent,
                            assign_form_model_component_1.AssignFormModal,
                            toscheck_model_component_1.TosCheckModal,
                            select_form_component_1.SelectFormComponent,
                            teams_players_box_component_2.TeamsPlayersListComponent,
                            teams_players_box_component_3.TeamsPlayersEligibilityComponent,
                            basic_medical_form_component_1.BasicMedicalForm,
                            relationdata_component_1.RelationComponent,
                            invite_modal_component_1.InviteModal,
                            insurance_image_component_1.InsuranceImageBoxComponent,
                            insurance_image_component_1.InsuranceImageSetComponent
                        ],
                        bootstrap: [app_component_1.AppComponent],
                        providers: [
                            common_1.DatePipe,
                            maxAppContext_service_1.MaxAppContext,
                            autoCompleteWorkaround_1.AutoCompleteWorkaround,
                            intercomRouterTracker_service_1.IntercomRouterTracker,
                            registration_context_service_1.RegistrationContext,
                            userAccount_service_1.UserAccountService,
                            user_profiles_service_1.UserProfiles,
                            organizations_service_1.Organizations,
                            linkedOrgRoleRequests_service_1.LinkedOrgRoleRequests,
                            activities_service_1.Activities,
                            activity_auth_service_1.ActivityAuthorizer,
                            assignments_service_1.Assignments,
                            teamInfo_service_1.TeamInfo,
                            df_pl_uploads_ng2_1.DfPlUploads2,
                            status_handler_registry_ng2_1.StatusHandlerRegistry,
                            confirmProfileDelete_1.ProfileUtil,
                            teams_resolve_1.OrganizationStructureResolve,
                            teams_player_details_resolve_1.TeamsPlayerDetailsResolve,
                            shared_service_1.SharedService,
                            site_search_service_1.SiteSearchService,
                            helper_service_1.Helper,
                            save_form_guard_1.SaveFormGuard,
                            reset_scroll_history_1.ResetScrollHistory,
                            tosaccept_service_1.Tosaccept,
                            base64Encoder_1.Base64Encoder,
                            document_factory_service_1.Documents,
                            document_change_saver_service_1.DocumentChangeSaver,
                            document_loader_service_1.DocumentLoader,
                            document_expression_evaluator_1.DocumentExpressionEvaluator,
                            basic_medical_saver_service_1.BasicMedicalSaver,
                            { provide: http_1.RequestOptions, useClass: app_base_request_options_1.AppBaseRequestOptions },
                            { provide: core_1.ErrorHandler, useClass: appExceptionHandler_service_1.MaxAppExceptionHandler }
                        ].concat(app_routing_1.routingProviders),
                        entryComponents: [
                            admin_form_print_modal_1.AdminFormPrintModal,
                            accessRequestApprovalModal_component_1.AccessRequestApprovalModal,
                            change_password_component_1.ChangePasswordModal,
                            packet_form_modal_component_1.PacketFormModal,
                            userProfileCreationModalPrompt_component_1.UserProfileCreationModalPrompt,
                            assign_form_model_component_1.AssignFormModal,
                            team_packet_creation_modal_component_1.TeamPacketCreationModalPrompt,
                            toscheck_model_component_1.TosCheckModal,
                            invite_modal_component_1.InviteModal
                        ]
                    }), 
                    __metadata('design:paramtypes', [])
                ], AppModule);
                return AppModule;
            }());
            exports_1("AppModule", AppModule);
        }
    }
});
//# sourceMappingURL=app.module.js.map