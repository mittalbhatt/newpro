System.register(["@angular/core", "./user_profiles.service", "@angular/router", "./organizations.service", "@angular/platform-browser", "./registration_context.service", "./userAccount.service", "./intercomRouterTracker.service"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, user_profiles_service_1, router_1, organizations_service_1, platform_browser_1, registration_context_service_1, userAccount_service_1, intercomRouterTracker_service_1;
    var MaxAppContext;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (user_profiles_service_1_1) {
                user_profiles_service_1 = user_profiles_service_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (organizations_service_1_1) {
                organizations_service_1 = organizations_service_1_1;
            },
            function (platform_browser_1_1) {
                platform_browser_1 = platform_browser_1_1;
            },
            function (registration_context_service_1_1) {
                registration_context_service_1 = registration_context_service_1_1;
            },
            function (userAccount_service_1_1) {
                userAccount_service_1 = userAccount_service_1_1;
            },
            function (intercomRouterTracker_service_1_1) {
                intercomRouterTracker_service_1 = intercomRouterTracker_service_1_1;
            }],
        execute: function() {
            MaxAppContext = (function () {
                function MaxAppContext(_router, _userProfiles, _organizations, _accounts, _sanitizer, _regCtx, _intercom) {
                    this._router = _router;
                    this._userProfiles = _userProfiles;
                    this._organizations = _organizations;
                    this._accounts = _accounts;
                    this._sanitizer = _sanitizer;
                    this._regCtx = _regCtx;
                    this._intercom = _intercom;
                }
                MaxAppContext.prototype.canActivate = function (route, state) {
                    //console.log('MaxAppCtx');
                    this.orgId = route.queryParams['orgId'] || this.orgId;
                    return this.initialize(state.url);
                };
                MaxAppContext.prototype.initialize = function (url, rebootIntercom) {
                    var _this = this;
                    if (url === void 0) { url = null; }
                    if (rebootIntercom === void 0) { rebootIntercom = false; }
                    return Promise.all([
                        this._accounts.getMyUserAccount(),
                        this._userProfiles.getMine().single().toPromise(),
                        this._organizations.getOrganizations().single().toPromise()])
                        .then(function (_a) {
                        // console.log("============");
                        // console.log(myProfiles);
                        // console.log("============");
                        var account = _a[0], myProfiles = _a[1], organizations = _a[2];
                        if (!_this.intercomBooted || rebootIntercom) {
                            window.Intercom(rebootIntercom ? "update" : "boot", account.$intercomPayload);
                            _this.intercomBooted = true;
                        }
                        _this.myProfiles = myProfiles.map(function (p) { return new user_profiles_service_1.UserProfile(p); });
                        _this.availableOrganizations = organizations;
                        _this.myOrganizations = organizations.filter(function (o) { return !!myProfiles.find(function (p) { return p.org == o._id; }); });
                        _this.currentAccount = account;
                        if (!_this.orgId && myProfiles[0])
                            _this.orgId = myProfiles[0].org;
                        if (!_this.currentOrg || _this.currentOrg._id != _this.orgId)
                            _this.currentOrg = _.find(_this.myOrganizations, function (o) { return o._id == _this.orgId; });
                        // console.log('Current org :', this.currentOrg);
                        _this.currentProfile = _.find(_this.myProfiles, function (p) { return p.org == _this.orgId; });
                        if (!_this.currentProfile) {
                            _this.currentProfile = _.find(_this.myProfiles, function (p) { return !!_.find(p.linkedOrgRoles, function (lor) { return lor.orgId == _this.orgId; }); });
                            if (_this.currentProfile) {
                                _this.orgId = _this.currentProfile.org;
                                _this.currentOrg = _.find(_this.availableOrganizations, function (o) { return o._id == _this.orgId; });
                            }
                        }
                        // console.log(this.currentProfile);
                        if (!_this.currentProfile) {
                            if (url && url.indexOf('create-own-profile') < 0)
                                _this._userProfiles.createProfileRedirectUrl = url;
                            var ret = true;
                            if (window.location.href.indexOf('create-own-profile') < 0 && (!url || url.indexOf('create-own-profile') < 0) && sessionStorage['createlogin'] == undefined) {
                                sessionStorage['createlogin'] = 'signintrue';
                                console.log('No current profile, redirecting to create.');
                                _this._router.navigateByUrl('/max-forms/create-own-profile');
                                ret = false;
                            }
                            if (_this.orgId) {
                                return _this._organizations.getOrgFromDirectory(_this.orgId).single().toPromise().then(function (o) {
                                    _this.currentOrg = o;
                                    if (_this.currentOrg)
                                        _this.currentOrgLogoBlobUrl = _this.currentOrg['logoUrl'];
                                    return ret;
                                });
                            }
                            return ret;
                        }
                        _this._organizations.getLogo(_this.currentOrg).single().toPromise()
                            .then(function (l) {
                            if (l)
                                _this.currentOrgLogoBlobUrl = _this._sanitizer.bypassSecurityTrustResourceUrl(l);
                        });
                        return true;
                    });
                };
                Object.defineProperty(MaxAppContext.prototype, "orgId", {
                    get: function () {
                        return store.session(MaxAppContext.ORG_ID);
                    },
                    set: function (value) {
                        if (!value)
                            store.session.remove(MaxAppContext.ORG_ID);
                        else
                            store.session(MaxAppContext.ORG_ID, value);
                    },
                    enumerable: true,
                    configurable: true
                });
                MaxAppContext.prototype.logout = function (nav) {
                    if (nav === void 0) { nav = true; }
                    store.clearAll();
                    delete this.myProfiles;
                    delete this.myOrganizations;
                    delete this.availableOrganizations;
                    delete this.currentOrg;
                    delete this.currentOrgLogoBlobUrl;
                    delete this.currentProfile;
                    delete this.currentAccount;
                    delete this._regCtx.persistent;
                    window.Intercom('shutdown');
                    this.intercomBooted = false;
                    this._intercom.loggedOutBoot();
                    if (nav)
                        this._router.navigateByUrl('/max-cover/login');
                    // window.location.replace('http://www.dragonflymax.com');
                };
                MaxAppContext.prototype.resetOrg = function () {
                    store.session.remove(MaxAppContext.ORG_ID);
                    delete this.currentOrgLogoBlobUrl;
                    this._router.navigateByUrl('/max-forms/create-own-profile');
                };
                MaxAppContext.prototype.getStates = function () {
                    var stateObj = [
                        { key: "OT", value: "Other" },
                        { key: "AL", value: "Alabama" },
                        { key: "AK", value: "Alaska" },
                        { key: "AZ", value: "Arizona" },
                        { key: "AR", value: "Arkansas" },
                        { key: "CA", value: "California" },
                        { key: "CO", value: "Colorado" },
                        { key: "CT", value: "Connecticut" },
                        { key: "DC", value: "District of Columbia" },
                        { key: "DE", value: "Deleware" },
                        { key: "FL", value: "Florida" },
                        { key: "GA", value: "Georgia" },
                        { key: "HI", value: "Hawaii" },
                        { key: "ID", value: "Idaho" },
                        { key: "IL", value: "Illinois" },
                        { key: "IN", value: "Indiana" },
                        { key: "IA", value: "Iowa" },
                        { key: "KS", value: "Kansas" },
                        { key: "KY", value: "Kentucky" },
                        { key: "LA", value: "Louisiana" },
                        { key: "ME", value: "Maine" },
                        { key: "MD", value: "Maryland" },
                        { key: "MA", value: "Massachusetts" },
                        { key: "MI", value: "Michigan" },
                        { key: "MS", value: "Mississippi" },
                        { key: "MN", value: "Minnesota" },
                        { key: "MO", value: "Missouri" },
                        { key: "MT", value: "Montana" },
                        { key: "NE", value: "Nebraska" },
                        { key: "NV", value: "Nevada" },
                        { key: "NH", value: "New Hampshire" },
                        { key: "NJ", value: "New Jersey" },
                        { key: "NM", value: "New Mexico" },
                        { key: "NY", value: "New York" },
                        { key: "NC", value: "North Carolina" },
                        { key: "ND", value: "North Dakota" },
                        { key: "OH", value: "Ohio" },
                        { key: "OK", value: "Oklahoma" },
                        { key: "OR", value: "Oregon" },
                        { key: "PA", value: "Pennsylvania" },
                        { key: "RI", value: "Rhode Island" },
                        { key: "SC", value: "South Carolina" },
                        { key: "SD", value: "South Dakota" },
                        { key: "TN", value: "Tennessee" },
                        { key: "TX", value: "Texas" },
                        { key: "UT", value: "Utah" },
                        { key: "VT", value: "Vermont" },
                        { key: "VA", value: "Virginia" },
                        { key: "WA", value: "Washington" },
                        { key: "WV", value: "West Virginia" },
                        { key: "WI", value: "Wisconsin" },
                        { key: "WY", value: "Wyoming" }
                    ];
                    return stateObj;
                };
                MaxAppContext.prototype.getParents = function () {
                    var parentObj = [
                        { key: "Mother", value: "Mother" },
                        { key: "Father", value: "Father" },
                        { key: "Grandmother", value: "Grandmother" },
                        { key: "Grandfather", value: "Grandfather" },
                        { key: "Guardian", value: "Guardian" },
                    ];
                    return parentObj;
                };
                MaxAppContext.ORG_ID = 'df_orgId';
                MaxAppContext = __decorate([
                    core_1.Injectable(), 
                    __metadata('design:paramtypes', [router_1.Router, user_profiles_service_1.UserProfiles, organizations_service_1.Organizations, userAccount_service_1.UserAccountService, platform_browser_1.DomSanitizer, registration_context_service_1.RegistrationContext, intercomRouterTracker_service_1.IntercomRouterTracker])
                ], MaxAppContext);
                return MaxAppContext;
            }());
            exports_1("MaxAppContext", MaxAppContext);
        }
    }
});
//# sourceMappingURL=maxAppContext.service.js.map