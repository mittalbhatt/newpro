import {Http, Response, RequestOptions, Headers} from "@angular/http";
import {Injectable} from "@angular/core";
import * as _ from "underscore";
import {DfObjectId} from "./DfObjectId";

declare var store;

export class Username
{
    username:string;
    type:string;
}

export class UserAccount
{
    constructor(id?:string)
    {
        this._id = (new DfObjectId(id)).toString();
    }

    _id:string;
    firstName:string;
    lastName:string;
    usernames:Username[];
    password:string;
}

export class PasswordResetRequestResponse
{
    userAccountId:string;
}

@Injectable()
export class UserAccountService
{
    cachedPendingAccount:UserAccount;

    constructor(private _http:Http)
    {
        // console.log(this.cachedPendingAccount);
    }

    saveAccount(acct:UserAccount, recaptchaResponse:any)
    {
        let body = _.extend({recaptchaResponse:recaptchaResponse}, acct);
        return this._http.put('/training/api/userAccount', body)
            .single()
            .toPromise();
    }

    requestVerification(username:string)
    {
        if (!this.cachedPassword)
            throw new Error('A password must be cached prior to requesting verification.');

        return this._http.post(`/training/api/accounts/verify/${encodeURIComponent(username)}`, null,
                {headers:new Headers({'Authorization':'Basic ' + btoa(`${username}:${this.cachedPassword}`)})}
            )
            .single()
            .toPromise();
    }

    fulfillVerification(username:string, code:string)
    {
        return this._http.get(`/training/api/accounts/verify/${username}?code=${code}`)
            .single()
            .toPromise();
    }

    requestPasswordReset(username:string)
    {
        let body = _.extend({}, {username: username});
        return this._http.post('/training/api/accounts/passwordResets', body)
            .map((res:Response) => <PasswordResetRequestResponse>res.json())
            .single()
            .toPromise();
    }

    resetPassword(userAccountId:string, username:string, password:string, code:string)
    {
        let body = {password:password};
        return this._http.post(`/training/api/accounts/${userAccountId}/passwordUpdates`, body,
            { headers: new Headers({'df-max-auth-confirm-username':username, 'df-max-auth-password-reset-code': code}) }
            )
            .single()
            .toPromise();
    }

    getMyUserAccount()
    {
        return this._http.get(`/training/api/accounts/mine`)
            .map((res:Response) => <UserAccount>res.json())
            .single()
            .toPromise();
    }

    get cachedPassword()
    {
        return store.session('CachedPassword');
    }

    set cachedPassword(value:string)
    {
        store.session('CachedPassword', value);
    }

    changePassword(userAccountId:string, password:string)
    {
        userAccountId = (new DfObjectId(userAccountId)).toString();
        let body = {password:password};
        // console.log(body);
        // console.log(userAccountId);
        
        return this._http.post(`/training/api/accounts/${userAccountId}/passwordUpdates`, body)
            .single()
            .toPromise();
    }

    getTosData(versionnumber:number)
    {
        return this._http.get(`/training/api/tos/${versionnumber}`)
            .map((res:Response) => res.json())
            .single()
            .toPromise();
    }

    updattosversion(versionnumberget:any)
    {
        return this._http.put('/training/api/accounts/mine/tos/acceptances', versionnumberget);
    }
}