System.register(["@angular/core", "@angular/http"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var __param = (this && this.__param) || function (paramIndex, decorator) {
        return function (target, key) { decorator(target, key, paramIndex); }
    };
    var core_1, http_1;
    var DocumentLoader;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (http_1_1) {
                http_1 = http_1_1;
            }],
        execute: function() {
            DocumentLoader = (function () {
                function DocumentLoader(_requestOps) {
                    this._requestOps = _requestOps;
                }
                DocumentLoader.prototype.openPdf = function (docId, window, pages) {
                    if (pages === void 0) { pages = ''; }
                    var url = "/training/api/documents/" + docId + "/pdf";
                    if (pages && pages.length)
                        url += '?pages=' + pages;
                    return this.requestPdf(window, 'GET', url);
                };
                DocumentLoader.prototype.openpacketformsPdf = function (activityId, window, pages) {
                    if (pages === void 0) { pages = ''; }
                    var url = "/training/api/activities/documentation/" + activityId + "/pdf";
                    if (pages && pages.length)
                        url += '?pages=' + pages;
                    return this.requestPdf(window, 'GET', url);
                };
                DocumentLoader.prototype.opengettingstartedPdf = function (currentOrgDetailsId, username, password, window, pages) {
                    if (pages === void 0) { pages = ''; }
                    var url = "/training/api/organizations/" + currentOrgDetailsId + "/parentSheet?auth.basic.username=" + username + "&auth.basic.password=" + password;
                    if (pages && pages.length)
                        url += '?pages=' + pages;
                    return this.requestPdf(window, 'GET', url);
                };
                DocumentLoader.prototype.openBulkPdf = function (documentStableIds, window) {
                    return this.requestPdf(window, 'PUT', '/training/api/documentbulk?cover=true', JSON.stringify(documentStableIds));
                };
                DocumentLoader.prototype.requestPdf = function (window, method, url, content) {
                    if (content === void 0) { content = undefined; }
                    var pdfWindow;
                    // Pointing the window to the blob does not work on lte IE 11, but they have
                    // their own method that does.
                    if (!window.navigator.msSaveOrOpenBlob)
                        pdfWindow = window.open("/maxweb/app/media/spinner.html");
                    var xhr = new XMLHttpRequest();
                    var p = new Promise(function (resolve, reject) {
                        xhr.addEventListener('load', function (r) {
                            if (xhr.status != 200) {
                                reject(r);
                                return;
                            }
                            var pdfBlob = new Blob([xhr.response], { type: 'application/pdf' });
                            if (!pdfWindow)
                                window.navigator.msSaveOrOpenBlob(pdfBlob, "document.pdf");
                            else
                                pdfWindow.location = (window.URL || window.webkitURL).createObjectURL(pdfBlob);
                            resolve();
                        });
                        xhr.addEventListener('error', function (e) {
                            reject(e);
                        });
                    });
                    p.catch(function () { if (pdfWindow)
                        pdfWindow.close(); });
                    xhr.open(method, url, true);
                    // IMPORTANT: for IE 11 to work you must set this after calling .open(...)
                    xhr.responseType = 'blob';
                    if (content)
                        xhr.setRequestHeader('Content-Type', 'application/json');
                    xhr.setRequestHeader('Authorization', this._requestOps.headers.get('Authorization'));
                    xhr.send(content);
                    return p;
                };
                DocumentLoader = __decorate([
                    core_1.Injectable(),
                    __param(0, core_1.Inject(http_1.RequestOptions)), 
                    __metadata('design:paramtypes', [http_1.RequestOptions])
                ], DocumentLoader);
                return DocumentLoader;
            }());
            exports_1("DocumentLoader", DocumentLoader);
        }
    }
});
//# sourceMappingURL=document_loader.service.js.map