import {Injectable, Inject} from "@angular/core";
import {StatusHandlerRegistry} from "./status_handler_registry_ng2";
import {Http} from "@angular/http";

declare var plupload;

@Injectable()
export class DfPlUploads2 {
    private _allFiles:any[];
    private _masterSettings:any;

    constructor(
        @Inject(StatusHandlerRegistry) private _fileStatusHandlerRegistry:StatusHandlerRegistry,
        private _http:Http) {

        this._allFiles = [];

        this._masterSettings = {
            runtimes: 'html5',
            multi_selection: false
        };
    }

    createUploader(settings:any)
    {
        var uploader = new plupload.Uploader(_.extend({}, this._masterSettings, settings.uploaderSettings));
        uploader.bind('FilesAdded', (u,a) => this.onFilesAddedHandlerFactory(settings)(u,a));
        uploader.bind('UploadComplete', (u,f) => this.onUploaderComplete(u,f));
        uploader.bind('Error', (u,a) => this.onPlUploadError(u,a));
    
        return uploader;
    };
    
    addFileStatusHandler(handler)
    {
        this._fileStatusHandlerRegistry.addHandler(handler, this._allFiles);
    }

    removeFileStatusHandler(handler)
    {
        this._fileStatusHandlerRegistry.removeHandler(handler);
    }

    private getUploadParams(fileParams:any, file:any)
    {
        file.paramsUrl = fileParams.paramsUrl;
        return this._http.put(file.paramsUrl, {contentType:file.type, filename:file.name})
            .map(response => response.json())
            .single().toPromise();
    }

    private putCompleteNotification(file:any)
    {
        return this._http.put(file.paramsUrl, {complete:true})
            .map(response => response.bytesLoaded ? response.json() : null)
            .single().toPromise();
    }

    private onFilesAddedHandlerFactory(settings)
    {
        return (uploader, addedFiles) =>
        {
            if (uploader.files.length > 1 || addedFiles.length > 1)
            {
                // Only 1 file per uploader+droptarget
                addedFiles.forEach(function(addedFile)
                {
                    uploader.removeFile(addedFile);
                });

                window.alert('You can only upload 1 file at a time.');

                return;
            }

            var file = addedFiles[0];
            file.dfUploadTag = settings.dfUploadTag;
            settings.getFileParams(file)
                 .then(dfUploadParams => {
                     file.dfUploadParams = dfUploadParams;
                     this._allFiles.push(file);
                     this._fileStatusHandlerRegistry.invokeHandlersForSubject(file, true);

                     return this.getUploadParams(file.dfUploadParams, file);
                 })
                 .then(uploadParams =>
                 {
                     if (uploadParams && !uploadParams.complete && uploadParams.providerType === 's3multipartform')
                     {
                         uploader.settings.url = uploadParams.uploadUrl;
                         uploader.settings.multipart_params = uploadParams.multipartFormData;
                         uploader.start();
                     }
                     else
                     {
                         throw new Error('No valid upload params found.');
                     }
                 })
                 .catch(e =>
                 {
                     console.log(e);

                     uploader.removeFile(file);
                     file.status = plupload.FAILED;
                     this._fileStatusHandlerRegistry.invokeHandlersForSubject(file, false);

                     throw e;
                 });

            return;
        };
    }

    private onUploaderComplete(uploader, files)
    {
        files.forEach(file =>
        {
            uploader.removeFile(file);
            for (var i = this._allFiles.length - 1; i >= 0; i--)
            {
                if (this._allFiles[i] === file)
                {
                    this._allFiles.splice(i, 1);
                    break;
                }
            }

            if (file.status === plupload.DONE)
            {
                //ProfileImageUploadRequest.complete(file.dfUploadParams, null,
                this.putCompleteNotification(file).then(data =>
                    {
                        // success
                        file.dfResultUrl = data ? data.resultUrl : null;
                        this._fileStatusHandlerRegistry.invokeHandlersForSubject(file, false);
                    })
                    .catch(e =>
                    {
                        // error
                        console.log(e);
                        file.status = plupload.FAILED;
                        this._fileStatusHandlerRegistry.invokeHandlersForSubject(file, false);
                    });
            }
            else
            {
                this._fileStatusHandlerRegistry.invokeHandlersForSubject(file, true);
            }
        });
        uploader.stop();
    }

    private onPlUploadError(uploader, args)
    {
        console.log(JSON.stringify({ message: 'Error from plupload.', args: args }));
        switch (args.code)
        {
            case plupload.FILE_SIZE_ERROR:
                window.alert('That file is too big.  The file must be less than ' + uploader.settings.filters.max_file_size);
                break;
            case plupload.FILE_EXTENSION_ERROR:
                window.alert('You can only upload .jpeg, .jpg, .png, and .gif files.');
                break;
            case plupload.IMAGE_DIMENSIONS_ERROR:
                window.alert('Max can\'t use this picture.  Try a different one.');
                break;
            default:
                window.alert('An upload error has occurred. Please refresh the page and try again.');
                break;
        }
    }
}