System.register(["@angular/core", "angular2-modal", "angular2-modal/plugins/bootstrap", "./maxAppContext.service", "./assignments.service", '@angular/router', "./user_profiles.service"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __extends = (this && this.__extends) || function (d, b) {
        for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, angular2_modal_1, bootstrap_1, maxAppContext_service_1, assignments_service_1, router_1, user_profiles_service_1;
    var CustomModalContext, InviteModal;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (angular2_modal_1_1) {
                angular2_modal_1 = angular2_modal_1_1;
            },
            function (bootstrap_1_1) {
                bootstrap_1 = bootstrap_1_1;
            },
            function (maxAppContext_service_1_1) {
                maxAppContext_service_1 = maxAppContext_service_1_1;
            },
            function (assignments_service_1_1) {
                assignments_service_1 = assignments_service_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (user_profiles_service_1_1) {
                user_profiles_service_1 = user_profiles_service_1_1;
            }],
        execute: function() {
            CustomModalContext = (function (_super) {
                __extends(CustomModalContext, _super);
                function CustomModalContext(d) {
                    _super.call(this);
                    this.d = d;
                    this.data = d;
                    //  this.size = "lg";
                }
                return CustomModalContext;
            }(bootstrap_1.BSModalContext));
            exports_1("CustomModalContext", CustomModalContext);
            InviteModal = (function () {
                function InviteModal(dialog, _userProfiles, _assignment, _ctx, router) {
                    this.dialog = dialog;
                    this._userProfiles = _userProfiles;
                    this._assignment = _assignment;
                    this._ctx = _ctx;
                    this.router = router;
                    console.log(this.dialog.context.data);
                    console.log(this.dialog.context.data.resdata);
                    this.itemdata = this.dialog.context.data.data;
                    this.resdata = this.dialog.context.data.resdata;
                    this.code = this.resdata.code.match(new RegExp('.{1,4}', 'g')).join("-");
                }
                InviteModal.prototype.onCancel = function () {
                    this.dialog.close(false);
                };
                InviteModal.prototype.texttoinvite = function () {
                    var _this = this;
                    var inviteobj = { userProfileId: this.itemdata.userProfileId, requireUniqueVerificationCode: "true", invitationSenderName: "Ms Butler" };
                    this._userProfiles.texttoinvite(inviteobj).single().toPromise().then(function (resdata) {
                        if (resdata !== undefined) {
                            console.log(resdata);
                            if (resdata.smsError !== undefined) {
                                _this.smserrrmessage = "The invitation could not be sent to the " + _this.itemdata.tel[0] + "\n                            . You may give that code to the user yourself, or you can try again.";
                            }
                            else {
                                _this.smsmessage = "An invitation was texted to " + _this.itemdata.tel[0] + ".";
                            }
                        }
                    });
                };
                InviteModal = __decorate([
                    core_1.Component({
                        selector: 'invite-modal-prompt',
                        template: "\n    <div class=\"modal-content clearfix\" style=\"text-align:left;\">\n    \n       <div class=\"col-xs-12\">\n        <h3><span *ngIf=\"itemdata.firstName\">{{itemdata.firstName}},</span>\n        <span *ngIf=\"itemdata.lastName\">{{itemdata.lastName}}</span></h3>\n       </div> \n        \n       <div class=\"col-xs-12\">RECIPIENT</div>\n       <div class=\"col-xs-12\">\n        <h3>Text or read the code below  \n            <span *ngIf=\"itemdata.lastName\">to {{itemdata.lastName}}</span></h3>\n       </div>     \n       <div class=\"col-xs-12\" style=\"color:#00529b;\"><h2 style=\" margin-top:10px\">{{ code}}</h2></div>\n       <div class=\"col-xs-12\" style=\"color:#00529b; margin-bottom:25px\">ACTIVATION CODE</div>\n       <div class=\"col-xs-12\" *ngIf=\"itemdata.tel[0]\" style=\"margin-bottom:18px\">\n            <a (click)=\"texttoinvite()\" class=\"btn btn-primary \">TEXT AND INVITE TO {{itemdata.tel[0]}}</a>\n       </div>\n    <div class=\"col-xs-12\" *ngIf=\"smserrrmessage\" style=\"color:#ac2925\">{{smserrrmessage}}</div>\n    <div class=\"col-xs-12\" *ngIf=\"smserrrmessage\" style=\"color:#ac2925\">{{smsmessage}}</div>\n        <div class=\"modal-footer\">\n          <button (click)=\"onCancel()\" type=\"button\" class=\"btn btn-primary\" style=\"float:right; margin-right:10px;\">Close</button>\n        </div>\n    </div>\n\n    ",
                    }), 
                    __metadata('design:paramtypes', [angular2_modal_1.DialogRef, user_profiles_service_1.UserProfiles, assignments_service_1.Assignments, maxAppContext_service_1.MaxAppContext, router_1.Router])
                ], InviteModal);
                return InviteModal;
            }());
            exports_1("InviteModal", InviteModal);
        }
    }
});
/*    <usa-map (selectedState)="onSelectState($event)"></usa-map>    */ 
//# sourceMappingURL=invite-modal.component.js.map