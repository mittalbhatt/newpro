import { Routes }         from '@angular/router';
import { AuthGuard }      from './auth-guard.service';
import { AuthService }    from './auth.service';
import { LoginComponent } from './login.component';
import {SignupComponent} from "./signup.component";
import {ForgotPassComponent} from "./forgot_pass.component";
import {ResetPassComponent} from "./reset_pass.component";
import {AccountVerificationComponent} from "./verifyAccount.component";
import {AccountVerificationCanDeactivate} from "./accountVerificationCanDeactivate.service";

export const loginRoutes: Routes = [
    { path: 'login', component: LoginComponent },
    { path: 'login/:username', component: LoginComponent},
    { path: 'signup', component: SignupComponent},
    { path: 'forgot-pass', component: ForgotPassComponent },
    { path: 'reset-pass/:userAccountId/:username', component: ResetPassComponent },
    { path: 'verify-account/:username', component:AccountVerificationComponent, canDeactivate:[AccountVerificationCanDeactivate]}
];

export const authProviders = [
    AuthGuard,
    AuthService,
    AccountVerificationCanDeactivate
];
