System.register(['@angular/core', "./registration_context.service"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, registration_context_service_1;
    var RegistrationHeading;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (registration_context_service_1_1) {
                registration_context_service_1 = registration_context_service_1_1;
            }],
        execute: function() {
            RegistrationHeading = (function () {
                function RegistrationHeading() {
                }
                __decorate([
                    core_1.Input('doc-act'), 
                    __metadata('design:type', Object)
                ], RegistrationHeading.prototype, "docAct", void 0);
                RegistrationHeading = __decorate([
                    core_1.Component({
                        selector: 'registration-heading',
                        template: "\n    <h1 class=\"cover-heading\">{{docAct ? docAct.documentationEventDescription.eventName : 'undefined'}}</h1>\n    <h2>{{docAct ? docAct.documentationEventDescription.coordinatorName : 'undefined'}}</h2>\n    ",
                        styles: ["\n        h1 {text-align:center}\n        h2 { color: rgba(0, 0, 0, .75); text-align:center }\n    "],
                        providers: [
                            registration_context_service_1.RegistrationContext
                        ]
                    }), 
                    __metadata('design:paramtypes', [])
                ], RegistrationHeading);
                return RegistrationHeading;
            }());
            exports_1("RegistrationHeading", RegistrationHeading);
        }
    }
});
//# sourceMappingURL=registration_heading.component.js.map