System.register([], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var PagedDataUtil;
    return {
        setters:[],
        execute: function() {
            PagedDataUtil = (function () {
                function PagedDataUtil() {
                }
                PagedDataUtil.getAllPages = function (getPage) {
                    return this.getAllPagesInternal([], getPage);
                };
                PagedDataUtil.getAllPagesInternal = function (accumulation, getPage) {
                    var _this = this;
                    var pageSize = 1000;
                    return getPage(accumulation.length, pageSize).single().toPromise()
                        .then(function (results) {
                        var concat = accumulation.concat(results);
                        if (results.length < pageSize)
                            return concat;
                        return _this.getAllPagesInternal(concat, getPage);
                    });
                };
                return PagedDataUtil;
            }());
            exports_1("PagedDataUtil", PagedDataUtil);
        }
    }
});
//# sourceMappingURL=pagedDataUtil.service.js.map