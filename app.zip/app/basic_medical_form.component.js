System.register(["@angular/router", "./user_profiles.service", "./registration_context.service", "@angular/core", "./document_factory.service", "underscore", "./basic_medical_saver.service", "./maxAppContext.service", "./intercomRouterTracker.service", "./relationdata.component", "./helper.service", "./DfObjectId"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var router_1, user_profiles_service_1, registration_context_service_1, core_1, document_factory_service_1, _, basic_medical_saver_service_1, core_2, maxAppContext_service_1, intercomRouterTracker_service_1, relationdata_component_1, helper_service_1, DfObjectId_1;
    var BasicMedicalPipe, BasicMedicalForm;
    return {
        setters:[
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (user_profiles_service_1_1) {
                user_profiles_service_1 = user_profiles_service_1_1;
            },
            function (registration_context_service_1_1) {
                registration_context_service_1 = registration_context_service_1_1;
            },
            function (core_1_1) {
                core_1 = core_1_1;
                core_2 = core_1_1;
            },
            function (document_factory_service_1_1) {
                document_factory_service_1 = document_factory_service_1_1;
            },
            function (_1) {
                _ = _1;
            },
            function (basic_medical_saver_service_1_1) {
                basic_medical_saver_service_1 = basic_medical_saver_service_1_1;
            },
            function (maxAppContext_service_1_1) {
                maxAppContext_service_1 = maxAppContext_service_1_1;
            },
            function (intercomRouterTracker_service_1_1) {
                intercomRouterTracker_service_1 = intercomRouterTracker_service_1_1;
            },
            function (relationdata_component_1_1) {
                relationdata_component_1 = relationdata_component_1_1;
            },
            function (helper_service_1_1) {
                helper_service_1 = helper_service_1_1;
            },
            function (DfObjectId_1_1) {
                DfObjectId_1 = DfObjectId_1_1;
            }],
        execute: function() {
            BasicMedicalPipe = (function () {
                function BasicMedicalPipe() {
                }
                BasicMedicalPipe.lookupValue = function (ident, data, cache) {
                    var value = cache[ident];
                    return value ? value.value : undefined;
                };
                BasicMedicalPipe.lookupTextValue = function (ident, data, cache) {
                    var ret = BasicMedicalPipe.lookupValue(ident, data, cache);
                    if (!ret)
                        ret = "";
                    return ret;
                };
                BasicMedicalPipe.prototype.transform = function (value, ident, cache) {
                    return BasicMedicalPipe.lookupTextValue(ident, value, cache);
                };
                BasicMedicalPipe = __decorate([
                    core_2.Pipe({ name: 'dataItem' }), 
                    __metadata('design:paramtypes', [])
                ], BasicMedicalPipe);
                return BasicMedicalPipe;
            }());
            exports_1("BasicMedicalPipe", BasicMedicalPipe);
            BasicMedicalForm = (function () {
                function BasicMedicalForm(_ctx, _appCtx, _router, _route, _documents, _userProfiles, _changeSaver, _intercom, _helper) {
                    var _this = this;
                    this._ctx = _ctx;
                    this._appCtx = _appCtx;
                    this._router = _router;
                    this._route = _route;
                    this._documents = _documents;
                    this._userProfiles = _userProfiles;
                    this._changeSaver = _changeSaver;
                    this._intercom = _intercom;
                    this._helper = _helper;
                    this.filename = '';
                    this.addmoreaddress = false;
                    this.index = 0;
                    this.valdata = '';
                    this.targetVal = '';
                    this.dataCache = {};
                    //use for email/phone
                    this.emailArray = [];
                    this.phoneArray = [];
                    this.errorclassemail = [];
                    this.errorclassphone = [];
                    this.firstname = [];
                    this.lastname = [];
                    //use for relation
                    this.relationArray = [];
                    this.initRelationObj = { "firstName": "", "lastName": "", "rel": "", "tel": [], "address": "", "city": "", "state": "", "zip": "", "email": "" };
                    this.sitesearch = null;
                    this.phoneArrayrelation = [];
                    this.filedSection = [];
                    this.msgClassName = "";
                    this.scrollClass = '';
                    this.isLoader = false;
                    this.isLoaderInsurence = false;
                    //use for checkbox arry medical conditions
                    this.medicalmainIdent = ["Asthma", "Anemia", "Diabetes", "Infections"];
                    this.existingMedicalConditionarry = [];
                    this.checkmedicalCondition = [];
                    this.othervalmedicalCondition = [];
                    //use for checkbox arry allergies
                    this.existingallergiesarry = [];
                    this.allergiesmainIdent = ["Medicines", "Pollens", "Food", "Stinging Insects"];
                    this.checkallergies = [];
                    this.othervalallergies = [];
                    //use for chekbox arry heartProblemsList
                    this.existinheartProblemsarry = [];
                    this.heartProblemsmainIdent = ["High blood pressure", "High cholesterol", "Kawasaki disease", "A heart murmur", "A heart infection"];
                    this.checkheartProblems = [];
                    this.othervalheartProblems = [];
                    this.destroyCheckValues = false;
                    this.relationerror = false;
                    this.isLinkedAccount = false;
                    this.validationErrors = {};
                    this._changeSaver.status.subscribe(function (status) {
                        if (!status.saved) {
                            _this.handleError(status.response);
                        }
                    });
                    this._userProfiles.updateRelativeData.subscribe(function (res) {
                        _this.isLoader = false;
                        if (!res.data) {
                            _this.handleError(res.data);
                        }
                    });
                    store.session('BasicMedicalRedirectURL', '/max-forms/packetList');
                }
                BasicMedicalForm.prototype.onScroll = function () {
                    this.stickMenu = document.body.scrollTop > this.startingMenuOffset - 5; // 5 matches the 'top' setting in the .left-menu-stick css class
                    if (document.body.scrollTop > 0) {
                        this.scrollClass = "boza-athlete-fix";
                    }
                    else {
                        this.scrollClass = "";
                    }
                };
                BasicMedicalForm.prototype.ngOnDestroy = function () {
                    this._changeSaver.stop();
                    store.session('BasicMedicalRedirectURL', '');
                    this.checkboxarraymaintain(this.documentSections, true);
                };
                BasicMedicalForm.prototype.ngOnInit = function () {
                    //this.startingMenuOffset = this.leftMenu.nativeElement.offsetTop;
                    this.filedSection = this._helper.basicMedicalFiledSection;
                    this.refresh();
                };
                BasicMedicalForm.prototype.changeDataFunction = function () {
                    this.relationData.unsaveData = true;
                };
                Object.defineProperty(BasicMedicalForm.prototype, "gradYearOptions", {
                    get: function () {
                        var currentYear = (new Date()).getFullYear();
                        return _.range(currentYear, currentYear + 13).map(function (i) { return i.toString(); });
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(BasicMedicalForm.prototype, "stateOptions", {
                    get: function () {
                        var stateObj = this._appCtx.getStates();
                        return _.chain(stateObj)
                            .flatten()
                            .value();
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(BasicMedicalForm.prototype, "parentOptions", {
                    get: function () {
                        var stateObj = this._appCtx.getParents();
                        return _.chain(stateObj)
                            .flatten()
                            .value();
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(BasicMedicalForm.prototype, "flaggedFields", {
                    get: function () {
                        var _this = this;
                        return _.chain(this.documentSections)
                            .pluck('fields')
                            .flatten()
                            .filter(function (f) {
                            return f.flagIf !== undefined && _this.lookupValue(f.ident) === f.flagIf;
                        })
                            .value();
                    },
                    enumerable: true,
                    configurable: true
                });
                BasicMedicalForm.prototype.showIfAllFields = function (section, field) {
                    var _this = this;
                    var currentSection = this.documentSections.filter(function (f) {
                        return f.name !== undefined && f.name === section.name;
                    });
                    var Obj = _.chain(currentSection)
                        .pluck('fields')
                        .flatten()
                        .filter(function (f) {
                        if (f.showIfAll != undefined) {
                            return (f.showIfAll != undefined && _.every(f.showIfAll, function (ff) {
                                return ((_this.lookupValue(ff.ident) == true || _this.lookupValue(ff.ident) == 1) && ff.ident === field.ident);
                            }));
                        }
                    })
                        .map(function (i) { return i; })
                        .value();
                    return Obj;
                };
                Object.defineProperty(BasicMedicalForm.prototype, "sectionsWithShortcuts", {
                    get: function () {
                        var _this = this;
                        if (!this.documentSections)
                            return [];
                        return this.documentSections.filter(function (ds) { return !!ds.shortcutName && !_this.shouldHideHideable(ds); });
                    },
                    enumerable: true,
                    configurable: true
                });
                BasicMedicalForm.prototype.fieldHasFormAlert = function (field) {
                    return (this.admin && (field.flagIf !== undefined) && (field.flagIf === this.lookupValue(field.ident)));
                };
                BasicMedicalForm.prototype.explainText = function (field) {
                    return field.explanationPrompt ? field.explanationPrompt : 'Please explain: ';
                };
                BasicMedicalForm.prototype.lookupValue = function (ident) {
                    if (!this.document)
                        return undefined;
                    return BasicMedicalPipe.lookupValue(ident, this.document.data, this.dataCache);
                };
                BasicMedicalForm.prototype.lookupTextValue = function (ident) {
                    return BasicMedicalPipe.lookupTextValue(ident, this.document.data, this.dataCache);
                };
                BasicMedicalForm.prototype.addmoreRelation = function () {
                    this.relationArray = [];
                    this.initRelationObj = { "firstName": "", "lastName": "", "rel": "", "tel": [], "address": "", "city": "", "state": "", "zip": "", "email": "" };
                    this.phoneArrayrelation = [{ phone: "" }];
                    this.relationArray.push(this.initRelationObj);
                };
                // add more textboxez on type email/phone
                BasicMedicalForm.prototype.changeEventField = function (type, event, index) {
                    if (event.length > 0) {
                        if (type == 'phone') {
                            var length = this.phoneArray.length;
                        }
                        else {
                            var length = this.emailArray.length;
                        }
                        if ((length - 1) === index) {
                            this.addmoreData(type);
                        }
                    }
                };
                //use for email/phone
                BasicMedicalForm.prototype.addmoreData = function (type) {
                    if (type == 'email') {
                        this.emailArray.push({ email: '' });
                    }
                    else if (type == 'phone') {
                        this.phoneArray.push({ phone: '' });
                    }
                    else if (type == 'phonerelation') {
                        this.phoneArrayrelation.push({ phone: '' });
                    }
                };
                BasicMedicalForm.prototype.removeData = function (i, type) {
                    if (type == 'email') {
                        this.emailArray.splice(i, 1);
                        var a = _.pluck(this.emailArray, "email");
                        a = a.filter(function (a) { return a != ""; });
                        this.updateValue("info.email", a);
                    }
                    else if (type == 'phone') {
                        this.phoneArray.splice(i, 1);
                        var a = _.pluck(this.phoneArray, "phone");
                        a = a.filter(function (a) { return a != ""; });
                        this.updateValue("info.tel", a);
                    }
                };
                BasicMedicalForm.prototype.saveData = function (event, type, index) {
                    var eventVal = "";
                    if (type == 'email') {
                        //let EMAIL_REGEXP = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
                        if (event.type !== undefined && event.type === 'blur') {
                            eventVal = event.target.value;
                        }
                        else {
                            eventVal = event;
                        }
                        this.changeEventField(type, eventVal, index);
                        //if (EMAIL_REGEXP.test(eventVal)) {
                        if (eventVal.length > 0) {
                            this.errorclassemail[index] = 'false';
                            var a = _.pluck(this.emailArray, "email");
                            a = a.filter(function (a) { return a != ""; });
                            if (event.type !== undefined && event.type === 'blur') {
                                this.updateValue("info.email", a);
                            }
                        }
                        else {
                            this.errorclassemail[index] = 'true';
                        }
                    }
                    else if (type == 'phone') {
                        //let PHONE_REGEXP = /^[0-9\-+\)\(]+$/;
                        if (event.type !== undefined && event.type === 'blur') {
                            eventVal = event.target.value;
                        }
                        else {
                            eventVal = event;
                        }
                        this.changeEventField(type, eventVal, index);
                        //if (PHONE_REGEXP.test(eventVal)) {
                        if (eventVal.length > 0) {
                            this.errorclassphone[index] = 'false';
                            var a = _.pluck(this.phoneArray, "phone");
                            a = a.filter(function (a) { return a != ""; });
                            if (event.type !== undefined && event.type === 'blur') {
                                this.updateValue("info.tel", a);
                            }
                        }
                        else {
                            this.errorclassphone[index] = 'true';
                        }
                    }
                    return false;
                };
                BasicMedicalForm.prototype.onYesNo = function (ident, answer) {
                    this.updateValue(ident, answer);
                    // if (answer === 0)
                    //     this.updateValue(ident + '_explanation', '');
                };
                BasicMedicalForm.prototype.onTextChange = function (ident, event, mainIdent) {
                    if (mainIdent === void 0) { mainIdent = null; }
                    delete this.validationErrors[mainIdent];
                    this.targetVal = event.target.value;
                    if (this.dataCache[ident] != undefined && this.dataCache[ident].value != this.targetVal) {
                        this.updateValue(ident, this.targetVal);
                    }
                    else if (this.dataCache[ident] == undefined) {
                        this.updateValue(ident, this.targetVal);
                    }
                };
                BasicMedicalForm.prototype.onNumberChange = function (ident, event, mainIdent) {
                    if (mainIdent === void 0) { mainIdent = null; }
                    delete this.validationErrors[mainIdent];
                    this.updateValue(ident, event.target.value);
                };
                BasicMedicalForm.prototype.onSelect = function (ident, event, mainIdent) {
                    if (mainIdent === void 0) { mainIdent = null; }
                    delete this.validationErrors[mainIdent];
                    this.updateValue(ident, event.target.value, 'select');
                };
                BasicMedicalForm.prototype.onSelectMultiCheckChange = function (ident, option, event) {
                    this.updateListValue(ident, option, event.target.checked);
                };
                BasicMedicalForm.prototype.valueArrayContains = function (ident, elemValue) {
                    if (!this.document)
                        return false;
                    var value = _.find(this.document.data, function (d) { return d.ident == ident; });
                    if (value)
                        return _.contains(value.value, elemValue);
                    return false;
                };
                BasicMedicalForm.prototype.checkboxvalueContains = function (arrytype, compairarry, event, mainIdent, name) {
                    if (mainIdent === void 0) { mainIdent = null; }
                    if (event.type !== undefined && event.type === 'blur') {
                        var eventVal = event.target.value;
                        var other = _.difference(arrytype, compairarry);
                        if (other.length > 0) {
                            var ind = _.indexOf(arrytype, other[0]);
                            arrytype[ind] = eventVal;
                        }
                        else {
                            arrytype.push(eventVal);
                        }
                    }
                    else {
                        if (event == true) {
                            arrytype.push(name);
                            arrytype = _.uniq(arrytype);
                        }
                        else {
                            var ind = _.indexOf(arrytype, name);
                            arrytype.splice(ind, 1);
                        }
                    }
                    var arr = arrytype.filter(function (n) { return n != ""; });
                    delete this.validationErrors[mainIdent];
                    this.updateValue(mainIdent, arr);
                };
                BasicMedicalForm.prototype.onSelectCheckboxChange = function (ident, event, mainIdent, name, index) {
                    if (mainIdent === void 0) { mainIdent = null; }
                    if (mainIdent == 'info.medicalConditionsList') {
                        this.checkboxvalueContains(this.existingMedicalConditionarry, this.medicalmainIdent, event, mainIdent, name);
                        delete this.validationErrors[ident];
                    }
                    else if (mainIdent == 'info.allergiesList') {
                        this.checkboxvalueContains(this.existingallergiesarry, this.allergiesmainIdent, event, mainIdent, name);
                        delete this.validationErrors[ident];
                    }
                    else if (mainIdent == 'info.heartProblemsList') {
                        this.checkboxvalueContains(this.existinheartProblemsarry, this.heartProblemsmainIdent, event, mainIdent, name);
                        delete this.validationErrors[ident];
                    }
                    else {
                        delete this.validationErrors[mainIdent];
                        this.updateValue(ident, event.target.checked);
                    }
                };
                BasicMedicalForm.prototype.updateValue = function (ident, value, inputType) {
                    if (inputType === void 0) { inputType = ''; }
                    delete this.validationErrors[ident];
                    var item = _.find(this.document.data, function (d) { return d.ident == ident; });
                    this._changeSaver.addChange({ ident: ident, value: value });
                    if (item) {
                        item.value = value;
                    }
                    else {
                        this.document.data.push({ ident: ident, value: value });
                    }
                    this.dataCache[ident] = { ident: ident, value: value };
                };
                BasicMedicalForm.prototype.updateListValue = function (ident, value, included) {
                    var item = _.find(this.document.data, function (d) { return d.ident == ident; });
                    if (!item) {
                        item = { ident: ident, value: [] };
                        this.document.data.push(item);
                    }
                    if (included)
                        item.value = _.union(item.value, [value]);
                    else
                        item.value = _.difference(item.value, [value]);
                    this._changeSaver.addChange({ ident: ident, value: item.value });
                    this.dataCache[ident] = { ident: ident, value: item.value };
                };
                BasicMedicalForm.prototype.goToSection = function (name) {
                    this.scrollIntoView(name);
                };
                BasicMedicalForm.prototype.goToField = function (ident) {
                    this.scrollIntoView(ident);
                };
                BasicMedicalForm.prototype.scrollIntoView = function (id) {
                    document.getElementById(id).scrollIntoView();
                    if (this.admin) {
                        // Account for name floating at top.
                        window.scrollBy(0, -100);
                    }
                };
                BasicMedicalForm.prototype.shouldHideHideable = function (field) {
                    var _this = this;
                    return field.showIfAll && !_.every(field.showIfAll, function (f) { return _this.lookupValue(f.ident) === f.value || (f.value == false && _this.lookupValue(f.ident) === undefined); });
                };
                BasicMedicalForm.prototype.valueIsNullUndefinedOrEmpty = function (ident) {
                    var val = this.lookupValue(ident);
                    if (val && val.trim)
                        val = val.trim();
                    return !val && (val !== false);
                };
                BasicMedicalForm.prototype.onClickReviewPdfPages = function (field) {
                    this.onYesNo(field.ident, true);
                };
                BasicMedicalForm.prototype.onPrint = function () {
                    var _this = this;
                    var win = window.open("/maxweb/app/media/spinner.html");
                    this._changeSaver.stop();
                    this._changeSaver.saveNow().single().toPromise()
                        .then(function () {
                        _this._changeSaver.start(_this._amrId, _this.profileId);
                        win.location.assign(_this.pdfUrl);
                    })
                        .catch(function (e) {
                        win.close();
                        _this._changeSaver.start(_this._amrId, _this.profileId);
                        _this.handleError(e, 'We encountered an error saving your changes. Please refresh and try again.');
                    });
                };
                BasicMedicalForm.prototype.getRequiredUnfilled = function (sections) {
                    var _this = this;
                    var requiredUnfilled = _.chain(sections)
                        .pluck('fields')
                        .flatten()
                        .filter(function (f) {
                        return (f.required || (f.requireIfAll && _.every(f.requireIfAll, function (ff) { return (_this.lookupValue(ff.ident) === ff.value) || (ff.value === 'Female' && _this.lookupValue(ff.ident) === 'Female') || ((ff.value == false || ff.value == 0) && _this.lookupValue(ff.ident) === undefined); })))
                            && (_this.valueIsNullUndefinedOrEmpty(f.ident) || _this.lookupTextValue(f.ident) == "") && (_this.lookupValue(f.ident) !== false && _this.lookupValue(f.ident) !== 0);
                    })
                        .pluck('ident')
                        .value();
                    var showIfAllRequiredUnfulfilled = _.chain(sections)
                        .pluck('fields')
                        .flatten()
                        .filter(function (f) {
                        return (f.showIfAll && _.every(f.showIfAll, function (ff) {
                            return (_this.lookupValue(ff.ident) == true || _this.lookupValue(ff.ident) == 1);
                        })) && ((_this.lookupValue(f.ident) == 0 || _this.lookupValue(f.ident) == false) || _this.lookupTextValue(f.ident) == "");
                    })
                        .pluck('showIfAll')
                        .map(function (i) { return i[0].ident + "_" + i[0].fieldsCount; })
                        .value();
                    var explanationsRequiredUnfulfilled = _.chain(sections)
                        .pluck('fields')
                        .flatten()
                        .filter(function (f) {
                        return f.explanationRequired && (_this.lookupValue(f.ident) == true || _this.lookupValue(f.ident) == 1) && _this.valueIsNullUndefinedOrEmpty(f.ident + '_explanation');
                    })
                        .pluck('ident')
                        .map(function (i) { return i + '_explanation'; })
                        .value();
                    var showIfAllRequiredUnfulfilledUnique = showIfAllRequiredUnfulfilled.filter(function (item, pos, self) {
                        var count = pos - (self.indexOf(item));
                        var fieldCount = item.slice(-1);
                        if (Number(fieldCount) == count && self.lastIndexOf(item) == pos) {
                            return item;
                        }
                        else {
                            return false;
                        }
                    }).map(function (ident) {
                        return ident.substring(0, ident.length - 2);
                    });
                    //requiredUnfilled = requiredUnfilled.concat(showIfAllRequiredUnfulfilledUnique);
                    requiredUnfilled = requiredUnfilled.concat(explanationsRequiredUnfulfilled);
                    requiredUnfilled.forEach(function (ident) { return _this.validationErrors[ident] = true; });
                    return requiredUnfilled;
                };
                BasicMedicalForm.prototype.applyValidations = function (type) {
                    var _this = this;
                    if (type === void 0) { type = false; }
                    this.validationErrors = {};
                    this.validationSummary = null;
                    var requiredUnfilled = this.getRequiredUnfilled(this.documentSections);
                    if (type == true) {
                        if (requiredUnfilled.length) {
                            var summary = requiredUnfilled.length > 1 ? 'There are' : 'There is';
                            summary += ' ' + requiredUnfilled.length + ' ';
                            summary += requiredUnfilled.length > 1 ? 'fields' : 'field';
                            summary += ' that you haven\'t filled in. Look for the fields marked in red.';
                            this.validationSummary = summary;
                            window.scrollTo(0, 0);
                            return;
                        }
                    }
                    var requiredResponseNotMatching = _.chain(this.documentSections)
                        .pluck('fields')
                        .flatten()
                        .filter(function (f) {
                        return f.requiredResponse !== undefined && !_.isEqual(_this.lookupValue(f.ident), f.requiredResponse);
                    })
                        .pluck('ident')
                        .value();
                    requiredResponseNotMatching.forEach(function (ident) { return _this.validationErrors[ident] = true; });
                    if (type == true) {
                        if (requiredResponseNotMatching.length) {
                            var summary = requiredResponseNotMatching.length > 1 ? 'There are' : 'There is';
                            summary += ' ' + requiredResponseNotMatching.length + ' ';
                            summary += requiredResponseNotMatching.length > 1 ? 'fields' : 'field';
                            summary += ' that does not contain the required response.  Look for the fields marked in red.';
                            this.validationSummary = summary;
                            window.scrollTo(0, 0);
                            return;
                        }
                    }
                };
                BasicMedicalForm.prototype.getRequireFieldCount = function (section) {
                    var _this = this;
                    var mainSection = this.documentSections.filter(function (f) {
                        return f.name !== undefined && f.name === section.name;
                    });
                    var requiredUnfilled = this.getRequiredUnfilled(mainSection);
                    // For email count
                    if (section.name == 'Contact Info' && requiredUnfilled.length > 0) {
                        if (_.indexOf(requiredUnfilled, 'info.email') != -1) {
                            if (this.emailArray.length > 0) {
                                if (this.emailArray[0].email != '') {
                                    requiredUnfilled = _.without(requiredUnfilled, 'info.email');
                                }
                            }
                        }
                    }
                    var finallenth = requiredUnfilled.length;
                    if (section.name == 'Contact Info' && this.subjectProfile.orgRoles.indexOf("ATH") > -1) {
                        this.relationCount = 0;
                        //  console.log( this.relationArray.length);
                        if (this.relationArray.length == 0) {
                            this.relationCount += 1;
                            this.relationerror = true;
                        }
                        else {
                            this.relationCount = 0;
                            this.relationerror = false;
                        }
                        this.relationArray.filter(function (f) {
                            if (f.firstName == "" && f.lastName == "") {
                                _this.relationCount += 1;
                            }
                            if (f.email == "" && (f.tel == undefined || f.tel[0] == "" || f.tel.length == 0)) {
                                _this.relationCount += 1;
                            }
                            if (_this.relationCount > 1) {
                                _this.relationCount = _this.relationCount - 1;
                            }
                        });
                        return finallenth + this.relationCount;
                    }
                    if (section.name == 'General Info' && ((this.existingallergiesarry.length == 0 || this.existingMedicalConditionarry.length == 0)
                        || ((this.existingallergiesarry.length == 1 && this.existingallergiesarry[0] == "")
                            || (this.existingMedicalConditionarry.length == 1 && this.existingMedicalConditionarry[0] == "")))) {
                        if ((this.existingallergiesarry.length == 1 && this.existingallergiesarry[0] == "") || this.existingallergiesarry.length == 0 && (this.lookupValue("info.specificAllergy") == true || this.lookupValue("info.specificAllergy") == 1)) {
                            finallenth = finallenth + 1;
                            this.validationErrors["info.specificAllergy"] = true;
                        }
                        if ((this.existingMedicalConditionarry.length == 1 && this.existingMedicalConditionarry[0] == "") || this.existingMedicalConditionarry.length == 0 && (this.lookupValue("info.existingMedicalCondition") == true || this.lookupValue("info.existingMedicalCondition") == 1)) {
                            finallenth = finallenth + 1;
                            this.validationErrors["info.existingMedicalCondition"] = true;
                        }
                        return finallenth;
                    }
                    else if (section.name == 'Heart Health' && (this.existinheartProblemsarry.length == 0
                        || (this.existinheartProblemsarry.length == 1 && this.existinheartProblemsarry[0] == ""))) {
                        if ((this.existinheartProblemsarry.length == 1 && this.existinheartProblemsarry[0] == "") || (this.existinheartProblemsarry.length == 0 && (this.lookupValue("info.anyHeartProblems") == true || this.lookupValue("info.anyHeartProblems") == 1))) {
                            finallenth = finallenth + 1;
                            this.validationErrors["info.anyHeartProblems"] = true;
                        }
                        return finallenth;
                    }
                    else {
                        return (requiredUnfilled.length > 0) ? (requiredUnfilled.length) : "";
                    }
                };
                BasicMedicalForm.prototype.canSign = function () {
                    return this.admin && !this.document.originalDescription.staffOnly && this.document.completedDate;
                };
                BasicMedicalForm.prototype.handleError = function (error, message) {
                    if (message === void 0) { message = null; }
                    var parsed = null;
                    try {
                        parsed = error.json();
                    }
                    catch (e) {
                    }
                    if (parsed && parsed.message) {
                        //this.errorMessage = parsed.message;
                        location.reload();
                        return;
                    }
                    if (error.message) {
                        this.errorMessage = error.message;
                        return;
                    }
                    this.errorMessage = message || 'We encountered an error saving your changes. Try refreshing the page.';
                    throw error;
                };
                BasicMedicalForm.prototype.loadImage = function (profile) {
                    var _this = this;
                    return this._userProfiles.getProfileImageUrl(profile).single().toPromise()
                        .then(function (url) {
                        _this.userprofileImage = url;
                    })
                        .catch(function (e) {
                        throw e;
                    });
                };
                BasicMedicalForm.prototype.checkboxcomman = function (showfield, existingarry, mainIdent) {
                    var contain = _.contains(existingarry, showfield.name);
                    if (showfield.type == 'longText') {
                        this.othervalallergies = _.difference(existingarry, mainIdent);
                        if (this.destroyCheckValues == false) {
                            showfield.showIfAll[0].checkvalue = this.othervalallergies[0];
                        }
                        else {
                            showfield.showIfAll[0].checkvalue = '';
                        }
                    }
                    else {
                        if (contain && this.destroyCheckValues == false) {
                            showfield.showIfAll[0].checkvalue = true;
                        }
                        else {
                            showfield.showIfAll[0].checkvalue = false;
                        }
                    }
                };
                BasicMedicalForm.prototype.sectioncheckboxset = function (section, field) {
                    var _this = this;
                    _.each(this.showIfAllFields(section, field), function (showfield) {
                        if (field.ident == 'info.specificAllergy') {
                            _this.checkboxcomman(showfield, _this.existingallergiesarry, _this.allergiesmainIdent);
                        }
                        else if (field.ident == 'info.existingMedicalCondition') {
                            _this.checkboxcomman(showfield, _this.existingMedicalConditionarry, _this.medicalmainIdent);
                        }
                        else if (field.ident == 'info.anyHeartProblems') {
                            _this.checkboxcomman(showfield, _this.existinheartProblemsarry, _this.heartProblemsmainIdent);
                        }
                    });
                };
                BasicMedicalForm.prototype.checkboxarraymaintain = function (documentSections, ngDestroy) {
                    var _this = this;
                    //console.log("destroyCheckValues => "+this.destroyCheckValues);
                    if (ngDestroy == true) {
                        this.destroyCheckValues = true;
                    }
                    _.each(documentSections, function (section) {
                        if (section.name == 'General Info') {
                            _.each(section.fields, function (field) {
                                _this.sectioncheckboxset(section, field);
                            });
                        }
                        else if (section.name == 'Heart Health') {
                            _.each(section.fields, function (field) {
                                _this.sectioncheckboxset(section, field);
                            });
                        }
                    });
                };
                BasicMedicalForm.prototype.loadparentImage = function () {
                    var _this = this;
                    return this._userProfiles.getProfileImageUrl(this.profile).single().toPromise()
                        .then(function (url) {
                        _this.parentImageurl = url;
                    })
                        .catch(function (e) {
                        console.log('Logo error', e);
                        throw e;
                    });
                };
                BasicMedicalForm.prototype.refresh = function () {
                    var _this = this;
                    this.loading = true;
                    var params = this._route.snapshot.params;
                    this._documentDescriptionActivity = params['docDescriptionActivityId'];
                    this._assignmentId = params['assignmentId'];
                    var profileId = params['profileId'];
                    this.profileId = params['profileId'];
                    this.subjectProfileId = profileId;
                    this.packetActivityId = params['packetActivityId'];
                    var loadProfile = this._userProfiles.getProfile(profileId).single().toPromise();
                    loadProfile.then(function (p) {
                        _this.subjectProfile = p;
                        if (_this.subjectProfile.imageUris == undefined) {
                            _this.subjectProfile['imageUris'] = [];
                        }
                        else {
                            _this.loadImage(_this.subjectProfile);
                        }
                        if (_this.subjectProfile.firstName != undefined) {
                            _this.currentuserFname = _this.subjectProfile.firstName;
                            _this.firstname.push(_this.subjectProfile.firstName);
                        }
                        if (_this.subjectProfile.lastName != undefined) {
                            _this.currentuserLname = _this.subjectProfile.lastName;
                            _this.lastname.push(_this.subjectProfile.lastName);
                        }
                        if (_this.subjectProfile.emails != undefined && _this.subjectProfile.emails.length > 0) {
                            var existingEmails = Array();
                            existingEmails[0] = _this.subjectProfile.email;
                            var i = 1;
                            _this.subjectProfile.emails.forEach(function (v, i) { existingEmails.push(_this.subjectProfile.emails[i]); }, i++);
                            existingEmails = _.uniq(existingEmails);
                            if (existingEmails && existingEmails.length > 0) {
                                existingEmails.forEach(function (emailVal) { return _this.emailArray.push({ email: emailVal }); });
                                _this.emailArray.push({ email: "" });
                            }
                            else {
                                _this.emailArray.push({ email: "" });
                            }
                        }
                        else {
                            var existingEmails = Array();
                            existingEmails[0] = _this.subjectProfile.email;
                            if (existingEmails[0] && existingEmails.length > 0 && existingEmails[0] != null) {
                                existingEmails.forEach(function (emailVal) { return _this.emailArray.push({ email: emailVal }); });
                                _this.emailArray.push({ email: "" });
                            }
                            else {
                                _this.emailArray.push({ email: "" });
                            }
                        }
                        if (_this.subjectProfile.tel != undefined && _this.subjectProfile.tel.length > 0) {
                            var existingPhone = _this.subjectProfile.tel;
                            if (existingPhone && existingPhone.length > 0) {
                                existingPhone.forEach(function (phoneVal) { return _this.phoneArray.push({ phone: phoneVal }); });
                                _this.phoneArray.push({ phone: "" });
                            }
                            else {
                                _this.phoneArray.push({ phone: "" });
                            }
                        }
                        else {
                            _this.phoneArray.push({ phone: "" });
                        }
                        // get relation parent image & isLinkedAccount check
                        if (_.has(_this.subjectProfile, 'relations') == true && _this.subjectProfile.relations.length != undefined && _this.subjectProfile.relations.length > 0) {
                            if (_this.subjectProfile.relations[0].userProfileId != undefined) {
                                var profileId_1 = _this.subjectProfile.relations[0].userProfileId;
                                if (profileId_1 && profileId_1 !== undefined) {
                                    _this._userProfiles.getProfile(profileId_1).single().toPromise().then(function (data) {
                                        _this.profile = data;
                                        if (_this.profile.orgRoles.indexOf("PRN") > -1) {
                                            _this.isLinkedAccount = true;
                                        }
                                        _this.loadparentImage();
                                    });
                                }
                            }
                        }
                        if (_this.subjectProfile.$amr != undefined && _this.subjectProfile.$amr.info != undefined) {
                            if (_.has(_this.subjectProfile.$amr.info, "medicalConditionsList")) {
                                _this.existingMedicalConditionarry = _this.subjectProfile.$amr.info.medicalConditionsList;
                            }
                            if (_.has(_this.subjectProfile.$amr.info, "allergiesList")) {
                                _this.existingallergiesarry = _this.subjectProfile.$amr.info.allergiesList;
                            }
                            if (_.has(_this.subjectProfile.$amr.info, "heartProblemsList")) {
                                _this.existinheartProblemsarry = _this.subjectProfile.$amr.info.heartProblemsList;
                            }
                        }
                        if (_this.subjectProfile.relations !== undefined) {
                            _this.relationArray = _this.subjectProfile.relations;
                        }
                        _this.admin = !!_this._appCtx.myProfiles.find(function (mp) {
                            return (mp.org == p.org && !!_.intersection(mp.orgRoles, ['TRN', 'OTRN', 'OADM']).length)
                                ||
                                    (mp.linkedOrgRoles && !!mp.linkedOrgRoles.find(function (lor) { return lor.orgId == p.org && !!_.intersection(lor.roles, ['TRN', 'OTRN', 'OADM']).length; }));
                        });
                    });
                    this.loadInsuranceCard(profileId);
                    if (this.filedSection[1] != undefined && this.filedSection[1].fields != undefined) {
                        this.filedSection[1].fields = _.reject(this.filedSection[1].fields, function (objArr) { return objArr.ident == "info.insuranceCard"; });
                    }
                    loadProfile
                        .then(function (p) { return p.amrId; })
                        .then(function (amrId) {
                        _this._amrId = amrId;
                        return _this._documents.findOrCreateAmrDocument(amrId).single().toPromise();
                    })
                        .then(function (documents) {
                        if (documents === undefined || documents.length == 0) {
                            //console.log("refresh++++++++++++");
                            _this.emailArray = [];
                            _this.phoneArray = [];
                            return _this.refresh();
                        }
                        if (documents != undefined && documents.length > 0) {
                            _this.loading = false;
                        }
                        // If there were multiple matches, they would all be returned here.
                        // We don't have a rule for selecting which one other than we would
                        // hope that the last in is the latest.
                        //console.log(documents);
                        _this.document = documents[documents.length - 1];
                        var infodata = [];
                        var firstname = _this.firstname[0];
                        var lastname = _this.lastname[0];
                        var documnentarry = Array();
                        documnentarry = _this.document.info;
                        var infoArr = _.each(_this.document.info, function (value, key, obj) {
                            if (key == 'firstName') {
                                value = firstname;
                            }
                            else {
                                infodata.push({
                                    ident: 'info.' + ['firstName'],
                                    value: firstname
                                });
                            }
                            if (key == 'lastName') {
                                value = lastname;
                            }
                            else {
                                infodata.push({
                                    ident: 'info.' + ['lastName'],
                                    value: lastname
                                });
                            }
                            infodata.push({
                                ident: 'info.' + [key],
                                value: value
                            });
                        });
                        _this.document.data = infodata;
                        //use for email/phone
                        var firstnamedata = _.find(_this.document.data, function (valget) {
                            if (valget.ident == 'info.firstName') {
                                return true;
                            }
                        });
                        var phone = _.find(_this.document.data, function (valget) {
                            if (valget.ident == 'info.tel') {
                                return true;
                            }
                        });
                        var email = _.find(_this.document.data, function (valget) {
                            if (valget.ident == 'info.email') {
                                return true;
                            }
                        });
                        if (firstnamedata == undefined) {
                            _this.document.data.push({
                                ident: 'info.firstName',
                                value: firstname
                            });
                            _this.document.data.push({
                                ident: 'info.lastName',
                                value: lastname
                            });
                        }
                        if (phone == undefined) {
                            _this.document.data.push({
                                ident: 'info.tel',
                                value: ''
                            });
                        }
                        if (email == undefined) {
                            _this.document.data.push({
                                ident: 'info.email',
                                value: ''
                            });
                        }
                        (_this.document.data || []).forEach(function (d) {
                            _this.dataCache[d.ident] = d;
                        });
                        _this.documentSections = _this.filedSection;
                        _this.applyValidations();
                        _this._changeSaver.start(_this._amrId, _this.profileId);
                        _this.checkboxarraymaintain(_this.documentSections, false);
                        var docStableId = _this.document.documentStableId;
                        var username = encodeURIComponent(_this._ctx.creds.username);
                        var password = encodeURIComponent(_this._ctx.creds.password);
                        _this.pdfUrl = window.location.protocol + "//" + window.location.host + "/training/api/documents/" + docStableId + "/pdf?auth.basic.username=" + username + "&auth.basic.password=" + password;
                    })
                        .catch(function (error) {
                        _this.loading = false;
                        _this.handleError(error);
                    });
                };
                // Save data for amr data on change tab
                BasicMedicalForm.prototype.changeFormTab = function (e, tab) {
                    var _this = this;
                    e.preventDefault();
                    window.scrollTo(0, 0);
                    this.confirmChangeRoute().then(function (res) {
                        return res;
                    }).catch(function (e) {
                        _this.handleError(e, 'We encountered an error saving your changes. Try refreshing the page.');
                        throw e;
                    });
                };
                // Save data for amr data on route change only
                BasicMedicalForm.prototype.confirmChangeRoute = function () {
                    var _this = this;
                    this.isLoader = true;
                    return new Promise(function (resolve, reject) {
                        _this._changeSaver.stop();
                        _this._changeSaver.saveNow().single().toPromise()
                            .then(function () {
                            _this._changeSaver.start(_this._amrId, _this.profileId);
                        })
                            .then(function () {
                            if (_this.relationArray !== undefined && _this.relationArray.length > 0) {
                                _this.relationData.saveData().then(function (res) {
                                    if (res == true) {
                                        resolve(true);
                                    }
                                    else {
                                        _this.isLoader = false;
                                        _this.handleError(res, 'We encountered an error saving your changes. Please refresh and try again.');
                                    }
                                }).catch(function (e) {
                                    throw e;
                                });
                            }
                            else {
                                _this.isLoader = false;
                                resolve(true);
                            }
                        })
                            .catch(function (error) {
                            _this._changeSaver.start(_this._amrId, _this.profileId);
                            _this.isLoader = false;
                            _this.handleError(error, 'We encountered an error saving your changes. Please refresh and try again.');
                        });
                    });
                };
                BasicMedicalForm.prototype.backButton = function () {
                    window.history.back();
                    // console.log(this._router.url);
                    // console.log(window.history.back());
                    // var backUrl = store.session('BasicMedicalRedirectURL');
                    // var route: any[] = [backUrl];
                    // route.push({ profileId: this.profileId });
                    // this._router.navigate(route);
                };
                BasicMedicalForm.prototype.refreshInsuranceData = function (e) {
                    this.isLoaderInsurence = true;
                    this.filedSection[1].fields = _.reject(this.filedSection[1].fields, function (objArr) { return objArr.ident == "info.insuranceCard"; });
                    this.loadInsuranceCard(this.profileId);
                };
                BasicMedicalForm.prototype.loadInsuranceCard = function (profileId) {
                    var _this = this;
                    var insuranceCardList = [];
                    var insuranceCardGroupIds = [];
                    // this.isShowDocumentGif = true;
                    this._userProfiles.getTeamUserDocument(profileId).single().toPromise()
                        .then(function (data) {
                        var datarev = data.reverse();
                        var infoArr = _.each(datarev, function (value, key, obj) {
                            if (value.documentGroup !== undefined) {
                                if (value.documentGroup.type !== undefined && value.documentGroup.type == "insuranceCard") {
                                    if (value.documentGroup.documentGroupId !== undefined) {
                                        value.ident = "info.insuranceCard";
                                        value.name = "Insurance Image";
                                        value.type = "image";
                                        value.pclass = "col-xs-6 col-sm-3";
                                        if (_.indexOf(insuranceCardGroupIds, value.documentGroup.documentGroupId) >= 0) {
                                            var documentGroupIdTmp_1 = value.documentGroup.documentGroupId;
                                            // find index of object from existing array, Where we have to put front/back object
                                            var finalIndex_1 = -1;
                                            var findMatchObject = _.find(insuranceCardList, function (itemMain, indexMain) {
                                                var findSubMatch = _.find(itemMain, function (itemSub, indexSub) {
                                                    if (itemSub.documentGroup.documentGroupId === documentGroupIdTmp_1) {
                                                        finalIndex_1 = indexMain;
                                                        return false;
                                                    }
                                                });
                                            });
                                            if (finalIndex_1 >= 0) {
                                                insuranceCardList[finalIndex_1].push(value);
                                            }
                                        }
                                        else {
                                            insuranceCardList.push([value]);
                                            insuranceCardGroupIds.push(value.documentGroup.documentGroupId);
                                        }
                                    }
                                }
                            }
                        });
                        /* Add logic for append  remaining front/back object in Array(insuranceCardList) */
                        var newInsuranceCardObject = {
                            ident: "info.insuranceCard",
                            name: "Insurance Image",
                            type: "image",
                            pclass: "col-xs-6 col-sm-3",
                            documentGroup: {
                                documentGroupId: "",
                                role: "front",
                                type: "insuranceCard"
                            }
                        };
                        var finalInsuranceCardList = insuranceCardList;
                        _.each(insuranceCardList, function (value, key) {
                            if (value.length == 1) {
                                if (value[0].documentGroup.role === "front") {
                                    finalInsuranceCardList[key].push({
                                        ident: "info.insuranceCard",
                                        name: "Insurance Image",
                                        type: "image",
                                        pclass: "col-xs-6 col-sm-3",
                                        documentGroup: {
                                            documentGroupId: value[0].documentGroup.documentGroupId,
                                            role: "back",
                                            type: "insuranceCard"
                                        }
                                    });
                                }
                                else {
                                    finalInsuranceCardList[key].unshift({
                                        ident: "info.insuranceCard",
                                        name: "Insurance Image",
                                        type: "image",
                                        pclass: "col-xs-6 col-sm-3",
                                        documentGroup: {
                                            documentGroupId: value[0].documentGroup.documentGroupId,
                                            role: "front",
                                            type: "insuranceCard"
                                        }
                                    });
                                }
                            }
                            else {
                                if (value[0].documentGroup.role === "back") {
                                    value.reverse();
                                }
                            }
                        });
                        var documentGroupIdForLastCard = (new DfObjectId_1.DfObjectId()).toString();
                        var finalInsuranceCardCount = finalInsuranceCardList.length;
                        finalInsuranceCardList[finalInsuranceCardCount] = [];
                        finalInsuranceCardList[finalInsuranceCardCount].push({
                            ident: "info.insuranceCard",
                            name: "Insurance Image",
                            type: "image",
                            pclass: "col-xs-6 col-sm-3",
                            documentGroup: {
                                documentGroupId: documentGroupIdForLastCard,
                                role: "front",
                                type: "insuranceCard"
                            }
                        });
                        finalInsuranceCardList[finalInsuranceCardCount].push({
                            ident: "info.insuranceCard",
                            name: "Insurance Image",
                            type: "image",
                            pclass: "col-xs-6 col-sm-3",
                            documentGroup: {
                                documentGroupId: documentGroupIdForLastCard,
                                role: "back",
                                type: "insuranceCard"
                            }
                        });
                        _this.filedSection[1].fields.push({
                            ident: "info.insuranceCard",
                            name: "Insurance Image",
                            type: "image",
                            pclass: "col-xs-6 col-sm-3",
                            imageList: finalInsuranceCardList
                        });
                        _this.isLoaderInsurence = false;
                    })
                        .catch(function (e) {
                        _this.isLoaderInsurence = false;
                        // this.isShowDocumentGif = false;
                        throw e;
                    });
                };
                __decorate([
                    core_1.Input(), 
                    __metadata('design:type', Boolean)
                ], BasicMedicalForm.prototype, "admin", void 0);
                __decorate([
                    core_1.ViewChild(relationdata_component_1.RelationComponent), 
                    __metadata('design:type', relationdata_component_1.RelationComponent)
                ], BasicMedicalForm.prototype, "relationData", void 0);
                __decorate([
                    core_1.ViewChild('leftMenu'), 
                    __metadata('design:type', core_1.ElementRef)
                ], BasicMedicalForm.prototype, "leftMenu", void 0);
                __decorate([
                    core_1.HostListener('window:scroll'), 
                    __metadata('design:type', Function), 
                    __metadata('design:paramtypes', []), 
                    __metadata('design:returntype', void 0)
                ], BasicMedicalForm.prototype, "onScroll", null);
                BasicMedicalForm = __decorate([
                    core_1.Component({
                        selector: 'basic-medical-form',
                        templateUrl: '/maxweb/app/app/basic_medical_form.component.html',
                    }), 
                    __metadata('design:paramtypes', [registration_context_service_1.RegistrationContext, maxAppContext_service_1.MaxAppContext, router_1.Router, router_1.ActivatedRoute, document_factory_service_1.Documents, user_profiles_service_1.UserProfiles, basic_medical_saver_service_1.BasicMedicalSaver, intercomRouterTracker_service_1.IntercomRouterTracker, helper_service_1.Helper])
                ], BasicMedicalForm);
                return BasicMedicalForm;
            }());
            exports_1("BasicMedicalForm", BasicMedicalForm);
        }
    }
});
//# sourceMappingURL=basic_medical_form.component.js.map