import {Injectable} from "@angular/core";
import {Router, NavigationStart} from "@angular/router";

@Injectable()
export class IntercomRouterTracker
{
    constructor(private _router:Router)
    {

    }

    install()
    {
        this.loggedOutBoot();

        this._router.events.filter(e => e instanceof NavigationStart).subscribe(e =>
        {
            (<any>window).Intercom("update");
        })
    }

    loggedOutBoot()
    {
        // boot for logged out users
        (<any>window).Intercom("boot", {
            app_id:'yqs3zlze'
        });
    }

    track(eventName:string, meta:any=null)
    {
        (<any>window).Intercom("trackEvent", eventName, meta);
    }
}