import {Component} from '@angular/core';

import {DialogRef, ModalComponent} from 'angular2-modal';
import {BSModalContext} from 'angular2-modal/plugins/bootstrap';
import {DocumentationDocDescriptionReference} from './documentation_activity';
import {AthleteDocumentationFormStatusItem} from "./athlete_form_status";

const PRINT_LIMIT = 50;

class PrintableFormViewModel {
    public selected:boolean;

    constructor(public doc:DocumentationDocDescriptionReference) {
    }
}

export class AdminFormPrintModalData extends BSModalContext {
    public forms:PrintableFormViewModel[];

    constructor(docs:DocumentationDocDescriptionReference[] = null,
                public selectedItems:AthleteDocumentationFormStatusItem[] = null,
                public allItems:AthleteDocumentationFormStatusItem[] = null)
    {
        super();

        this.selectedItems = this.selectedItems || [];

        this.forms = (docs || []).map(d => new PrintableFormViewModel(d));
    }

    selectedForms()
    {
        return this.forms.filter(f => f.selected).map(f => f.doc);
    }
}

@Component({
    selector: 'admin-form-print-modal-content',
    template: `
                <div class="modal-content">
                  <div class="modal-header">
                    <button type="button" class="close" (click)="onClose()">&times;</button>
                    <h4 class="modal-title">Print</h4>
                  </div>
                  <div class="modal-body" style="text-align:left">
                     <h3>Which Forms?</h3>
                     <table>
                        <tr><td><input type="checkbox" [(ngModel)]="allSelected" /></td><td><a href="javascript:void(0)" (click)="allSelected = !allSelected">Toggle All</a></td></tr>
                        <tr style="cursor:pointer" *ngFor="let doc of context.forms">
                            <td valign="top">
                                <input type="checkbox" [(ngModel)]="doc.selected" />
                            </td>
                            <td (click)="doc.selected = !doc.selected" style="padding-bottom:6px;">
                                {{doc.doc.name}}
                            </td>
                        </tr>
                     </table>
                     <h3>Which Athletes?</h3>
                    <div class="radio">
                      <label>
                        <input type="radio" name="optionsRadios" value="selected" [disabled]="printSelectedDisabled" (click)="printOption = 'selected'" [checked]="printOption == 'selected'">
                        <span [style.color]="selectedItemsMessage ? 'gray' : 'inherit'">Selected athletes <em>{{selectedItemsMessage}}</em></span>
                      </label>
                    </div>
                    <div class="radio">
                      <label>
                        <input type="radio" name="optionsRadios" value="range" (click)="printOption = 'range'" [checked]="printOption == 'range'">
                        Specified range
                      </label>
                    </div>
                    
                    <div *ngIf="printOption == 'range'">
                        Select range (limit {{limit}}):
                        <input type="number" min="1" [max]="context.allItems.length" [(ngModel)]="rangeStart" (blur)="fixRange()" style="width:50px;" />
                        to
                        <input type="number" [min]="rangeStart" [max]="rangeEndMax()" [(ngModel)]="rangeEnd" (blur)="fixRange()" style="width:50px;" />
                    </div>
                  </div>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-danger" (click)="onClose()">Cancel</button>
                    <button type="button" class="btn btn-default" (click)="onPrint()">Print</button>
                  </div>
                </div>`
})
export class AdminFormPrintModal implements ModalComponent<AdminFormPrintModalData> {

    private limit = PRINT_LIMIT;
    private _allSelected:boolean;

    context: AdminFormPrintModalData;
    selectedItemsMessage: string;
    printSelectedDisabled:boolean;

    printOption:string;
    rangeStart:number;
    rangeEnd:number;

    constructor(public dialog: DialogRef<AdminFormPrintModalData>) {
        this.context = dialog.context;
        this.printOption = 'selected';

        console.log(this.context);
        

        if (this.context.selectedItems.length > PRINT_LIMIT) {
            this.printSelectedDisabled = true;
            this.printOption = 'range';
            this.selectedItemsMessage = `Select fewer than ${PRINT_LIMIT} rows to use this option.`;
        }
        else if (this.context.selectedItems.length < 1) {
            this.printSelectedDisabled = true;
            this.printOption = 'range';
            this.selectedItemsMessage = 'Use the checkboxes on rows to select items.';
        }

        this.rangeStart = 1;
        this.rangeEnd = this.rangeEndMax();
        this.allSelected = true;
    }
    
    rangeEndMax()
    {
        return Math.min(this.rangeStart + this.limit - 1, this.context.allItems.length);
    }

    private fixRange()
    {
        setTimeout(() => {
            if (this.rangeStart < 1)
                this.rangeStart = 1;
            if (this.rangeStart > this.context.allItems.length)
                this.rangeStart = this.context.allItems.length;


            if (this.rangeEnd < this.rangeStart)
                this.rangeEnd = this.rangeStart;
            if (this.rangeEnd > this.rangeEndMax())
                this.rangeEnd = this.rangeEndMax();
        }, 1);
    }

    private onClose()
    {
        this.dialog.close();
    }

    private onPrint()
    {
        var selectedPrintFormIds =
            _.sortBy(this.context.selectedForms(), f => this.context.forms.map(ff => ff.doc).indexOf(f))
                .map(d => d.activityId);

        var items:AthleteDocumentationFormStatusItem[];
        if (this.printOption == 'range')
            items = this.context.allItems.slice(this.rangeStart-1, this.rangeEnd);
        else
            items = this.context.selectedItems;

        var ids = _.chain(items)
            .sortBy(i => this.context.allItems.indexOf(i))
            .map(i => i.statuses.filter(s => selectedPrintFormIds.indexOf(s.documentDescriptionActivityId) > -1))
            .flatten()
            .map(s => s.documentInstanceStableId)
            .value();

        this.dialog.close(ids)
    }

    private set allSelected(value:boolean)
    {
        this._allSelected = value;
        this.context.forms.forEach(d => d.selected = value);
    }

    private get allSelected():boolean
    {
        return this._allSelected;
    }
}