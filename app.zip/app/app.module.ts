import {NgModule, ErrorHandler} from '@angular/core';
import {BrowserModule} from '@angular/platform-browser';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import { DatePipe } from "@angular/common";

import {AppComponent} from './app.component';
import {routing, routingProviders} from './app.routing';
import {AthleteRegistration} from "./registration/athlete_registration.component";
import {LandingComponent} from "./landing.component";
import {AthDocDashboard} from "./ath_doc_dashboard.component";
import {AthleteDocumentationForm, DataItemPipe} from "./athlete_doc_form.component";
import {BasicMedicalForm, BasicMedicalPipe} from "./basic_medical_form.component";
import {HttpModule, JsonpModule, RequestOptions} from "@angular/http";
import {RegistrationContext} from "./registration_context.service";
import {UserAccountService} from "./userAccount.service";
import {RegistrationHeading} from "./registration_heading.component";
import {ProfileTypeChooser} from "./profileTypeChooser.component";
import {UserProfiles} from "./user_profiles.service";
import {OwnProfileCreator} from "./ownProfileCreator.component";
import {AppBaseRequestOptions} from "./app_base_request_options";
import {DefaultSportChooser} from "./defaultSportChooser.component";
import {MaxAppExceptionHandler} from "./appExceptionHandler.service";
import {RelatedProfilesList} from "./relatedProfilesList.component";
import {RelatedProfile} from "./relatedProfile.component";
import {LandingComponentBlank} from "./landing_blank.component";
import {MaxFormsShell} from "./max-forms-shell.component";
import {ParentChildFormsContextChooser} from "./parentChildFormsContextChooser.component";
import {RelatedProfileCreator} from "./relatedProfileCreator.component";
import {CoverShell} from "./cover.component";
import {LoginComponent} from "./login.component";
import {SignupComponent} from "./signup.component";
import {AccountVerificationComponent} from "./verifyAccount.component";
import {ForgotPassComponent} from "./forgot_pass.component";
import {ResetPassComponent} from "./reset_pass.component";
import {MaxAppContext} from "./maxAppContext.service";
import {Organizations} from "./organizations.service";
import {PacketList} from "./packetList.component";
import {Activities} from "./activities.service";
import {Assignments} from "./assignments.service";
import {DfPlUploadHost} from "./df_pl_uploader_ng2.directive";
import {UserProfileComponent} from "./userProfile.component";
import {DfPlUploads2} from "./df_pl_uploads_ng2";
import {StatusHandlerRegistry} from "./status_handler_registry_ng2";
import {MaxAdminMenuComponent} from "./adminMenu.component";
import {ModalModule} from "angular2-modal";
import {BootstrapModalModule} from "angular2-modal/plugins/bootstrap";
import {DocumentDataExpressionPipe} from "./document_data_expression.pipe";
import {ComboDayPicker} from "./registration/combo_day_picker";
import {DocumentChangeSaver} from "./document_change_saver.service";
import {Documents} from "./document_factory.service";
import {DocumentExpressionEvaluator} from "./document_expression_evaluator";
import {DocumentLoader} from "./document_loader.service";
import {ActivityAuthorizer} from "./registration/activity_auth.service";
import {ReCaptchaComponent} from "angular2-recaptcha/angular2-recaptcha";
import {Ng2BootstrapModule} from "ng2-bootstrap/ng2-bootstrap";

import {DndModule} from 'ng2-dnd';
import {FormsProfileEditor} from "./formsProfileEditor.component";
import {AdminEventView} from "./admin_event_view.component"
import {PendingProfilesView} from "./pending_profile_approval.component";
import {AdminFormPrintModal} from "./admin_form_print_modal";
import {AccessRequestApprovalModal} from "./accessRequestApprovalModal.component";
import {TeamInfo} from "./teamInfo.service";
import {ProfileUtil} from "./confirmProfileDelete";
import {GetTheAppComponent} from "./getTheApp.component";
import {PhoneDisplayPipe} from "./phoneDisplay.pipe";
import { KeysPipe } from "./key-value.pipe";
import { filterPipe } from "./teams-players.component";
import {OrgContextChooser} from "./orgContextChooser.component";
import {LinkedOrgRoleRequests} from "./linkedOrgRoleRequests.service";
import {AutoCompleteWorkaround} from "./autoCompleteWorkaround";
import {UserProfileCreationModalPrompt} from "./userProfileCreationModalPrompt.component";
import {TeamPacketCreationModalPrompt} from "./team-packet-creation-modal.component";
import {OrgHeadingComponent} from "./orgHeading.component";
import {FormsOrgChooserComponent} from "./formsOrgChooser.component";
import {IntercomRouterTracker} from "./intercomRouterTracker.service";
import { TeamsComponent } from "./teams.component";
import { TeamsPlayersComponent } from "./teams-players.component";
import { OrganizationStructureResolve } from "./teams.resolve";
import { SharedService } from "./shared.service";
import { TeamsPlayersBoxComponent } from "./teams-players-box.component";
import { TeamsPlayerDetailsComponent } from "./teams-player-details.component";
import { TeamsPlayerDetailsResolve } from "./teams-player-details.resolve";
import { SiteSearchService } from "./site-search.service";
import { SearchPopupComponent } from "./search-popup.component";
import { TeamOrganizationBoxComponent } from "./team-organization-box.component";
import { TeamsPlayerInjuryComponent } from "./teams-player-injury.component";
import { DocumentsComponent } from "./documents.component";
import { hiddenPipe } from './documents.component';
import { DocumentlistMediaComponent } from "./documentlist-media.component";
import {ChangePasswordModal} from "./change-password.component";
import { Helper } from "./helper.service";
import { TeamsFormComponent } from "./teams-form.component";
import {PacketFormModal} from "./packet-form-modal.component";
import {UsaMapComponent} from "./usa-map.component";
import {AssignFormModal} from "./assign-form-model.component";
import {SaveFormGuard} from "./save-form-guard";
import { SwiperModule, SwiperConfigInterface } from 'ngx-swiper-wrapper';
import { TosCheckModal } from './toscheck-model.component';
import { Tosaccept } from './tosaccept.service';
import { ResetScrollHistory } from './reset-scroll-history';
import { SelectFormComponent } from "./select-form.component";
import { TeamsPlayersListComponent } from "./teams-players-box.component";
import { TeamsPlayersEligibilityComponent } from "./teams-players-box.component";
import {BasicMedicalSaver} from "./basic_medical_saver.service";
import {RelationComponent} from "./relationdata.component";
import {InviteModal} from "./invite-modal.component";
import { InsuranceImageBoxComponent, InsuranceImageSetComponent } from "./insurance_image.component";
import {Base64Encoder} from "./base64Encoder";

const SWIPER_CONFIG: SwiperConfigInterface = {
    direction: 'horizontal',
    slidesPerView: 4,
    freeMode: true,
    initialSlide: 1,
    spaceBetween: 0,
    centeredSlides: true,
    observer: true,
    nextButton: '.swiper-button-next',
    prevButton: '.swiper-button-prev',
    pagination: '.swiper-pagination',
};


@NgModule({
    imports:[
        BrowserModule,
        FormsModule,
        ReactiveFormsModule,
        HttpModule,
        JsonpModule,
        routing,
        ModalModule.forRoot(),
        BootstrapModalModule,
        Ng2BootstrapModule,
        DndModule.forRoot(),
        SwiperModule.forRoot(SWIPER_CONFIG)
    ],
    declarations: [
        AppComponent,
        LandingComponent,
        AthleteRegistration,
        AthDocDashboard,
        AthleteDocumentationForm,
        RegistrationHeading,
        ProfileTypeChooser,
        OwnProfileCreator,
        DefaultSportChooser,
        RelatedProfilesList,
        RelatedProfile,
        MaxFormsShell,
        LandingComponentBlank,
        ParentChildFormsContextChooser,
        RelatedProfileCreator,
        CoverShell,
        LoginComponent,
        SignupComponent,
        AccountVerificationComponent,
        ForgotPassComponent,
        ResetPassComponent,
        PacketList,
        DfPlUploadHost,
        UserProfileComponent,
        MaxAdminMenuComponent,
        DataItemPipe,
        BasicMedicalPipe,
        DocumentDataExpressionPipe,
        ComboDayPicker,
        ReCaptchaComponent,
        FormsProfileEditor,
        AdminEventView,
        PendingProfilesView,
        AdminFormPrintModal,
        AccessRequestApprovalModal,
        UserProfileCreationModalPrompt,
        TeamPacketCreationModalPrompt,
        GetTheAppComponent,
        PhoneDisplayPipe,
        KeysPipe,
        filterPipe,
        OrgContextChooser,
        OrgHeadingComponent,
        FormsOrgChooserComponent,
        TeamsComponent,
        TeamsPlayersComponent,
        TeamsPlayersBoxComponent,
        TeamsPlayerDetailsComponent,
        SearchPopupComponent,
        TeamOrganizationBoxComponent,
        TeamsPlayerInjuryComponent,
        DocumentsComponent,
        hiddenPipe,
        DocumentlistMediaComponent,
        ChangePasswordModal,
        TeamsFormComponent,
        PacketFormModal,
        UsaMapComponent,
        AssignFormModal,
        TosCheckModal,
        SelectFormComponent,
        TeamsPlayersListComponent,
        TeamsPlayersEligibilityComponent,
        BasicMedicalForm,
        RelationComponent,
        InviteModal,
        InsuranceImageBoxComponent,
        InsuranceImageSetComponent
    ],
    bootstrap:[AppComponent],
    providers:[
        DatePipe,
        MaxAppContext,
        AutoCompleteWorkaround,
        IntercomRouterTracker,
        RegistrationContext,
        UserAccountService,
        UserProfiles,
        Organizations,
        LinkedOrgRoleRequests,
        Activities,
        ActivityAuthorizer,
        Assignments,
        TeamInfo,
        DfPlUploads2,
        StatusHandlerRegistry,
        ProfileUtil,
        OrganizationStructureResolve,
        TeamsPlayerDetailsResolve,
        SharedService,
        SiteSearchService,
        Helper,
        SaveFormGuard,
        ResetScrollHistory,
        Tosaccept,
        Base64Encoder,
        Documents, DocumentChangeSaver, DocumentLoader, DocumentExpressionEvaluator,
        BasicMedicalSaver,
        {provide: RequestOptions, useClass: AppBaseRequestOptions},
        {provide: ErrorHandler, useClass:MaxAppExceptionHandler},
        ...routingProviders
    ],
    entryComponents:[
        AdminFormPrintModal,
        AccessRequestApprovalModal,
        ChangePasswordModal,
        PacketFormModal,
        UserProfileCreationModalPrompt,
        AssignFormModal,
        TeamPacketCreationModalPrompt,
        TosCheckModal,
        InviteModal
    ]
})
export class AppModule {
    constructor()
    {
    }
}