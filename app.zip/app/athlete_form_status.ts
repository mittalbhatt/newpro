import {DocumentationActivity} from './documentation_activity';
import {DocumentationDocumentData} from "./documentation_document";
import {Organization} from "./organizations.service";
import {Assignment} from "./assignments.service";

export class AthleteDocumentationFormStatus {
    documentDescriptionActivityId:string;
    documentInstanceId:string;
    documentInstanceStableId:string;
    completedDate:Date;
    fieldsWithAlerts:DocumentationDocumentData[];
}

export class AthleteDocumentationFormStatusItem {
    athleteDisplayName:string;
    profileId:string;
    assignmentId:string;
    athleteDob:string;
    processedDate:Date;
    accepted:boolean;
    packetSubmittedDate:Date;
    statuses:AthleteDocumentationFormStatus[];
    summaryValues:any;
}

export class AthleteDocumentationFormStatusSummary {
    documentationActivity:DocumentationActivity;
    documentationAssignment:Assignment;
    org:Organization;
    items:AthleteDocumentationFormStatusItem[];
}