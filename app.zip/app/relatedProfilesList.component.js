System.register(["@angular/core", "@angular/router", "./user_profiles.service", "./maxAppContext.service"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, router_1, user_profiles_service_1, maxAppContext_service_1;
    var RelatedProfilesList;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (user_profiles_service_1_1) {
                user_profiles_service_1 = user_profiles_service_1_1;
            },
            function (maxAppContext_service_1_1) {
                maxAppContext_service_1 = maxAppContext_service_1_1;
            }],
        execute: function() {
            RelatedProfilesList = (function () {
                function RelatedProfilesList(_route, _router, _profilesSvc, _ctx) {
                    this._route = _route;
                    this._router = _router;
                    this._profilesSvc = _profilesSvc;
                    this._ctx = _ctx;
                    this._user_img = [];
                    this.isloading = false;
                    this.itemClicked = new core_1.EventEmitter();
                    this.itemEditClicked = new core_1.EventEmitter();
                    this.itemDeleteClicked = new core_1.EventEmitter();
                }
                Object.defineProperty(RelatedProfilesList.prototype, "profileId", {
                    set: function (value) {
                        var _this = this;
                        this.isloading = true;
                        if (this._profileId == value)
                            return;
                        this._profileId = value;
                        if (!value) {
                            this.relatedProfiles = [];
                            return;
                        }
                        this._profilesSvc.getAllProfiles()
                            .then(function (profiles) {
                            _this.relatedProfiles = profiles.filter(function (p) { return p.org == _this._ctx.orgId &&
                                p.relations && p.relations.find(function (r) { return r.userProfileId == _this._profileId && (r.roles || []).filter(function (ro) { return _this.relationRoles.indexOf(ro) != -1; }); }); })
                                .map(function (p) { return new user_profiles_service_1.UserProfile(p); });
                            _this.isloading = false;
                        })
                            .catch(function (e) {
                            console.log(e);
                            _this.errorMessage = 'We encountered an unexpected error. Refresh the page and try again.';
                            _this.isloading = false;
                            throw e;
                        });
                        ;
                    },
                    enumerable: true,
                    configurable: true
                });
                RelatedProfilesList.prototype.onAddNew = function () {
                    this._router.navigate(['/max-forms/chooseFormsProfile', this._profileId, 'create'], { relativeTo: this._route.parent });
                };
                RelatedProfilesList.prototype.onRowClick = function (profile) {
                    this.itemClicked.emit(profile);
                };
                RelatedProfilesList.prototype.onEditClick = function (profile, event) {
                    event.stopPropagation();
                    this.itemEditClicked.emit(profile);
                };
                RelatedProfilesList.prototype.onDeleteClick = function (profile, event) {
                    event.stopPropagation();
                    this.itemDeleteClicked.emit(profile);
                };
                RelatedProfilesList.prototype.clear = function (profile) {
                    var idx = this.relatedProfiles.indexOf(profile);
                    this.relatedProfiles.splice(idx, 1);
                };
                __decorate([
                    core_1.Input(), 
                    __metadata('design:type', Array)
                ], RelatedProfilesList.prototype, "relationRoles", void 0);
                __decorate([
                    core_1.Input(), 
                    __metadata('design:type', String), 
                    __metadata('design:paramtypes', [String])
                ], RelatedProfilesList.prototype, "profileId", null);
                __decorate([
                    core_1.Output(), 
                    __metadata('design:type', Object)
                ], RelatedProfilesList.prototype, "itemClicked", void 0);
                __decorate([
                    core_1.Output(), 
                    __metadata('design:type', Object)
                ], RelatedProfilesList.prototype, "itemEditClicked", void 0);
                __decorate([
                    core_1.Output(), 
                    __metadata('design:type', Object)
                ], RelatedProfilesList.prototype, "itemDeleteClicked", void 0);
                RelatedProfilesList = __decorate([
                    core_1.Component({
                        selector: 'related-profiles-list',
                        template: "\n<div>\n    <div class=\"list-group\">\n        <div *ngIf=\"isloading\">\n            <img src=\"/maxweb/app/media/ajax-loader.gif\" />\n        </div>\n        <related-profile *ngFor=\"let profile of relatedProfiles\" [userProfile]=\"profile\"></related-profile>\n    </div>\n    <div class=\"list-group\">\n        <button type=\"button\" class=\"list-group-item\" (click)=\"onAddNew()\"><span style=\"float:left; color:green;\" class=\"glyphicon glyphicon-plus\"></span>&nbsp;&nbsp;&nbsp;Add a Child in {{_ctx.currentOrg?.name || '...loading school name...'}}</button>    \n    </div>\n</div>\n"
                    }), 
                    __metadata('design:paramtypes', [router_1.ActivatedRoute, router_1.Router, user_profiles_service_1.UserProfiles, maxAppContext_service_1.MaxAppContext])
                ], RelatedProfilesList);
                return RelatedProfilesList;
            }());
            exports_1("RelatedProfilesList", RelatedProfilesList);
        }
    }
});
//# sourceMappingURL=relatedProfilesList.component.js.map