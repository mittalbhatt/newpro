import {Component, ElementRef, Inject, HostListener, trigger, transition, style, animate, state, Input, ViewChild} from "@angular/core";
import {Location} from "@angular/common";
import {Router, ActivatedRoute, NavigationEnd, RoutesRecognized} from "@angular/router";
import { Organizations } from "./organizations.service";
import {MaxAppContext} from "./maxAppContext.service";
import { UserProfiles } from "./user_profiles.service";
import { SharedService } from "./shared.service";
import { DOCUMENT } from "@angular/platform-browser";
import {Modal} from 'angular2-modal/plugins/bootstrap';
import {Subscription} from 'rxjs/Subscription';
import {TeamsFormComponent} from './teams-form.component';
import { TabsetComponent } from 'ng2-bootstrap/ng2-bootstrap';
import {Pipe, PipeTransform} from '@angular/core';

@Pipe({name:'filterdata'})
export class filterPipe implements PipeTransform {
  transform(value, args:any) : any {
    if (!value) {
      return value;
    } 
return value.filter(o => _.contains(o.orgRoles,'CCH')==false);
   //console.log(sessionStorage['userProfileData']);
  }
}
export class filterParameters{
    orgId:string;
    teamId:string;
    injured: boolean;
    orgRoles:string="ATH";
    orgViews:string = "Cards";
}

@Component({
    selector: 'teams-players',
    animations: [
        trigger('fadeInOut', [
          transition('void => *', [
            style({opacity:0}), //style only for transition transition (after transiton it removes)
            animate(1000, style({opacity:1})) // the new state of the transition(after transiton it removes)
          ]),
          transition('* => void', [
            animate(1000, style({opacity:0})) // the new state of the transition(after transiton it removes)
          ])
        ])
    ],
    templateUrl: '/maxweb/app/app/teams-players.component.html'
})
export class TeamsPlayersComponent {

    private orgStructureData:any;
    skip:number=0;
    take:number=50;
    private userProfileData:any=[];
    private loading:boolean=true;
    private isAutoloading:boolean=false;
    private currentOrgTeam:Object={org:"Everyone", team:''};
    public _element:any;
    private isDataLoaded:boolean=true;
    private sortingParameter:string="sortLastName,sortFirstName";
    public filterParameter = new filterParameters();
    private sortingOrderParameter:string="";
    private noMoreRecords:boolean=false;
    private isCurrentTab:string="teamtab";
    // private unsavedFormData:any;
    private selectOrgTeamSubscribe: Subscription;
    public viewType: string;
    bodyScrollTop: number=0;
    eligibilitychecktrue:boolean=false;
    eligibilitycheck:boolean=false;
    public selectedOrgDetails:any;
    role:string;

    @ViewChild(TeamsFormComponent) teamForm: TeamsFormComponent;
    @ViewChild('staticTabs') staticTabs: TabsetComponent;

    constructor(
        public ctx:  MaxAppContext,
        private _route: ActivatedRoute,
        public _router:Router,
        private _userProfilesSvc: UserProfiles,
        private _organizations: Organizations,
        private _shared: SharedService,
        public element:ElementRef,
        @Inject(DOCUMENT) private document: Document,
        private _model:Modal,
        private location:Location
    )
    {
        this._element = this.element.nativeElement;
        this.selectOrgTeamSubscribe = this._shared.selectedOrgTeam.subscribe(data=>{
            this.currentOrgTeam = data;
        });
    }

    ngOnDestroy() {
        document.body.className = "";
        this.selectOrgTeamSubscribe.unsubscribe();
    }

    ngOnInit() {

        // this.getPrevRoute.unsubscribe();
        // this.getPrevRoute = this._router.events
        //     .filter((e:any) => e.constructor.name === 'RoutesRecognized')
        //     .pairwise()
        //     .subscribe((e: any[]) => {
        //         let url = e[0].urlAfterRedirects;
        //         var urlSplitted = url.split("/");

        //         if(urlSplitted.length > 0){
        //             if(urlSplitted[1] !== "player" && urlSplitted[2] !== "player"){
        //                 console.log("Not previous player details route");

        //             }else{
        //                 console.log("previous player details route");
        //                 sessionStorage['numberOfRecords'] = "";
        //                 sessionStorage['bodyScrollTop'] = 0;
        //                 this.getPrevRoute.unsubscribe();
        //             }
        //         }
        //     });

        // this.getPrevRoute.unsubscribe();

        document.body.className = "team-fix-page";
        this._route.params.subscribe(params =>
        {
            console.log('here')
            this.filterParameter.orgId = params['orgId'];

            this.selectedOrgDetails = this.ctx.availableOrganizations.find(o => {
                return o._id === this.filterParameter.orgId;
            });

            this.filterParameter.teamId = params['teamId'];
            this.sortingOrderParameter ="";
            if(sessionStorage['sortorderview']!=='null'){
               this.sortingOrderParameter=sessionStorage['sortorderview'];
             }else{
                 this.sortingOrderParameter="";
             }

            if(sessionStorage['filterview']!=='null'){
                if(sessionStorage['filterview']=='All'){
                    this.filterParameter.injured = null;
                }else{
                    console.log(sessionStorage['filterview']);
                    this.filterParameter.injured = (sessionStorage['filterview']=='true')? true:false;
                }

            }else{
                this.filterParameter.injured=null;
            }
            this.viewType = 'Cards';
             if(sessionStorage['sortview']!=='null'){
               this.sortingParameter=sessionStorage['sortview'];
             }else{
                 this.sortingParameter="sortLastName,sortFirstName";
             }
           // this.filterParameter.orgRoles = "ATH";
            //use for role filter tab set
            if(sessionStorage['roleviewlist']!=='null'){
                if(sessionStorage['roleviewlist']=='All'){
                    this.filterParameter.orgRoles = null;
                }else{
                    this.filterParameter.orgRoles = sessionStorage['roleviewlist'];
                }

            }else{
                this.filterParameter.orgRoles="ATH";
            }

             let isAdmin:(roles:boolean)=>any = roles =>
                {
                   // console.log(roles);
                    // return roles;
                     if(roles==true){
                     return this.eligibilitychecktrue=true;
                     }else{
                   //  return this.eligibilitychecktrue=false;

                     }
                };
                 let istags:(roles:string)=>boolean = roles =>
                {

                    if(','+this.filterParameter.teamId+','==roles){
                         console.log(','+this.filterParameter.teamId+'=='+roles);
                       return true;
                    }
                   return false;
                };


                var checkorgroleadmin= _.intersection(this.ctx.currentProfile.orgRoles, ['ADM', 'OTRN', 'OADM', 'UADM']).length;
                var checkorgroletrn= _.intersection(this.ctx.currentProfile.orgRoles, ['TRN', 'CCH']).length;
                var checkorgroletrnCCN= _.intersection(this.ctx.currentProfile.orgRoles, ['TRN', 'CCN']).length;

                if(checkorgroleadmin>0){
                    
                    this.eligibilitychecktrue=true;

                }else if(checkorgroletrn>0 && checkorgroletrnCCN==0){
                    
                    if(this.ctx.currentProfile.org == this.filterParameter.orgId && (this.filterParameter.teamId==undefined || this.filterParameter.teamId=='')){
                         // isAdmin(true);
                         this.eligibilitychecktrue=true;
                    }else if(this.ctx.currentProfile.org == this.filterParameter.orgId && (this.filterParameter.teamId !== undefined || this.filterParameter.teamId !=='')){
                        _.find(this.ctx.currentProfile.tags, (lor:any)=>{
                            if(lor.includes(this.filterParameter.teamId)){
                               return  this.eligibilitychecktrue=true;
                            }else{
                               return this.eligibilitychecktrue=false;
                            }
                        })
                    }

                }else{
                     this.eligibilitychecktrue=false;

                }
           //console.log(this.eligibilitychecktrue);
             if(this.eligibilitychecktrue!==undefined && this.eligibilitychecktrue==true){
                   this.eligibilitycheck=true;
             }
            //use for view filter set
            if(sessionStorage['cardview']!==undefined ){
                if(this.eligibilitychecktrue!==undefined && this.eligibilitychecktrue==true){
                    this.filterParameter.orgViews = sessionStorage['cardview']
                }
                else{
                   this.filterParameter.orgViews="Cards";
                }

            }else{
                this.filterParameter.orgViews="Cards";
            }

            this.getFreshTeamList();
            this._shared.currentOrgTeamId.emit({orgId:this.filterParameter.orgId, teamId:this.filterParameter.teamId});
        });

        if(sessionStorage['isCurrentTab'] !== undefined){
            this.isCurrentTab = sessionStorage['isCurrentTab'];
        }

    }

    goToDetails(id){
        if(id){
            // sessionStorage['numberOfRecords'] = this.skip;
            // sessionStorage['bodyScrollTop'] = this.bodyScrollTop;
            this._router.navigate(['main/player', id]);
        }
    }

    @Input("isSaveData") isSaveData(){
        console.log(this.isSaveData);
    }

    getFreshTeamList(){
             this.filterParameter.orgRoles
        this.userProfileData=[];
        this.skip = 0;

        if(sessionStorage['numberOfRecords'] !== undefined && sessionStorage['numberOfRecords'] !== "null" && sessionStorage['numberOfRecords'] !== null && sessionStorage['numberOfRecords'] >= 50){
            this.take = sessionStorage['numberOfRecords'];
        }
        this.loading = true;
        this.getTeamList();
    }

    getTeamList(){
       this.isAutoloading = true;
       this.isDataLoaded = false;

     this._userProfilesSvc.getTeamUserProfiles(
           this.skip,
           this.take,
           false,
           this.sortingParameter,
           this.sortingOrderParameter,
           this.filterParameter).subscribe(data=>{

            if(data.length){

              if(this.filterParameter.orgRoles==null && this.filterParameter.orgViews== 'Eligibility'){
                     //this.userProfileData
                  var teamfilterdata = data.filter(o => _.contains(o.orgRoles,'CCH')==false);
                 // console.log(teamInfoValues);
                  this.userProfileData = this.userProfileData.concat(teamfilterdata);
                   
              }else{
                     this.userProfileData = this.userProfileData.concat(data);
                    
              }
                   
            
               
                if(this.skip === 0 && sessionStorage['bodyScrollTop'] != '0'){
                    setTimeout(()=>{
                        if(sessionStorage['bodyScrollTop'] !== undefined && sessionStorage['bodyScrollTop'] !== 0 && sessionStorage['bodyScrollTop'] !== '0'){
                            window.scrollTo(0, sessionStorage['bodyScrollTop']);
                            sessionStorage['numberOfRecords'] = null;
                            sessionStorage['bodyScrollTop'] = 0;
                        }
                    },500);
                }

                this.skip += data.length;
                this.take = 50;
            }
            this.isAutoloading = false;
            this.loading = false;
            if((data.length % this.take) == 0){
                this.isDataLoaded = true;
                this.noMoreRecords=false;
            }else{

                this.noMoreRecords=true;
            }
       },
       (e)=>{
           console.log('Logo error', e);
            throw e;
       },
       ()=>{

       });
    }

    @HostListener("window:scroll", [])
    onWindowScroll() {
        var bodyScrollTop = this.document.documentElement.scrollTop || this.document.body.scrollTop;
        if(bodyScrollTop / (this.document.body.scrollHeight - this.document.body.clientHeight)>0.9){
            if(this.isDataLoaded == true && this.isCurrentTab == "teamtab")
            {
                this.getTeamList();
            }
        }

        if(bodyScrollTop >= 1 && bodyScrollTop <= 19){
            document.querySelector('body').classList.add("filter-opacity");

            document.querySelector('body').classList.remove("filter-fix");
            document.querySelector('body').classList.remove("filter-opacity-2");
            document.querySelector('body').classList.remove("filter-opacity-3");

        }else if(bodyScrollTop >= 20 && bodyScrollTop <= 39){
            document.querySelector('body').classList.remove("filter-fix");
            document.querySelector('body').classList.remove("filter-opacity");
            document.querySelector('body').classList.remove("filter-opacity-3");

            document.querySelector('body').classList.add("filter-opacity-2");
        }else if(bodyScrollTop >= 40 && bodyScrollTop <= 56){
            document.querySelector('body').classList.remove("filter-opacity-2");
            document.querySelector('body').classList.remove("filter-fix");
            document.querySelector('body').classList.remove("filter-opacity");

            document.querySelector('body').classList.add("filter-opacity-3");
        }else if(bodyScrollTop >= 57){
            document.querySelector('body').classList.remove("filter-opacity-3");
            document.querySelector('body').classList.remove("filter-opacity-2");
            document.querySelector('body').classList.remove("filter-opacity");

            document.querySelector('body').classList.add("filter-fix");
        }else{
            document.querySelector('body').classList.remove("filter-fix");
            document.querySelector('body').classList.remove("filter-opacity-3");
            document.querySelector('body').classList.remove("filter-opacity-2");
            document.querySelector('body').classList.remove("filter-opacity");
        }

        this.bodyScrollTop = bodyScrollTop;
        
        if(bodyScrollTop >= 57){
            sessionStorage['numberOfRecords'] = this.skip;
            sessionStorage['bodyScrollTop'] = this.bodyScrollTop;
        }
    }

    setSorting(sort){

        if(sort=='currentDesignationStatus.sortInjuryStatus'){
            this.sortingOrderParameter="-";
            sessionStorage['sortorderview'] = "-";
        }else{
            this.sortingOrderParameter = "";
            sessionStorage['sortorderview'] = "";
        }
        if(sort){
           this.setSessiondata();
            sessionStorage['sortview'] = sort;

            this.sortingParameter = sort;
        }
        this.getFreshTeamList();
    }

    setSortingOrder(order){
             this.setSessiondata();
        if(order == ""){
            this.sortingOrderParameter = "-";
            sessionStorage['sortorderview'] = "-";
        }
        else{
            this.sortingOrderParameter = "";
            sessionStorage['sortorderview'] = "";
        }
        this.getFreshTeamList();
    }

    setFilter(filter){
         if(filter==null){
            sessionStorage['filterview'] = 'All';
        }else{
            sessionStorage['filterview']=filter;
        }
        if(filter !== undefined){
            this.setSessiondata();
            this.filterParameter.injured = filter;
            sessionStorage['filterview'] = filter;
        }
        this.getFreshTeamList();
    }
     setView(view){
        if(view !== undefined){
            this.viewType = view;
        }
    }

    setOrgRoles(role){
        if(role=='CCH'){
           this.eligibilitychecktrue=false; 
           if(sessionStorage['cardview']=='Eligibility'){
              this.filterParameter.orgViews = 'Cards';
           }
          
        }else{
          this.eligibilitychecktrue=true;   
        }
        if(role==null){
            sessionStorage['roleviewlist'] = 'All';
        }else{

            sessionStorage['roleviewlist']=role;
             this.filterParameter.orgRoles = role;
        }

        if(role !== undefined){
           this.setSessiondata();
            this.filterParameter.orgRoles = role;
            sessionStorage['roleviewlist']=role;
        }
        this.getFreshTeamList();
    }

    setCardview(viewtype)
    {
         //this.userProfileData=  sessionStorage['userProfileData'];
        
          
        sessionStorage['cardview'] = viewtype;
         if(viewtype !== undefined){
             this.setSessiondata();
            this.filterParameter.orgViews = viewtype;
        }
    }
    setSessiondata(){
          sessionStorage['numberOfRecords'] = null;
         sessionStorage['bodyScrollTop'] = 0;
    }

    changeTab(e, type){
        sessionStorage['isCurrentTab'] = type;
        if(type == "teamtab"){
            e.preventDefault();
            e.stopPropagation();
            this.teamForm.lostCurrentRoute().then(res=>{
                console.log(res);
                if(res){
                    this.isCurrentTab = "teamtab";
                    this.sortingOrderParameter ="";
                    this.sortingParameter="sortLastName,sortFirstName";
                    this.filterParameter.injured = null;
                    this.filterParameter.orgRoles = "ATH";
                    this.viewType = "Cards";
                    this.filterParameter.orgViews = "Cards";
                    this.getFreshTeamList();
                }else{
                    this.isCurrentTab = "formtab";
                }
            });
        }

        if(type == "formtab" && this.filterParameter.orgId !== "Everyone" && this.filterParameter.orgId !== null && this.filterParameter.orgId !== undefined){
            this.isCurrentTab = "formtab";
            this.teamForm.refresh();
        }
    }

    // ========== START: this all code related to packet tab form ====================
    // Save data for packet tab on route change only
    confirmChangeRoute():Promise<boolean>{
        return new Promise((resolve, reject) => {
            this.teamForm.lostCurrentRoute().then(data=>{
                if(data){
                    resolve(true);
                }else{
                    resolve(false);
                }
            });
        });
    }
    // ======= END: this all code related to packet tab form ==========================
}