import { Routes, RouterModule }  from '@angular/router';

import {loginRoutes, authProviders} from "./login.routing";
import {MaxFormsShell} from "./max-forms-shell.component";
import {formsRoutes, formsProviders} from "./max-forms.routing";
import {CoverShell} from "./cover.component";
import {MaxAppContext} from "./maxAppContext.service";
import {AuthGuard} from "./auth-guard.service";
import {LandingComponent} from "./landing.component";
import {UserProfileComponent} from "./userProfile.component";
import {ContextProfileRouteGuard} from "./contextProfileRouteGuard.service";
import {PendingProfilesView} from "./pending_profile_approval.component";
import {GetTheAppComponent} from "./getTheApp.component";
import {FormsOrgChooserComponent} from "./formsOrgChooser.component";
import { TeamsComponent } from "./teams.component";
import { TeamsPlayersComponent } from "./teams-players.component";
import { OrganizationStructureResolve } from "./teams.resolve";
import { TeamsPlayerDetailsComponent } from "./teams-player-details.component";
import { TeamsPlayerDetailsResolve } from "./teams-player-details.resolve";
import { AthleteDocumentationForm } from "./athlete_doc_form.component";
import { BasicMedicalForm } from "./basic_medical_form.component";
import { SaveFormGuard } from "./save-form-guard";
import { Tosaccept } from "./tosaccept.service";
import { SelectFormComponent } from "./select-form.component";
import { ResetScrollHistory } from './reset-scroll-history';
import {BasicMedicalSaver} from "./basic_medical_saver.service";

const appRoutes: Routes = [
    {
        path:'',
        pathMatch:'full',
        redirectTo:'main'
    },
    {
        path: 'max-forms',
        component: MaxFormsShell,
        children: [
            ...formsRoutes
        ],
        canActivate:[AuthGuard, MaxAppContext, Tosaccept]
    },

    {
        path: 'max-forms',
        children: [
            {
               path:'form/:profileId/:packetActivityId/:assignmentId/:docDescriptionActivityId',
               component:AthleteDocumentationForm,
               canActivate:[AuthGuard, MaxAppContext, Tosaccept]
            },
            {
                path:'singleForm/:profileId/:docDescriptionActivityId',
                component:AthleteDocumentationForm,
                canActivate:[AuthGuard, MaxAppContext, Tosaccept]
            },            
            {
               path:'create-form/:currentorgId',
               component:SelectFormComponent,
               data:{type:"create-form"},
               canActivate:[AuthGuard, MaxAppContext, Tosaccept]
            },
            {
               path:'edit-form/:currentorgId/:formId',
               component:SelectFormComponent,
               data:{type:"edit-form"},
               canActivate:[AuthGuard, MaxAppContext, Tosaccept]
            }
        ]
    },
    {
        path: 'main',
        component: MaxFormsShell,
        children: [
            {
                path:'',
                pathMatch:'full',
                component:UserProfileComponent,
                canActivate:[ContextProfileRouteGuard]
            },            
            {
                path:'profile/:userProfileId',
                component:UserProfileComponent,
                canActivate:[Tosaccept]
            },
            {
                path:'admin/access-requests',
                component:PendingProfilesView,
                canActivate:[Tosaccept]
            },
            {
                path:'teams',
                component:TeamsComponent,
               // canActivate:[Tosaccept, ResetScrollHistory],
                resolve:{
                  _orgStructureData: OrganizationStructureResolve
                },
                children:[
                    {
                        path:'',
                        component:TeamsPlayersComponent,
                        canActivate:[Tosaccept, ResetScrollHistory]
                    },
                    {
                        path:':orgId',
                        component:TeamsPlayersComponent,
                        canDeactivate: [SaveFormGuard],
                        canActivate:[Tosaccept, ResetScrollHistory]
                    },
                    {
                        path:':orgId/:teamId',
                        component:TeamsPlayersComponent,
                        canDeactivate: [SaveFormGuard],
                        canActivate:[Tosaccept, ResetScrollHistory]
                    }
                 ]
            },
            {
                path:'player/:id',
                component:TeamsPlayerDetailsComponent,
                canActivate:[Tosaccept],
                // canDeactivate: [ResetScrollHistory]
                // resolve:{
                //   _userProfileDetails: TeamsPlayerDetailsResolve
                // }
            },
            {
                path:'basicmedicalForm/:profileId/:docDescriptionActivityId',
                component:BasicMedicalForm,
                canDeactivate: [BasicMedicalSaver],
                canActivate:[AuthGuard, MaxAppContext, Tosaccept]
            }
        ],
        canActivate:[AuthGuard, MaxAppContext]
    },
    {
        path:'max-cover',
        component: CoverShell,
        children:[
            {
                path:'landing',
                component:LandingComponent
            },
            {
                path:'landing/:id',
                component:LandingComponent
            },
            {
                path:'get-the-app',
                component:GetTheAppComponent
            },
            {
                path:'choose-org',
                component:FormsOrgChooserComponent
            },
            ...loginRoutes
        ]
    },
    ...loginRoutes
];

export const routingProviders:any[] = [
    ...authProviders,
    ...formsProviders,
    ContextProfileRouteGuard
];

export const routing = RouterModule.forRoot(appRoutes);