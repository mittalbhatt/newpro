System.register(['@angular/core', '@angular/router', "./registration_context.service", "./activities.service", "./registration_heading.component", "./organizations.service", "./maxAppContext.service"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, router_1, registration_context_service_1, activities_service_1, registration_heading_component_1, organizations_service_1, maxAppContext_service_1;
    var LandingComponent;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (registration_context_service_1_1) {
                registration_context_service_1 = registration_context_service_1_1;
            },
            function (activities_service_1_1) {
                activities_service_1 = activities_service_1_1;
            },
            function (registration_heading_component_1_1) {
                registration_heading_component_1 = registration_heading_component_1_1;
            },
            function (organizations_service_1_1) {
                organizations_service_1 = organizations_service_1_1;
            },
            function (maxAppContext_service_1_1) {
                maxAppContext_service_1 = maxAppContext_service_1_1;
            }],
        execute: function() {
            LandingComponent = (function () {
                function LandingComponent(_route, _activities, _orgs, _ctx) {
                    this._route = _route;
                    this._activities = _activities;
                    this._orgs = _orgs;
                    this._ctx = _ctx;
                }
                LandingComponent.prototype.ngOnInit = function () {
                    var orgId = this._route.snapshot.queryParams['orgId'] || this._route.snapshot.params['orgId'];
                    console.log(orgId);
                    if (orgId)
                        this._ctx.orgId = orgId;
                    else
                        orgId = this._ctx.orgId;
                    var id = this._route.snapshot.queryParams['id'] || this._route.snapshot.params['id'];
                    console.log(id);
                    this.init(orgId, id);
                };
                LandingComponent.prototype.onClickDocAct = function (act) {
                    this.init(act.orgId);
                };
                LandingComponent.prototype.init = function (orgId, id) {
                    var _this = this;
                    if (orgId === void 0) { orgId = null; }
                    if (id === void 0) { id = null; }
                    this.orgId = orgId;
                    this._orgs.getOrgFromDirectory(orgId).single().toPromise()
                        .then(function (org) {
                        _this._ctx.currentOrg = org;
                        console.log(org);
                        if (org)
                            _this.logo = org['logoUrl'];
                    })
                        .catch(function (e) {
                        console.log(e, 'Error loading org from directory.');
                    });
                    this._activities.getDocumentationActivities(orgId, id).single().toPromise()
                        .then(function (activitiesResults) {
                        _this.allDocActs = activitiesResults;
                        if (!id && !orgId)
                            return;
                        if (orgId && _this.allDocActs[0]) {
                            _this.coordinatorName = _this.allDocActs[0].documentationEventDescription.coordinatorName;
                        }
                    })
                        .catch(function (e) {
                        console.error(e);
                        _this.errorMessage = 'We hit an error.  Please refresh to try again.';
                    });
                };
                LandingComponent = __decorate([
                    core_1.Component({
                        selector: 'app-landing',
                        template: "\n    <div id=\"landing-title\">\n            <div [hidden]=\"!errorMessage\" class=\"alert alert-danger\">{{errorMessage}}</div>\n            <div style=\"margin:auto\">\n                <div style=\"margin-bottom:27px;\">\n                    <org-heading></org-heading>\n                </div>\n                <p class=\"lead\">\n                    <a class=\"btn btn-lg btn-default\" [routerLink]=\"['/max-forms/packetList']\" [queryParams]=\"{orgId:orgId}\">Get Started</a>\n                </p>\n                \n            </div>\n            <!--<div *ngIf=\"!coordinatorName && !docAct\" style=\"max-width:300px; margin:auto;\">-->\n                <!--<div class=\"list-group\">-->\n                    <!--<a href=\"javascript:void(0)\" (click)=\"onClickDocAct(act)\" class=\"list-group-item\" *ngFor=\"let act of allDocActs\">-->\n                        <!--<strong>{{act.documentationEventDescription.coordinatorName}}</strong><br/>-->\n                        <!--{{act.documentationEventDescription.eventName}}-->\n                    <!--</a>-->\n                <!--</div>-->\n            <!--</div>-->\n            \n            <a [routerLink]=\"['/max-cover/choose-org']\">&lt;&lt; Choose a different team</a>\n    </div>\n        ",
                        providers: [
                            registration_context_service_1.RegistrationContext, activities_service_1.Activities, registration_heading_component_1.RegistrationHeading
                        ]
                    }), 
                    __metadata('design:paramtypes', [router_1.ActivatedRoute, activities_service_1.Activities, organizations_service_1.Organizations, maxAppContext_service_1.MaxAppContext])
                ], LandingComponent);
                return LandingComponent;
            }());
            exports_1("LandingComponent", LandingComponent);
        }
    }
});
//# sourceMappingURL=landing.component.js.map