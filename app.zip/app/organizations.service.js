System.register(["@angular/http", "@angular/core", "rxjs/Rx"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var __param = (this && this.__param) || function (paramIndex, decorator) {
        return function (target, key) { decorator(target, key, paramIndex); }
    };
    var http_1, core_1, Rx_1;
    var OrgMedia, Organization, Org, Teams, OrgStructure, Organizations;
    return {
        setters:[
            function (http_1_1) {
                http_1 = http_1_1;
            },
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (Rx_1_1) {
                Rx_1 = Rx_1_1;
            }],
        execute: function() {
            OrgMedia = (function () {
                function OrgMedia() {
                }
                return OrgMedia;
            }());
            exports_1("OrgMedia", OrgMedia);
            Organization = (function () {
                function Organization() {
                    this.userTagFormat = ',Sport,Position,';
                }
                return Organization;
            }());
            exports_1("Organization", Organization);
            Org = (function () {
                function Org() {
                }
                return Org;
            }());
            exports_1("Org", Org);
            Teams = (function () {
                function Teams() {
                }
                return Teams;
            }());
            exports_1("Teams", Teams);
            // export class Entries { 
            //     org:Org[]; 
            //     selected:boolean; 
            //     initiallyVisible:boolean; 
            //     teams:Teams[]
            // }
            OrgStructure = (function () {
                function OrgStructure() {
                }
                return OrgStructure;
            }());
            exports_1("OrgStructure", OrgStructure);
            Organizations = (function () {
                function Organizations(_http, _requestOps) {
                    this._http = _http;
                    this._requestOps = _requestOps;
                    this.orgStructureData = new core_1.EventEmitter();
                }
                Organizations.prototype.createOrg = function (org) {
                    return this._http.put('/training/api/organizations', org);
                };
                Organizations.prototype.getOrganizations = function () {
                    return this._http.get('/training/api/organizations?limit=1000')
                        .map(function (response) { return (response.json()); });
                };
                Organizations.prototype.update = function (id, update) {
                    return this._http.put("/training/api/organizations/" + id + "/update", update);
                };
                Organizations.prototype.getLogoMedia = function (org, create) {
                    if (create === void 0) { create = false; }
                    var purpose = 'logo600';
                    var logoMedia = (org.media || []).find(function (m) { return m.purpose == purpose; });
                    if (!logoMedia && create) {
                        logoMedia = new OrgMedia();
                        logoMedia.purpose = purpose;
                        org.media = org.media || [];
                        org.media.push(logoMedia);
                    }
                    return logoMedia;
                };
                Organizations.prototype.getLogo = function (organization) {
                    var _this = this;
                    return Rx_1.Observable.create(function (observer) {
                        var logoMedia = _this.getLogoMedia(organization);
                        if (!logoMedia) {
                            observer.next(null);
                            observer.complete();
                            return;
                        }
                        var req = new XMLHttpRequest();
                        var url = "/training/api/organizations/" + organization._id + "/media/" + encodeURIComponent(logoMedia.mediaId);
                        req.open('get', url);
                        req.onreadystatechange = function () {
                            if (req.readyState == 4 && req.status == 200) {
                                var loc = req.getResponseHeader('location');
                                //console.log('Getting logo - ' + loc);
                                var req2_1 = new XMLHttpRequest();
                                req2_1.open('get', loc);
                                req2_1.responseType = 'blob';
                                req2_1.onreadystatechange = function () {
                                    if (req2_1.readyState == 4 && req2_1.status == 200) {
                                        var win = window;
                                        var urlCreator = (win.URL || win.webkitURL);
                                        var blobUrl = urlCreator.createObjectURL(req2_1.response);
                                        observer.next(blobUrl);
                                        observer.complete();
                                    }
                                    else if (req2_1.readyState == 4) {
                                        observer.error(new Error(req.responseText));
                                    }
                                };
                                req2_1.send();
                            }
                            else if (req.readyState == 4) {
                                observer.error(new Error(req.responseText));
                            }
                        };
                        req.setRequestHeader('Authorization', _this._requestOps.headers.get('Authorization'));
                        req.send();
                    });
                };
                Organizations.prototype.getLogoUrldocumentmedia = function (value) {
                    var _this = this;
                    return Rx_1.Observable.create(function (observer) {
                        if (value.media[0].thumbnailId) {
                            var logoMedia = value.media[0].thumbnailId;
                        }
                        else {
                            var logoMedia = value.media[0].mediaId;
                        }
                        if (!logoMedia) {
                            observer.next(null);
                            observer.complete();
                            return;
                        }
                        var req = new XMLHttpRequest();
                        var url = "/training/api/documents/" + value._id + "/media/" + encodeURIComponent(logoMedia);
                        req.open('get', url);
                        req.onreadystatechange = function () {
                            if (req.readyState == 4 && req.status == 200) {
                                var loc = req.getResponseHeader('location');
                                observer.next(loc);
                                observer.complete();
                            }
                            else if (req.readyState == 4) {
                                observer.error(new Error(req.responseText));
                            }
                        };
                        req.setRequestHeader('Authorization', _this._requestOps.headers.get('Authorization'));
                        req.send();
                    });
                };
                Organizations.prototype.getLogoUrldocumentmediapopup = function (currmediaid, id) {
                    var _this = this;
                    return Rx_1.Observable.create(function (observer) {
                        var logoMedia = currmediaid;
                        if (!logoMedia) {
                            observer.next(null);
                            observer.complete();
                            return;
                        }
                        var req = new XMLHttpRequest();
                        var url = "/training/api/documents/" + id + "/media/" + encodeURIComponent(logoMedia);
                        req.open('get', url);
                        req.onreadystatechange = function () {
                            if (req.readyState == 4 && req.status == 200) {
                                var loc = req.getResponseHeader('location');
                                observer.next(loc);
                                observer.complete();
                            }
                            else if (req.readyState == 4) {
                                observer.error(new Error(req.responseText));
                            }
                        };
                        req.setRequestHeader('Authorization', _this._requestOps.headers.get('Authorization'));
                        req.send();
                    });
                };
                Organizations.prototype.getLogoUrl = function (organization) {
                    var _this = this;
                    return Rx_1.Observable.create(function (observer) {
                        var logoMedia = _this.getLogoMedia(organization);
                        if (!logoMedia) {
                            observer.next(null);
                            observer.complete();
                            return;
                        }
                        var req = new XMLHttpRequest();
                        var url = "/training/api/organizations/" + organization._id + "/media/" + encodeURIComponent(logoMedia.mediaId);
                        req.open('get', url);
                        req.onreadystatechange = function () {
                            if (req.readyState == 4 && req.status == 200) {
                                var loc = req.getResponseHeader('location');
                                observer.next(loc);
                                observer.complete();
                            }
                            else if (req.readyState == 4) {
                                observer.error(new Error(req.responseText));
                            }
                        };
                        req.setRequestHeader('Authorization', _this._requestOps.headers.get('Authorization'));
                        req.send();
                    });
                };
                Organizations.prototype.getOrgFromDirectory = function (orgId) {
                    var args = new http_1.RequestOptions();
                    args.search = new http_1.URLSearchParams();
                    args.search.append('$filter.0._id', "ObjectId(" + orgId + ")");
                    args.search.append('limit', '1');
                    return this._http.get('/training/api/organizations/directory', args)
                        .map(function (res) { return res.json()[0]; });
                };
                Organizations.prototype.getOrgByCodeFromDirectory = function (code) {
                    var args = new http_1.RequestOptions();
                    args.search = new http_1.URLSearchParams();
                    args.search.append('$filter.0.shortCode', code.toUpperCase());
                    args.search.append('limit', '1');
                    return this._http.get('/training/api/organizations/directory', args)
                        .map(function (res) { return res.json()[0]; });
                };
                Organizations.prototype.getOrgsBySearchFromDirectory = function (search, limit) {
                    if (limit === void 0) { limit = 25; }
                    var args = new http_1.RequestOptions();
                    args.search = new http_1.URLSearchParams();
                    args.search.append('$search', search);
                    args.search.append('limit', limit.toString());
                    return this._http.get('/training/api/organizations/directory', args)
                        .map(function (res) { return (res.json()); });
                };
                Organizations.prototype.getOrgStructureConfig = function (profileId) {
                    return this._http.get("/training/api/orgStructureConfig/byUser/" + profileId).map(function (res) { return (res.json()); });
                };
                Organizations = __decorate([
                    core_1.Injectable(),
                    __param(1, core_1.Inject(http_1.RequestOptions)), 
                    __metadata('design:paramtypes', [http_1.Http, http_1.RequestOptions])
                ], Organizations);
                return Organizations;
            }());
            exports_1("Organizations", Organizations);
        }
    }
});
//# sourceMappingURL=organizations.service.js.map