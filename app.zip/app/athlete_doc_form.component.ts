import {Router, ActivatedRoute, ActivatedRouteSnapshot, CanDeactivate, RouterStateSnapshot} from "@angular/router";
import {UserProfiles, UserProfile} from "./user_profiles.service";
import {RegistrationContext} from "./registration_context.service";
import {
    Component, OnInit, OnDestroy, Input, ViewChild,
    HostListener, ElementRef
} from "@angular/core";
import {Documents} from "./document_factory.service";
import {
    DocumentationDocument,
    DocumentDescriptionFormatSection, DocumentDescriptionFormatSectionField, DocumentationDocumentData,
    HideableDocumentElement
} from "./documentation_document";
import * as _ from "underscore";
import {DocumentChangeSaver} from "./document_change_saver.service";
import {Pipe, PipeTransform} from '@angular/core';
import {MaxAppContext} from "./maxAppContext.service";
import {IntercomRouterTracker} from "./intercomRouterTracker.service";

@Pipe({name:'dataItem'})
export class DataItemPipe implements PipeTransform {
    static lookupValue(ident:string, data:any[], cache:any)
    {
        var value = cache[ident];
        return value ? value.value : undefined;
    }

    static lookupTextValue(ident:string, data, cache:any)
    {
        var ret = DataItemPipe.lookupValue(ident, data, cache);
        if (!ret)
            ret = "";
        return ret;
    }

    transform(value:any[], ident:string, cache:any) : any {
        return DataItemPipe.lookupTextValue(ident, value, cache);
    }
}

@Component({
    selector: 'ath-doc-form',
    templateUrl:'/maxweb/app/app/ath_doc_form.component.html',
    // styleUrls:['/maxweb/app/app/ath_doc_form.component.css'], -- not working for some reason - I'll just include it in the root index.html
})

export class AthleteDocumentationForm implements OnInit, OnDestroy, CanDeactivate<AthleteDocumentationForm> {
    private _documentDescriptionActivity:string;
    private _assignmentId:string;
    
    document:DocumentationDocument;
    documentSections:DocumentDescriptionFormatSection[];
    errorMessage:string;
    validationErrors:any;
    validationSummary:string;
    submitting:boolean;
    printing:boolean;
    loading:boolean;
    pdfUrl:string;
    packetActivityId:string;

    subjectProfileId:string;
    subjectProfile:UserProfile;

    // should be able to specify @Input('viewer-as-admin') to have a better parameter name, but that's not working with ngUpgrade
    @Input() admin:boolean;

    @ViewChild('leftMenu')leftMenu:ElementRef;
    stickMenu:boolean;
    startingMenuOffset:number;

    dataCache:any = {};

    constructor(
        private _ctx: RegistrationContext,
        private _appCtx: MaxAppContext,
        private _router:Router,
        private _route: ActivatedRoute,
        private _documents:Documents,
        private _userProfiles:UserProfiles,
        private _changeSaver:DocumentChangeSaver,
        private _intercom:IntercomRouterTracker
    )  {
        this.validationErrors = {};
        this._changeSaver.status.subscribe(status =>
        {
            if (!status.saved)
                this.handleError(status.response);
        });
    }

    @HostListener('window:scroll')
    onScroll()
    {
        this.stickMenu = document.body.scrollTop > this.startingMenuOffset - 5; // 5 matches the 'top' setting in the .left-menu-stick css class
    }

    ngOnDestroy()
    {
        this._changeSaver.stop();
    }

    ngOnInit()
    {
        this.startingMenuOffset = this.leftMenu.nativeElement.offsetTop;
        // console.log('START ' + this.startingMenuOffset);
        this.refresh();
    }

    canDeactivate(component:AthleteDocumentationForm, route:ActivatedRouteSnapshot, state: RouterStateSnapshot):any
    {
        this._changeSaver.stop();
        return this._changeSaver.saveNow().single().toPromise()
            .then(() => {
                return true;
            })
            .catch(error =>
            {
                this.submitting = false;
                this._changeSaver.start(this.document._id);

                this.handleError(error, 'We encountered an error saving your changes. Please refresh and try again.');
            });
    }

    get gradYearOptions():string[]
    {
        var currentYear = (new Date()).getFullYear();
        return _.range(currentYear, currentYear+13).map(i => i.toString());
    }

    get flaggedFields():DocumentDescriptionFormatSectionField[]
    {
        return _.chain(this.documentSections)
            .pluck('fields')
            .flatten()
            .filter((f:DocumentDescriptionFormatSectionField) =>
            {
                return f.flagIf !== undefined && this.lookupValue(f.ident) === f.flagIf;
            })
            .value();
    }

    get sectionsWithShortcuts()
    {
        if (!this.documentSections)
            return [];

        return this.documentSections.filter(ds => !!ds.shortcutName && !this.shouldHideHideable(ds));
    }
    
    fieldHasFormAlert(field:DocumentDescriptionFormatSectionField)
    {
        return (this.admin && (field.flagIf !== undefined) && (field.flagIf === this.lookupValue(field.ident)));
    }

    explainText(field:DocumentDescriptionFormatSectionField)
    {
        return field.explanationPrompt ? field.explanationPrompt : 'Please explain: ';
    }

    lookupValue(ident:string)
    {
        if (!this.document)
            return undefined;

        return DataItemPipe.lookupValue(ident, this.document.data, this.dataCache);
    }

    lookupTextValue(ident:string)
    {
        return DataItemPipe.lookupTextValue(ident, this.document.data, this.dataCache);
    }

    valueArrayContains(ident:string, elemValue:any)
    {
        if (!this.document)
            return false;

        var value = _.find(this.document.data, d => d.ident == ident);
        if (value)
            return _.contains(value.value, elemValue);

        return false;
    }

    //valuesNotInList(ident:string, values:any)
    //{
    //    if (!this.document)
    //        return "";
    //
    //    var value = _.find(this.document.data, d => d.ident == ident);
    //    if (value)
    //        return _.without(value.value, values);
    //
    //    return "";
    //}

    onYesNo(ident:string, answer:boolean)
    {
        this.updateValue(ident, answer);

        if (answer === false)
            this.updateValue(ident+'_explain', '');
    }

    onTextChange(ident:string, event:any)
    {
        this.updateValue(ident, event.target.value);
    }

    onSelectMultiCheckChange(ident:string, option:string, event:any)
    {
        this.updateListValue(ident, option, event.target.checked);
    }

    updateValue(ident:string, value:any)
    {
        delete this.validationErrors[ident];

        this._changeSaver.addChange({ident:ident, value:value});

        var item = _.find(this.document.data, d => d.ident == ident);
        if (item)
            item.value = value;
        else
            this.document.data.push({ident:ident, value:value});

        this.dataCache[ident] = {ident:ident, value:value};
    }

    updateListValue(ident:string, value:any, included:boolean)
    {
        var item = _.find(this.document.data, d => d.ident == ident);
        if (!item)
        {
            item = {ident: ident, value: []};
            this.document.data.push(item);
        }

        if (included)
            item.value = _.union(item.value, [value]);
        else
            item.value = _.difference(item.value, [value]);

        this._changeSaver.addChange({ident:ident, value:item.value});

        this.dataCache[ident] = {ident:ident, value:item.value};
    }
    
    goToSection(name:string)
    {
        this.scrollIntoView(name);
    }

    goToField(ident:string)
    {
        this.scrollIntoView(ident);
    }

    private scrollIntoView(id:string)
    {
        document.getElementById(id).scrollIntoView();

        if (this.admin)
        {
            // Account for name floating at top.
            window.scrollBy(0, -100);
        }
    }
    
    shouldHideHideable(field:HideableDocumentElement)
    {
        return field.showIfAll && !_.every(field.showIfAll, f => this.lookupValue(f.ident) === f.value);
    }

    valueIsNullUndefinedOrEmpty(ident)
    {
        var val = this.lookupValue(ident);
        if (val && val.trim)
            val = val.trim();

        return !val && (val !== false);
    }

    onClickReviewPdfPages(field)
    {
        this.onYesNo(field.ident, true);
    }

    onPrint()
    {
        var win = window.open(`/maxweb/app/media/spinner.html`);

        this._changeSaver.stop();
        this._changeSaver.saveNow().single().toPromise()
            .then(() =>
            {
                this._changeSaver.start(this.document._id);
                win.location.assign(this.pdfUrl);
            })
            .catch(e =>
            {
                win.close();
                this._changeSaver.start(this.document._id);
                this.handleError(e, 'We encountered an error saving your changes. Please refresh and try again.');
            });
    }

    onSubmit()
    {
        this.validationErrors = {};
        this.validationSummary = null;

        var requiredUnfilled = _.chain(this.documentSections)
            .pluck('fields')
            .flatten()
            .filter(f => {
                return (f.required || (f.requireIfAll && _.every(f.requireIfAll, (ff:DocumentationDocumentData) => this.lookupValue(ff.ident) === ff.value)))
                    && this.valueIsNullUndefinedOrEmpty(f.ident);
            })
            .pluck('ident')
            .value();

        var explanationsRequiredUnfulfilled = _.chain(this.documentSections)
            .pluck('fields')
            .flatten()
            .filter(f => {
                return f.explanationRequired && this.lookupValue(f.ident) === true && this.valueIsNullUndefinedOrEmpty(f.ident + '_explain')
            })
            .pluck('ident')
            .map(i => i + '_explain')
            .value();

        requiredUnfilled = requiredUnfilled.concat(explanationsRequiredUnfulfilled);
        requiredUnfilled.forEach(ident => this.validationErrors[ident] = true);

        if (requiredUnfilled.length)
        {
            var summary = requiredUnfilled.length > 1 ? 'There are' : 'There is';
            summary += ' ' + requiredUnfilled.length + ' ';
            summary += requiredUnfilled.length > 1 ? 'fields' : 'field';
            summary += ' that you haven\'t filled in. Look for the fields marked in red.';
            this.validationSummary = summary;
            window.scrollTo(0,0);
            // console.log(JSON.stringify(requiredUnfilled));
            return;
        }

        var requiredResponseNotMatching = _.chain(this.documentSections)
            .pluck('fields')
            .flatten()
            .filter(f => {
                return f.requiredResponse !== undefined && !_.isEqual(this.lookupValue(f.ident), f.requiredResponse);
            })
            .pluck('ident')
            .value();

        requiredResponseNotMatching.forEach(ident => this.validationErrors[ident] = true);

        if (requiredResponseNotMatching.length)
        {
            var summary = requiredResponseNotMatching.length > 1 ? 'There are' : 'There is';
            summary += ' ' + requiredResponseNotMatching.length + ' ';
            summary += requiredResponseNotMatching.length > 1 ? 'fields' : 'field';
            summary += ' that does not contain the required response.  Look for the fields marked in red.';
            this.validationSummary = summary;
            window.scrollTo(0, 0);
            // console.log(JSON.stringify(requiredResponseNotMatching));
            return;
        }

        this.submitting = true;
        
        this._changeSaver.stop();
        this._changeSaver.saveNow().single().toPromise()
            .then(() =>
            {
                if (this.canSign())
                    return Promise.resolve(null);

                return this._documents.completeDocument(this.document._id).single().toPromise();
            })
            .then(() =>
            {
                if (this.document.type == 'Medical' && this.document.name == 'Medical Record')
                {
                    var records = [{medicalRecordStableDocumentId:this.document.documentStableId}];
                    return this._userProfiles.updateProfile(this.subjectProfile._id, {$set:{medicalRecords:records}}).single().toPromise();
                }
                else
                {
                    return Promise.resolve(null);
                }
            })
            .then(() => {
                this._intercom.track('submitted-form', {formName:this.document.name});
                this.goBack();
            })
            .catch(error =>
            {
                this.submitting = false;
                this._changeSaver.start(this.document._id);

                this.handleError(error, 'We encountered an error saving your changes. Please refresh and try again.');
            });
    }

    private onBack()
    {
        this._changeSaver.stop();
        this._changeSaver.saveNow().single().toPromise()
            .then(() => {
                this.goBack();
            })
            .catch(error =>
            {
                this.submitting = false;
                this._changeSaver.start(this.document._id);

                this.handleError(error, 'We encountered an error saving your changes. Please refresh and try again.');
            });
    }

    private goBack() 
    {
        if (this.admin)
        {
            this._router.navigate(['admin/event', this.packetActivityId], {relativeTo:this._route.parent});
        }
        else
        {
            let queryParams = {
              activityId:this.packetActivityId,profileId:this.subjectProfileId
            };

            
            // if(this._documentDescriptionActivity !== undefined && this._documentDescriptionActivity !== ""){
            //     activityId = this._documentDescriptionActivity;
            // }
            console.log(this.packetActivityId);

            if(this.packetActivityId !== undefined && this.packetActivityId !== ""){
                this._router.navigate(['athDocDashboard',this.packetActivityId, this.subjectProfileId], {relativeTo:this._route.parent});
            }else{
                this._router.navigate(['packetList', {profileId:this.subjectProfileId}], {relativeTo:this._route.parent});
            }
            

            // this._router.navigate(['/max-forms/athDocDashboard'], {queryParams: queryParams});

            // this._router.navigate(['packetList', {profileId:this.subjectProfileId}], {relativeTo:this._route.parent});
        }
    }

    canSign()
    {
        return this.admin && !this.document.originalDescription.staffOnly && this.document.completedDate;
    }

    private handleError(error:any, message:string=null)
    {
        let parsed = null;
        try {
            parsed = error.json();
        } catch(e)
        {

        }

        if (parsed && parsed.message)
        {
            this.errorMessage = parsed.message;
            return;
        }

        if (error.message)
        {
            this.errorMessage = error.message;
            return;
        }

        this.errorMessage = message || 'An error has occurred. Please refresh and try again.';
        window.scrollTo(0,0);

        throw error;
    }

    pdfPagesUrl(field)
    {
        var url = this.pdfUrl;
        if (field.pages)
            url += '&pages=' + field.pages;
        return url;
    }

    private refresh()
    {
        this.loading = true;
        let params = this._route.snapshot.params;

        
        this._documentDescriptionActivity = params['docDescriptionActivityId'];
        this._assignmentId = params['assignmentId'];
        let profileId = params['profileId'];
        this.subjectProfileId = profileId;
        
        this.packetActivityId = params['packetActivityId'];
        var loadProfile = this._userProfiles.getProfile(profileId).single().toPromise();

        loadProfile.then(p => {
            this.subjectProfile = p;
            if (this._appCtx.currentProfile && this.subjectProfileId === this._appCtx.currentProfile._id)
            {
                this.admin = false;
            }
            else
            {
                this.admin = !!this._appCtx.myProfiles.find(mp =>
                    (mp.org == p.org && !!_.intersection(mp.orgRoles, ['TRN', 'OTRN', 'OADM']).length)
                    ||
                    (mp.linkedOrgRoles && !!mp.linkedOrgRoles.find(lor => lor.orgId == p.org && !!_.intersection(lor.roles, ['TRN', 'OTRN', 'OADM']).length)));
            }
        });

        loadProfile
            .then(p => p._id)
            .then(pid => {
                return this._documents.findOrCreateDocument(
                    this._documentDescriptionActivity,
                    this._assignmentId,
                    pid).single().toPromise();
            })
            .then(documents => {
                this.loading = false;

                // If there were multiple matches, they would all be returned here.
                // We don't have a rule for selecting which one other than we would
                // hope that the last in is the latest.
                this.document = documents[documents.length - 1];
                (this.document.data || []).forEach(d =>
                {
                    this.dataCache[d.ident] = d;
                });
                this.documentSections = this.document.originalDescription.format.sections;
                this._changeSaver.start(this.document._id);

                var docStableId = this.document.documentStableId;
                var username = encodeURIComponent(this._ctx.creds.username);
                var password = encodeURIComponent(this._ctx.creds.password);
                this.pdfUrl = `${window.location.protocol}//${window.location.host}/training/api/documents/${docStableId}/pdf?auth.basic.username=${username}&auth.basic.password=${password}`;
            })
            .catch(error => {
                this.loading = false;
                this.handleError(error);
            });
    }
}
