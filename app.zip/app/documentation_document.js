System.register([], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var DocumentDescriptionFormatSectionField, DocumentDescriptionFormatSection, DocumentDescriptionFormat, DocumentDescription, DocumentationDocumentData, DocumentationShowIfAllData, DocumentationDocument;
    return {
        setters:[],
        execute: function() {
            DocumentDescriptionFormatSectionField = (function () {
                function DocumentDescriptionFormatSectionField() {
                }
                return DocumentDescriptionFormatSectionField;
            }());
            exports_1("DocumentDescriptionFormatSectionField", DocumentDescriptionFormatSectionField);
            DocumentDescriptionFormatSection = (function () {
                function DocumentDescriptionFormatSection() {
                }
                return DocumentDescriptionFormatSection;
            }());
            exports_1("DocumentDescriptionFormatSection", DocumentDescriptionFormatSection);
            DocumentDescriptionFormat = (function () {
                function DocumentDescriptionFormat() {
                }
                return DocumentDescriptionFormat;
            }());
            exports_1("DocumentDescriptionFormat", DocumentDescriptionFormat);
            DocumentDescription = (function () {
                function DocumentDescription() {
                }
                return DocumentDescription;
            }());
            exports_1("DocumentDescription", DocumentDescription);
            DocumentationDocumentData = (function () {
                function DocumentationDocumentData() {
                }
                return DocumentationDocumentData;
            }());
            exports_1("DocumentationDocumentData", DocumentationDocumentData);
            DocumentationShowIfAllData = (function () {
                function DocumentationShowIfAllData() {
                }
                return DocumentationShowIfAllData;
            }());
            exports_1("DocumentationShowIfAllData", DocumentationShowIfAllData);
            DocumentationDocument = (function () {
                function DocumentationDocument() {
                }
                return DocumentationDocument;
            }());
            exports_1("DocumentationDocument", DocumentationDocument);
        }
    }
});
//# sourceMappingURL=documentation_document.js.map