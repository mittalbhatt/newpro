import { Injectable } from '@angular/core';
import { Resolve, ActivatedRouteSnapshot } from '@angular/router';
import { Organizations, OrgStructure } from "./organizations.service";
import {MaxAppContext} from "./maxAppContext.service";

// Get list data of organization structure
@Injectable()
export class OrganizationStructureResolve implements Resolve<OrgStructure> {
  constructor(
      private _organizations: Organizations,
      public ctx: MaxAppContext,
      ) {}
  resolve(route: ActivatedRouteSnapshot) {
    return this._organizations.getOrgStructureConfig(this.ctx.currentProfile._id);
  }
}

// Get list data of teams employers
// @Injectable()
// export class UsersGetResolve implements Resolve<any> {
//   constructor(private _organizations: Organizations,) {}
//   resolve(route: ActivatedRouteSnapshot) {
//     const id = +route.params['id'];
//     return this._users.getUser(id);
//   }
// }