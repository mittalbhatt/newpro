import { Component, ChangeDetectionStrategy, ChangeDetectorRef} from '@angular/core';
import {Observable} from 'rxjs/Rx';
import {DfObjectId} from "./DfObjectId";
import {Assignments, Assignment} from "./assignments.service";
import {MaxAppContext} from "./maxAppContext.service";
import {Overlay, overlayConfigFactory} from 'angular2-modal';
import {Subscription} from 'rxjs/Subscription';
import { ActivatedRoute, Router } from '@angular/router';
import {Modal, BSModalContext} from 'angular2-modal/plugins/bootstrap';

@Component({
  selector: 'app-root',
  templateUrl: '/maxweb/app/app/select-form.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush
}) 
export class SelectFormComponent {
     formFields:Array<any> = [
        {
          "name": "",
          "shortcutName":"",
          "fields":[],
        },
        {
          "ident": "",
          "name": "",
          "hint": "",
          "type": "text",
          "required": true,
          "defaultValue": ""
        },
        {
          "ident": "",
          "name": "",
          "type": "selectOne",
          "options": [
            "Male",
            "Female"
          ],
          "defaultValue": ""
        },
        {
          "ident": "",
          "name": "",
          "hint": "",
          "type": "date",
          "required": true,
          "defaultValue": ""
        },
        {
          "ident": "",
          "name": "",
          "hint": "",
          "type": "shorttext",
          "required": true,
          "defaultValue": ""
        },
        {
          "ident": "",
          "name": "",
          "hint": "",
          "type": "longtext",
          "required": true,
          "defaultValue": ""
        }
    ];

   dynamicForm:Array<any> = [];
   forampostdata:any;
   model:SelectFormComponent;
   addfieldText:any;
   private lastTxtSearchVal:string="";
   popupDataSubscribe: Subscription;
   currentorgId: String="";
   formId: String="";
   hideme:Array<any> = [];
   editformname:boolean=false;
   formname:string='';
   errorclassfield:Array<any> = [];
   isSubmittFirstTime:boolean=false;
   isLoadRecords:boolean=false;
   isSave:boolean=false;

    constructor(
        private _assignmentsSvc:Assignments,
        public ctx:MaxAppContext,
        private route: ActivatedRoute,
        private router: Router,
        private _modal:Modal,
        private chgRef: ChangeDetectorRef
    )
    {
          this.route.params.subscribe(params => {
          this.formId = params['formId'];
          this.currentorgId = params['currentorgId'];
          let urlType = this.route.snapshot.data['type'];
          if(urlType == "edit-form"){
            this.isLoadRecords = true;
            this._assignmentsSvc.getActivities("Document").subscribe(
              (data:any)=>{
                if(data){
                    let findObj: any = _.find(data, {_id: this.formId});
                    if(findObj !== null && findObj !== undefined){
                        this.formname = findObj.name;
                        findObj.format.sections.forEach(section => {
                          this.dynamicForm.push(section);
                          this.chgRef.markForCheck();
                        });
                    }
                }  
              },
              e=>{ throw e; },
              ()=>{this.isLoadRecords = false;}
            );
          }

        });
    }
    
    trackByIndex(index: number, obj: any): any {
      return index;
    }

    transferDataSuccess($event: any) {
        if($event.dragData !== undefined && $event.dragData !== null && $event.dragData.fields!==undefined){
          var obj = JSON.parse(JSON.stringify($event.dragData));
          this.dynamicForm.push(obj);
        }
    }

    addSectionFields($event: any, i: number){
       if($event.dragData !== undefined && $event.dragData !== null && $event.dragData.type!==undefined){
        var obj = JSON.parse(JSON.stringify($event.dragData));
        this.dynamicForm[i].fields.push(obj);
      }
    }

    removeField(i:number,type:String,j:number=null){
      let msg:String="Are you sure? you want to delete section!";
      if(type=="section_field"){
        msg = "Are you sure? you want to delete field!";
      }
      this.areYouSure(msg).then((res:boolean)=>{
        if(res){
          if(type=="section_field"){
            if(this.dynamicForm[i].fields !== undefined && j !== null){
              this.dynamicForm[i].fields.splice(j,1);
              this.chgRef.markForCheck();
            }
          }else if(type=="section"){
            if(this.dynamicForm !== undefined){
              this.dynamicForm.splice(i,1);
              this.chgRef.markForCheck();
            }
          }
        }
      });
    }

    changesection(item,key){
      this.hideme[item] = key;
    }

    editform(index,key){
      this.editformname=key;
    }

    checkerror(i:number=null,j:number=null):boolean{
      if(this.isSubmittFirstTime){
        if(i !== null && j !== null){
          if(this.dynamicForm[i].fields[j].name !== undefined && this.dynamicForm[i].fields[j].name === ""){
            return true;
          }
        }else if(i !== null){
          if(
            (this.dynamicForm[i].name !== undefined ) && (this.dynamicForm[i].name === "" || this.dynamicForm[i].fields.length === 0)
          ){
            return true;
          }
        }
      }
      return false;
    }

    checkErrorBeforeSave():Promise<boolean>{
      return new Promise((resolve, reject) => {
        let i=0;
        let isError:boolean = false;
        this.dynamicForm.forEach(section =>{
          let j=0;

          if(this.checkerror(i)){
            resolve(true);
          }
          section.fields.forEach(field =>{

            if(this.checkerror(i,j)){
              resolve(true);
            }
            j++;
          });
          i++;
        });
        resolve(false);
      });
    }
    
    onAddFormdata(){
      this.isSubmittFirstTime = true;
      this.checkErrorBeforeSave().then(error=>{
        if(!error){
          this.isSave = true;
          let formId = (new DfObjectId()).toString();
          let profileId = this.ctx.currentProfile;
          this.forampostdata={
            "_id": formId, 
            "type": "Document",
            "documentType": "documentation",
            "context": "",
            "lastModifiedDate": "", 
            "documentAudience": [{
              "roles": [
                "TRN"
              ],
              "ofUserProfile": {
                "_id": profileId
              }
            }],
            "name": this.formname, 
            "orgId": this.currentorgId,
            "format": {
              "sections": this.dynamicForm
            }
          };
          
          this._assignmentsSvc.createForm(this.forampostdata).single().toPromise().then((d:any)=>{
            this.isSave = false;
            console.log(this.currentorgId);
            this.router.navigateByUrl(`/main/teams/${this.currentorgId}`);
          }).catch(e=>{
          });
        }
      }).catch(e=>{ console.log(e)});
    }

    areYouSure(msg:String=null):Promise<boolean>{
        return new Promise((resolve, reject) => {
            this._modal.confirm()
            .size('sm').isBlocking(true).showClose(false).keyboard(27)
            .body(`${msg}`)
            .headerClass("hide")
            .okBtnClass("btn btn-primary")
            .cancelBtnClass("btn btn-danger")
            .open().then((dialog : any ) => {
                return dialog.result;
            }).then(result =>{
                if(result === true){
                    resolve(true);                    
                }else{
                    resolve(false);
                }
            }).catch((e:any)=>{
                resolve(e);
            }).catch((e:any)=>{
                resolve(e);
            });
        });
    }
}