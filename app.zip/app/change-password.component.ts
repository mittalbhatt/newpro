import {Component} from "@angular/core";
import {BSModalContext} from "angular2-modal/plugins/bootstrap";
import {UserProfile, UserProfiles} from "./user_profiles.service";
import {DialogRef, ModalComponent} from "angular2-modal";
import {OnInit} from "@angular/core";
import {DfObjectId} from "./DfObjectId";
import {UserAccountService, UserAccount, Username} from "./userAccount.service";
import {MaxAppContext} from "./maxAppContext.service";
import {Helper} from "./helper.service";

export class ChangePasswordData extends BSModalContext
{
    pendingProfile:UserProfile;
    save:() => Promise<boolean>;
}

export class ChangePasswordModel{
    new_password:string;
    confirm_password:string;
}

@Component({
    selector:'change-password-modal-content',
    template:`
    <div class="modal-content">
        <form (ngSubmit)="changePassword()">
        <div class="modal-header">
        <h4 class="modal-title pull-left">Change Password</h4>
        <button type="button" class="close pull-right" (click)="closeModel()" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
        </div>
        <div class="modal-body">
            <div *ngIf="errorMessage" class="alert alert-danger"><span [innerHTML]="errorMessage" class="error-msg"></span></div>
            <div *ngIf="successMessage" class="alert alert-success"><span [innerHTML]="successMessage" class="error-msg"></span></div>
            <span *ngIf="!successMessage">
            <div class="form-group">
                <label for="level">Password</label>
                <input [(ngModel)]="model.new_password" type="password" class="form-control" name="new_password" id="new_password" placeholder="New Password" />
            </div>
            <div class="form-group">
                <label for="level">Confirm Password</label>
                <input [(ngModel)]="model.confirm_password" type="password" class="form-control" name="confirm_password" id="confirm_password" placeholder="Confirm Password" />
            </div>
            </span>
        </div>
        <div class="modal-footer">
            <button type="submit" class="btn btn-primary" *ngIf="!successMessage">Change Password</button>
            <button type="button" class="btn btn-danger" (click)="closeModel()" *ngIf="!successMessage">Cancel</button>
            <button type="button" class="btn btn-default" (click)="closeModel()" *ngIf="successMessage">Ok</button>
        </div>
        </form>
    </div>
`
})
export class ChangePasswordModal implements OnInit, ModalComponent<ChangePasswordData>
{
    errorMessage:string;
    successMessage:string;
    saving:boolean;
    model:ChangePasswordModel;
    submitting:boolean=true;

    constructor(
        public dialog:DialogRef<ChangePasswordData>,
        private _profilesSvc:UserProfiles,
        private _acctSvc:UserAccountService,
        private _max:MaxAppContext,
        private _helper:Helper
    ){
        this.model = new ChangePasswordModel();
    }

    ngOnInit()
    {
        console.log(this._max);
    }

    closeModel(){
        this.dialog.close(false);
    }

    changePassword(){
        this.errorMessage = "";
        this.submitting = true;
        if(this.model.new_password === undefined || this.model.confirm_password === undefined){
            this.errorMessage = "Please enter password & confirm password.";
            this.submitting = false;
            return;
        }

        if(this.model.new_password !== this.model.confirm_password){
            this.errorMessage = "Please enter password and confirm password are equal.";
            this.submitting = false;
            return;
        }

        let password_valid = this._helper.validatePassword(this.model.new_password);
        if(!password_valid){
            this.errorMessage = "Your password must be at least 8 characters long and must contain at least 3 of the following:";
            this.errorMessage += "<ul>";
            this.errorMessage += "<li> a symbol (like: !@#$%^&*) </li>";
            this.errorMessage += "<li> a number. </li>";
            this.errorMessage += "<li> a lower case letter. </li>";
            this.errorMessage += "<li> an upper case letter. </li>";
            this.errorMessage += "</ul>"

            this.submitting = false;
            return;
        }

        // if(this.submitting == false){ 
        //     this.errorMessage = "We encountered an unexpected error.";
        //     return;
        // }

        if(this.submitting){
            this.successMessage = "";
            this._acctSvc.changePassword(this._max.currentAccount._id,this.model.new_password).then(() =>{
                this.successMessage = "Your password has been changed successfully.";
            }).catch(err =>{
                this.errorMessage = "We encountered an unexpected error.";
                console.log(err);
            });
        }
        
        
        /*
        POST to /training/api/accounts/:userAccountId/passwordUpdates
        JSON Body:
        {password: .... }
        */
    }
}