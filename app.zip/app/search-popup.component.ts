import {Component, Inject, HostListener, ViewChild, ElementRef} from "@angular/core";
import {Router} from "@angular/router";
import { SiteSearchService, SiteSearch } from "./site-search.service";
import { DOCUMENT } from "@angular/platform-browser";

@Component({
    selector: 'site-search-box',
    templateUrl:'/maxweb/app/app/search-popup.component.html'
})
export class SearchPopupComponent {
    private site_search:string="";
    private siteSearchResult:any=[];
    private isShowSearchPopup:boolean=false;
    private isShowGif:boolean=false;
    private isDataLoaded:boolean=true;
    skip:number=0;
    take:number=30;
    private noMoreRecords:boolean=false;
    private sitesearch:any=null;
    private lastTxtSearchVal:string="";
    private viewType:string;
    @ViewChild('searchPopupDiv')searchPopupDiv:ElementRef;
    constructor(
        private _router: Router,
        private _siteSearch:SiteSearchService,
        @Inject(DOCUMENT) private document: Document,
    ){

    }

    siteSearch(event){
        if(this.lastTxtSearchVal !== event){
            this.lastTxtSearchVal = event;
            this.getSiteSearch();
        }
    }

    getSiteSearch(is_scroll:boolean=false){
        if(this.site_search.length >= 3){
            this.isShowSearchPopup = true;
            this.isShowGif = true;
            this.isDataLoaded = false;
            if(is_scroll === false){
                this.skip = 0;
                this.siteSearchResult=[];
            }

            if(this.sitesearch){
                this.sitesearch.unsubscribe();
            }
            this.sitesearch = this._siteSearch.siteSearch(
                this.site_search,
                this.skip,
                this.take,
            ).subscribe(
                (data:SiteSearch)=>{
                    this.viewType = 'Cards';

                    if(data.length){
                        if(is_scroll === true){
                            this.siteSearchResult = this.siteSearchResult.concat(data);
                        }else{
                            this.siteSearchResult = data;
                        }
                        this.skip = this.siteSearchResult.length;
                    }
                    if(data.length == this.take){
                        this.isDataLoaded = true;
                        this.noMoreRecords = false;
                    }else{
                        this.noMoreRecords=true;
                    }
                },
                (err:any)=>{ console.log('Log error', err); throw err; },
                ()=>{
                    this.isShowGif = false;
                }
            );


        }else{
            this.isShowSearchPopup=false;
        }
    }

    searchRedirect(data: SiteSearch){
        this.isShowSearchPopup = false;
        this.siteSearchResult = null;
        this.site_search = "";

        if(data._type == "userProfiles")
        this._router.navigate(['main/player', data._id]);

        if(data._type == "organizations") {
            sessionStorage['urlafterredict'] = '/main/teams/'+data._id;
            this._router.navigate(['main/teams', data._id]);
        }

        if(data._type == "listValues_teamInfo") {
            sessionStorage['urlafterredict'] = '/main/teams/'+data._id+'/'+data._source.value.code;
            this._router.navigate(['main/teams', data._source.orgId, data._source.value.code]);
        }
    }

    onScrollSearch(event) {
        var ele=this.document.getElementById("searchdiv");
        var bodyScrollTop = this.document.getElementById("searchdiv").scrollTop;
        // if((ele.scrollHeight - ele.clientHeight) <= bodyScrollTop){
        if(bodyScrollTop / (ele.scrollHeight - ele.clientHeight)>0.8){
            if(this.isDataLoaded == true){
                this.getSiteSearch(true);
            }
        }
    }

    @HostListener('document:click', ['$event'])
    onOutsideClick($event)
    {
        if (!this.searchPopupDiv.nativeElement.contains($event.target)){
            this.closePopup();
        }
    }

    closePopup(){
        this.siteSearchResult=[];
        this.site_search = "";
        this.isShowSearchPopup = false;
    }
}

