import {Injectable, EventEmitter} from "@angular/core";
import {Http, Response, RequestOptions, URLSearchParams} from "@angular/http";
import {PagedDataUtil} from "./pagedDataUtil.service";
import {MaxAppContext} from "./maxAppContext.service";

export interface Activity {
    _id:string;
    type:string;
}

export interface Assignment {
    _id:string;
    category:string;
    documentLibraryCategory: string;
    activities:Activity[];
    assignees:{orgId?:string, userProfileId:string}[];
    submissionCode:string;
}

export interface AssignmentSubmissionResult {
    code:string;
    emailRecipient:string;
}


export class Packet{
    _id:string;
    activities:[{
        _id: string;
        documentationEventDescription:{
            menuTitle: string;
            coordinatorName: string;
            eventName: string;
            documents: [{
                activityId:string;
                name:string;
                required:boolean;
            }];
            summaryFields : any;
        },
        orgId : string;
        type : string;
    }];
    assignedByDeviceRegistrationId:string;
    assignedByIpAddress:string;
    assignedDate:string;
    assignees:[{
        orgId:string;
        role:string;
        tag:string;
    }];
    audience:Array<any>;
    audienceInclusions:[{
        canEdit:boolean;
        ofOrg:string;
        roles:Array<any>;
    }];
    category:string;
    creatorOrgId:string;
    lastModifiedDate:string;
    occurrencesLastCreatedDate:string;
    startDate:string;

    // constructor(data:any) {
    //     for(var k in data)
    //     {
    //         this[k] = data[k];
    //     }
    // }
}

@Injectable()
export class Assignments {

    public getPopupData = new EventEmitter();
    constructor(
        private _http:Http,
        public ctx:MaxAppContext
    ) {
                
    }

    getUserAssignments(category:string, userProfileId:string)
    {
        return PagedDataUtil.getAllPages((s,t) => this.getUserAssignmentPage(category, userProfileId, s, t));
    }

    getUserAssignmentPage(category:string, userProfileId:string, skip:number, take:number)
    {
        return this._http.get(`/training/api/assignments?skip=${skip}&limit=${take}&userProfileId=${userProfileId}&category=${category}`)
            .map((res:Response) => <Assignment[]>res.json());
    }

    getUserPacketList(category:string, skip:number, take:number)
    {
        return this._http.get(`/training/api/assignments?skip=${skip}&limit=${take}&category=${category}&excludeReplaced=true&excludeEnded=true`)
            .map((res:Response) => <Assignment[]>res.json());
    }

    getMine(packetDisposition:boolean=false) {
        return PagedDataUtil.getAllPages((s,t) => this.getMinePage(s,t, packetDisposition));
    }

    createPacket(packet:any)
    {
        return this._http.put('/training/api/assignments', packet).map((res:Response) => <any[]>res.json());
    }

    createForm(packet:any)
    {
        return this._http.put(`/training/api/activities`, packet).map((res:Response) => <any[]>res.json());
    }

    getMinePage(skip:number, take:number, packetDisposition:boolean=false)
    {
        var args = packetDisposition ? this.getDocPacketArgs() : new RequestOptions();

        return this._http.get(`/training/api/assignments/mine?skip=${skip}&limit=${take}`, args)
            .map((res:Response) => <Assignment[]>res.json());
    }

    submit(assignmentId, profileId=null) {

         if(profileId === null){
             let profile = this.ctx.currentProfile;
             profileId = profile._id;
         }

        return this._http.put(`/training/api/assignments/${assignmentId}/${profileId}/submission`, '')
            .map((res:Response) => <AssignmentSubmissionResult>res.json());
    }

    requestConfirmation(assignmentId:string, profileId:string, emailAddress:string) {
        return this._http.post(`/training/api/assignments/${assignmentId}/${profileId}/submission-confirmation?email=${emailAddress}`, '');
    }

    findOrCreate(activityId:string, profileId:string)
    {
        return this._http.get(`/training/api/activities/${activityId}/assignmentFactory/${profileId}`)
            .map((res:Response) => <Assignment>res.json());
    }

    getActivities(type:string, skip:number=0, take:number=1000){

        var args = new RequestOptions();
        args.search = new URLSearchParams();
        args.search.append('skip', skip.toString());
        args.search.append('limit', take.toString());
        args.search.append('type', `${type}`);
        return this._http.get(`/training/api/activities`, args)
            .map((res:Response) => <Assignment>res.json());
    }    

    delete(id:string) {
        return this._http.delete(`/training/api/assignments/${id}`);
    }
    
    deleteAssigement(id:string) {
        return this._http.put(`/training/api/assignments/${id}/end`,'');
    }

    getAllPackets(includeActivityResponses:boolean=true){
        var args = this.getDocPacketArgs();

        args.search.append('skip', '0');
        args.search.append('limit', '1000');

        if (includeActivityResponses)
        {
            args.search.append('includeActivityResponses', 'true');
            args.search.append('includeActivityResponsesAcrossReplacedAssignments', 'true');
        }

        return this._http.get(`/training/api/assignments`, args)
            .map((res:Response) => <Packet[]>res.json());
    }

    getAssignments(activityId:string, skip:number=0, take:number=1000){
        // var args = new RequestOptions();
        // args.search = new URLSearchParams();
        // args.search.append('skip', skip.toString());
        // args.search.append('limit', take.toString());

        //return this._http.get(`/training/api/assignments/${activityId}`, args)
        return this._http.get(`/training/api/assignments/${activityId}`)
            .map((res:Response) => <any>res.json());
    }

    submitAdministratively(assignmentId, activityId, userProfileId)
    {
        return this._http.post(`/training/api/assignments/${assignmentId}/activities/${activityId}/responses?userProfileId=${userProfileId}`,
            {completedDate:new Date(), responseData:{submitted:true, submittedAdministratively:true}});
    }

    private getDocPacketArgs(): RequestOptions
    {
        var args = new RequestOptions();
        args.search = new URLSearchParams();
        args.search.append('category', 'Documentation');
        args.search.append('excludeReplaced', 'true');
        args.search.append('excludeEnded', 'true');
        return args;
    }
}