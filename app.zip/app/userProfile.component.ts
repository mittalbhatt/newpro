import {Component, ViewChild} from "@angular/core";
import {UserProfile, UserProfiles} from "./user_profiles.service";
import {ActivatedRoute, Router} from "@angular/router";
import {Assignments, Assignment} from "./assignments.service";
import {DfUuidGen} from "./df_uuid_gen";
import {Organizations, Organization} from "./organizations.service";
import {RelatedProfilesList} from "./relatedProfilesList.component";
import {MaxAppContext} from "./maxAppContext.service";
import {ProfileUtil} from "./confirmProfileDelete";
import {IntercomRouterTracker} from "./intercomRouterTracker.service";
import {Modal, BSModalContext} from 'angular2-modal/plugins/bootstrap';
import {Overlay, overlayConfigFactory} from 'angular2-modal';

declare var plupload;

@Component({
    selector:'user-profile',
    template:`
 <!--<div class="profile-card" style="background-color:#ffffe0">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12" style="font-size:18px;">Go get the app for the full<br/> DragonFly MAX experience!</div>
                </div>
                <div class="row">
                    <div class="col-xs-6">
                        <a target="_blank" href="https://itunes.apple.com/us/app/dragonfly-max/id894686415">
                            <img style="width:90%; height:100%; margin:6%" src="app/media/Download_on_the_App_Store_Badge_US-UK_135x40.svg"/>
                        </a>
                    </div>
                    <div class="col-xs-6">
                        <a target="_blank" href='https://play.google.com/store/apps/details?id=com.dragonfly.max.live&hl=en&utm_source=global_co&utm_medium=prtnr&utm_content=Mar2515&utm_campaign=PartBadge&pcampaignid=MKT-Other-global-all-co-prtnr-py-PartBadge-Mar2515-1'>
                            <img style="width:100%; height:100%" alt='Get it on Google Play' src='https://play.google.com/intl/en_us/badges/images/generic/en_badge_web_generic.png'/>
                        </a>
                    </div>
                </div>
            </div>
        </div>
-->
<div class="team-page" >
<div class="container-fluid">
    <div class="alert alert-info" *ngFor="let msg of organizationApprovedMessages" [hidden]="msg.hidden">
        Waiting for approval for {{msg.name}}.
        <a (click)="areYouSure(msg.name, msg.profile)" class="text-right cursor-pointer">
            <i class="fa fa-trash-o text-right" aria-hidden="true"></i>
        </a>
    </div>
    <div class="profile-card">
        <div *ngIf="errorMessage" class="alert alert-danger">{{errorMessage}}</div>

        <div *ngIf="loading">
            <img src="/maxweb/app/media/ajax-loader.gif" />
            Loading...
        </div>

        <div *ngIf="!loading && !errorMessage">



            <h1>{{profile?.athleteTitleName}}</h1>
            <p *ngIf="profileOrg?.roles && profileOrg.roles.indexOf('Training') < 0" style="margin-bottom:10px;">{{profile?.roleDisplayTitle}} in {{profileOrg?.name}}</p>

            <!-- <h5 *ngIf="relatedList?.relatedProfiles?.length" style="text-align:left">My Kids:</h5> -->
            <h4 *ngIf="profileOrg?.roles && profile?.orgRoles?.indexOf('PRN') > -1 && relatedList?.relatedProfiles?.length==0" class="profilelist-h4">To get started filling out forms, click or tap ‘Add a child’</h4>
            <related-profiles-list *ngIf="profileOrg?.roles && profile?.orgRoles?.indexOf('PRN') > -1" #profileList [profileId]="profileId" (itemDeleteClicked)="onClickDeleteRelatedUser($event)" (itemClicked)="onClickRelatedUser($event)" (itemEditClicked)="onClickEditRelatedUser($event)" [relationRoles]="['PRN']"></related-profiles-list>

            <h5 *ngIf="documentationAssignments?.length" style="text-align: left">Available forms:</h5>
            <div class="list-group">
                <button *ngFor="let assignment of documentationAssignments" type="button" class="list-group-item" (click)="onClickFormsAssignment(assignment)">
                    {{assignment.activities[0].documentationEventDescription.eventName}}
                    <span style="float:right" class="glyphicon glyphicon-menu-right"></span>
                </button>
            </div>

            <button *ngIf="profile?.orgRoles?.indexOf('ATH') > -1 || (_ctx.currentProfile?._id == profile?._id && profile?.orgRoles?.indexOf('TRN') < 0 && profile?.orgRoles?.indexOf('PRN') < 0)" (click)="onClickFillForms()" class="btn btn-primary">Fill out forms</button>

            <div *ngIf="isAdmin">
                <table style="width:100%; margin:auto; margin-top:0px; margin-bottom:20px;">
                <tr><td style="border-bottom:1px solid #5d5d5d; width:30%;">&nbsp;</td><td width="auto"><p style="font-size:18px; margin-top:10px; margin-right:2px; margin-left:2px; height:1px;">Administration</p></td><td style="border-bottom:1px solid #5d5d5d; width:30%">&nbsp;</td></tr>
              </table>
                <max-admin-menu></max-admin-menu>
            </div>
        </div>
    </div>
</div>
</div>

`
})
export class UserProfileComponent
{
    loading:boolean;
    errorMessage:string;

    profileId:string;
    profile:UserProfile;
    profileOrg:Organization;
    documentationAssignments:Assignment[];

    organizationApprovedMessages:any=[];
    organizationApprovedCount:number=0;


    profileImageUploading:boolean;
    profileImageUploadSettings:any;
    profileImageUrl:string;
    profileImageUploadStateChangeHandler:(state:any, fromUploaderEvent:boolean, resultUrl:string) => void;

    @ViewChild('profileList') relatedList:RelatedProfilesList;

    constructor(
        private _profilesSvc:UserProfiles,
        private _assignmentsSvc:Assignments,
        private _organizations:Organizations,
        private _route:ActivatedRoute,
        private _ctx:MaxAppContext,
        private _router:Router,
        private _profileUtil:ProfileUtil,
        private _modal:Modal,
        private _intercom:IntercomRouterTracker
    ){
        this.profileImageUploadStateChangeHandler = (s,f,r) => this.onProfileImageUploadStateChanged(s, f, r);

        this._route.params.subscribe(params =>
        {
            this.profileId = params['userProfileId'];
            this.refresh();
        })
        console.log("After Login");
        console.log(this._ctx);

        this.organizationApprovedMessage();
    }

    organizationApprovedMessage()
    {
        _.each(this._ctx.myProfiles,  (profile:any)=>{
            if(profile.state) {
                if(profile.state.pendingApproval !== undefined && profile.state.pendingApproval == true) {
                    if(_.intersection(profile.orgRoles, ['TRN']).length == 0) {
                        //console.log("Roles===========================");
                        //console.log(profile.orgRoles);
                        //console.log(_.intersection(profile.orgRoles, ['PRN']));
                        //console.log(_.intersection(profile.orgRoles, ['TRN', 'OTRN', 'ADM', 'CCH']).length);
                        let isHide = false;
                        if(_.intersection(profile.orgRoles, ['TRN', 'OTRN', 'ADM', 'CCH']).length==0 && _.intersection(profile.orgRoles, ['PRN']).length==1 )
                        {
                            isHide = true;
                            //console.log("hide True");
                        }
                        let org = _.find(this._ctx.availableOrganizations, (o:any)=>{
                            return o._id == profile.org
                        });
                        //console.log("Org----------------------");
                        //console.log(org.name);
                        this.organizationApprovedMessages.push({
                            profileId: profile._id,
                            profile: profile,
                            name: org.name,
                            sortName: org.sortName,
                            hidden: isHide
                        });
                    }
                } else {
                    this.organizationApprovedCount++;
                }
            }
        });
    }

    get isAdmin()
    {
        if (!this.profile)
            return false;
        if (!this.profile.orgRoles)
            return false;

        return !!_.intersection(this.profile.orgRoles, ['OTRN', 'TRN', 'OADM']).length;
    }

    refresh()
    {
        this.loading = true;

        delete this.profileImageUrl;

        let userProfileId = this.profileId;

        this.profileImageUploadSettings = {
            getFileParams: () =>
            {
                var fileId = DfUuidGen.newUuid();

                var imageUrl = `/training/api/userProfiles/${userProfileId}/images/${fileId}`;
                this.profile.imageUris[0] = imageUrl;

                return Promise.resolve(
                       {
                           fileId: fileId,
                           userProfileId: userProfileId,
                           paramsUrl: imageUrl
                       });
            },
            dfUploadTag: 'profile-image-' + userProfileId,
            uploaderSettings: {
                filters: {
                    max_file_size: '10mb',
                    mime_types: [
                        { title: "Image files", extensions: "jpeg,jpg,gif,png" }
                    ]
                },
                resize: {
                    width: 600,
                    height: 600
                }
            }
        };

        let profilePromise = this._profilesSvc.getProfile(userProfileId).single().toPromise();
        let documentationAssignmentsPromise = this._assignmentsSvc.getUserAssignments('Documentation', userProfileId);

        Promise.all<any>([profilePromise, documentationAssignmentsPromise])
            .then(([profile, documentationAssignments]:[UserProfile, Assignment[]]) =>
            {
                this.profile = new UserProfile(profile);
                this.loadImage();
                this.documentationAssignments = documentationAssignments;

                return this._ctx.myOrganizations.find(o => o._id == profile.org);
            })
            .then((org:Organization) =>
            {
                this.profileOrg = org;
                this.loading = false;
            })
            .catch(e =>
            {
                console.log(e);
                this.errorMessage = 'We encountered an unexpected error.  Try refreshing the page.';
                throw e;
            });
    }

    onProfileImageUploadStateChanged(state, fromUploaderEvent, resultUrl)
    {
        if (state === plupload.DONE)
        {
            this._intercom.track('set-profile-picture');

            this.loadImage().then(() => this.profileImageUploading = false)
                .catch(e => {
                    this.profileImageUploading = false;
                    throw e;
                });
        }
        else if (state === plupload.FAILED)
        {
            console.log('UPLOAD FAILED');
            this.profileImageUploading = false;
            this.errorMessage = 'An error was encountered while uploading your image.  Refresh the page and try again.';

            // Don't leave a bad image ref in the profile.
            //UserProfileUpdate.save({ profileId: userProfileId }, { $set: { images: [] } });
        }
        else
        {
            console.log('UPLOAD OK');
            this.profileImageUploading = true;
        }
    };

    loadImage()
    {
        return this._profilesSvc.getProfileImageUrl(this.profile).single().toPromise()
            .then(url => this.profileImageUrl = url)
            .catch(e => {
                console.log('Logo error', e);
                throw e;
            });
    }

    onClickRelatedUser(profile:UserProfile)
    {
        this._router.navigate(['profile', profile._id], {relativeTo:this._route.parent});
    }

    onClickEditRelatedUser(profile:UserProfile)
    {
        this._router.navigate(['/max-forms/editFormsProfile', profile._id]);
    }

    onClickDeleteRelatedUser(profile:UserProfile)
    {
        // cache this field's value because somehow it gets unset
        let relatedList = this.relatedList;
        if (!relatedList)
            throw new Error('relatedList is undefined');

        this._profileUtil.confirmProfileDelete(profile, () =>
        {
            this.loading = true;
            this._profilesSvc.deleteProfile(profile)
                .single().toPromise().then(() =>
            {
                relatedList.clear(profile);
                this.loading = false;
            })
                .catch(e =>
                {
                    this.loading = false;
                    this.errorMessage = 'We encountered an unexpected error. Refresh the page and try again.';
                    throw e;
                })
        });
    }

    onClickFillForms()
    {
        var route:any[] = ['/max-forms/packetList'];
        if (this.profile.orgRoles.indexOf('ATH') > -1)
            route.push({profileId:this.profileId});
        this._router.navigate(route);
    }

    onClickFormsAssignment(assignment:Assignment)
    {
        this._router.navigate(['/max-forms/athDocDashboard', assignment.activities[0]._id, this.profileId]);
    }

    areYouSure (organizationName, profile)
    {
        this._modal.confirm()
        .size('sm').isBlocking(true).showClose(false).keyboard(27)
        .body(`Are you sure you want to revoke your request to join  ${organizationName}?`)
        .headerClass("hide")
        .okBtn('Revoke My Request')
        .okBtnClass("btn btn-danger")
        .cancelBtnClass("btn btn-primary")
        .open().then((dialog : any ) => {
            return dialog.result;
        }).then(result =>{
            this._profilesSvc.deleteProfile(profile)
                .single().toPromise().then(() =>
            {
                this.organizationApprovedMessages = _.reject(this.organizationApprovedMessages, function(arrItem:any){
                    return arrItem.profileId === profile._id;
                });
                if(this.organizationApprovedMessages.length === 0 && this.organizationApprovedCount === 0) {
                    this._ctx.resetOrg();
                }
            }).catch(e =>
            {
                this.errorMessage = 'We encountered an unexpected error. Refresh the page and try again.';
                throw e;
            })

        }).catch((e:any)=>{

        });
    }
}