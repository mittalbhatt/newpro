System.register(["@angular/router", "@angular/core", "./userAccount.service", 'angular2-modal', 'angular2-modal/plugins/bootstrap', "./auth.service", "./toscheck-model.component", 'rxjs/add/operator/pairwise'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var router_1, core_1, userAccount_service_1, angular2_modal_1, bootstrap_1, auth_service_1, toscheck_model_component_1;
    var Tosaccept;
    return {
        setters:[
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (userAccount_service_1_1) {
                userAccount_service_1 = userAccount_service_1_1;
            },
            function (angular2_modal_1_1) {
                angular2_modal_1 = angular2_modal_1_1;
            },
            function (bootstrap_1_1) {
                bootstrap_1 = bootstrap_1_1;
            },
            function (auth_service_1_1) {
                auth_service_1 = auth_service_1_1;
            },
            function (toscheck_model_component_1_1) {
                toscheck_model_component_1 = toscheck_model_component_1_1;
            },
            function (_1) {}],
        execute: function() {
            Tosaccept = (function () {
                function Tosaccept(_router, routenew, _accounts, _modal, _auth) {
                    var _this = this;
                    this._router = _router;
                    this.routenew = routenew;
                    this._accounts = _accounts;
                    this._modal = _modal;
                    this._auth = _auth;
                    this.isShow = true;
                    this._router.events.subscribe(function (event) {
                        if (event instanceof router_1.NavigationEnd) {
                            //console.log("NavigationEnd");
                            _this.isShow = true;
                        }
                    });
                }
                Tosaccept.prototype.canActivate = function (route, state) {
                    //console.log("canActivate");
                    return this.initialize();
                };
                Tosaccept.prototype.initialize = function () {
                    var _this = this;
                    // console.log(localStorage["tosPopupData"]);
                    // if(localStorage["tosPopupData"] === undefined){
                    this._accounts.getMyUserAccount()
                        .then(function (account) {
                        //console.log(account);
                        _this.currentAccount = account;
                        if (account['tos']) {
                            if (account['tos']['acceptances'] != undefined) {
                                var currentAccountArr = _.filter(account['tos']['acceptances'], function (o) {
                                    //account['$requiredTermsOfService']=4; 
                                    if (o['version'] == account['$requiredTermsOfService']) {
                                        return o;
                                    }
                                });
                                if (currentAccountArr.length <= 0) {
                                    //console.log('openpopup');
                                    //  localStorage["tosPopupData"] = JSON.stringify({isShow: true, version: account['$requiredTermsOfService']});
                                    _this.openTospopup(account['$requiredTermsOfService']);
                                }
                                else {
                                }
                            }
                        }
                        else {
                            _this.openTospopup(account['$requiredTermsOfService']);
                        }
                    });
                    return true;
                };
                Tosaccept.prototype.openTospopup = function (vesionnumber) {
                    var _this = this;
                    console.log("isShow: ", this.isShow);
                    if (this.isShow) {
                        this.isShow = false;
                        this._accounts.getTosData(vesionnumber)
                            .then(function (tosdata) {
                            if (tosdata != undefined && tosdata != '') {
                                var body = tosdata.content.html;
                            }
                            else {
                                var body = tosdata.content.plainText;
                            }
                            var customModalData = new toscheck_model_component_1.TosModalContext({ body: body, versionnumberget: vesionnumber });
                            var config = angular2_modal_1.overlayConfigFactory(customModalData, bootstrap_1.BSModalContext);
                            _this._modal.open(toscheck_model_component_1.TosCheckModal, config).then(function (result) {
                            })
                                .catch(function (e) { return console.log(e); });
                        });
                    }
                };
                Tosaccept = __decorate([
                    core_1.Injectable(), 
                    __metadata('design:paramtypes', [router_1.Router, router_1.ActivatedRoute, userAccount_service_1.UserAccountService, bootstrap_1.Modal, auth_service_1.AuthService])
                ], Tosaccept);
                return Tosaccept;
            }());
            exports_1("Tosaccept", Tosaccept);
        }
    }
});
//# sourceMappingURL=tosaccept.service.js.map