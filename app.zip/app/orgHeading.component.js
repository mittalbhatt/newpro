System.register(["@angular/core", "./maxAppContext.service", "./organizations.service"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, maxAppContext_service_1, organizations_service_1;
    var OrgHeadingComponent;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (maxAppContext_service_1_1) {
                maxAppContext_service_1 = maxAppContext_service_1_1;
            },
            function (organizations_service_1_1) {
                organizations_service_1 = organizations_service_1_1;
            }],
        execute: function() {
            OrgHeadingComponent = (function () {
                function OrgHeadingComponent(_organizations, _ctx) {
                    this._organizations = _organizations;
                    this._ctx = _ctx;
                }
                OrgHeadingComponent.prototype.ngOnInit = function () {
                    var _this = this;
                    var currentId = this.org ? this.org._id : null;
                    if (this._ctx.orgId && currentId != this._ctx.orgId) {
                        this._organizations.getOrgFromDirectory(this._ctx.orgId).single().toPromise()
                            .then(function (o) { return _this.org = o; });
                    }
                };
                OrgHeadingComponent = __decorate([
                    core_1.Component({
                        selector: 'org-heading',
                        template: "\n<div>\n<img *ngIf=\"org?.logoUrl\" [src]=\"org?.logoUrl\" style=\"max-width:200px; max-height:200px;\" />\n<h2 *ngIf=\"!org?.logoUrl && org?.name\">{{org?.name}}</h2>\n<h5 *ngIf=\"org?.logoUrl && org?.name\" style=\"margin-bottom:0px;\">{{org?.name}}</h5>\n</div>\n        "
                    }), 
                    __metadata('design:paramtypes', [organizations_service_1.Organizations, maxAppContext_service_1.MaxAppContext])
                ], OrgHeadingComponent);
                return OrgHeadingComponent;
            }());
            exports_1("OrgHeadingComponent", OrgHeadingComponent);
        }
    }
});
//# sourceMappingURL=orgHeading.component.js.map