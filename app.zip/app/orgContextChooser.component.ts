import {Component, EventEmitter, Output, OnInit, Input} from "@angular/core";
import {Organizations, Organization} from "./organizations.service";
import {Observable} from "rxjs/Rx";
import {FormControl} from "@angular/forms";
import {IntercomRouterTracker} from "./intercomRouterTracker.service";

@Component({
    selector:'org-context-chooser',
    template:`
<div>
    <div style="max-width:500px;" *ngIf="errorMessage" class="alert alert-danger">{{errorMessage}}</div>
    <div *ngIf="!org">
        <h4>Find school by school code:</h4>
        <p><em>Ask your Coach or Athletic Trainer for the code.</em></p>
        <form #codeForm="ngForm" (ngSubmit)="onSubmit()">
            <div style="max-width:200px; margin:auto;" class="input-group">
                <input [(ngModel)]="code" style="border-left:1px solid #ccc;" name="code" id="code"  autocorrect="off" autocapitalize="off" spellcheck="false" type="text" class="form-control" placeholder="School Code" required />
                <span class="input-group-btn">
                    <button type="submit" class="btn btn-default" [disabled]="!codeForm.form.valid">Go</button>
                </span>
            </div>
        </form>
    </div>
    <!--<div *ngIf="!org">-->
         <!--<table style="width:80%; margin: 10px 30px 30px;">-->
            <!--<tr><td style="border-bottom:1px solid #5d5d5d; width:45%;">&nbsp;</td><td width="auto"><p style="margin-top:10px; margin-right:2px; margin-left:2px; height:1px;">or</p></td><td style="border-bottom:1px solid #5d5d5d; width:45%">&nbsp;</td></tr>-->
         <!--</table>-->
    <!---->
                    <!--<h4>Search for your school:</h4>-->
                    <!--<template #orgTypeAheadTemplate let-org="item">-->
                             <!--<div>-->
                                <!--<h5>{{org.name}}</h5>-->
                                <!--<h6 *ngIf="org.city && org.stateCode">{{org.city}}, {{org.stateCode}}</h6>-->
                                <!--<h6>School Code: <em>{{org.shortCode}}</em></h6>-->
                                <!--<h6 *ngIf="org.ncesCode">NCES ID: <em>{{org.ncesCode}}</em></h6>-->
                            <!--</div>-->
                    <!--</template>-->
                    <!---->
                    <!--<div class="input-group">-->
                        <!--<span class="input-group-addon"><span class="glyphicon glyphicon-search"></span></span>-->
                        <!--<input -->
                            <!--[(ngModel)]="orgSearch"-->
                            <!--[typeahead]="orgSearchDataSource"-->
                            <!--[typeaheadItemTemplate]="orgTypeAheadTemplate"-->
                            <!--[typeaheadItemTemplate]="schoolTypeAheadTemplate" -->
                            <!--[typeaheadWaitMs]="5"-->
                            <!--[typeaheadMinLength]="1"-->
                            <!--(typeaheadOnSelect)="onSelectSearchOrg($event)"-->
                            <!--(typeaheadNoResults)="changeTypeaheadNoResults($event)"-->
                            <!--(typeaheadLoading)="changeTypeaheadLoading($event)"-->
                            <!--style="border-left:0px;"-->
                            <!--id="schoolName"-->
                            <!--name="schoolName"-->
                            <!--type="text" -->
                            <!--class="form-control"-->
                            <!--placeholder="School or Team Name" -->
                            <!--autocomplete="off" />-->
                    <!--</div>-->
                    <!--<img [hidden]="!searching" src="app/media/linear-activity-indicator.gif" />-->
                    <!---->
                    <!--<div *ngIf="noOrgSearchResults===true"><em>No results found.</em></div>-->
    <!--</div>-->
    <div *ngIf="org && orgChosenByCode">
        <h4>The code <strong>{{org.shortCode}}</strong> matches <strong>{{org.name}}</strong></h4>
        <!--<button style="margin-right:20px;" (click)="onContinue()" type="button" class="btn btn-primary">Continue with {{org.name}}</button>-->
        <!--<button (click)="onBack()" type="button" class="btn btn-danger">Back</button>-->
    </div>
    <div *ngIf="org && !orgChosenByCode">
        <h4>You have chosen <strong>{{org.name}}</strong> with school code <strong>{{org.shortCode}}</strong></h4>              
    </div>
</div>
`
})
export class OrgContextChooser
{
    private code:string;
    private org:Organization;
    private orgChosenByCode:boolean;
    private errorMessage:string;

    private orgSearch:string;
    private noOrgSearchResults:boolean;
    private searching:boolean;
    private orgSearchDataSource:Observable<Organization>;

    @Output() orgChosen = new EventEmitter<Organization>();

    constructor(
        private _orgsService:Organizations,
        private _intercom:IntercomRouterTracker)
    {
        this.orgSearchDataSource = Observable.create((observer:any) =>
        {
            observer.next(this.orgSearch);
        }).mergeMap((token:string) =>
        {
            return this._orgsService.getOrgsBySearchFromDirectory(token, 6);
        });
    }

    reset()
    {
        delete this.org;
        delete this.code;
    }

    private onSubmit()
    {
        if (!this.code)
            return;

        this.errorMessage = null;

        this._orgsService.getOrgByCodeFromDirectory(this.code).single().toPromise()
            .then(org =>
            {
                if (!org)
                {
                    this.errorMessage = 'The code you entered did not match any teams.';
                }
                else
                {
                    this._intercom.track('found-org-by-code', {code:this.code, org:org.name, orgId:org._id});

                    this.org = org;
                    this.orgChosenByCode = true;
                    this.orgChosen.emit(org);
                }
            })
            .catch(e =>
            {
                this.errorMessage = 'An unexpected error was encountered. Please try again.';
                throw e;
            })
    }

    private onContinue()
    {
        this.orgChosen.emit(this.org);
    }

    private onSelectSearchOrg(e:{item:Organization})
    {
        this._intercom.track('found-org-by-search', {org:e.item.name, orgId:e.item._id});

        this.org = e.item;
        this.orgChosenByCode = false;
        this.orgChosen.emit(e.item);
    }

    private changeTypeaheadNoResults(e:boolean):void
    {
        this.noOrgSearchResults = e;
    }

    private changeTypeaheadLoading(e:boolean):void
    {
        this.searching = e;
    }
}