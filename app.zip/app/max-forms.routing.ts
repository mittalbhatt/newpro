import {Routes} from "@angular/router";
import {AthleteDocumentationForm} from "./athlete_doc_form.component";
import {AthDocDashboard} from "./ath_doc_dashboard.component";
import {LandingComponentBlank} from "./landing_blank.component";
import {OwnProfileCreator} from "./ownProfileCreator.component";
import {ParentChildFormsContextChooser} from "./parentChildFormsContextChooser.component";
import {FormsProfileChooserRouter} from "./formsProfileChooserRouter.service";
import {RelatedProfileCreator} from "./relatedProfileCreator.component";
import {FormsProfileEditor} from "./formsProfileEditor.component";
import {PacketList} from "./packetList.component";
import {AdminEventView} from "./admin_event_view.component";
import {FormsOrgChooserComponent} from "./formsOrgChooser.component";
import { BasicMedicalForm } from "./basic_medical_form.component";

export const formsRoutes:Routes = [
    {
        path:'blank',
        data: { title :'LandingBlank' },
        component:LandingComponentBlank
    },
    {
        path:'packetList',
        component:PacketList,
        canActivate:[FormsProfileChooserRouter]
    },
    {
        path:'athDocDashboard/:activityId/:profileId',
        component:AthDocDashboard
    },
  
    {
        path: 'create-own-profile',
        component:OwnProfileCreator
    },
    {
        path:'chooseFormsProfile/:profileId',
        component:ParentChildFormsContextChooser
    },
    {
        path:'chooseFormsProfile/:profileId/create',
        component:RelatedProfileCreator
    },
    {
        path:'editFormsProfile/:profileId',
        component:FormsProfileEditor
    },
    {
        path:'admin/event/:eventId',
        component:AdminEventView
    }
];

export const formsProviders = [
    FormsProfileChooserRouter
];