import {Component, Output, EventEmitter, ElementRef, ViewChild} from "@angular/core";
import {ModalComponent, DialogRef} from "angular2-modal";
import {BSModalContext} from "angular2-modal/plugins/bootstrap";
import {DfObjectId} from "./DfObjectId";
import {MaxAppContext} from "./maxAppContext.service";
import { Assignments, Assignment } from "./assignments.service";
import { Observable } from 'rxjs';
import {Router} from '@angular/router';
import { UserProfiles, UserProfile } from "./user_profiles.service";

import _ from "underscore";

export class CustomModalContext extends BSModalContext {
    public data: any;

    constructor(private d:any){
        super();
        this.data = d;
      //  this.size = "lg";
    }
}

@Component({
    selector:'invite-modal-prompt',
    template:`
    <div class="modal-content clearfix" style="text-align:left;">
    
       <div class="col-xs-12">
        <h3><span *ngIf="itemdata.firstName">{{itemdata.firstName}},</span>
        <span *ngIf="itemdata.lastName">{{itemdata.lastName}}</span></h3>
       </div> 
        
       <div class="col-xs-12">RECIPIENT</div>
       <div class="col-xs-12">
        <h3>Text or read the code below  
            <span *ngIf="itemdata.lastName">to {{itemdata.lastName}}</span></h3>
       </div>     
       <div class="col-xs-12" style="color:#00529b;"><h2 style=" margin-top:10px">{{ code}}</h2></div>
       <div class="col-xs-12" style="color:#00529b; margin-bottom:25px">ACTIVATION CODE</div>
       <div class="col-xs-12" *ngIf="itemdata.tel[0]" style="margin-bottom:18px">
            <a (click)="texttoinvite()" class="btn btn-primary ">TEXT AND INVITE TO {{itemdata.tel[0]}}</a>
       </div>
    <div class="col-xs-12" *ngIf="smserrrmessage" style="color:#ac2925">{{smserrrmessage}}</div>
    <div class="col-xs-12" *ngIf="smserrrmessage" style="color:#ac2925">{{smsmessage}}</div>
        <div class="modal-footer">
          <button (click)="onCancel()" type="button" class="btn btn-primary" style="float:right; margin-right:10px;">Close</button>
        </div>
    </div>

    `,
   
    
})
export class InviteModal implements ModalComponent<CustomModalContext>
{
    itemdata:any;
    context: CustomModalContext;
    resdata:any;
    code:any;
    smsmessage:any;
    smserrrmessage:any;
   
    constructor(public dialog:DialogRef<CustomModalContext>, private _userProfiles: UserProfiles, private _assignment: Assignments, private _ctx:MaxAppContext,private router: Router)
    {
         console.log(this.dialog.context.data);
         console.log(this.dialog.context.data.resdata);
         this.itemdata=this.dialog.context.data.data;
         this.resdata=this.dialog.context.data.resdata;
         this.code=this.resdata.code.match(new RegExp('.{1,4}', 'g')).join("-");
    }
     private onCancel()
    {
        this.dialog.close(false);
    }
    texttoinvite(){
         var inviteobj ={userProfileId:this.itemdata.userProfileId,requireUniqueVerificationCode:"true",invitationSenderName:"Ms Butler"}
         this._userProfiles.texttoinvite(inviteobj).single().toPromise().then((resdata:any)=>{
            if(resdata!==undefined){
                console.log(resdata);
               if ( resdata.smsError!==undefined )
                 {
                    this.smserrrmessage=  `The invitation could not be sent to the ${this.itemdata.tel[0]}
                            . You may give that code to the user yourself, or you can try again.`;
                    
                }
                else
                {
                    this.smsmessage= `An invitation was texted to ${this.itemdata.tel[0]}.`;
                }
            }
         });
    }
}
/*    <usa-map (selectedState)="onSelectState($event)"></usa-map>    */