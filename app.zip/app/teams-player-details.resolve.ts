import { Injectable } from '@angular/core';
import { Resolve, ActivatedRouteSnapshot } from '@angular/router';
import { UserProfiles, UserProfile } from "./user_profiles.service";

// Get list data of organization structure
@Injectable()
export class TeamsPlayerDetailsResolve implements Resolve<UserProfile> {

  constructor(
      private _userProfilesSvc: UserProfiles,
      ) {}
  resolve(route: ActivatedRouteSnapshot) {

    const id = route.params['id'];
    return this._userProfilesSvc.getProfile(id);

    // this._route.params.subscribe(params =>
    // {
    //     console.log(params);
    //     // this.playerId = params['playerId'];
    //     // this._userProfilesSvc.getProfile(this.playerId).toPromise().then(data =>{
    //     //     return data;
    //     // }).catch(e =>{
    //     //     console.log('Logo error', e);
    //     //     throw e;
    //     // });
    // });
  }
}
