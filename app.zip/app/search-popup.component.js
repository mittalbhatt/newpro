System.register(["@angular/core", "@angular/router", "./site-search.service", "@angular/platform-browser"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var __param = (this && this.__param) || function (paramIndex, decorator) {
        return function (target, key) { decorator(target, key, paramIndex); }
    };
    var core_1, router_1, site_search_service_1, platform_browser_1;
    var SearchPopupComponent;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (site_search_service_1_1) {
                site_search_service_1 = site_search_service_1_1;
            },
            function (platform_browser_1_1) {
                platform_browser_1 = platform_browser_1_1;
            }],
        execute: function() {
            SearchPopupComponent = (function () {
                function SearchPopupComponent(_router, _siteSearch, document) {
                    this._router = _router;
                    this._siteSearch = _siteSearch;
                    this.document = document;
                    this.site_search = "";
                    this.siteSearchResult = [];
                    this.isShowSearchPopup = false;
                    this.isShowGif = false;
                    this.isDataLoaded = true;
                    this.skip = 0;
                    this.take = 30;
                    this.noMoreRecords = false;
                    this.sitesearch = null;
                    this.lastTxtSearchVal = "";
                }
                SearchPopupComponent.prototype.siteSearch = function (event) {
                    if (this.lastTxtSearchVal !== event) {
                        this.lastTxtSearchVal = event;
                        this.getSiteSearch();
                    }
                };
                SearchPopupComponent.prototype.getSiteSearch = function (is_scroll) {
                    var _this = this;
                    if (is_scroll === void 0) { is_scroll = false; }
                    if (this.site_search.length >= 3) {
                        this.isShowSearchPopup = true;
                        this.isShowGif = true;
                        this.isDataLoaded = false;
                        if (is_scroll === false) {
                            this.skip = 0;
                            this.siteSearchResult = [];
                        }
                        if (this.sitesearch) {
                            this.sitesearch.unsubscribe();
                        }
                        this.sitesearch = this._siteSearch.siteSearch(this.site_search, this.skip, this.take).subscribe(function (data) {
                            _this.viewType = 'Cards';
                            if (data.length) {
                                if (is_scroll === true) {
                                    _this.siteSearchResult = _this.siteSearchResult.concat(data);
                                }
                                else {
                                    _this.siteSearchResult = data;
                                }
                                _this.skip = _this.siteSearchResult.length;
                            }
                            if (data.length == _this.take) {
                                _this.isDataLoaded = true;
                                _this.noMoreRecords = false;
                            }
                            else {
                                _this.noMoreRecords = true;
                            }
                        }, function (err) { console.log('Log error', err); throw err; }, function () {
                            _this.isShowGif = false;
                        });
                    }
                    else {
                        this.isShowSearchPopup = false;
                    }
                };
                SearchPopupComponent.prototype.searchRedirect = function (data) {
                    this.isShowSearchPopup = false;
                    this.siteSearchResult = null;
                    this.site_search = "";
                    if (data._type == "userProfiles")
                        this._router.navigate(['main/player', data._id]);
                    if (data._type == "organizations") {
                        sessionStorage['urlafterredict'] = '/main/teams/' + data._id;
                        this._router.navigate(['main/teams', data._id]);
                    }
                    if (data._type == "listValues_teamInfo") {
                        sessionStorage['urlafterredict'] = '/main/teams/' + data._id + '/' + data._source.value.code;
                        this._router.navigate(['main/teams', data._source.orgId, data._source.value.code]);
                    }
                };
                SearchPopupComponent.prototype.onScrollSearch = function (event) {
                    var ele = this.document.getElementById("searchdiv");
                    var bodyScrollTop = this.document.getElementById("searchdiv").scrollTop;
                    // if((ele.scrollHeight - ele.clientHeight) <= bodyScrollTop){
                    if (bodyScrollTop / (ele.scrollHeight - ele.clientHeight) > 0.8) {
                        if (this.isDataLoaded == true) {
                            this.getSiteSearch(true);
                        }
                    }
                };
                SearchPopupComponent.prototype.onOutsideClick = function ($event) {
                    if (!this.searchPopupDiv.nativeElement.contains($event.target)) {
                        this.closePopup();
                    }
                };
                SearchPopupComponent.prototype.closePopup = function () {
                    this.siteSearchResult = [];
                    this.site_search = "";
                    this.isShowSearchPopup = false;
                };
                __decorate([
                    core_1.ViewChild('searchPopupDiv'), 
                    __metadata('design:type', core_1.ElementRef)
                ], SearchPopupComponent.prototype, "searchPopupDiv", void 0);
                __decorate([
                    core_1.HostListener('document:click', ['$event']), 
                    __metadata('design:type', Function), 
                    __metadata('design:paramtypes', [Object]), 
                    __metadata('design:returntype', void 0)
                ], SearchPopupComponent.prototype, "onOutsideClick", null);
                SearchPopupComponent = __decorate([
                    core_1.Component({
                        selector: 'site-search-box',
                        templateUrl: '/maxweb/app/app/search-popup.component.html'
                    }),
                    __param(2, core_1.Inject(platform_browser_1.DOCUMENT)), 
                    __metadata('design:paramtypes', [router_1.Router, site_search_service_1.SiteSearchService, Document])
                ], SearchPopupComponent);
                return SearchPopupComponent;
            }());
            exports_1("SearchPopupComponent", SearchPopupComponent);
        }
    }
});
//# sourceMappingURL=search-popup.component.js.map