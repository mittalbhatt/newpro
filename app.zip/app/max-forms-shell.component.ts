import {Component, HostListener, ViewChild, ElementRef} from "@angular/core";
import {MaxAppContext} from "./maxAppContext.service";
import {Organization} from "./organizations.service";
import {Router} from "@angular/router";
import { UserProfiles, UserProfile } from "./user_profiles.service";
import { SiteSearchService, SiteSearch } from "./site-search.service";
import {Modal, BSModalContext} from 'angular2-modal/plugins/bootstrap';
import {Overlay, overlayConfigFactory} from 'angular2-modal';
import {ChangePasswordModal, ChangePasswordData} from "./change-password.component";
import {Assignments, Packet} from "./assignments.service";
@Component({
    selector:'max-forms-shell',
    templateUrl:'/maxweb/app/app/max-forms-shell.component.html'
})
export class MaxFormsShell {
    orgSelectorOpen:boolean;
    profileSelectorOpen:boolean;
    pendingUserCount:number;
    //@ViewChild('orgSelectorDropdown')orgSelectorDropdown:ElementRef;
    //@ViewChild('profileSelectorDropdown')profileSelectorDropdown:ElementRef;
    public currentDate:any;
    public sideMenuPackets:Packet[];
    private profileImageUrl:any;
    private profile:any;
    private currentAccount:any;
    private isShowAeccessRequestMenu:boolean=false;
    private isShowTeamMenu:boolean=false;
    constructor(
        public ctx:MaxAppContext, 
        private _router:Router, 
        private _userProfilesSvc: UserProfiles,
        private _modal:Modal,
        private _assignments:Assignments
    )
    {
        let d = new Date();
        this.currentDate = d.getFullYear();
    }

    ngOnInit() { 
        //let profilePromise = this._userProfilesSvc.getProfile(userProfileId).single().toPromise();

        if(this.ctx.myProfiles && this.ctx.myProfiles !== null){
            // this.isShowAeccessRequestMenu = true;
            // console.log(this.ctx.myProfiles);

            this.ctx.myProfiles.forEach(profile => {
                if(profile.orgRoles.indexOf("OADM") > -1 || profile.orgRoles.indexOf("UADM") > -1){
                    this.isShowAeccessRequestMenu = true;
                }

                if(this.isShowAeccessRequestMenu === false){
                    if(profile.linkedOrgRoles && profile.linkedOrgRoles !== undefined && profile.linkedOrgRoles.length > 0){
                        profile.linkedOrgRoles.forEach(orgRole => {
                            if(orgRole.roles.indexOf("OADM") > -1 || orgRole.roles.indexOf("UADM") > -1){
                                this.isShowAeccessRequestMenu = true;
                            }
                        });
                    }
                }

                if(profile.orgRoles.indexOf("TRN") > -1 || profile.orgRoles.indexOf("OTRN") > -1 || profile.orgRoles.indexOf("ADM") > -1 || profile.orgRoles.indexOf("CCH") > -1){
                    this.isShowTeamMenu = true;
                }

                if(this.isShowTeamMenu === false){
                    if(profile.linkedOrgRoles && profile.linkedOrgRoles !== undefined && profile.linkedOrgRoles.length > 0){
                        profile.linkedOrgRoles.forEach(orgRole => {
                            if(profile.orgRoles.indexOf("TRN") > -1 || profile.orgRoles.indexOf("OTRN") > -1 || profile.orgRoles.indexOf("ADM") > -1 || profile.orgRoles.indexOf("CCH") > -1){
                                this.isShowTeamMenu = true;
                            }
                        });
                    }
                }
            });
        }

        if (this.isShowTeamMenu)
        {
            this._assignments.getMine(true).then(res =>
            {
                let packets = <Packet[]>res;
                let sideMenuPackets = packets.filter(p =>
                    p.activities[0]
                    && p.activities[0].documentationEventDescription
                    && p.activities[0].documentationEventDescription.menuTitle);

                this.sideMenuPackets = sideMenuPackets;
            })
        }

        this._userProfilesSvc.getPendingUserCount().single().toPromise() .then(count => { 
            this.pendingUserCount = count; 
        });

        this.currentAccount = this.ctx.currentAccount;
        
        let profile = this.ctx.currentProfile;
        if(profile && profile !== undefined){
            this._userProfilesSvc.getProfile(profile._id).single().toPromise().then((data)=>{
                this.profile = data;
                this.loadImage();
            });
        } 
    }

    onDropdownToggleClick($event)
    {
        $event.stopPropagation();
        this.orgSelectorOpen = !this.orgSelectorOpen;
        this.profileSelectorOpen = false;
    }

    onDropdownProfileMenu($event)
    {
        $event.stopPropagation();
        this.profileSelectorOpen = !this.profileSelectorOpen;
        this.orgSelectorOpen = false;
    }

    // @HostListener('document:click', ['$event'])
    // onOutsideClick($event)
    // {
    //     if (!this.orgSelectorDropdown.nativeElement.contains($event.target))
    //         this.orgSelectorOpen = false;

    //     if (!this.profileSelectorDropdown.nativeElement.contains($event.target))
    //         this.profileSelectorOpen = false;
    // }

    get orgChoices() : Organization[]
    {
        if (this.ctx.myOrganizations && this.ctx.currentOrg)
            return this.ctx.myOrganizations.filter(o => o._id != this.ctx.currentOrg._id);
        else
            return [];
    }

    loadImage()
    {
        return this._userProfilesSvc.getProfileImageUrl(this.profile).single().toPromise()
            .then(url => {
                this.profileImageUrl = url;
            })
            .catch(e => {
                console.log('Logo error', e);
                throw e;
            });
    }
 
    onChooseOrg(org:Organization)
    {
        this.orgSelectorOpen = false;
        this.ctx.orgId = org._id;
        this._router.navigate(['main']);
    }

    changePassword(){
        let profile = this.ctx.currentProfile;
        let config = overlayConfigFactory(new BSModalContext(), BSModalContext);
        //let save = () => this._userProfiles.createProfile(profile).single().toPromise();
        config = overlayConfigFactory({pendingProfile: profile}, ChangePasswordData);
        return this._modal.open(ChangePasswordModal, config);
    }
}