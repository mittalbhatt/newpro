import {Http, RequestOptions, URLSearchParams, Response} from "@angular/http";
import {Injectable, Inject} from "@angular/core";
import {Observable} from "rxjs/Rx";

export class LinkedOrgRoleRequest {
    _id:string;
    profileId:string;
    requestedOrgId:string;
    requestedRoles:string[];
    requestedOrg:{name:string};
}

@Injectable()
export class LinkedOrgRoleRequests {
    constructor(private _http:Http, @Inject(RequestOptions) private _requestOps:RequestOptions) {

    }

    createRequest(req:LinkedOrgRoleRequest)
    {
        return this._http.put('/training/api/linkedOrgRoleRequests', req);
    }
}