System.register(["@angular/core", "./auth.service", "@angular/router", "./userAccount.service", "./maxAppContext.service"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, auth_service_1, router_1, userAccount_service_1, maxAppContext_service_1;
    var AccountVerificationComponent;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (auth_service_1_1) {
                auth_service_1 = auth_service_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (userAccount_service_1_1) {
                userAccount_service_1 = userAccount_service_1_1;
            },
            function (maxAppContext_service_1_1) {
                maxAppContext_service_1 = maxAppContext_service_1_1;
            }],
        execute: function() {
            AccountVerificationComponent = (function () {
                function AccountVerificationComponent(_auth, _acctSvc, _router, _ctx, _route) {
                    this._auth = _auth;
                    this._acctSvc = _acctSvc;
                    this._router = _router;
                    this._ctx = _ctx;
                    this._route = _route;
                }
                AccountVerificationComponent.prototype.ngOnInit = function () {
                    var username = this._route.snapshot.params['username'];
                    if (username)
                        this.username = decodeURIComponent(username);
                    if (!this.username) {
                        this.errorMessage = 'Unexpected error encountered. You have accessed this page in an invalid manner.';
                        return;
                    }
                    if (this.verificationRequested[this.username] == 'verified') {
                        this.alertAndRedirect();
                        return;
                    }
                    if (!this.verificationRequested[this.username]) {
                        this.requestVerification();
                    }
                };
                AccountVerificationComponent.prototype.requestVerification = function () {
                    var _this = this;
                    this.sending = true;
                    this._acctSvc.requestVerification(this.username)
                        .then(function (res) {
                        delete _this._acctSvc.cachedPendingAccount;
                        var body = res.status == 200 ? res.json() : null;
                        if (body && body.status == 'verified') {
                            _this.alertAndRedirect();
                            return;
                        }
                        _this.sending = false;
                        var vr = _this.verificationRequested;
                        vr[_this.username] = true;
                        _this.verificationRequested = vr;
                    })
                        .catch(function (e) {
                        _this.sending = false;
                        if (e.json && e.json().message) {
                            _this.errorMessage = e.json().message;
                            if (e.json().code == 400 && _this._acctSvc.cachedPendingAccount) {
                                _this.done = true;
                                _this._router.navigate(['signup', { errorMessage: _this.errorMessage }], { relativeTo: _this._route.parent });
                                return;
                            }
                        }
                        else {
                            _this.errorMessage = 'Unexpected error encountered. Try refreshing the page.';
                        }
                        throw e;
                    });
                };
                AccountVerificationComponent.prototype.alertAndRedirect = function () {
                    window.alert('This account has already been verified.');
                    this.redirect();
                };
                AccountVerificationComponent.prototype.goToSignup = function () {
                    this._ctx.logout(false);
                    this.done = true;
                    this._router.navigate(['signup'], { relativeTo: this._route.parent });
                };
                AccountVerificationComponent.prototype.onSubmit = function () {
                    var _this = this;
                    if (this.submitting)
                        return;
                    if (!this.code) {
                        this.errorMessage = 'Please enter your code.';
                        return;
                    }
                    this.submitting = true;
                    this.errorMessage = null;
                    this._acctSvc.fulfillVerification(this.username, this.code.replace(/\D/g, ''))
                        .then(function () {
                        var vr = _this.verificationRequested;
                        vr[_this.username] = 'verified';
                        _this.verificationRequested = vr;
                        if (_this._acctSvc.cachedPassword)
                            return _this._auth.login(_this.username, _this._acctSvc.cachedPassword);
                        else
                            return Promise.resolve(false);
                    })
                        .then(function (result) {
                        _this.done = true;
                        _this.submitting = false;
                        delete _this._acctSvc.cachedPassword;
                        if (result === false) {
                            _this._router.navigateByUrl('/max-cover/login');
                            return;
                        }
                        _this.redirect();
                    })
                        .catch(function (err) {
                        _this.submitting = false;
                        window.scrollTo(0, 0);
                        if (err.status == 404) {
                            _this.errorMessage = 'Incorrect verification code.';
                            delete _this.code;
                            _this.codeInput.nativeElement.focus();
                        }
                        else {
                            _this.errorMessage = 'We encountered an unexpected error.';
                        }
                        throw err;
                    });
                };
                AccountVerificationComponent.prototype.redirect = function () {
                    this.done = true;
                    var url = this._auth.redirectUrl;
                    console.log("Logged in.  Redirect url: " + url);
                    this._auth.redirectUrl = null;
                    if (url)
                        this._router.navigateByUrl(url);
                    else
                        this._router.navigateByUrl('/');
                };
                Object.defineProperty(AccountVerificationComponent.prototype, "verificationRequested", {
                    get: function () {
                        return store.session('VerificationRequested') || {};
                    },
                    set: function (value) {
                        store.session('VerificationRequested', value);
                    },
                    enumerable: true,
                    configurable: true
                });
                __decorate([
                    core_1.ViewChild('codeInput'), 
                    __metadata('design:type', core_1.ElementRef)
                ], AccountVerificationComponent.prototype, "codeInput", void 0);
                AccountVerificationComponent = __decorate([
                    core_1.Component({
                        selector: 'max-account-verification',
                        template: "\n<div *ngIf=\"errorMessage\" style=\"max-width:500px; margin:20px auto;\" class=\"alert alert-danger\">{{errorMessage}}</div>\n    <div id=\"signup-form\">\n        <div>\n            <org-heading #heading></org-heading>\n            <img *ngIf=\"!heading.org\" class=\"max-wordmark-logo\" src=\"app/media/hurricane-100.png\"/>\n            <span *ngIf=\"!heading.org\" class=\"max-wordmark-text\">DragonFly MAX</span>\n            <a style=\"font-size:10px;\" href=\"javascript:void(0)\" (click)=\"reset()\" *ngIf=\"heading.org\">Not part of {{heading.org.name}}? Click here.</a>\n        </div>\n        \n            <h3>Verify Your Account</h3>\n            <div *ngIf=\"!verificationRequested[username]\">\n                <img src=\"/maxweb/app/media/ajax-loader.gif\" />\n            </div>\n            <div *ngIf=\"verificationRequested[username]\">\n                <p>We just sent a verification code to</p>\n                <h4 *ngIf=\"username?.length < 29\" style=\"color:black\">{{username?.toLowerCase()}}</h4>\n                <h6 *ngIf=\"username?.length >= 29\" style=\"color:black; font-weight: bold\">{{username?.toLowerCase()}}</h6>\n                <p>Check your messages and enter the code below, or <img *ngIf=\"sending\" width=\"15\" src=\"/maxweb/app/media/ajax-loader.gif\"> <a *ngIf=\"!sending\" href=\"javascript:void(0)\" style=\"color:darkred\" (click)=\"requestVerification()\">click here to resend.</a></p>\n            <form #loginForm=\"ngForm\" (ngSubmit)=\"onSubmit()\">\n              <div class=\"form-group\">\n                <label for=\"code\">Code</label>\n                <input #codeInput [(ngModel)]=\"code\" type=\"text\" class=\"form-control\" name=\"code\" placeholder=\"Verification code\" required autofocus>\n              </div>\n              <button type=\"submit\" [disabled]=\"submitting\" class=\"btn btn-default\">Submit</button>\n            </form>\n            \n           \n        </div>\n         <div style=\"text-align: left; margin-top:10px;\"><a style=\"color:darkred\" href=\"javascript:void(0)\" (click)=\"goToSignup()\">&lt;&lt; Return to sign-up</a></div>\n    </div>\n"
                    }), 
                    __metadata('design:paramtypes', [auth_service_1.AuthService, userAccount_service_1.UserAccountService, router_1.Router, maxAppContext_service_1.MaxAppContext, router_1.ActivatedRoute])
                ], AccountVerificationComponent);
                return AccountVerificationComponent;
            }());
            exports_1("AccountVerificationComponent", AccountVerificationComponent);
        }
    }
});
//# sourceMappingURL=verifyAccount.component.js.map