import {Injectable} from "@angular/core";
import {MaxAppContext} from "./maxAppContext.service";
import {CanActivate, RouterStateSnapshot, ActivatedRouteSnapshot, Router} from "@angular/router";

@Injectable()
export class ContextProfileRouteGuard implements CanActivate
{
    constructor(private _ctx:MaxAppContext, private _router:Router)
    {

    }

    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot)
    {
        return this._ctx.initialize().then(res =>
        {
            if (res)
            {
                this._router.navigate(['/main/profile', this._ctx.currentProfile._id]);
                return false;
            }
        });
    }
}