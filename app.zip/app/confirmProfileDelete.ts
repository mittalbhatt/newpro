import {UserProfile} from "./user_profiles.service";
import {Modal} from "angular2-modal";
import {Injectable} from "@angular/core";

@Injectable()
export class ProfileUtil
{
    constructor(private _modal:Modal){}

    confirmProfileDelete(profile:UserProfile, invokeDelete:()=>void)
    {
        (<any>this._modal.confirm())
            .size('sm')
            .isBlocking(true)
            .showClose(false)
            .keyboard(27)
            .title('Confirm')
            .body(`Are you sure you want to permanently delete ${profile.athleteTitleName}?`)
            .bodyClass('modal-body text-left')
            .okBtn('Yes - Delete')
            .open()
            .then(res =>
            {
                return res.result;
            })
            .then(res =>
            {
                if (res === true)
                {
                    invokeDelete();
                }
            })
            .catch(e =>
            {
                if (e)
                    throw e;

                // canceled
            })
    }
}