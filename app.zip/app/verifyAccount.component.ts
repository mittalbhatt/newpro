import {Component, OnInit, ViewChild, ElementRef} from "@angular/core";
import {AuthService} from "./auth.service";
import {Router, ActivatedRoute, CanDeactivate, RouterStateSnapshot, ActivatedRouteSnapshot} from "@angular/router";
import {UserAccountService} from "./userAccount.service";
import {MaxAppContext} from "./maxAppContext.service";
import {Response} from "@angular/http";

declare var store;

@Component({
    selector: 'max-account-verification',
    template:`
<div *ngIf="errorMessage" style="max-width:500px; margin:20px auto;" class="alert alert-danger">{{errorMessage}}</div>
    <div id="signup-form">
        <div>
            <org-heading #heading></org-heading>
            <img *ngIf="!heading.org" class="max-wordmark-logo" src="app/media/hurricane-100.png"/>
            <span *ngIf="!heading.org" class="max-wordmark-text">DragonFly MAX</span>
            <a style="font-size:10px;" href="javascript:void(0)" (click)="reset()" *ngIf="heading.org">Not part of {{heading.org.name}}? Click here.</a>
        </div>
        
            <h3>Verify Your Account</h3>
            <div *ngIf="!verificationRequested[username]">
                <img src="/maxweb/app/media/ajax-loader.gif" />
            </div>
            <div *ngIf="verificationRequested[username]">
                <p>We just sent a verification code to</p>
                <h4 *ngIf="username?.length < 29" style="color:black">{{username?.toLowerCase()}}</h4>
                <h6 *ngIf="username?.length >= 29" style="color:black; font-weight: bold">{{username?.toLowerCase()}}</h6>
                <p>Check your messages and enter the code below, or <img *ngIf="sending" width="15" src="/maxweb/app/media/ajax-loader.gif"> <a *ngIf="!sending" href="javascript:void(0)" style="color:darkred" (click)="requestVerification()">click here to resend.</a></p>
            <form #loginForm="ngForm" (ngSubmit)="onSubmit()">
              <div class="form-group">
                <label for="code">Code</label>
                <input #codeInput [(ngModel)]="code" type="text" class="form-control" name="code" placeholder="Verification code" required autofocus>
              </div>
              <button type="submit" [disabled]="submitting" class="btn btn-default">Submit</button>
            </form>
            
           
        </div>
         <div style="text-align: left; margin-top:10px;"><a style="color:darkred" href="javascript:void(0)" (click)="goToSignup()">&lt;&lt; Return to sign-up</a></div>
    </div>
`
})
export class AccountVerificationComponent implements OnInit {

    errorMessage:string;
    sending:boolean;

    username:string;
    code:string;
    submitting:boolean;
    done:boolean;

    @ViewChild('codeInput')codeInput:ElementRef;

    constructor(private _auth:AuthService,
                private _acctSvc:UserAccountService,
                private _router:Router,
                private _ctx:MaxAppContext,
                private _route:ActivatedRoute)
    {

    }

    ngOnInit()
    {
        let username = this._route.snapshot.params['username'];
        if (username)
            this.username = decodeURIComponent(username);

        if (!this.username)
        {
            this.errorMessage = 'Unexpected error encountered. You have accessed this page in an invalid manner.';
            return;
        }

        if (this.verificationRequested[this.username] == 'verified')
        {
            this.alertAndRedirect();
            return;
        }

        if (!this.verificationRequested[this.username])
        {
            this.requestVerification();
        }
    }

    requestVerification()
    {
        this.sending = true;
        this._acctSvc.requestVerification(this.username)
            .then((res:Response) =>
            {
                delete this._acctSvc.cachedPendingAccount;

                var body = res.status == 200 ? res.json() : null;
                if (body && body.status == 'verified')
                {
                    this.alertAndRedirect();
                    return;
                }

                this.sending = false;
                let vr = this.verificationRequested;
                vr[this.username] = true;
                this.verificationRequested = vr;
            })
            .catch(e =>
            {
                this.sending = false;

                if (e.json && e.json().message)
                {
                    this.errorMessage = e.json().message;

                    if (e.json().code == 400 && this._acctSvc.cachedPendingAccount)
                    {
                        this.done = true;
                        this._router.navigate(['signup', {errorMessage:this.errorMessage}], {relativeTo:this._route.parent});
                        return;
                    }
                }
                else
                {
                    this.errorMessage = 'Unexpected error encountered. Try refreshing the page.';
                }

                throw e;
            });
    }

    private alertAndRedirect()
    {
        window.alert('This account has already been verified.');
        this.redirect();
    }

    goToSignup()
    {
        this._ctx.logout(false);
        this.done = true;
        this._router.navigate(['signup'], {relativeTo:this._route.parent});
    }

    onSubmit()
    {
        if (this.submitting)
            return;

        if (!this.code)
        {
            this.errorMessage = 'Please enter your code.';
            return;
        }

        this.submitting = true;
        this.errorMessage = null;

        this._acctSvc.fulfillVerification(this.username, this.code.replace(/\D/g,''))
            .then(():any =>
            {
                let vr = this.verificationRequested;
                vr[this.username] = 'verified';
                this.verificationRequested = vr;

                if (this._acctSvc.cachedPassword)
                    return this._auth.login(this.username, this._acctSvc.cachedPassword);
                else
                    return Promise.resolve(false)
            })
            .then(result =>
            {
                this.done = true;
                this.submitting = false;
                delete this._acctSvc.cachedPassword;

                if (result === false)
                {
                    this._router.navigateByUrl('/max-cover/login');
                    return;
                }

                this.redirect();
            })
            .catch(err =>
            {
                this.submitting = false;
                window.scrollTo(0, 0);

                if (err.status == 404)
                {
                    this.errorMessage = 'Incorrect verification code.';
                    delete this.code;
                    this.codeInput.nativeElement.focus();
                }
                else
                {
                    this.errorMessage = 'We encountered an unexpected error.';
                }

                throw err;
            });
    }

    redirect()
    {
        this.done = true;

        let url = this._auth.redirectUrl;
        console.log(`Logged in.  Redirect url: ${url}`);
        this._auth.redirectUrl = null;
        if (url)
            this._router.navigateByUrl(url);
        else
            this._router.navigateByUrl('/');
    }

    get verificationRequested()
    {
        return store.session('VerificationRequested') || {};
    }

    set verificationRequested(value:any)
    {
        store.session('VerificationRequested', value);
    }
}