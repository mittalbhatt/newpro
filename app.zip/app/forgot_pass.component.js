System.register(["@angular/core", "@angular/router", "./userAccount.service"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, router_1, userAccount_service_1;
    var ForgotPassComponent;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (userAccount_service_1_1) {
                userAccount_service_1 = userAccount_service_1_1;
            }],
        execute: function() {
            ForgotPassComponent = (function () {
                function ForgotPassComponent(_acctSvc, _router, _route) {
                    this._acctSvc = _acctSvc;
                    this._router = _router;
                    this._route = _route;
                    var username = this._route.snapshot.params['username'];
                    if (username)
                        this.username = decodeURIComponent(username);
                }
                ForgotPassComponent.prototype.onSubmit = function () {
                    var _this = this;
                    if (this.submitting)
                        return;
                    this.submitting = true;
                    this.errorMessage = null;
                    this._acctSvc.requestPasswordReset(this.username.trim())
                        .then(function (result) {
                        _this._router.navigate(['reset-pass', result.userAccountId, _this.username.trim()], { relativeTo: _this._route.parent });
                    })
                        .catch(function (err) {
                        _this.submitting = false;
                        console.log(err);
                        _this.errorMessage = 'I was unable to send a password reset code.  Did you sign up with a different mobile number or email?';
                    });
                };
                ForgotPassComponent = __decorate([
                    core_1.Component({
                        selector: 'max-forgot-pass',
                        template: "\n    <div *ngIf=\"errorMessage\" style=\"max-width:500px; margin:20px auto;\" class=\"alert alert-danger\">{{errorMessage}}</div>\n    <div id=\"forgot-pass-form\">\n        <div>\n            <img class=\"max-wordmark-logo\" src=\"app/media/hurricane-100.png\"/>\n            <span class=\"max-wordmark-text\">DragonFly MAX</span>\n        </div>\n        <h3>Reset Password</h3>\n        <p>Enter the email address or mobile phone number associated with your MAX account.</p>\n        \n        <form #forgotPassForm=\"ngForm\" (ngSubmit)=\"onSubmit()\">\n          <div class=\"form-group\">\n            <label for=\"username\">Login</label>\n            <input [(ngModel)]=\"username\"  autocorrect=\"off\" autocapitalize=\"off\" spellcheck=\"false\" type=\"text\" class=\"form-control\" name=\"username\" placeholder=\"Mobile # or email address\" required>\n          </div>\n          <button type=\"submit\" class=\"btn btn-default\" [disabled]=\"!forgotPassForm.form.valid\">Send Reset Code</button>\n        </form>\n    </div>\n"
                    }), 
                    __metadata('design:paramtypes', [userAccount_service_1.UserAccountService, router_1.Router, router_1.ActivatedRoute])
                ], ForgotPassComponent);
                return ForgotPassComponent;
            }());
            exports_1("ForgotPassComponent", ForgotPassComponent);
        }
    }
});
//# sourceMappingURL=forgot_pass.component.js.map