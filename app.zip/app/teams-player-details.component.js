System.register(["@angular/core", "@angular/router", '@angular/common', "./user_profiles.service", "./teamInfo.service", "./sportCodes", "./maxAppContext.service", "./pending_profile_approval.component", "./organizations.service", "angular2-modal"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __extends = (this && this.__extends) || function (d, b) {
        for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, router_1, common_1, user_profiles_service_1, teamInfo_service_1, sportCodes_1, maxAppContext_service_1, pending_profile_approval_component_1, organizations_service_1, angular2_modal_1;
    var KeysPipe, TeamsPlayerDetailsComponent;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (common_1_1) {
                common_1 = common_1_1;
            },
            function (user_profiles_service_1_1) {
                user_profiles_service_1 = user_profiles_service_1_1;
            },
            function (teamInfo_service_1_1) {
                teamInfo_service_1 = teamInfo_service_1_1;
            },
            function (sportCodes_1_1) {
                sportCodes_1 = sportCodes_1_1;
            },
            function (maxAppContext_service_1_1) {
                maxAppContext_service_1 = maxAppContext_service_1_1;
            },
            function (pending_profile_approval_component_1_1) {
                pending_profile_approval_component_1 = pending_profile_approval_component_1_1;
            },
            function (organizations_service_1_1) {
                organizations_service_1 = organizations_service_1_1;
            },
            function (angular2_modal_1_1) {
                angular2_modal_1 = angular2_modal_1_1;
            }],
        execute: function() {
            KeysPipe = (function () {
                function KeysPipe() {
                }
                KeysPipe.prototype.transform = function (value, args) {
                    if (!value) {
                        return value;
                    }
                    var keys = [];
                    for (var key in value) {
                        keys.push({ key: key, value: value[key] });
                    }
                    return keys;
                };
                KeysPipe = __decorate([
                    core_1.Pipe({ name: 'keys' }), 
                    __metadata('design:paramtypes', [])
                ], KeysPipe);
                return KeysPipe;
            }());
            exports_1("KeysPipe", KeysPipe);
            TeamsPlayerDetailsComponent = (function (_super) {
                __extends(TeamsPlayerDetailsComponent, _super);
                function TeamsPlayerDetailsComponent(_profilesSvc, _orgsSvc, _modal, _route, router, _location, _teamInfoSvc, _ctx, _userProfilesSvc) {
                    var _this = this;
                    _super.call(this, _profilesSvc, _orgsSvc, _modal, router, _route);
                    this._profilesSvc = _profilesSvc;
                    this._orgsSvc = _orgsSvc;
                    this._modal = _modal;
                    this._route = _route;
                    this.router = router;
                    this._location = _location;
                    this._teamInfoSvc = _teamInfoSvc;
                    this._ctx = _ctx;
                    this._userProfilesSvc = _userProfilesSvc;
                    this._userProfile = null;
                    this.isShowGif = false;
                    this.userTags = [];
                    this.sportName = "";
                    this.injuryDetails = [];
                    this.isShowInjuryGif = true;
                    this.documentDataList = [];
                    this.isShowDocumentGif = true;
                    this.pendingApproval = true;
                    this.isShowApproveRemove = false;
                    this.isCurrentPlayerTab = "injuriestab";
                    this.userdata = [];
                    this.groupedGroup = null;
                    this.showMedicalDemoInfoButton = false;
                    this.isShowDeleteButton = false;
                    this.istrashshow = false;
                    this.hasAccount = false;
                    this.parentHasAccount = false;
                    this._profilesSvc.getProfileData.subscribe(function (res) {
                        if (res.action == "approve") {
                            //console.log("EventEmitter Call: "+this.playerId);
                            _this.isShowApproveRemove = false;
                            _this.refreshProfile();
                        }
                        else if (res.action == "disapprove") {
                            //console.log("EventEmitter Call: Remove");
                            _this.router.navigate(['/main/admin/access-requests']);
                        }
                        else if (res.action == "delete") {
                            //console.log("EventEmitter Call: Delete "+sessionStorage['redirectUrl']);
                            //this.router.navigate([sessionStorage['redirectUrl']]);
                            window.history.back();
                        }
                    }, function (error) {
                        console.log("Error");
                        throw error;
                    });
                }
                TeamsPlayerDetailsComponent.prototype.ngOnInit = function () {
                    this.refreshProfile();
                    if (sessionStorage['isCurrentPlayerTab'] != "" && sessionStorage['isCurrentPlayerTab'] !== undefined) {
                        this.isCurrentPlayerTab = sessionStorage['isCurrentPlayerTab'];
                    }
                };
                TeamsPlayerDetailsComponent.prototype.ngOnDestroy = function () {
                    sessionStorage['isCurrentPlayerTab'] = "";
                };
                TeamsPlayerDetailsComponent.prototype.refreshProfile = function (clearError) {
                    var _this = this;
                    if (clearError === void 0) { clearError = true; }
                    if (clearError)
                        this.errorMessage = null;
                    this._route.params.subscribe(function (params) {
                        _this.playerId = params['id'];
                        _this.isShowGif = true;
                        _this.getHasAnAccountText(_this.playerId);
                        _this._userProfilesSvc.getProfile(_this.playerId).toPromise().then(function (data) {
                            _this.userdata = data;
                            //console.log(this.userdata);
                            _this.sportName = "";
                            _this._userProfile = new user_profiles_service_1.UserProfile(data);
                            _this._userProfile.specificAllergyShow = _this._userProfile.getSpecificAllergyShow(_this._userProfile);
                            _this._userProfile.displayAllergy = _this._userProfile.getSpecificAllergy(_this._userProfile);
                            _this._userProfile.existingMedicalConditionShow = _this._userProfile.getExistingMedicalConditionShow(_this._userProfile);
                            _this._userProfile.displayexistingMedicalCondition = _this._userProfile.getExistingMedicalCondition(_this._userProfile);
                            _this._userProfile.displayDOB = _this._userProfile.getDOB(_this._userProfile);
                            _this._userProfile.displayGradYear = _this._userProfile.getGradYear(_this._userProfile);
                            var targetProfileOrg = _this._ctx.availableOrganizations.find(function (o) { return o._id == _this._userProfile.org; });
                            var medicalDocActivityId = (targetProfileOrg.defaultDocuments.find(function (d) { return d.form == 'medical' && d.context == 'userProfile'; }) || { activityId: undefined }).activityId;
                            _this.medicalDocumentActivityId = medicalDocActivityId;
                            if (_.has(_this._userProfile, 'orgRoles')) {
                                if (_this._userProfile.orgRoles.indexOf("ATH") > -1 || _this._userProfile.orgRoles.indexOf("CCH") > -1) {
                                    _this.showMedicalDemoInfoButton = true;
                                }
                            }
                            var viewerProfile = _this._ctx.myProfiles.find(function (p) { return p.org === _this._userProfile.org || !!(p.linkedOrgRoles || []).find(function (lor) { return lor.orgId === _this._userProfile.org; }); });
                            if (viewerProfile.orgRoles.indexOf("OADM") > -1 || viewerProfile.orgRoles.indexOf("UADM") > -1) {
                                _this.istrashshow = true;
                            }
                            _this.userTags = [];
                            _this.getInjuryStatus();
                            _this.loadImage();
                            if (_this._userProfile.tags) {
                                _this.userTags = _this._userProfile.tags;
                            }
                            _this._teamInfoSvc.getAllTeamInfoEntries()
                                .then(function (teamInfoValues) {
                                _this.teamInfoValues = teamInfoValues;
                                //this.isShowGif =false;
                                // console.log(this.teamInfoValues);
                                _this.userTags.forEach(function (code) {
                                    var sport = _this.nameForSportCode(code);
                                    if (_this.sportName == "") {
                                        _this.sportName += sport;
                                    }
                                    else {
                                        _this.sportName += ", " + sport;
                                    }
                                });
                            })
                                .catch(function (e) {
                                //this.errorMessage = 'We encountered an unexpected error.  Please try again.';
                                throw e;
                            });
                            //console.log("Profile User Roles:---------------------");
                            //console.log(this._userProfile.orgRoles);
                            //console.log(this._userProfile.state);
                            // added for userprofileModel object pass in onAprove method
                            var profiles = _this._profilesSvc.getPendingProfiles();
                            profiles.single().subscribe(function (p) {
                                _this.isShowGif = false;
                                var profileModels = p.map(function (p) { return new pending_profile_approval_component_1.PendingProfileModel(p); });
                                _this._userProfileModel = profileModels.filter(function (po) { return po.profile._id == _this.playerId; });
                                if (_this._userProfileModel.length > 0) {
                                    if (_this._userProfileModel[0].profile.state.pendingApproval === true && (_this._ctx.currentProfile.orgRoles.indexOf("OADM") > -1 || _this._ctx.currentProfile.orgRoles.indexOf("UADM") > -1)) {
                                        //console.log("test1");
                                        _this.isShowApproveRemove = true;
                                    }
                                }
                            }, function (error) {
                                console.log('Something went wrong', error);
                                throw error;
                            });
                            if (_this._userProfile.state != undefined && _this._userProfile.state.pendingApproval != undefined && _this._userProfile.state.pendingApproval === true && _.intersection(_this._userProfile.orgRoles, ['CCH', 'TRN', 'OTRN', 'OADM', 'UADM']).length == 0) {
                                _this.isShowDeleteButton = true;
                            }
                            //console.log('isShowApproveRemove=============isShowDeleteButton');
                            //console.log(this.isShowApproveRemove+"============="+this.isShowDeleteButton);
                        }).catch(function (e) {
                            console.log('Logo error', e);
                            throw e;
                        });
                    });
                };
                TeamsPlayerDetailsComponent.prototype.getHasAnAccountText = function (playerId) {
                    var _this = this;
                    this._profilesSvc.getAllProfilesToCheck()
                        .then(function (profiles) {
                        _this.phoneImage = '/maxweb/app/media/icons8-SMS-50.png';
                        var userAccount = profiles.filter(function (p) { return p._id == playerId; }).map(function (p) { return new user_profiles_service_1.UserProfile(p); });
                        if (_.has(userAccount[0], '$userAccount') || (_this._userProfile.state != undefined && _this._userProfile.state.pendingApproval != undefined && _this._userProfile.state.pendingApproval == true)) {
                            //console.log("Has an Account");
                            _this.hasAccount = true;
                        }
                        var relatedProfiles = [];
                        if (_.has(userAccount[0], 'relations')) {
                            relatedProfiles = profiles.filter(function (p) { return userAccount[0].relations != undefined && userAccount[0].relations.find(function (r) { return r.userProfileId == p._id; }); });
                        }
                        if (relatedProfiles != undefined && relatedProfiles.length != 0) {
                            //console.log("Parent has an Account");
                            _this.parentHasAccount = true;
                        }
                        if (_this.hasAccount == true && _this.parentHasAccount == true) {
                            _this.hasAccountText = 'Athlete and parent both have accounts';
                        }
                        else if (_this.hasAccount == true) {
                            _this.hasAccountText = 'Has an account';
                        }
                        else if (_this.parentHasAccount == true) {
                            _this.hasAccountText = 'Parent has an account';
                        }
                        else {
                            _this.hasAccountText = 'No Account';
                            _this.phoneImage = '/maxweb/app/media/no-account-icons.png';
                        }
                    })
                        .catch(function (e) {
                        console.log(e);
                        _this.errorMessage = 'We encountered an unexpected error. Refresh the page and try again.';
                        throw e;
                    });
                };
                TeamsPlayerDetailsComponent.prototype.getOrgStateCity = function (org) {
                    if (org === void 0) { org = ""; }
                    var stateCityStr = "";
                    if (org) {
                        var currentOrgDetails = this._ctx.availableOrganizations.find(function (o) {
                            return o._id === org;
                        });
                        if (currentOrgDetails !== undefined) {
                            if (currentOrgDetails.city !== undefined && currentOrgDetails.city != "" && currentOrgDetails.city != null) {
                                stateCityStr = currentOrgDetails.city;
                            }
                            if (currentOrgDetails.stateCode !== undefined && currentOrgDetails.stateCode != "" && currentOrgDetails.stateCode != null) {
                                if (stateCityStr == "") {
                                    stateCityStr = currentOrgDetails.stateCode;
                                }
                                else {
                                    stateCityStr += " - " + currentOrgDetails.stateCode;
                                }
                            }
                        }
                    }
                    return stateCityStr;
                };
                // nameForSportCode(code:string)
                // {
                //     if(this.teamInfoValues){
                //         code = code.replace(",","").replace(",","").replace(",","");
                //         let sport = this.teamInfoValues.find(tc => tc.value.code == code);
                //         return sport ? sport.value.name : 'UNKNOWN';
                //     }
                //     return "";
                // }
                TeamsPlayerDetailsComponent.prototype.nameForSportCode = function (code) {
                    //console.log(code);
                    code = code.replace(",", "");
                    var code_arr = code.split(":");
                    code_arr = code_arr[0].split(",");
                    // console.log(code_arr[0]);
                    var sport = sportCodes_1.SportCodes.find(function (sc) { return sc.code == code_arr[0]; });
                    return sport ? sport.name : code_arr[0];
                };
                TeamsPlayerDetailsComponent.prototype.backClicked = function () {
                    this._location.back();
                };
                TeamsPlayerDetailsComponent.prototype.loadImage = function () {
                    var _this = this;
                    return this._userProfilesSvc.getProfileImageUrl(this._userProfile).single().toPromise()
                        .then(function (url) {
                        _this._user_img = url;
                    })
                        .catch(function (e) {
                        console.log('Logo error', e);
                        throw e;
                    });
                };
                TeamsPlayerDetailsComponent.prototype.getInjuryStatus = function () {
                    var _this = this;
                    this.injuryDetails = [];
                    sessionStorage['isCurrentPlayerTab'] = 'injuriestab';
                    this.isShowInjuryGif = true;
                    var filterParameter = { user: this.playerId };
                    this._userProfilesSvc.getUserInjuryStatus(0, 100, filterParameter).toPromise().then(function (data) {
                        _this.injuryDetails = data; //new UserInjuryDetails(data);
                        _this.isShowInjuryGif = false;
                    }).catch(function (err) {
                        _this.isShowInjuryGif = false;
                        throw err;
                    });
                };
                TeamsPlayerDetailsComponent.prototype.selectdocumentdata = function (documentid) {
                    var _this = this;
                    this.documentDataList = [];
                    sessionStorage['isCurrentPlayerTab'] = 'documentstab';
                    this.isShowDocumentGif = true;
                    this._userProfilesSvc.getTeamUserDocument(documentid).single().toPromise()
                        .then(function (data) {
                        _this.isShowDocumentGif = false;
                        _this.documentDataList = data;
                    })
                        .catch(function (e) {
                        _this.isShowDocumentGif = false;
                        throw e;
                    });
                };
                TeamsPlayerDetailsComponent.prototype.onClickMedicalDemoInfoDoc = function () {
                    this._router.navigate(['/main/basicmedicalForm', this._userProfile._id, this.medicalDocumentActivityId], { relativeTo: this._route.parent });
                };
                TeamsPlayerDetailsComponent = __decorate([
                    core_1.Component({
                        selector: 'teams-player-details',
                        templateUrl: '/maxweb/app/app/teams-player-details.component.html'
                    }), 
                    __metadata('design:paramtypes', [user_profiles_service_1.UserProfiles, organizations_service_1.Organizations, angular2_modal_1.Modal, router_1.ActivatedRoute, router_1.Router, common_1.Location, teamInfo_service_1.TeamInfo, maxAppContext_service_1.MaxAppContext, user_profiles_service_1.UserProfiles])
                ], TeamsPlayerDetailsComponent);
                return TeamsPlayerDetailsComponent;
            }(pending_profile_approval_component_1.PendingProfilesView));
            exports_1("TeamsPlayerDetailsComponent", TeamsPlayerDetailsComponent);
        }
    }
});
//# sourceMappingURL=teams-player-details.component.js.map