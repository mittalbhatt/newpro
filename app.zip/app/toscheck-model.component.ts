    import {Component, Output, EventEmitter} from "@angular/core";
    import {UserAccount, UserAccountService} from "./userAccount.service";
    import {CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router} from "@angular/router";
    import {ModalComponent, DialogRef} from "angular2-modal";
    import { Observable } from 'rxjs';
    import {Modal, BSModalContext} from 'angular2-modal/plugins/bootstrap';
    import {MaxAppContext} from "./maxAppContext.service";
    export class TosModalContext extends BSModalContext {
        public data: any;

        constructor(private d:any){
            super();
            this.data = d;
            this.size = "lg";
        }
    }

    @Component({
        selector:'tos-form-modal-prompt',
        template:`
        <div class="modal-content" style="text-align:center;">
        <div class="modal-header">
        <h4> Terms of Service </h4>
        </div>
        <div class="modal-body" style="text-align:left;height:600px;padding-left: 25px;overflow-y: auto;">
        <div [innerHTML]="this.contentdata"></div>
        </div>
        <div *ngIf="!this.contentdata" class="modal-body">
        <img src="/maxweb/app/media/ajax-loader.gif" />
        Processing...    
        </div>
        <div class="modal-footer">
        <button (click)="saveToseVersion()" type="button" class="btn btn-primary" style="float:right; margin-right:10px;">Accept</button>
        <button (click)="onCancel()" type="button" class="btn btn-danger" style="float:right; margin-right:10px;">Do Not Accept</button>
        </div>
        </div>
        `
    })
    export class TosCheckModal implements ModalComponent<TosModalContext>
    {
        contentdata:any;
        versionnumber:number;
        context: TosModalContext;

        constructor(
            public dialog:DialogRef<TosModalContext>, 
            public ctx:MaxAppContext, 
            private _modal:Modal,
            private _router:Router,
            private _accounts:UserAccountService
            )
        {

            this.contentdata=this.dialog.context.data.body;
            this.versionnumber=this.dialog.context.data.versionnumberget;
        }
        private saveToseVersion()
        {   
            var versiondata = { version: this.versionnumber }; 
            this._accounts.updattosversion(versiondata).single().toPromise().then(d=>{
                this.dialog.close(false);
                localStorage["tosPopupData"] = JSON.stringify({isShow: false, version: this.versionnumber});
            });
            
        }
        private onCancel()
        {   this.dialog.close(false);    
            this.ctx.logout();
            
        }

        
    }