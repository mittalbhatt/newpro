// Works around issue where Chrome on iOS (and reportedly Safari in some cases)
// does not raise the input event after an auto-complete option has been selected.
// Watch this issue: https://github.com/angular/angular/issues/12395
// I believe if that is resolved we may be able to remove this.
System.register(["@angular/core", "@angular/router", "underscore"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, router_1, _;
    var AutoCompleteWorkaround;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (_1) {
                _ = _1;
            }],
        execute: function() {
            AutoCompleteWorkaround = (function () {
                function AutoCompleteWorkaround(_router) {
                    this._router = _router;
                }
                AutoCompleteWorkaround.prototype.install = function (rootElement) {
                    var _this = this;
                    var inputElements = [];
                    this._router.events.subscribe(function (e) {
                        if (e instanceof router_1.NavigationStart) {
                            inputElements.forEach(function (el) { return el.removeEventListener('blur', _this.blurListener); });
                            inputElements.splice(0, inputElements.length);
                        }
                        else if (e instanceof router_1.NavigationEnd) {
                            _this.findByLocalName(rootElement.nativeElement, 'input', inputElements);
                            inputElements.forEach(function (el) { return el.addEventListener('blur', _this.blurListener); });
                        }
                    });
                };
                AutoCompleteWorkaround.prototype.blurListener = function (fe) {
                    var doc = window.document;
                    var event = doc.createEvent("HTMLEvents");
                    event.initEvent("input", true, true);
                    fe.target.dispatchEvent(event);
                };
                AutoCompleteWorkaround.prototype.findByLocalName = function (element, localName, seed) {
                    var _this = this;
                    _.forEach(element.childNodes, function (child) {
                        if (child.localName == localName)
                            seed.push(child);
                        _this.findByLocalName(child, localName, seed);
                    });
                };
                AutoCompleteWorkaround = __decorate([
                    core_1.Injectable(), 
                    __metadata('design:paramtypes', [router_1.Router])
                ], AutoCompleteWorkaround);
                return AutoCompleteWorkaround;
            }());
            exports_1("AutoCompleteWorkaround", AutoCompleteWorkaround);
        }
    }
});
//# sourceMappingURL=autoCompleteWorkaround.js.map