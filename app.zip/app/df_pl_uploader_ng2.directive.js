System.register(["@angular/core", "./df_pl_uploads_ng2"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var __param = (this && this.__param) || function (paramIndex, decorator) {
        return function (target, key) { decorator(target, key, paramIndex); }
    };
    var core_1, df_pl_uploads_ng2_1;
    var DfPlUploadHost;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (df_pl_uploads_ng2_1_1) {
                df_pl_uploads_ng2_1 = df_pl_uploads_ng2_1_1;
            }],
        execute: function() {
            DfPlUploadHost = (function () {
                function DfPlUploadHost(_el, _uploads) {
                    var _this = this;
                    this._el = _el;
                    this._uploads = _uploads;
                    this._fileStatusHandler = function (f, fue) { return _this.fileStatusHandler(f, fue); };
                }
                Object.defineProperty(DfPlUploadHost.prototype, "uploadSettings", {
                    get: function () {
                        return this._uploadSettings;
                    },
                    set: function (value) {
                        this._uploadSettings = value;
                        this.initUploader();
                    },
                    enumerable: true,
                    configurable: true
                });
                DfPlUploadHost.prototype.onDragEnter = function () {
                    this._el.nativeElement.classList.add('dragover');
                };
                DfPlUploadHost.prototype.onDragLeave = function () {
                    this._el.nativeElement.classList.remove('dragover');
                };
                DfPlUploadHost.prototype.onDrop = function () {
                    this._el.nativeElement.classList.remove('dragover');
                };
                DfPlUploadHost.prototype.fileStatusHandler = function (file, fromUploaderEvent) {
                    console.log(file.dfUploadTag, this.uploadSettings.dfUploadTag);
                    //if (file.dfUploadTag === this.uploadSettings.dfUploadTag) {
                    if (this.onUploadStateChanged)
                        this.onUploadStateChanged(file.status, fromUploaderEvent, file.dfResultUrl);
                    //}
                };
                DfPlUploadHost.prototype.ngOnDestroy = function () {
                    this._uploader = null;
                    this._uploads.removeFileStatusHandler(this._fileStatusHandler);
                };
                DfPlUploadHost.prototype.ngOnInit = function () {
                    this.initUploader();
                };
                DfPlUploadHost.prototype.initUploader = function () {
                    if (!this._uploader && this.uploadSettings) {
                        this._uploads.addFileStatusHandler(this._fileStatusHandler);
                        var uploadSettings = _.extend({}, this.uploadSettings);
                        uploadSettings.uploaderSettings = _.extend({}, uploadSettings.uploaderSettings);
                        uploadSettings.uploaderSettings.url = 'http://dragonflyathletics.com'; // temporary url.  Plupload requires some url to init.
                        uploadSettings.uploaderSettings.drop_element = this._el.nativeElement; //element.context;
                        uploadSettings.uploaderSettings.browse_button = this._el.nativeElement; //element.context;
                        this._uploader = this._uploads.createUploader(uploadSettings);
                        this._uploader.init();
                    }
                };
                __decorate([
                    core_1.Input('uploadSettings'), 
                    __metadata('design:type', Object), 
                    __metadata('design:paramtypes', [Object])
                ], DfPlUploadHost.prototype, "uploadSettings", null);
                __decorate([
                    core_1.Input('uploadStateChanged'), 
                    __metadata('design:type', Function)
                ], DfPlUploadHost.prototype, "onUploadStateChanged", void 0);
                __decorate([
                    core_1.Input('targetTooltip'), 
                    __metadata('design:type', String)
                ], DfPlUploadHost.prototype, "targetTooltip", void 0);
                __decorate([
                    core_1.HostListener('dragenter'), 
                    __metadata('design:type', Function), 
                    __metadata('design:paramtypes', []), 
                    __metadata('design:returntype', void 0)
                ], DfPlUploadHost.prototype, "onDragEnter", null);
                __decorate([
                    core_1.HostListener('dragleave'), 
                    __metadata('design:type', Function), 
                    __metadata('design:paramtypes', []), 
                    __metadata('design:returntype', void 0)
                ], DfPlUploadHost.prototype, "onDragLeave", null);
                __decorate([
                    core_1.HostListener('drop'), 
                    __metadata('design:type', Function), 
                    __metadata('design:paramtypes', []), 
                    __metadata('design:returntype', void 0)
                ], DfPlUploadHost.prototype, "onDrop", null);
                DfPlUploadHost = __decorate([
                    core_1.Directive({
                        selector: '[df-pl-upload-host]'
                    }),
                    __param(1, core_1.Inject(df_pl_uploads_ng2_1.DfPlUploads2)), 
                    __metadata('design:paramtypes', [core_1.ElementRef, df_pl_uploads_ng2_1.DfPlUploads2])
                ], DfPlUploadHost);
                return DfPlUploadHost;
            }());
            exports_1("DfPlUploadHost", DfPlUploadHost);
        }
    }
});
//# sourceMappingURL=df_pl_uploader_ng2.directive.js.map