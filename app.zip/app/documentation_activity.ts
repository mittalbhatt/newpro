import {Activity} from "./assignments.service";

export interface DocumentationDocDescriptionReference {
    name:string;
    activityId:string;
    required:boolean;
    staffOnly:boolean;
    completedDate:Date
    instanceExists:boolean;
}

export interface DocumentationEventDescription {
    coordinatorName:string;
    eventName:string;
    documents:DocumentationDocDescriptionReference[];
}

export interface DocumentationActivity extends Activity {
    _id: string;
    orgId:string;
    documentationEventDescription: DocumentationEventDescription
}