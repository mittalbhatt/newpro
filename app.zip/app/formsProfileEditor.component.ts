import {Component, OnInit} from "@angular/core";
import {ActivatedRoute} from "@angular/router";
import {SportCode} from "./sportCodes";
import {UserProfiles, UserProfile} from "./user_profiles.service";

@Component({
    selector:'forms-profile-editor',
    template:
        `
<div *ngIf="!profile" class="alert alert-success">Loading...</div>
<div *ngIf="errorMessage" style="max-width:400px; margin:auto;" class="alert alert-danger">{{errorMessage}}</div>
<h3>Edit profile:</h3>
<div style="max-width:500px; margin:auto;">
    <form>
        <div class="form-group">
            <label for="username">First Name</label>
            <input [(ngModel)]="firstName" type="text" class="form-control" id="firstName" name="firstName" placeholder="First Name" required>
          </div>
          
          <div class="form-group">
            <label for="username">Last Name</label>
            <input [(ngModel)]="lastName" type="text" class="form-control" id="lastName" name="lastName" placeholder="Last Name" required>
          </div>
    </form>
    <label>Sports</label>
    <default-sport-chooser *ngIf="!profile?.tags?.length" [initialSelectedSportCodes]="profile?.pendingSports" (sportsSelected)="onSelectedSportsChange($event)"></default-sport-chooser>
    <p *ngIf="profile?.tags?.length"><em>Your profile has been approved - you can no longer edit your sports.</em></p>
    <div style="height:100px;">
        <button style="float:right;" class="btn btn-default" [disabled]="saving" (click)="onSave()">Save</button>
        <button style="float:right; margin-right:10px;" class="btn btn-danger" [disabled]="saving" (click)="onCancel()">Cancel</button>
    </div>
</div>
`
})
export class FormsProfileEditor implements OnInit
{
    errorMessage:string;
    saving:boolean;
    profileId:string;

    selectedSports:SportCode[];

    lastName:string;
    firstName:string;
    profile:UserProfile;

    constructor(
        route:ActivatedRoute,
        private _userProfiles:UserProfiles
    )
    {
        this.profileId = route.snapshot.params['profileId'];
    }

    ngOnInit()
    {
        this._userProfiles.getProfile(this.profileId).single().toPromise()
            .then(profile =>
            {
                this.profile = profile;
                this.lastName = profile.lastName;
                this.firstName = profile.firstName;
            })
            .catch(e =>
            {
                this.errorMessage = 'We encountered an unexpected error.  Try refreshing.';
                throw e;
            })
    }

    onSelectedSportsChange(value)
    {
        this.selectedSports = value;
    }

    onSave()
    {
        if (!this.firstName || !this.lastName)
        {
            this.errorMessage = 'All fields are required.';
            window.scrollTo(0,0);
            return;
        }

        this.saving = true;

        this._userProfiles.updateProfile(this.profileId,
            {
                $set:
                {
                    firstName:this.firstName,
                    sortFirstName:(this.firstName || '').toLowerCase(),
                    lastName:this.lastName,
                    sortLastName:(this.lastName || '').toLowerCase(),
                    pendingSports:(this.selectedSports || []).map(so => so.code)
                }
            }).single().toPromise()
            .then(() =>
            {
                this.saving = false;
                window.history.back();
            })
            .catch(e =>
            {
                this.saving = false;
                this.errorMessage = 'An unexpected error has occurred.';
                throw e;
            });
    }

    onCancel()
    {
        window.history.back();
    }
}