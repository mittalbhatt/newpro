System.register(["@angular/core", "@angular/router", "./maxAppContext.service", "./organizations.service", "./assignments.service", "./packet-form-modal.component", "./assign-form-model.component", 'angular2-modal/plugins/bootstrap', 'angular2-modal', "./team-packet-creation-modal.component", "./DfObjectId", './document_loader.service', './shared.service', 'ngx-swiper-wrapper'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, router_1, maxAppContext_service_1, organizations_service_1, assignments_service_1, packet_form_modal_component_1, assign_form_model_component_1, bootstrap_1, angular2_modal_1, team_packet_creation_modal_component_1, DfObjectId_1, document_loader_service_1, shared_service_1, ngx_swiper_wrapper_1;
    var PacketForm, TeamsFormComponent;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (maxAppContext_service_1_1) {
                maxAppContext_service_1 = maxAppContext_service_1_1;
            },
            function (organizations_service_1_1) {
                organizations_service_1 = organizations_service_1_1;
            },
            function (assignments_service_1_1) {
                assignments_service_1 = assignments_service_1_1;
            },
            function (packet_form_modal_component_1_1) {
                packet_form_modal_component_1 = packet_form_modal_component_1_1;
            },
            function (assign_form_model_component_1_1) {
                assign_form_model_component_1 = assign_form_model_component_1_1;
            },
            function (bootstrap_1_1) {
                bootstrap_1 = bootstrap_1_1;
            },
            function (angular2_modal_1_1) {
                angular2_modal_1 = angular2_modal_1_1;
            },
            function (team_packet_creation_modal_component_1_1) {
                team_packet_creation_modal_component_1 = team_packet_creation_modal_component_1_1;
            },
            function (DfObjectId_1_1) {
                DfObjectId_1 = DfObjectId_1_1;
            },
            function (document_loader_service_1_1) {
                document_loader_service_1 = document_loader_service_1_1;
            },
            function (shared_service_1_1) {
                shared_service_1 = shared_service_1_1;
            },
            function (ngx_swiper_wrapper_1_1) {
                ngx_swiper_wrapper_1 = ngx_swiper_wrapper_1_1;
            }],
        execute: function() {
            // import { _ as _l } from "lodash";
            // import * as _l from "lodash";
            PacketForm = (function () {
                function PacketForm(data) {
                    //replacesAssignmentId: string;
                    this.category = 'Documentation';
                    this.startDate = new Date();
                    this.assignees = [];
                    for (var k in data) {
                        this[k] = data[k];
                    }
                }
                return PacketForm;
            }());
            exports_1("PacketForm", PacketForm);
            TeamsFormComponent = (function () {
                // @Output() unsavedData = new EventEmitter();
                function TeamsFormComponent(_assignmentsSvc, _organizations, element, router, _modal, _docLoader, _shared, _ctx) {
                    var _this = this;
                    this._assignmentsSvc = _assignmentsSvc;
                    this._organizations = _organizations;
                    this.element = element;
                    this.router = router;
                    this._modal = _modal;
                    this._docLoader = _docLoader;
                    this._shared = _shared;
                    this._ctx = _ctx;
                    this.packetdatalist = true;
                    this.packetformDataList = [];
                    this.selectedRow = null;
                    this.selectedPacket = null;
                    this.unsavedPacket = null;
                    this.isSavingData = false;
                    this.isLoadingPacket = false;
                    this.assignedToString = "None";
                    this.arrowupactive = true;
                    this.arrowdownactive = true;
                    this.isAssigneesAvailable = false;
                    this.isAssigneesChange = false;
                    this.onremoveform = false;
                    this.type = 'directive';
                    this.config = {
                        //loop: false,
                        nextButton: '.swiper-button-next',
                        prevButton: '.swiper-button-prev',
                        direction: 'horizontal',
                        slideToClickedSlide: true,
                        width: 990,
                        height: 500,
                        autoHeight: true,
                        slidesPerView: 6,
                        onInit: function (swiper) {
                            swiper.slideTo(2, 1, true);
                        },
                        onSlideChangeStart: function (swiper) {
                            if (swiper.activeIndex == swiper.slides.length) {
                                swiper.nextButton.addClass(swiper.params.buttonDisabledClass);
                            }
                            if (swiper.activeIndex == 2) {
                                swiper.prevButton.addClass(swiper.params.buttonDisabledClass);
                            }
                        },
                        onSlideChangeEnd: function (swiper) {
                            if (swiper.activeIndex == (swiper.slides.length - 2)) {
                                swiper.nextButton.addClass(swiper.params.buttonDisabledClass);
                            }
                            if (swiper.activeIndex == 2) {
                                swiper.prevButton.addClass(swiper.params.buttonDisabledClass);
                            }
                        },
                        freeMode: true,
                        threshold: 0,
                        spaceBetween: 0,
                        breakpoints: {
                            1024: {
                                slidesPerView: 4,
                                spaceBetween: 10
                            },
                            768: {
                                slidesPerView: 4,
                                spaceBetween: 10
                            },
                            640: {
                                slidesPerView: 3,
                                spaceBetween: 10
                            },
                            425: {
                                slidesPerView: 2,
                                spaceBetween: 10
                            }
                        },
                        observer: true
                    };
                    // console.log(this.selectedPacket);
                    // For get all popup data (Assign people, add form, add packet name)
                    this.popupDataSubscribe = this._assignmentsSvc.getPopupData.subscribe(function (res) {
                        if (res.type == "form") {
                            _this.manageUnsavedPacket(res.data, "form");
                        }
                        else if (res.type == "assignees") {
                            _this.manageUnsavedPacket(res.data, "assignees");
                        }
                        else if (res.type == "packet") {
                            _this.packetName = res.data;
                            if (res.isNew !== undefined && res.isNew === true) {
                                _this.resetChanges();
                            }
                            _this.manageUnsavedPacket(res.data, "packet");
                        }
                        else if (res.type == "print") {
                            _this.onPrint(res.data, _this.selectedPacket);
                        }
                    });
                    // For get organization data on change dropdown or route
                    this.orgStructureSubscribe = this._organizations.orgStructureData.subscribe(function (res) {
                        _this.currentOrgData = res;
                        if (_this.currentOrgData.data !== null && _this.currentOrgData.org !== "Everyone") {
                            _this.refresh();
                        }
                    });
                }
                TeamsFormComponent.prototype.ngOnInit = function () {
                };
                TeamsFormComponent.prototype.ngOnDestroy = function () {
                    this.orgStructureSubscribe.unsubscribe();
                    this.popupDataSubscribe.unsubscribe();
                };
                //use for packet list data
                TeamsFormComponent.prototype.refresh = function () {
                    var _this = this;
                    this.resetChanges();
                    this.isLoadingPacket = true;
                    this.isAssigneesChange = false;
                    this.isAssigneesAvailable = false;
                    if (this.documentationAssignmentsPromise) {
                        this.documentationAssignmentsPromise.unsubscribe();
                    }
                    this.documentationAssignmentsPromise = this._assignmentsSvc.getUserPacketList('Documentation', 0, 1000).subscribe(function (data) {
                        // console.log(data);
                        var groupeotherdDocsnew = _.filter(data, function (d) {
                            if (d.activities[0].orgId == _this.currentOrgData.org) {
                                return d;
                            }
                        });
                        groupeotherdDocsnew = _.sortBy(groupeotherdDocsnew, function (o) {
                            return -(new Date(o.lastModifiedDate).getTime());
                        });
                        if (groupeotherdDocsnew[0] !== undefined && groupeotherdDocsnew[0] !== null && groupeotherdDocsnew.length > 0) {
                            if (sessionStorage['currentPacket'] !== "undefined" && sessionStorage['currentPacket'] !== undefined && sessionStorage['currentPacket'] !== null && sessionStorage['currentPacket'] !== "") {
                                var i_1 = 0;
                                var j_1 = 1;
                                var selectedPack = _.filter(groupeotherdDocsnew, function (d) {
                                    i_1++;
                                    if (d._id == sessionStorage['currentPacket']) {
                                        j_1 = i_1;
                                        return d;
                                    }
                                });
                                if (selectedPack[0] !== undefined && selectedPack[0] !== null) {
                                    _this.onClickFormsAssignment(selectedPack[0]);
                                }
                                else {
                                    _this.onClickFormsAssignment(groupeotherdDocsnew[0]);
                                }
                                _this.config.initialSlide = j_1;
                            }
                            else {
                                _this.onClickFormsAssignment(groupeotherdDocsnew[0]);
                            }
                        }
                        _this.documentationAssignments = groupeotherdDocsnew;
                        // console.log(this.documentationAssignments);
                    }, function (e) {
                        _this.errorMessage = 'We encountered an unexpected error.  Try refreshing the page.';
                        throw e;
                    }, function () {
                        _this.isLoadingPacket = false;
                    });
                };
                // Using for display assignees string
                TeamsFormComponent.prototype.displayAssignees = function () {
                    var _this = this;
                    this.assignedToString = "None";
                    if (this.selectedPacket !== undefined &&
                        this.selectedPacket !== null &&
                        this.selectedPacket.assignees !== undefined &&
                        this.selectedPacket.assignees !== null &&
                        this.selectedPacket.assignees.length > 0) {
                        var teamArr_1 = _.groupBy(this.selectedPacket.assignees, function (o) {
                            return o.role;
                        });
                        if (teamArr_1['ATH'] !== undefined && teamArr_1['ATH'].length > 0) {
                            var role_1 = "";
                            role_1 = "Athletes";
                            if (teamArr_1['CCH'] !== undefined && teamArr_1['CCH'].length > 0) {
                                role_1 = "Athletes and Coaches";
                            }
                            var i_2 = 0;
                            var teams_1 = "";
                            _.each(teamArr_1['ATH'], function (o) {
                                i_2++;
                                if (o.tag == undefined) {
                                    teams_1 = "All sports";
                                }
                                else {
                                    var sportArr = _.find(_this.currentOrgData.data.teams, function (s) {
                                        return s.team.code == o.tag;
                                    });
                                    var sport = sportArr.team.name;
                                    var level = (sportArr.team.level == undefined) ? "" : sportArr.team.level;
                                    if (teams_1 == "") {
                                        teams_1 = level + " " + sport;
                                    }
                                    else {
                                        teams_1 += ", " + level + " " + sport;
                                    }
                                }
                                if (i_2 == teamArr_1['ATH'].length) {
                                    _this.assignedToString = role_1 + " in " + teams_1;
                                }
                            });
                        }
                        else if (teamArr_1['CCH'] !== undefined && teamArr_1['CCH'].length > 0) {
                            var role_2 = "";
                            role_2 = "Coaches";
                            var i_3 = 0;
                            var teams_2 = "";
                            _.each(teamArr_1['CCH'], function (o) {
                                i_3++;
                                if (o.tag == undefined) {
                                    teams_2 = "All sports";
                                }
                                else {
                                    var sportArr = _.find(_this.currentOrgData.data.teams, function (s) {
                                        return s.team.code == o.tag;
                                    });
                                    var sport = sportArr.team.name;
                                    var level = (sportArr.team.level == undefined) ? "" : sportArr.team.level;
                                    if (teams_2 == "") {
                                        teams_2 = level + " " + sport;
                                    }
                                    else {
                                        teams_2 += ", " + level + " " + sport;
                                    }
                                }
                                if (i_3 == teamArr_1['CCH'].length) {
                                    _this.assignedToString = role_2 + " in " + teams_2;
                                }
                            });
                        }
                    }
                };
                // If any changes in packet then call this function
                TeamsFormComponent.prototype.manageUnsavedPacket = function (data, type) {
                    var _this = this;
                    this.rolesdataarray = _.find(this._ctx.myProfiles, function (d) {
                        if (d._id == _this._ctx.currentProfile._id) {
                            return d;
                        }
                    });
                    if (this.unsavedPacket === null) {
                        var profileId = (new DfObjectId_1.DfObjectId()).toString();
                        if (this.assignmentDataById !== undefined && this.assignmentDataById._id !== undefined) {
                            this.replaceId = this.assignmentDataById._id; // old assignment id
                        }
                        else {
                            this.replaceId = this.assignmentId;
                        }
                        var packetdata = {};
                        if (this.assignmentId !== null && this.assignmentId !== undefined) {
                            // packetdata = this.selectedPacket;
                            var documents = [];
                            if (type == "form") {
                                documents = data;
                            }
                            else if (type == "form-modify") {
                                documents = this.packetformDataList;
                            }
                            else if (this.selectedPacket.activities[0].documentationEventDescription.documents !== undefined) {
                                documents = this.selectedPacket.activities[0].documentationEventDescription.documents;
                            }
                            var assignees = [];
                            if (type == "assignees") {
                                assignees = data;
                            }
                            else if (this.selectedPacket.assignees !== undefined) {
                                assignees = this.selectedPacket.assignees;
                            }
                            packetdata = {
                                _id: profileId,
                                replacesAssignmentId: this.replaceId,
                                assignmentStableId: this.selectedPacket.assignmentStableId,
                                category: 'Documentation',
                                startDate: new Date(),
                                audienceInclusions: [{
                                        roles: [
                                            "OADM",
                                            "OTRN",
                                        ],
                                        ofOrg: this.currentOrgData.data.org.orgId,
                                        canEdit: true
                                    }],
                                activities: [{
                                        _id: profileId,
                                        localOnly: true,
                                        documentationEventDescription: {
                                            coordinatorName: this.currentOrgData.data.org.name,
                                            eventName: this.packetName,
                                            documents: documents,
                                            summaryFields: []
                                        },
                                        orgId: this.currentOrgData.data.org.orgId,
                                        type: "Documentation"
                                    }],
                                assignees: assignees
                            };
                            this.packetformDataList = documents;
                        }
                        else {
                            packetdata = {
                                _id: profileId,
                                assignmentStableId: profileId,
                                category: 'Documentation',
                                startDate: new Date(),
                                audienceInclusions: [{
                                        roles: [
                                            "OADM",
                                            "OTRN",
                                        ],
                                        ofOrg: this.currentOrgData.data.org.orgId,
                                        canEdit: true
                                    }],
                                activities: [{
                                        _id: profileId,
                                        localOnly: true,
                                        documentationEventDescription: {
                                            coordinatorName: this.currentOrgData.data.org.name,
                                            eventName: this.packetName,
                                            documents: [],
                                            summaryFields: []
                                        },
                                        orgId: this.currentOrgData.data.org.orgId,
                                        type: "Documentation"
                                    }],
                                assignees: []
                            };
                            this.packetformDataList = [];
                        }
                        this.unsavedPacket = new PacketForm(packetdata);
                    }
                    else {
                        if (type == "packet") {
                            this.unsavedPacket.activities[0].documentationEventDescription.eventName = data;
                        }
                        else if (type == "form") {
                            this.packetformDataList = data;
                        }
                        else if (type == "assignees") {
                            this.unsavedPacket.assignees = data;
                        }
                        else if (type == "form-modify") {
                            this.unsavedPacket.activities[0].documentationEventDescription.documents = this.packetformDataList;
                        }
                    }
                    this.unsavedPacket.activities[0].documentationEventDescription.documents = this.packetformDataList;
                    this.selectedPacket = this.unsavedPacket;
                    // this.unsavedData.emit(this.unsavedPacket);
                    // console.log(this.selectedPacket);
                    // console.log(this.documentationAssignments);
                    this.displayAssignees();
                    this.checkAssigneesPrompt();
                };
                TeamsFormComponent.prototype.checkAssigneesPrompt = function () {
                    var _this = this;
                    this.isAssigneesChange = false;
                    this.isAssigneesAvailable = false;
                    if (this.unsavedPacket !== null) {
                        var selectedPack = _.find(this.documentationAssignments, function (o) {
                            return _this.assignmentId === o._id;
                        });
                        if (selectedPack !== null && selectedPack !== undefined) {
                            if ((selectedPack.assignees !== undefined && selectedPack.assignees.length > 0)
                                &&
                                    (this.unsavedPacket.assignees !== undefined && this.unsavedPacket.assignees.length == 0)) {
                                this.isAssigneesChange = true;
                            }
                        }
                        if (this.unsavedPacket.assignees !== undefined && this.unsavedPacket.assignees.length > 0) {
                            this.isAssigneesAvailable = true;
                        }
                    }
                };
                // Chage form order using drag
                TeamsFormComponent.prototype.dragSuccess = function () {
                    this.manageUnsavedPacket(this.packetformDataList, "form-modify");
                };
                // If you change any packet then lost unsaved packet data
                TeamsFormComponent.prototype.lostDataPrompt = function () {
                    var _this = this;
                    return new Promise(function (resolve, reject) {
                        if (_this.unsavedPacket == null) {
                            resolve(true);
                        }
                        else {
                            _this._modal.confirm()
                                .size('lg').isBlocking(true).showClose(false).keyboard(27)
                                .body("You have unsaved changes to " + _this.unsavedPacket.activities[0].documentationEventDescription.eventName + ".  Do you want to save these changes before you move on?<br><br>If you don't save your changes, they will be lost.")
                                .addButton('btn btn-primary', 'Save changes', function (dialogFooter) {
                                dialogFooter.dialog.dismiss();
                                resolve("save");
                            })
                                .headerClass("hide")
                                .okBtn("Discard Changes").okBtnClass("btn btn-danger")
                                .cancelBtnClass("btn btn-danger")
                                .open().then(function (dialog) {
                                return dialog.result;
                            }).then(function (result) {
                                if (result === true) {
                                    resolve(true);
                                }
                                else {
                                    resolve(false);
                                }
                            }).catch(function (e) {
                                reject(e);
                            }).catch(function (e) {
                                reject(e);
                            });
                        }
                    });
                };
                // Change packet details then call this function
                TeamsFormComponent.prototype.onClickFormsAssignment = function (assignment) {
                    var _this = this;
                    if (assignment === void 0) { assignment = null; }
                    if (assignment !== null && assignment !== undefined)
                        sessionStorage['currentPacket'] = assignment._id;
                    if (this.unsavedPacket !== null) {
                        this.lostDataPrompt().then(function (res) {
                            if (res == "save") {
                                _this.checkBeforeSave().then(function (res) {
                                    if (res == true) {
                                        _this.savedata();
                                        _this.changePacket(assignment);
                                    }
                                });
                            }
                            else {
                                _this.resetChanges();
                                _this.refresh();
                                _this.changePacket(assignment);
                            }
                        }).catch(function (e) {
                            // this.onCancel();
                        });
                    }
                    else {
                        this.changePacket(assignment);
                    }
                };
                TeamsFormComponent.prototype.resetChanges = function () {
                    this.selectedRow = null;
                    this.arrowupactive = true;
                    this.arrowdownactive = true;
                    this.unsavedPacket = null;
                    this.assignmentId = null;
                    this.selectedPacket = null;
                    this.assignedToString = "None";
                    this.selectedPacket = null;
                    // this.unsavedData.emit(this.unsavedPacket);
                };
                TeamsFormComponent.prototype.changePacket = function (assignment) {
                    if (assignment === void 0) { assignment = null; }
                    if (assignment !== null) {
                        this.resetChanges();
                        this.selectedPacket = assignment;
                    }
                    if (assignment === null) {
                        this.addPacket(null);
                    }
                    else {
                        this.assignmentId = this.selectedPacket._id;
                        if (this.selectedPacket.activities[0].documentationEventDescription.documents) {
                            this.packetformDataList = Array.apply(this, this.selectedPacket.activities[0].documentationEventDescription.documents);
                        }
                        this.packetName = this.selectedPacket.activities[0].documentationEventDescription.eventName;
                    }
                    this.displayAssignees();
                };
                // Use for assignment add OR edit
                TeamsFormComponent.prototype.checkBeforeSave = function () {
                    var _this = this;
                    return new Promise(function (resolve, reject) {
                        if (_this.isAssigneesChange) {
                            _this.checkAssigneeAvailableOrNot().then(function (data) {
                                resolve(data);
                            }).catch(function (e) {
                                reject(e);
                            });
                        }
                        if (_this.isAssigneesAvailable) {
                            _this.checkAssigneeIfAvailable().then(function (data) {
                                resolve(data);
                            }).catch(function (e) {
                                // console.log(e);
                                reject(e);
                            });
                        }
                        if (_this.isAssigneesChange === false && _this.isAssigneesAvailable === false) {
                            resolve(true);
                        }
                    });
                };
                TeamsFormComponent.prototype.onSaveData = function (is_get_list) {
                    var _this = this;
                    if (is_get_list === void 0) { is_get_list = true; }
                    if (is_get_list == false) {
                        this.savedata(false);
                    }
                    else {
                        this.checkBeforeSave().then(function (res) {
                            if (res) {
                                _this.savedata();
                            }
                        }).catch(function (e) {
                            //   console.log(e);
                        });
                    }
                };
                // Change route then ask unsaved popup
                TeamsFormComponent.prototype.lostCurrentRoute = function () {
                    var _this = this;
                    return new Promise(function (resolve, reject) {
                        if (_this.unsavedPacket !== null) {
                            _this.lostDataPrompt().then(function (res) {
                                if (res == "save") {
                                    _this.checkBeforeSave().then(function (res) {
                                        if (res == true) {
                                            _this.onSaveData(false);
                                            resolve(true);
                                        }
                                    });
                                }
                                else {
                                    resolve(true);
                                }
                            }).catch(function (e) {
                                // this.onCancel();
                                resolve(false);
                                // throw e;
                            });
                        }
                        else {
                            resolve(true);
                        }
                    });
                };
                TeamsFormComponent.prototype.savedata = function (is_get_list) {
                    var _this = this;
                    if (is_get_list === void 0) { is_get_list = true; }
                    this.isSavingData = true;
                    this._assignmentsSvc.createPacket(this.unsavedPacket).single().toPromise().then(function (d) {
                        if (is_get_list) {
                            _this.refresh();
                        }
                        if (d._id !== undefined) {
                            sessionStorage['currentPacket'] = d._id;
                        }
                        else {
                            sessionStorage['currentPacket'] = "";
                        }
                        // this.unsavedPacket = null;
                        // this.unsavedData.emit(this.unsavedPacket);
                        _this.resetChanges();
                        _this.isSavingData = false;
                    }).catch(function (e) {
                        _this.isSavingData = false;
                        _this._modal.alert().message("Some error has been occur while saving the data.").open();
                        console.log(e);
                        throw e;
                    });
                };
                // Befaore save packet availabe and on save packet is not availabe then show this popup
                TeamsFormComponent.prototype.areYouSure = function () {
                    var _this = this;
                    return new Promise(function (resolve, reject) {
                        _this._modal.confirm()
                            .size('sm').isBlocking(true).showClose(false).keyboard(27)
                            .body("Are you sure you want to cancel?")
                            .headerClass("hide")
                            .okBtn("Discard Changes").okBtnClass("btn btn-danger")
                            .cancelBtn("No").cancelBtnClass("btn btn-primary")
                            .open().then(function (dialog) {
                            return dialog.result;
                        }).then(function (result) {
                            if (result === true) {
                                resolve(true);
                            }
                            else {
                                resolve(false);
                            }
                        }).catch(function (e) {
                            resolve(e);
                        }).catch(function (e) {
                            resolve(e);
                        });
                    });
                };
                // Befaore save packet availabe and on save packet is not availabe then show this popup
                TeamsFormComponent.prototype.checkAssigneeAvailableOrNot = function () {
                    var _this = this;
                    return new Promise(function (resolve, reject) {
                        _this._modal.confirm()
                            .size('lg').isBlocking(true).showClose(false).keyboard(27)
                            .body("You have removed everyone from this forms packet.  If you continue, these forms will no longer be assigned to anyone, but any forms that have already been filled out will still be in those athlete's records.<br><br>Are you sure you want to unassign this packet?")
                            .headerClass("hide")
                            .okBtnClass("btn btn-primary")
                            .cancelBtnClass("btn btn-danger")
                            .open().then(function (dialog) {
                            return dialog.result;
                        }).then(function (result) {
                            if (result === true) {
                                resolve(true);
                            }
                            else {
                                resolve(false);
                            }
                        }).catch(function (e) {
                            resolve(e);
                        }).catch(function (e) {
                            resolve(e);
                        });
                    });
                };
                // Befaore save packet availabe and on save packet is not availabe then show this popup
                TeamsFormComponent.prototype.checkAssigneeIfAvailable = function () {
                    var _this = this;
                    return new Promise(function (resolve, reject) {
                        _this._modal.confirm()
                            .size('lg').isBlocking(true).showClose(false).keyboard(27)
                            .body("If you continue, these forms will immediately be assigned to the people and sports you selected.  Are you ready to assign these forms now?<br><br>If you want to save your work but aren't ready to assign it yet, click Cancel, then go clear all the checkboxes in the 'Assigned to' box and click Save again.  You can go pick who to assign the forms to when you're ready to assign it.")
                            .headerClass("hide")
                            .okBtn("Assign These Forms Now").okBtnClass("btn btn-primary")
                            .cancelBtnClass("btn btn-primary")
                            .open().then(function (dialog) {
                            return dialog.result;
                        }).then(function (result) {
                            if (result === true) {
                                resolve(true);
                            }
                            else {
                                resolve(false);
                            }
                        }).catch(function (e) {
                            resolve(e);
                        }).catch(function (e) {
                            resolve(e);
                        });
                    });
                };
                //use for Add OR Update packet popup list data
                TeamsFormComponent.prototype.addPacket = function (assignment) {
                    var _this = this;
                    if (assignment === void 0) { assignment = null; }
                    var packetName = "";
                    if (assignment !== null && assignment !== undefined && assignment.activities[0].documentationEventDescription.eventName !== undefined) {
                        packetName = assignment.activities[0].documentationEventDescription.eventName;
                        if (assignment._id !== this.assignmentId) {
                            this.lostDataPrompt().then(function (res) {
                                if (res == "save") {
                                    _this.checkBeforeSave().then(function (res) {
                                        if (res == true) {
                                            _this.savedata();
                                            _this.changePacket(assignment);
                                        }
                                    });
                                }
                                else {
                                    _this.resetChanges();
                                    _this.changePacket(assignment);
                                    _this.openPacketPopup(packetName);
                                }
                            }).catch(function (e) {
                                // throw e;
                                // this.onCancel();
                            });
                        }
                        else {
                            this.openPacketPopup(packetName);
                        }
                    }
                    else {
                        this.openPacketPopup(packetName);
                    }
                };
                TeamsFormComponent.prototype.openPacketPopup = function (packetName) {
                    var _this = this;
                    if (packetName === void 0) { packetName = null; }
                    // this.assignedToString = "None";
                    var packetId = (new DfObjectId_1.DfObjectId()).toString();
                    var context = new bootstrap_1.BSModalContext();
                    var adminFormPrintModalData = new team_packet_creation_modal_component_1.AssignmentModalContext(packetName);
                    var config = angular2_modal_1.overlayConfigFactory(adminFormPrintModalData, bootstrap_1.BSModalContext);
                    this._modal.open(team_packet_creation_modal_component_1.TeamPacketCreationModalPrompt, config)
                        .then(function (result) { return result.result; })
                        .then(function (result) { }).then(function (result) {
                        if (result) {
                            _this.refresh();
                        }
                    })
                        .catch(function (e) { return console.log(e); });
                };
                TeamsFormComponent.prototype.requiredForms = function () {
                    if (!this.documentDescriptions)
                        return [];
                    return this.documentDescriptions.filter(function (dd) { return dd.required; });
                };
                //use for generate packet pdf data
                TeamsFormComponent.prototype.onPrint = function (activityId, selectedarray) {
                    var _this = this;
                    if (selectedarray.managedByDF == true) {
                    }
                    else {
                        this.printing = true;
                        this.errorMessage = '';
                        if (activityId.length < 1) {
                            this.printing = false;
                            this.errorMessage = 'The selected Form(s) have not filled out any of the selected forms.';
                            return;
                        }
                        this._docLoader.openpacketformsPdf(activityId, window).then(function () {
                            _this.printing = false;
                        }).catch(function (error) {
                            _this.printing = false;
                            console.error(error);
                            _this.errorMessage = 'We encountered an error printing.  Please try again.';
                        });
                    }
                };
                TeamsFormComponent.prototype.onCancel = function () {
                    var _this = this;
                    this.areYouSure().then(function (res) {
                        if (res) {
                            var selectedPack = _.find(_this.documentationAssignments, function (o) {
                                return _this.assignmentId === o._id;
                            });
                            if (selectedPack !== undefined && selectedPack !== null) {
                                _this.changePacket(selectedPack);
                            }
                            else {
                                _this.resetChanges();
                                if (_this.documentationAssignments !== undefined && _this.documentationAssignments !== null) {
                                    _this.changePacket(_this.documentationAssignments[0]);
                                }
                            }
                        }
                        else {
                        }
                    }).catch(function (e) {
                        console.log(e);
                    });
                };
                //use for Assignment delete  data
                TeamsFormComponent.prototype.onRemoveForm = function (i, name) {
                    var _this = this;
                    this._modal.confirm()
                        .size('lg')
                        .isBlocking(true)
                        .showClose(false)
                        .headerClass("hide")
                        .cancelBtnClass("btn btn-primary")
                        .keyboard(27)
                        .body("Do you want to remove " + name + " from " + this.packetName + "?")
                        .bodyClass('modal-body text-left')
                        .okBtn("Remove " + name).okBtnClass("btn btn-danger okbutton")
                        .open()
                        .then(function (res) {
                        res.result.then(function (r) {
                            if (r === true) {
                                if (_this.packetformDataList.length > 0) {
                                    var filtered2 = _.reject(_this.packetformDataList, function (arrItem) {
                                        return arrItem.name === name;
                                    });
                                    _this.packetformDataList = filtered2;
                                }
                                _this.manageUnsavedPacket(_this.packetformDataList, "form-modify");
                            }
                        })
                            .catch(function (e) {
                            if (e)
                                throw e;
                        });
                    });
                };
                TeamsFormComponent.prototype.onRemoveOnlyDisplayMessage = function () {
                    var _this = this;
                    this.onremoveform = true;
                    this._modal.alert().message("This form cannot be deleted.").open().then(function (res) {
                        res.result.then(function (r) {
                            if (r === true) {
                                _this.onremoveform = false;
                            }
                        });
                    });
                };
                TeamsFormComponent.prototype.setClickedRow = function (index, managedByDF) {
                    if (managedByDF == true && this.onremoveform == false) {
                        this._modal.alert().message("This form cannot be changed.").open();
                    }
                    else {
                        this.arrowdownactive = false;
                        this.arrowupactive = false;
                        this.selectedRow = index;
                        if (this.selectedRow <= 0) {
                            this.arrowupactive = true;
                            this.arrowdownactive = false;
                        }
                        if (this.selectedRow == (Object.keys(this.packetformDataList).length) - 1) {
                            this.arrowdownactive = true;
                            this.arrowupactive = false;
                        }
                    }
                };
                // Move up form for using this function
                TeamsFormComponent.prototype.moveUp = function (num, managedByDF) {
                    //  console.log(this.selectedRow);
                    if (managedByDF == true) {
                        this._modal.alert().message("This form cannot be changed.").open();
                    }
                    else {
                        if (this.selectedRow == 1 || this.selectedRow <= 0) {
                            this.arrowupactive = true;
                            this.arrowdownactive = false;
                        }
                        if (num !== null && num > 0) {
                            if (this.selectedRow == 1 || this.selectedRow <= 0) {
                                this.arrowupactive = true;
                            }
                            else {
                                this.arrowupactive = false;
                                this.arrowdownactive = false;
                            }
                            var tmp = this.packetformDataList[num - 1];
                            this.packetformDataList[num - 1] = this.packetformDataList[num];
                            this.packetformDataList[num] = tmp;
                            this.selectedRow--;
                            this.manageUnsavedPacket(this.packetformDataList, "form-modify");
                        }
                    }
                };
                // Move down form for using this function
                TeamsFormComponent.prototype.moveDown = function (num, managedByDF) {
                    if (managedByDF == true) {
                        this._modal.alert().message("This form cannot be changed.").open();
                    }
                    else {
                        if (num !== null && num < (Object.keys(this.packetformDataList).length) - 1) {
                            var tmp = this.packetformDataList[num + 1];
                            this.packetformDataList[num + 1] = this.packetformDataList[num];
                            this.packetformDataList[num] = tmp;
                            this.selectedRow++;
                            this.arrowupactive = false;
                            this.manageUnsavedPacket(this.packetformDataList, "form-modify");
                        }
                        if (this.selectedRow == (Object.keys(this.packetformDataList).length) - 1) {
                            this.arrowdownactive = true;
                        }
                        else {
                            this.arrowdownactive = false;
                        }
                    }
                };
                //
                TeamsFormComponent.prototype.droppedPerson = function (event) {
                    this.droppedValue = event.dragData;
                };
                // Open popup for add form
                TeamsFormComponent.prototype.getActivities = function (managedByDF) {
                    if (managedByDF == true) {
                        this._modal.alert().message("This packet cannot be modified.").open();
                    }
                    else {
                        var adminFormPrintModalData = new packet_form_modal_component_1.CustomModalContext({ data: this.selectedPacket.activities[0].documentationEventDescription.documents, org: this.currentOrgData });
                        var config = angular2_modal_1.overlayConfigFactory(adminFormPrintModalData, bootstrap_1.BSModalContext);
                        this._modal.open(packet_form_modal_component_1.PacketFormModal, config).then(function (result) {
                        })
                            .catch(function (e) { return console.log(e); });
                    }
                };
                // Open popup for add assignees
                TeamsFormComponent.prototype.formAssigns = function () {
                    var customModalData = new assign_form_model_component_1.AssignFormModalContext({ currentOrgData: this.currentOrgData, selectedPacket: this.selectedPacket.assignees });
                    var config = angular2_modal_1.overlayConfigFactory(customModalData, bootstrap_1.BSModalContext);
                    this._modal.open(assign_form_model_component_1.AssignFormModal, config).then(function (result) {
                    })
                        .catch(function (e) { return console.log(e); });
                };
                // For remove package
                TeamsFormComponent.prototype.removeAssignment = function (assignmentId, name) {
                    var _this = this;
                    this.lostDataPrompt().then(function (res) {
                        if (res === "save") {
                            _this.onSaveData();
                        }
                        else if (res === true) {
                            _this._modal.confirm()
                                .size('lg').isBlocking(true).showClose(false).keyboard(27)
                                .body("Do you want to delete " + name + "?<br><br>Afterward, it will no longer be assigned to anyone, but any forms that have already been filled out will still be in MAX.")
                                .headerClass("hide")
                                .okBtn("Remove").okBtnClass("btn btn-danger")
                                .cancelBtnClass("btn btn-primary")
                                .open().then(function (dialog) {
                                return dialog.result;
                            }).then(function (result) {
                                if (result === true) {
                                    // Delete code
                                    _this._assignmentsSvc.deleteAssigement(assignmentId).subscribe(function () {
                                        _this.refresh();
                                    }, function (e) {
                                        _this.errorMessage = 'We encountered an error deleting packet ';
                                        throw e;
                                    });
                                }
                            }).catch(function (e) {
                            }).catch(function (e) {
                            });
                        }
                    }).catch(function (e) {
                        console.log(e);
                    });
                };
                TeamsFormComponent.prototype.removeAssignmentOnlyDisplayMessage = function () {
                    this._modal.alert().message("This packet cannot be deleted.").open();
                };
                TeamsFormComponent.prototype.editAssignmentOnlyDisplayMessage = function () {
                    this._modal.alert().message("This packet cannot be edited.").open();
                };
                TeamsFormComponent.prototype.formAssignsdisable = function () {
                    this._modal.alert().message("This packet cannot be Assign.").open();
                };
                TeamsFormComponent.prototype.disableunAssignsEveryone = function () {
                    this._modal.alert().message("This packet cannot be unassign for Everyone.").open();
                };
                //use for crousal setting
                TeamsFormComponent.prototype.toggleType = function () {
                    this.type = this.type == 'component' ? 'directive' : 'component';
                };
                TeamsFormComponent.prototype.onReachEnd = function (event) {
                    // console.log('Swiper at the end!');
                };
                TeamsFormComponent.prototype.onIndexChange = function (index) {
                    // console.log('Swiper index: ' + index);
                };
                TeamsFormComponent.prototype.unAssignsEveryone = function () {
                    this.manageUnsavedPacket([], "assignees");
                };
                __decorate([
                    core_1.ViewChild(ngx_swiper_wrapper_1.SwiperComponent), 
                    __metadata('design:type', ngx_swiper_wrapper_1.SwiperComponent)
                ], TeamsFormComponent.prototype, "swiperView", void 0);
                TeamsFormComponent = __decorate([
                    core_1.Component({
                        selector: 'teams-form',
                        templateUrl: '/maxweb/app/app/teams-form.component.html',
                    }), 
                    __metadata('design:paramtypes', [assignments_service_1.Assignments, organizations_service_1.Organizations, core_1.ElementRef, router_1.Router, bootstrap_1.Modal, document_loader_service_1.DocumentLoader, shared_service_1.SharedService, maxAppContext_service_1.MaxAppContext])
                ], TeamsFormComponent);
                return TeamsFormComponent;
            }());
            exports_1("TeamsFormComponent", TeamsFormComponent);
        }
    }
});
//# sourceMappingURL=teams-form.component.js.map