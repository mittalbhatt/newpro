System.register(["@angular/core", "@angular/router", "./maxAppContext.service", "./site-search.service", "./organizations.service"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, router_1, maxAppContext_service_1, site_search_service_1, organizations_service_1;
    var TeamOrganizationBoxComponent;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (maxAppContext_service_1_1) {
                maxAppContext_service_1 = maxAppContext_service_1_1;
            },
            function (site_search_service_1_1) {
                site_search_service_1 = site_search_service_1_1;
            },
            function (organizations_service_1_1) {
                organizations_service_1 = organizations_service_1_1;
            }],
        execute: function() {
            TeamOrganizationBoxComponent = (function () {
                function TeamOrganizationBoxComponent(_router, _ctx) {
                    this._router = _router;
                    this._ctx = _ctx;
                }
                Object.defineProperty(TeamOrganizationBoxComponent.prototype, "teamOrganization", {
                    set: function (data) {
                        this.teamOrganizationData = data;
                        if (data._type == "listValues_teamInfo") {
                            this.orgData = this.getOrganizationDetails(data._source.orgId);
                        }
                        else if (data._type == "organizations") {
                            this.orgData = this.getOrganizationDetails(data._id);
                        }
                    },
                    enumerable: true,
                    configurable: true
                });
                TeamOrganizationBoxComponent.prototype.getOrganizationDetails = function (orgId) {
                    if (orgId) {
                        //return this._ctx.availableOrganizations.find(o => o._id == orgId);
                        var org = this._ctx.availableOrganizations.find(function (o) { return o._id == orgId; });
                        if (!org) {
                            org = new organizations_service_1.Organization();
                        }
                        return org;
                    }
                };
                __decorate([
                    core_1.Input('teamOrganization'), 
                    __metadata('design:type', site_search_service_1.SiteSearch), 
                    __metadata('design:paramtypes', [site_search_service_1.SiteSearch])
                ], TeamOrganizationBoxComponent.prototype, "teamOrganization", null);
                TeamOrganizationBoxComponent = __decorate([
                    core_1.Component({
                        selector: 'teams-organization-box',
                        template: "\n        <div style=\"cursor: pointer\" class=\"school-result\" *ngIf=\"teamOrganizationData._type=='organizations'\">\n            <h3> {{ teamOrganizationData?._source?.name }} </h3>\n            <p> <span *ngIf=\"orgData?.city\">{{orgData?.city}},</span> <span *ngIf=\"orgData?.stateCode\">{{orgData?.stateCode}} - </span> <span *ngIf=\"orgData?.shortCode\">{{orgData?.shortCode}}</span></p>\n        </div>\n        \n        <div style=\"cursor: pointer\" class=\"school-result\" *ngIf=\"teamOrganizationData._type=='listValues_teamInfo'\">\n            <h3> {{ teamOrganizationData?._source?.value?.name }} <span>{{ teamOrganizationData?._source?.value?.level }}</span></h3>\n            <p><span *ngIf=\"orgData?.city\">{{orgData?.city}},</span> <span *ngIf=\"orgData?.stateCode\">{{orgData?.stateCode}} - </span> <span *ngIf=\"orgData?.shortCode\">{{orgData?.shortCode}}</span></p>\n        </div>\n    "
                    }), 
                    __metadata('design:paramtypes', [router_1.Router, maxAppContext_service_1.MaxAppContext])
                ], TeamOrganizationBoxComponent);
                return TeamOrganizationBoxComponent;
            }());
            exports_1("TeamOrganizationBoxComponent", TeamOrganizationBoxComponent);
        }
    }
});
//# sourceMappingURL=team-organization-box.component.js.map