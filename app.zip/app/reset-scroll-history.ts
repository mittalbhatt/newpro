import { Injectable } from '@angular/core';
import {CanActivate, CanDeactivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router, ActivatedRoute, NavigationEnd, NavigationStart, RoutesRecognized} from "@angular/router";

@Injectable()
export class ResetScrollHistory implements CanActivate {

  constructor(
    private _router: Router
  ){  }
  
  canActivate() {
   
    let prevUrl:string = this._router.url;
    var urlSplitted = prevUrl.split("/");
    if(urlSplitted.length > 0){
        if(urlSplitted[1] !== "player" && urlSplitted[2] !== "player"){
            console.log("Reset");
            sessionStorage['numberOfRecords'] = null;
            sessionStorage['bodyScrollTop'] = 0;
            sessionStorage['roleview']=null;
            sessionStorage['sortview']=null;
            sessionStorage['filterview']=null;
            sessionStorage['sortorderview']=null;
           // sessionStorage['cardview']="Cards";
          
        }else{
          
        }
    }
    return true;
  }
}