import {Component, OnInit, Input} from '@angular/core';
import {DocumentationActivity, DocumentationDocDescriptionReference} from './documentation_activity';
import {Assignments} from "./assignments.service";
import {UserProfiles, UserProfile} from "./user_profiles.service";
import {Documents} from "./document_factory.service";
import {Router, ActivatedRoute} from "@angular/router";
import {DocumentLoader} from "./document_loader.service";
import {Subscription} from "rxjs";
import {IntercomRouterTracker} from "./intercomRouterTracker.service";

@Component({
    selector: 'ath-doc-dashboard',
    template: `
            
            <div [hidden]="!errorMessage" class="alert alert-danger">{{errorMessage}}</div>
            <div [hidden]="!confirmationCode" class="alert alert-success">
                <div [hidden]="!submittedDuringThisSession">
                    <p>Your {{docAct?.documentationEventDescription?.eventName}} packet is submitted! Confirmation code: <strong>{{confirmationCode}}</strong></p>
                    <p><a href="javascript:void(0)" (click)="printPacket()"><strong>Click here to download a copy.</strong></a> </p>
                    <div style="width:250px; margin: auto; margin-top:10px;" *ngIf="codeRecipientEmails[0]">
                        A message with this code was sent to:
                        <ul style="text-align:left; margin-left:10px; font-weight:bold">
                            <li *ngFor="let email of codeRecipientEmails">{{email}}</li>
                        </ul>
                    </div>
                    
                    <form class="form-inline" style="margin-top:15px" (ngSubmit)="onSubmitEmailCopy()">
                        <p>Enter an email address or mobile # to receive a copy of the confirmation email (optional):</p>
                        <input [(ngModel)]="email" name="email" type="text"/>
                        <button [disabled]="emailingCopy" type="submit" class="btn btn-default"><img *ngIf="emailingCopy" src="/maxweb/app/media/ajax-loader-white.gif" /><span *ngIf="!emailingCopy">Send</span></button>
                    </form>
                </div>
                
                <div [hidden]="submittedDuringThisSession">
                   <p>Your {{docAct?.documentationEventDescription?.eventName}} packet is already submitted.</p>
                   <p><a href="javascript:void(0)" (click)="printPacket()"><strong>Click here to download a copy.</strong></a> </p>
                </div>
                
                <h3>Download the app for the full MAX experience!</h3>
           <get-the-app [columns]="true"></get-the-app>
                
                <div style="margin-top:30px;">
                    <button class="btn btn-primary" [routerLink]="['/main']">Go to home page</button>
                </div>
             </div>
            <div [hidden]="confirmationCode" style="margin:auto; max-width:300px;">
                <h1 *ngIf="showName">{{profile?.firstName}} {{profile?.lastName}}</h1>
                <div *ngIf="requiredForms().length==0 && profile?.firstName!==''" style="font-style:italic"> No forms available</div>
                <div *ngIf="requiredForms().length!==0">
                <p *ngIf="!canSubmit()" style="font-size:18px; font-weight: bold">{{docAct?.documentationEventDescription?.eventName}}</p>
                <p style="font-style:italic">{{completedDocCount()}} of {{requiredDocCount()}} Completed <span *ngIf="canSubmit()"><br />Press <strong>Submit Packet</strong> below.</span></p>
                <div class="progress">
                    <div [ngClass]="{'progress-bar':true, 'progress-bar-success':canSubmit()}" role="progressbar" [style.width]="percentComplete() + '%'" style="min-width:2em">
                        {{percentComplete() | number:'1.0-0' }}%
                    </div>
                </div>
                <div style="margin-top: -12px;padding-bottom: 13px;">
                <button [disabled]="submitting" *ngIf="canSubmit()" (click)="onSubmit()" class="btn btn-default">Submit Packet</button>
                </div>
                <div [hidden]="!!documentDescriptions" class="alert alert-info">Loading...</div>
                <div class="list-group">
                    <a href="javascript:void(0)" (click)="onClickDoc(doc.activityId)" class="list-group-item" *ngFor="let doc of requiredForms()">
                        {{doc.name}}
                        <span *ngIf="doc.completedDate" class="badge" style="background:green"><span class="glyphicon glyphicon-ok"></span></span>
                        <span *ngIf="doc.instanceExists && !doc.completedDate" class="badge" style="background:gold">&nbsp;</span>
                    </a>
                </div>
                
                <div *ngIf="optionalForms().length">
                    <p style="font-size:18px; font-weight: bold">Optional Forms</p>
                    <div class="list-group">
                        <a href="javascript:void(0)" (click)="onClickDoc(doc.activityId)" class="list-group-item" *ngFor="let doc of optionalForms()">
                            {{doc.name}}
                            <span *ngIf="doc.completedDate" class="badge" style="background:green"><span class="glyphicon glyphicon-ok"></span></span>
                            <span *ngIf="doc.instanceExists && !doc.completedDate" class="badge" style="background:gold">&nbsp;</span>
                        </a>
                    </div>
                </div>
                <button [disabled]="submitting" *ngIf="canSubmit()" (click)="onSubmit()" class="btn btn-default">Submit Packet</button>
            </div></div>
    `
})

export class AthDocDashboard implements OnInit {
    docAct: DocumentationActivity;
    documentDescriptions: DocumentationDocDescriptionReference[];
    assignmentId:string;
    profile:UserProfile;
    errorMessage:string;
    submitting:boolean;
    confirmationCode:string;
    codeRecipientEmails:string[];
    emailingCopy:boolean;
    email:string;
    submittedDuringThisSession:boolean;
    showName:boolean;
    _profileId:string=null;

    private _activityId:string;

    constructor(
        private _router:Router,
        private _route:ActivatedRoute,
        private _assignments:Assignments,
        private _userProfiles:UserProfiles,
        private _documents:Documents,
        private _docLoader:DocumentLoader,
        private _intercom:IntercomRouterTracker
    )  {
        this.codeRecipientEmails = [];
    }

    ngOnInit()
    {
        let activityId = this._route.snapshot.params['activityId'];
        if (activityId)
        {
            this.activityId = activityId;
            this.showName = true;
        }
    }

    @Input('activityId') set activityId(value:string)
    {
        this.submittedDuringThisSession = false;

        let profileId = this._route.snapshot.params['profileId'];
        this._profileId = profileId;
        let activityId = value;
        this._activityId = activityId;
        if (!activityId)
            return;

        this._userProfiles.getProfile(profileId).single().toPromise()
            .then(p =>{
               // console.log(p);
                this.profile = p;
            });

        this._assignments.getAssignments(activityId).single().toPromise()
            .then(assignment =>
            {
                if (assignment.activities[0].type == 'Documentation')
                {
                    var act: DocumentationActivity = <DocumentationActivity>assignment.activities[0];
                    this.docAct = act;
                    this.documentDescriptions = act.documentationEventDescription.documents.filter(d => !d.staffOnly);
                    this.assignmentId = assignment._id;
                    this.confirmationCode = this.formatCode(assignment.submissionCode);
                }
                else
                {
                    throw new Error('Unexpected assignment format from the server.');
                }

                return this._documents.getDocumentationDocuments(assignment.assignmentStableId, this._profileId).single().toPromise();
            })
            .then(documents =>
            {
                this.documentDescriptions.forEach(dd =>
                {
                    var doc = documents.filter(d => d.originalDescription._id == dd.activityId)[0];
                    if (doc)
                    {
                        dd.instanceExists = true;
                        dd.completedDate = doc.completedDate;
                    }
                })
            });
    }

    onClickDoc(activityId)
    {
        this._router.navigate(['form', this.profile._id, this._activityId, this.assignmentId, activityId], {relativeTo:this._route.parent});
    }

    canSubmit()
    {
        if (!this.documentDescriptions)
            return false;

        return this.requiredForms().filter(dd => !!dd.completedDate).length == this.requiredDocCount();
    }

    onSubmit()
    {
        this.errorMessage = null;
        this.submitting = true;
        this._assignments.submit(this.assignmentId, this._profileId).single().toPromise()
            .then(res =>
            {
                this.submittedDuringThisSession = true;
                this.confirmationCode = this.formatCode(res.code);
                if (res.emailRecipient)
                    this.codeRecipientEmails.push(res.emailRecipient);

                this._intercom.track('submitted-forms-packet',{packetName:this.docAct.documentationEventDescription.eventName});
            })
            .catch(err =>
            {
                console.error(err);
                this.submitting = false;
                this.errorMessage = 'There was an error submitting your packet.  Please try again.';
            });
    }

    onSubmitEmailCopy()
    {
        var email = this.email;
        if (!email)
            return;

        delete this.email;

        this.errorMessage = null;
        this.emailingCopy = true;

        this._assignments.requestConfirmation(this.assignmentId, this._profileId, email).single().toPromise().then(() => {
            this.codeRecipientEmails.push(email);
            this.emailingCopy = false;
        }).catch(e =>
        {
            console.error(e);
            this.emailingCopy = false;
            this.errorMessage = 'There was an error emailing your confirmation.  Please try again.';
        });
    }

    percentComplete()
    {
        if (!this.documentDescriptions)
            return 0;
        if(100 * this.completedDocCount() / this.requiredDocCount()==100){
           
           return (100 * this.completedDocCount() / this.requiredDocCount()-5);
        }else{
          return 100 * this.completedDocCount() / this.requiredDocCount();
        }
        
    }

    completedDocCount()
    {
        if (!this.documentDescriptions)
            return 0;

        return this.documentDescriptions.filter(dd => dd.required && !!dd.completedDate).length;
    }

    requiredDocCount()
    {
        if (!this.documentDescriptions)
            return 0;

        return this.requiredForms().length;
    }

    requiredForms()
    {
        if (!this.documentDescriptions)
            return [];

        return this.documentDescriptions.filter(dd => dd.required);
    }

    optionalForms()
    {
        if (!this.documentDescriptions)
            return [];

        return this.documentDescriptions.filter(dd => !dd.required);
    }

    printPacket()
    {
        let url = `/training/api/assignments/documentation/${this.assignmentId}/${this.profile._id}/pdf`;
        this._docLoader.requestPdf(window, 'GET', url);
    }

    private formatCode(code)
    {
        if (!code)
            return undefined;

        return code.slice(0, code.length/2) + '-' + code.slice(code.length/2);
    }
}
