import {Component, Input} from "@angular/core";
import {Router} from "@angular/router";
import {MaxAppContext} from "./maxAppContext.service";
import { SiteSearchService, SiteSearch } from "./site-search.service";
import {Organization} from "./organizations.service";
@Component({
    selector: 'teams-organization-box',
    template:`
        <div style="cursor: pointer" class="school-result" *ngIf="teamOrganizationData._type=='organizations'">
            <h3> {{ teamOrganizationData?._source?.name }} </h3>
            <p> <span *ngIf="orgData?.city">{{orgData?.city}},</span> <span *ngIf="orgData?.stateCode">{{orgData?.stateCode}} - </span> <span *ngIf="orgData?.shortCode">{{orgData?.shortCode}}</span></p>
        </div>
        
        <div style="cursor: pointer" class="school-result" *ngIf="teamOrganizationData._type=='listValues_teamInfo'">
            <h3> {{ teamOrganizationData?._source?.value?.name }} <span>{{ teamOrganizationData?._source?.value?.level }}</span></h3>
            <p><span *ngIf="orgData?.city">{{orgData?.city}},</span> <span *ngIf="orgData?.stateCode">{{orgData?.stateCode}} - </span> <span *ngIf="orgData?.shortCode">{{orgData?.shortCode}}</span></p>
        </div>
    `
    //templateUrl: '/maxweb/app/app/teams-players-box.component.html'
})
export class TeamOrganizationBoxComponent {

    private teamOrganizationData:any;
    private orgData:any;
    constructor(
        private _router:Router,
        private _ctx: MaxAppContext
    ){}

    @Input('teamOrganization') 
    set teamOrganization(data:SiteSearch){
        this.teamOrganizationData = data;

        if(data._type == "listValues_teamInfo"){
            this.orgData = this.getOrganizationDetails(data._source.orgId);
        }else if(data._type == "organizations"){
            this.orgData = this.getOrganizationDetails(data._id);
        }
    }
    
    getOrganizationDetails(orgId){
        if(orgId){
             //return this._ctx.availableOrganizations.find(o => o._id == orgId);
            var org = this._ctx.availableOrganizations.find(o => o._id == orgId);
            if (!org)
            {
                org = new Organization();
            }
            return org;
        }
    }
}