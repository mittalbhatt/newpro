import {Component, Input} from '@angular/core';
import { DocumentationActivity } from './documentation_activity';
import {RegistrationContext} from "./registration_context.service";

@Component({
    selector: 'registration-heading',
    template: `
    <h1 class="cover-heading">{{docAct ? docAct.documentationEventDescription.eventName : 'undefined'}}</h1>
    <h2>{{docAct ? docAct.documentationEventDescription.coordinatorName : 'undefined'}}</h2>
    `,
    styles: [`
        h1 {text-align:center}
        h2 { color: rgba(0, 0, 0, .75); text-align:center }
    `],
    providers: [
        RegistrationContext
    ]
})

export class RegistrationHeading  {
    @Input('doc-act') docAct: DocumentationActivity;
}
