System.register(["@angular/router", "./user_profiles.service", "./registration_context.service", "@angular/core", "./document_factory.service", "underscore", "./document_change_saver.service", "./maxAppContext.service", "./intercomRouterTracker.service"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var router_1, user_profiles_service_1, registration_context_service_1, core_1, document_factory_service_1, _, document_change_saver_service_1, core_2, maxAppContext_service_1, intercomRouterTracker_service_1;
    var DataItemPipe, AthleteDocumentationForm;
    return {
        setters:[
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (user_profiles_service_1_1) {
                user_profiles_service_1 = user_profiles_service_1_1;
            },
            function (registration_context_service_1_1) {
                registration_context_service_1 = registration_context_service_1_1;
            },
            function (core_1_1) {
                core_1 = core_1_1;
                core_2 = core_1_1;
            },
            function (document_factory_service_1_1) {
                document_factory_service_1 = document_factory_service_1_1;
            },
            function (_1) {
                _ = _1;
            },
            function (document_change_saver_service_1_1) {
                document_change_saver_service_1 = document_change_saver_service_1_1;
            },
            function (maxAppContext_service_1_1) {
                maxAppContext_service_1 = maxAppContext_service_1_1;
            },
            function (intercomRouterTracker_service_1_1) {
                intercomRouterTracker_service_1 = intercomRouterTracker_service_1_1;
            }],
        execute: function() {
            DataItemPipe = (function () {
                function DataItemPipe() {
                }
                DataItemPipe.lookupValue = function (ident, data, cache) {
                    var value = cache[ident];
                    return value ? value.value : undefined;
                };
                DataItemPipe.lookupTextValue = function (ident, data, cache) {
                    var ret = DataItemPipe.lookupValue(ident, data, cache);
                    if (!ret)
                        ret = "";
                    return ret;
                };
                DataItemPipe.prototype.transform = function (value, ident, cache) {
                    return DataItemPipe.lookupTextValue(ident, value, cache);
                };
                DataItemPipe = __decorate([
                    core_2.Pipe({ name: 'dataItem' }), 
                    __metadata('design:paramtypes', [])
                ], DataItemPipe);
                return DataItemPipe;
            }());
            exports_1("DataItemPipe", DataItemPipe);
            AthleteDocumentationForm = (function () {
                function AthleteDocumentationForm(_ctx, _appCtx, _router, _route, _documents, _userProfiles, _changeSaver, _intercom) {
                    var _this = this;
                    this._ctx = _ctx;
                    this._appCtx = _appCtx;
                    this._router = _router;
                    this._route = _route;
                    this._documents = _documents;
                    this._userProfiles = _userProfiles;
                    this._changeSaver = _changeSaver;
                    this._intercom = _intercom;
                    this.dataCache = {};
                    this.validationErrors = {};
                    this._changeSaver.status.subscribe(function (status) {
                        if (!status.saved)
                            _this.handleError(status.response);
                    });
                }
                AthleteDocumentationForm.prototype.onScroll = function () {
                    this.stickMenu = document.body.scrollTop > this.startingMenuOffset - 5; // 5 matches the 'top' setting in the .left-menu-stick css class
                };
                AthleteDocumentationForm.prototype.ngOnDestroy = function () {
                    this._changeSaver.stop();
                };
                AthleteDocumentationForm.prototype.ngOnInit = function () {
                    this.startingMenuOffset = this.leftMenu.nativeElement.offsetTop;
                    // console.log('START ' + this.startingMenuOffset);
                    this.refresh();
                };
                AthleteDocumentationForm.prototype.canDeactivate = function (component, route, state) {
                    var _this = this;
                    this._changeSaver.stop();
                    return this._changeSaver.saveNow().single().toPromise()
                        .then(function () {
                        return true;
                    })
                        .catch(function (error) {
                        _this.submitting = false;
                        _this._changeSaver.start(_this.document._id);
                        _this.handleError(error, 'We encountered an error saving your changes. Please refresh and try again.');
                    });
                };
                Object.defineProperty(AthleteDocumentationForm.prototype, "gradYearOptions", {
                    get: function () {
                        var currentYear = (new Date()).getFullYear();
                        return _.range(currentYear, currentYear + 13).map(function (i) { return i.toString(); });
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(AthleteDocumentationForm.prototype, "flaggedFields", {
                    get: function () {
                        var _this = this;
                        return _.chain(this.documentSections)
                            .pluck('fields')
                            .flatten()
                            .filter(function (f) {
                            return f.flagIf !== undefined && _this.lookupValue(f.ident) === f.flagIf;
                        })
                            .value();
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(AthleteDocumentationForm.prototype, "sectionsWithShortcuts", {
                    get: function () {
                        var _this = this;
                        if (!this.documentSections)
                            return [];
                        return this.documentSections.filter(function (ds) { return !!ds.shortcutName && !_this.shouldHideHideable(ds); });
                    },
                    enumerable: true,
                    configurable: true
                });
                AthleteDocumentationForm.prototype.fieldHasFormAlert = function (field) {
                    return (this.admin && (field.flagIf !== undefined) && (field.flagIf === this.lookupValue(field.ident)));
                };
                AthleteDocumentationForm.prototype.explainText = function (field) {
                    return field.explanationPrompt ? field.explanationPrompt : 'Please explain: ';
                };
                AthleteDocumentationForm.prototype.lookupValue = function (ident) {
                    if (!this.document)
                        return undefined;
                    return DataItemPipe.lookupValue(ident, this.document.data, this.dataCache);
                };
                AthleteDocumentationForm.prototype.lookupTextValue = function (ident) {
                    return DataItemPipe.lookupTextValue(ident, this.document.data, this.dataCache);
                };
                AthleteDocumentationForm.prototype.valueArrayContains = function (ident, elemValue) {
                    if (!this.document)
                        return false;
                    var value = _.find(this.document.data, function (d) { return d.ident == ident; });
                    if (value)
                        return _.contains(value.value, elemValue);
                    return false;
                };
                //valuesNotInList(ident:string, values:any)
                //{
                //    if (!this.document)
                //        return "";
                //
                //    var value = _.find(this.document.data, d => d.ident == ident);
                //    if (value)
                //        return _.without(value.value, values);
                //
                //    return "";
                //}
                AthleteDocumentationForm.prototype.onYesNo = function (ident, answer) {
                    this.updateValue(ident, answer);
                    if (answer === false)
                        this.updateValue(ident + '_explain', '');
                };
                AthleteDocumentationForm.prototype.onTextChange = function (ident, event) {
                    this.updateValue(ident, event.target.value);
                };
                AthleteDocumentationForm.prototype.onSelectMultiCheckChange = function (ident, option, event) {
                    this.updateListValue(ident, option, event.target.checked);
                };
                AthleteDocumentationForm.prototype.updateValue = function (ident, value) {
                    delete this.validationErrors[ident];
                    this._changeSaver.addChange({ ident: ident, value: value });
                    var item = _.find(this.document.data, function (d) { return d.ident == ident; });
                    if (item)
                        item.value = value;
                    else
                        this.document.data.push({ ident: ident, value: value });
                    this.dataCache[ident] = { ident: ident, value: value };
                };
                AthleteDocumentationForm.prototype.updateListValue = function (ident, value, included) {
                    var item = _.find(this.document.data, function (d) { return d.ident == ident; });
                    if (!item) {
                        item = { ident: ident, value: [] };
                        this.document.data.push(item);
                    }
                    if (included)
                        item.value = _.union(item.value, [value]);
                    else
                        item.value = _.difference(item.value, [value]);
                    this._changeSaver.addChange({ ident: ident, value: item.value });
                    this.dataCache[ident] = { ident: ident, value: item.value };
                };
                AthleteDocumentationForm.prototype.goToSection = function (name) {
                    this.scrollIntoView(name);
                };
                AthleteDocumentationForm.prototype.goToField = function (ident) {
                    this.scrollIntoView(ident);
                };
                AthleteDocumentationForm.prototype.scrollIntoView = function (id) {
                    document.getElementById(id).scrollIntoView();
                    if (this.admin) {
                        // Account for name floating at top.
                        window.scrollBy(0, -100);
                    }
                };
                AthleteDocumentationForm.prototype.shouldHideHideable = function (field) {
                    var _this = this;
                    return field.showIfAll && !_.every(field.showIfAll, function (f) { return _this.lookupValue(f.ident) === f.value; });
                };
                AthleteDocumentationForm.prototype.valueIsNullUndefinedOrEmpty = function (ident) {
                    var val = this.lookupValue(ident);
                    if (val && val.trim)
                        val = val.trim();
                    return !val && (val !== false);
                };
                AthleteDocumentationForm.prototype.onClickReviewPdfPages = function (field) {
                    this.onYesNo(field.ident, true);
                };
                AthleteDocumentationForm.prototype.onPrint = function () {
                    var _this = this;
                    var win = window.open("/maxweb/app/media/spinner.html");
                    this._changeSaver.stop();
                    this._changeSaver.saveNow().single().toPromise()
                        .then(function () {
                        _this._changeSaver.start(_this.document._id);
                        win.location.assign(_this.pdfUrl);
                    })
                        .catch(function (e) {
                        win.close();
                        _this._changeSaver.start(_this.document._id);
                        _this.handleError(e, 'We encountered an error saving your changes. Please refresh and try again.');
                    });
                };
                AthleteDocumentationForm.prototype.onSubmit = function () {
                    var _this = this;
                    this.validationErrors = {};
                    this.validationSummary = null;
                    var requiredUnfilled = _.chain(this.documentSections)
                        .pluck('fields')
                        .flatten()
                        .filter(function (f) {
                        return (f.required || (f.requireIfAll && _.every(f.requireIfAll, function (ff) { return _this.lookupValue(ff.ident) === ff.value; })))
                            && _this.valueIsNullUndefinedOrEmpty(f.ident);
                    })
                        .pluck('ident')
                        .value();
                    var explanationsRequiredUnfulfilled = _.chain(this.documentSections)
                        .pluck('fields')
                        .flatten()
                        .filter(function (f) {
                        return f.explanationRequired && _this.lookupValue(f.ident) === true && _this.valueIsNullUndefinedOrEmpty(f.ident + '_explain');
                    })
                        .pluck('ident')
                        .map(function (i) { return i + '_explain'; })
                        .value();
                    requiredUnfilled = requiredUnfilled.concat(explanationsRequiredUnfulfilled);
                    requiredUnfilled.forEach(function (ident) { return _this.validationErrors[ident] = true; });
                    if (requiredUnfilled.length) {
                        var summary = requiredUnfilled.length > 1 ? 'There are' : 'There is';
                        summary += ' ' + requiredUnfilled.length + ' ';
                        summary += requiredUnfilled.length > 1 ? 'fields' : 'field';
                        summary += ' that you haven\'t filled in. Look for the fields marked in red.';
                        this.validationSummary = summary;
                        window.scrollTo(0, 0);
                        // console.log(JSON.stringify(requiredUnfilled));
                        return;
                    }
                    var requiredResponseNotMatching = _.chain(this.documentSections)
                        .pluck('fields')
                        .flatten()
                        .filter(function (f) {
                        return f.requiredResponse !== undefined && !_.isEqual(_this.lookupValue(f.ident), f.requiredResponse);
                    })
                        .pluck('ident')
                        .value();
                    requiredResponseNotMatching.forEach(function (ident) { return _this.validationErrors[ident] = true; });
                    if (requiredResponseNotMatching.length) {
                        var summary = requiredResponseNotMatching.length > 1 ? 'There are' : 'There is';
                        summary += ' ' + requiredResponseNotMatching.length + ' ';
                        summary += requiredResponseNotMatching.length > 1 ? 'fields' : 'field';
                        summary += ' that does not contain the required response.  Look for the fields marked in red.';
                        this.validationSummary = summary;
                        window.scrollTo(0, 0);
                        // console.log(JSON.stringify(requiredResponseNotMatching));
                        return;
                    }
                    this.submitting = true;
                    this._changeSaver.stop();
                    this._changeSaver.saveNow().single().toPromise()
                        .then(function () {
                        if (_this.canSign())
                            return Promise.resolve(null);
                        return _this._documents.completeDocument(_this.document._id).single().toPromise();
                    })
                        .then(function () {
                        if (_this.document.type == 'Medical' && _this.document.name == 'Medical Record') {
                            var records = [{ medicalRecordStableDocumentId: _this.document.documentStableId }];
                            return _this._userProfiles.updateProfile(_this.subjectProfile._id, { $set: { medicalRecords: records } }).single().toPromise();
                        }
                        else {
                            return Promise.resolve(null);
                        }
                    })
                        .then(function () {
                        _this._intercom.track('submitted-form', { formName: _this.document.name });
                        _this.goBack();
                    })
                        .catch(function (error) {
                        _this.submitting = false;
                        _this._changeSaver.start(_this.document._id);
                        _this.handleError(error, 'We encountered an error saving your changes. Please refresh and try again.');
                    });
                };
                AthleteDocumentationForm.prototype.onBack = function () {
                    var _this = this;
                    this._changeSaver.stop();
                    this._changeSaver.saveNow().single().toPromise()
                        .then(function () {
                        _this.goBack();
                    })
                        .catch(function (error) {
                        _this.submitting = false;
                        _this._changeSaver.start(_this.document._id);
                        _this.handleError(error, 'We encountered an error saving your changes. Please refresh and try again.');
                    });
                };
                AthleteDocumentationForm.prototype.goBack = function () {
                    if (this.admin) {
                        this._router.navigate(['admin/event', this.packetActivityId], { relativeTo: this._route.parent });
                    }
                    else {
                        var queryParams = {
                            activityId: this.packetActivityId, profileId: this.subjectProfileId
                        };
                        // if(this._documentDescriptionActivity !== undefined && this._documentDescriptionActivity !== ""){
                        //     activityId = this._documentDescriptionActivity;
                        // }
                        console.log(this.packetActivityId);
                        if (this.packetActivityId !== undefined && this.packetActivityId !== "") {
                            this._router.navigate(['athDocDashboard', this.packetActivityId, this.subjectProfileId], { relativeTo: this._route.parent });
                        }
                        else {
                            this._router.navigate(['packetList', { profileId: this.subjectProfileId }], { relativeTo: this._route.parent });
                        }
                    }
                };
                AthleteDocumentationForm.prototype.canSign = function () {
                    return this.admin && !this.document.originalDescription.staffOnly && this.document.completedDate;
                };
                AthleteDocumentationForm.prototype.handleError = function (error, message) {
                    if (message === void 0) { message = null; }
                    var parsed = null;
                    try {
                        parsed = error.json();
                    }
                    catch (e) {
                    }
                    if (parsed && parsed.message) {
                        this.errorMessage = parsed.message;
                        return;
                    }
                    if (error.message) {
                        this.errorMessage = error.message;
                        return;
                    }
                    this.errorMessage = message || 'An error has occurred. Please refresh and try again.';
                    window.scrollTo(0, 0);
                    throw error;
                };
                AthleteDocumentationForm.prototype.pdfPagesUrl = function (field) {
                    var url = this.pdfUrl;
                    if (field.pages)
                        url += '&pages=' + field.pages;
                    return url;
                };
                AthleteDocumentationForm.prototype.refresh = function () {
                    var _this = this;
                    this.loading = true;
                    var params = this._route.snapshot.params;
                    this._documentDescriptionActivity = params['docDescriptionActivityId'];
                    this._assignmentId = params['assignmentId'];
                    var profileId = params['profileId'];
                    this.subjectProfileId = profileId;
                    this.packetActivityId = params['packetActivityId'];
                    var loadProfile = this._userProfiles.getProfile(profileId).single().toPromise();
                    loadProfile.then(function (p) {
                        _this.subjectProfile = p;
                        if (_this._appCtx.currentProfile && _this.subjectProfileId === _this._appCtx.currentProfile._id) {
                            _this.admin = false;
                        }
                        else {
                            _this.admin = !!_this._appCtx.myProfiles.find(function (mp) {
                                return (mp.org == p.org && !!_.intersection(mp.orgRoles, ['TRN', 'OTRN', 'OADM']).length)
                                    ||
                                        (mp.linkedOrgRoles && !!mp.linkedOrgRoles.find(function (lor) { return lor.orgId == p.org && !!_.intersection(lor.roles, ['TRN', 'OTRN', 'OADM']).length; }));
                            });
                        }
                    });
                    loadProfile
                        .then(function (p) { return p._id; })
                        .then(function (pid) {
                        return _this._documents.findOrCreateDocument(_this._documentDescriptionActivity, _this._assignmentId, pid).single().toPromise();
                    })
                        .then(function (documents) {
                        _this.loading = false;
                        // If there were multiple matches, they would all be returned here.
                        // We don't have a rule for selecting which one other than we would
                        // hope that the last in is the latest.
                        _this.document = documents[documents.length - 1];
                        (_this.document.data || []).forEach(function (d) {
                            _this.dataCache[d.ident] = d;
                        });
                        _this.documentSections = _this.document.originalDescription.format.sections;
                        _this._changeSaver.start(_this.document._id);
                        var docStableId = _this.document.documentStableId;
                        var username = encodeURIComponent(_this._ctx.creds.username);
                        var password = encodeURIComponent(_this._ctx.creds.password);
                        _this.pdfUrl = window.location.protocol + "//" + window.location.host + "/training/api/documents/" + docStableId + "/pdf?auth.basic.username=" + username + "&auth.basic.password=" + password;
                    })
                        .catch(function (error) {
                        _this.loading = false;
                        _this.handleError(error);
                    });
                };
                __decorate([
                    core_1.Input(), 
                    __metadata('design:type', Boolean)
                ], AthleteDocumentationForm.prototype, "admin", void 0);
                __decorate([
                    core_1.ViewChild('leftMenu'), 
                    __metadata('design:type', core_1.ElementRef)
                ], AthleteDocumentationForm.prototype, "leftMenu", void 0);
                __decorate([
                    core_1.HostListener('window:scroll'), 
                    __metadata('design:type', Function), 
                    __metadata('design:paramtypes', []), 
                    __metadata('design:returntype', void 0)
                ], AthleteDocumentationForm.prototype, "onScroll", null);
                AthleteDocumentationForm = __decorate([
                    core_1.Component({
                        selector: 'ath-doc-form',
                        templateUrl: '/maxweb/app/app/ath_doc_form.component.html',
                    }), 
                    __metadata('design:paramtypes', [registration_context_service_1.RegistrationContext, maxAppContext_service_1.MaxAppContext, router_1.Router, router_1.ActivatedRoute, document_factory_service_1.Documents, user_profiles_service_1.UserProfiles, document_change_saver_service_1.DocumentChangeSaver, intercomRouterTracker_service_1.IntercomRouterTracker])
                ], AthleteDocumentationForm);
                return AthleteDocumentationForm;
            }());
            exports_1("AthleteDocumentationForm", AthleteDocumentationForm);
        }
    }
});
//# sourceMappingURL=athlete_doc_form.component.js.map