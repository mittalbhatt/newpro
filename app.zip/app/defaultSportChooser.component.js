System.register(["./sportCodes", "@angular/core", "underscore"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var sportCodes_1, core_1, _;
    var SportCodeOptionModel, template, DefaultSportChooser;
    return {
        setters:[
            function (sportCodes_1_1) {
                sportCodes_1 = sportCodes_1_1;
            },
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (_1) {
                _ = _1;
            }],
        execute: function() {
            SportCodeOptionModel = (function () {
                function SportCodeOptionModel(sportCode, onSelectedChanged) {
                    this._selected = false;
                    this.sportCode = sportCode;
                    this._onSelectedChanged = onSelectedChanged;
                }
                Object.defineProperty(SportCodeOptionModel.prototype, "selected", {
                    get: function () {
                        return this._selected;
                    },
                    set: function (value) {
                        this._selected = value;
                        if (this._onSelectedChanged)
                            this._onSelectedChanged(this);
                    },
                    enumerable: true,
                    configurable: true
                });
                return SportCodeOptionModel;
            }());
            template = "\n<div class=\"container-fluid\" style=\"max-width:700px\">\n    <div class=\"row\" *ngFor=\"let row of sportOptionsRows\">\n        <div class=\"col-xs-4\" *ngFor=\"let sport of row\">\n            <div class=\"checkbox\">\n                <label>\n                    <input type=\"checkbox\" [(ngModel)]=\"sport.selected\"> {{sport.sportCode.name}}\n                </label>\n            </div>\n        </div>\n    </div>\n</div>\n";
            DefaultSportChooser = (function () {
                function DefaultSportChooser() {
                    var _this = this;
                    this.sportsSelected = new core_1.EventEmitter();
                    this.sportOptions = sportCodes_1.SportCodes.map(function (sc) { return new SportCodeOptionModel(sc, function (x) { return _this.onSelected(); }); });
                    var cols = 3;
                    this.sportOptionsRows = _.chain(this.sportOptions)
                        .map(function (so, idx) { return { so: so, col: Math.floor(idx / cols) }; })
                        .groupBy('col')
                        .values()
                        .map(function (v) { return v.map(function (vv) { return vv.so; }); })
                        .value();
                }
                Object.defineProperty(DefaultSportChooser.prototype, "initialSelectedSportCodes", {
                    set: function (value) {
                        if (!value)
                            return;
                        this.sportOptions.forEach(function (so) { return so.selected = value.indexOf(so.sportCode.code) > -1; });
                    },
                    enumerable: true,
                    configurable: true
                });
                DefaultSportChooser.prototype.onSelected = function () {
                    this.sportsSelected.emit(this.sportOptions.filter(function (so) { return so.selected; }).map(function (so) { return so.sportCode; }));
                };
                __decorate([
                    core_1.Output(), 
                    __metadata('design:type', core_1.EventEmitter)
                ], DefaultSportChooser.prototype, "sportsSelected", void 0);
                __decorate([
                    core_1.Input(), 
                    __metadata('design:type', Array), 
                    __metadata('design:paramtypes', [Array])
                ], DefaultSportChooser.prototype, "initialSelectedSportCodes", null);
                DefaultSportChooser = __decorate([
                    core_1.Component({
                        selector: 'default-sport-chooser',
                        template: template
                    }), 
                    __metadata('design:paramtypes', [])
                ], DefaultSportChooser);
                return DefaultSportChooser;
            }());
            exports_1("DefaultSportChooser", DefaultSportChooser);
        }
    }
});
//# sourceMappingURL=defaultSportChooser.component.js.map