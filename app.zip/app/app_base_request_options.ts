import {BaseRequestOptions, Headers, RequestMethod} from "@angular/http";
import {ReflectiveInjector, Injectable} from "@angular/core";
import {Base64Encoder} from "./base64Encoder";
import {RegistrationContext} from "./registration_context.service";

@Injectable()
export class AppBaseRequestOptions extends BaseRequestOptions {
    private _headers:Headers;

    get headers()
    {
        var injector = ReflectiveInjector.resolveAndCreate([RegistrationContext]);
        var ctx = injector.get(RegistrationContext);

        // Use a copy so that the value is not retained across requests
        // in case the credentials are updated.  The ctor that takes a Headers
        // instance did not appear to actually  make a deep copy.
        var headersCopy = new Headers(this._headers ? this._headers.values() : null);

        if (this.method != 'GET' && this.method != RequestMethod.Get)
            headersCopy.set('Content-Type', 'application/json');

        if ((!this._headers || !this._headers.has('Authorization')) && ctx.creds)
        {
            var auth = ReflectiveInjector.resolveAndCreate([Base64Encoder]).get(Base64Encoder).encode(ctx.creds.username + ':' + ctx.creds.password);
            headersCopy.set('Authorization', 'Basic ' + auth);
        }

        return headersCopy;
    }

    set headers(value:Headers)
    {
        this._headers = value;
    }
}