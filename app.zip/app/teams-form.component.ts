import {Component, ElementRef, Inject, Output, EventEmitter, ViewChild, OnDestroy, ChangeDetectionStrategy} from "@angular/core";
import {Router, ActivatedRoute, Event as RouterEvent, NavigationStart, RoutesRecognized } from "@angular/router";
import {MaxAppContext} from "./maxAppContext.service";
import {UserProfiles, UserProfile } from "./user_profiles.service";
import {Organizations, Organization } from "./organizations.service";
import {Assignments, Assignment} from "./assignments.service";
import {PacketFormModal, CustomModalContext} from "./packet-form-modal.component";
import {AssignFormModal, AssignFormModalContext} from "./assign-form-model.component";
import {Modal, BSModalContext} from 'angular2-modal/plugins/bootstrap';
import {Overlay, overlayConfigFactory} from 'angular2-modal';
import {TeamPacketCreationModalPrompt, AssignmentModalContext} from "./team-packet-creation-modal.component";
import {DfObjectId} from "./DfObjectId";
import {DocumentationActivity, DocumentationDocDescriptionReference} from './documentation_activity';
import {Documents} from "./document_factory.service";
import {DocumentLoader} from './document_loader.service';
import {SharedService} from './shared.service';
import { SwiperComponent, SwiperConfigInterface } from 'ngx-swiper-wrapper';
import {Subscription} from 'rxjs/Subscription';
// import { _ as _l } from "lodash";
// import * as _l from "lodash";

export class PacketForm{
    _id: string;
    assignmentStableId:string;
    //replacesAssignmentId: string;
    category: string='Documentation';
    startDate: any = new Date();
    creatorOrgId: string;
    
    audienceInclusions: [{
        roles: string;
        ofOrg: string;
        canEdit: boolean;
    }];
    activities:[{
        _id: string;
        documentationEventDescription:{
            coordinatorName: string;
            eventName: string;
            documents: Array<Object>;
            summaryFields : any;
        },
        orgId : string;
        canEdit: boolean;
        type : string;
    }];
    assignees: any = [];
    constructor(data:any) {
        for(var k in data)
        {
            this[k] = data[k];
        }
    }
}
@Component({
    selector: 'teams-form',
    templateUrl: '/maxweb/app/app/teams-form.component.html',
    // changeDetection: ChangeDetectionStrategy.Default
})
export class TeamsFormComponent implements OnDestroy{

    @ViewChild(SwiperComponent) swiperView: SwiperComponent; //use for crousal setting
    documentationAssignments:any[];
    profile: UserProfile;
    errorMessage:string;
    documentDescriptions: DocumentationDocDescriptionReference[];
    assignmentId:string;
    private currentOrgDetails:any;
    replaceId:string;
    packetdatalist:boolean=true;
    packetformData:any;
    packetformDataList:Array<Object>=[];
    printing:boolean;
    selectedRow:any = null;
    droppedValue: number;
    assignmentDataById:any;
    currentOrgData:any;
    packetName:string;
    selectedPacket:PacketForm=null;
    unsavedPacket:PacketForm=null;
    isSavingData:boolean=false;
    isLoadingPacket:boolean=false;
    assignedToString:string="None";
    tabtype: string;
    arrowupactive: boolean=true;
    arrowdownactive: boolean=true;
    rolesdataarray:any;
    isAssigneesAvailable:boolean=false;
    isAssigneesChange:boolean=false;
    onremoveform:boolean=false;


     public type: string = 'directive';
     public config: SwiperConfigInterface = {
        //loop: false,

        nextButton: '.swiper-button-next',
        prevButton: '.swiper-button-prev',
        direction: 'horizontal',
        slideToClickedSlide:true,
        width:990,
        height:500,
        autoHeight:true,
        slidesPerView: 6,
        onInit: function(swiper){
        swiper.slideTo(2, 1, true);

        },
        onSlideChangeStart: function (swiper) {
           if(swiper.activeIndex==swiper.slides.length){
                swiper.nextButton.addClass(swiper.params.buttonDisabledClass);
            }
            if(swiper.activeIndex==2){
                swiper.prevButton.addClass(swiper.params.buttonDisabledClass);
            }
        },
        onSlideChangeEnd: function (swiper) {
            if(swiper.activeIndex==(swiper.slides.length-2)){
                swiper.nextButton.addClass(swiper.params.buttonDisabledClass);
            }
            if(swiper.activeIndex==2){
                swiper.prevButton.addClass(swiper.params.buttonDisabledClass);
            }

        },
        freeMode: true,
        threshold: 0,
        spaceBetween: 0,
        breakpoints: {

            1024: {
                slidesPerView: 4,
                spaceBetween: 10
            },
            768: {
                slidesPerView: 4,
                spaceBetween: 10
            },
            640: {
                slidesPerView: 3,
                spaceBetween: 10
            },
            425: {
                slidesPerView: 2,
                spaceBetween: 10
            }
        },
        observer: true

    };
    // tabSubscribe: Subscription;
    orgStructureSubscribe: Subscription;
    popupDataSubscribe: Subscription;
    // packDataSubscribe: Subscription;
    documentationAssignmentsPromise:Subscription;
    assignmentstableIdarray:any;
    assignmentStableId:string;

    // @Output() unsavedData = new EventEmitter();

    constructor(
        private _assignmentsSvc:Assignments,
        private _organizations: Organizations,
        public element:ElementRef,
        private router: Router,
        private _modal:Modal,
        private _docLoader:DocumentLoader,
        private _shared:SharedService,
        private _ctx:MaxAppContext
    )
    {
        // console.log(this.selectedPacket);
        // For get all popup data (Assign people, add form, add packet name)
          this.popupDataSubscribe = this._assignmentsSvc.getPopupData.subscribe(res=>{
            if(res.type == "form"){
                this.manageUnsavedPacket(res.data, "form");
            }else if(res.type == "assignees"){
                this.manageUnsavedPacket(res.data, "assignees");
            }else if(res.type == "packet"){
                this.packetName = res.data;
                if(res.isNew !== undefined && res.isNew === true){
                    this.resetChanges();
                }
                this.manageUnsavedPacket(res.data, "packet");
            }else if(res.type == "print"){
                this.onPrint(res.data,this.selectedPacket);
            }
        });

        // For get organization data on change dropdown or route
        this.orgStructureSubscribe = this._organizations.orgStructureData.subscribe((res:any)=>{
            this.currentOrgData = res;
            if(this.currentOrgData.data !== null && this.currentOrgData.org !== "Everyone"){
                this.refresh();
            }
        });
    }

    ngOnInit() {
    }

    ngOnDestroy() {
        this.orgStructureSubscribe.unsubscribe();
        this.popupDataSubscribe.unsubscribe();
    }

    //use for packet list data
    refresh(){
        this.resetChanges();
        this.isLoadingPacket = true;

        this.isAssigneesChange = false;
        this.isAssigneesAvailable = false;
        if(this.documentationAssignmentsPromise){
            this.documentationAssignmentsPromise.unsubscribe();
        }
        this.documentationAssignmentsPromise = this._assignmentsSvc.getUserPacketList('Documentation',0,1000).subscribe(data =>
        {
            // console.log(data);

            var groupeotherdDocsnew = _.filter(data, (d:any) =>{
                if(d.activities[0].orgId == this.currentOrgData.org  ){
                    return d;
                }
            });
            groupeotherdDocsnew = _.sortBy(groupeotherdDocsnew, (o:any)=>{
                return - (new Date(o.lastModifiedDate).getTime());
            });

            if(groupeotherdDocsnew[0] !== undefined && groupeotherdDocsnew[0] !== null && groupeotherdDocsnew.length > 0){
                if(sessionStorage['currentPacket'] !== "undefined" && sessionStorage['currentPacket'] !== undefined && sessionStorage['currentPacket'] !== null && sessionStorage['currentPacket'] !==""){
                    let i=0;
                    let j=1;
                    let selectedPack:any = _.filter(groupeotherdDocsnew, (d:any) =>{
                        i++;
                        if(d._id == sessionStorage['currentPacket']){
                            j = i;
                            return d;
                        }
                    });

                    if(selectedPack[0] !== undefined && selectedPack[0] !== null){
                        this.onClickFormsAssignment(selectedPack[0]);
                    }else{
                        this.onClickFormsAssignment(groupeotherdDocsnew[0]);
                    }
                    this.config.initialSlide = j;
                }else{
                    this.onClickFormsAssignment(groupeotherdDocsnew[0]);
                }
            }
            this.documentationAssignments = groupeotherdDocsnew;
            // console.log(this.documentationAssignments);

        },
        (e)=>{
            this.errorMessage = 'We encountered an unexpected error.  Try refreshing the page.';
            throw e;
        },
        ()=>{
            this.isLoadingPacket = false;
        }
        );
    }

    // Using for display assignees string
    displayAssignees(){
        this.assignedToString="None";
        if(
            this.selectedPacket !== undefined &&
            this.selectedPacket !== null &&
            this.selectedPacket.assignees !== undefined &&
            this.selectedPacket.assignees !== null &&
            this.selectedPacket.assignees.length > 0
        ){
            let teamArr =  _.groupBy(this.selectedPacket.assignees, (o:any)=>{
                return o.role;
            });
            if(teamArr['ATH'] !== undefined && teamArr['ATH'].length > 0 ){

                let role ="";
                role = "Athletes";
                if(teamArr['CCH'] !== undefined && teamArr['CCH'].length > 0 ){
                    role = "Athletes and Coaches";
                }

                let i=0;
                let teams = "";
                _.each(teamArr['ATH'],  (o:any)=>{
                    i++;

                    if(o.tag == undefined){
                        teams = "All sports";
                    }else{
                        let sportArr = _.find(this.currentOrgData.data.teams, (s:any)=>{
                            return s.team.code == o.tag;
                        });

                        let sport =  sportArr.team.name;
                        let level =  (sportArr.team.level == undefined) ? "" : sportArr.team.level;
                        if(teams == ""){
                            teams = level + " " + sport;
                        }else{
                            teams += ", " + level + " " + sport;
                        }
                    }

                    if(i == teamArr['ATH'].length){
                         this.assignedToString = `${role} in ${teams}`;
                    }
                });

            }else if(teamArr['CCH'] !== undefined && teamArr['CCH'].length > 0 ){
                let role ="";
                role = "Coaches";

                let i=0;
                let teams = "";
                _.each(teamArr['CCH'],  (o:any)=>{
                    i++;

                    if(o.tag == undefined){
                        teams = "All sports";
                    }else{
                        let sportArr = _.find(this.currentOrgData.data.teams, (s:any)=>{
                            return s.team.code == o.tag;
                        });

                        let sport =  sportArr.team.name;
                        let level =  (sportArr.team.level == undefined) ? "" : sportArr.team.level;
                        if(teams == ""){
                            teams = level + " " + sport;
                        }else{
                            teams += ", " + level + " " + sport;
                        }
                    }

                    if(i == teamArr['CCH'].length){
                         this.assignedToString = `${role} in ${teams}`;
                    }
                });
            }
        }
    }

    // If any changes in packet then call this function
    manageUnsavedPacket(data:any, type:string){
        this.rolesdataarray = _.find(this._ctx.myProfiles, (d:any) =>{
            if(d._id == this._ctx.currentProfile._id){
                return d;
            }
        });



        if(this.unsavedPacket === null){
            let profileId = (new DfObjectId()).toString();

            if(this.assignmentDataById !== undefined && this.assignmentDataById._id !== undefined){
                this.replaceId = this.assignmentDataById._id; // old assignment id
              //  this.assignmentstableId=this.assignmentDataById._id;
            }else{
                this.replaceId = this.assignmentId;

            }
            let packetdata ={};
            if(this.assignmentId !== null && this.assignmentId !== undefined){ // On Edit
                // packetdata = this.selectedPacket;
                let documents = [];
                if(type == "form"){
                    documents = data;
                }else if(type == "form-modify"){
                    documents = this.packetformDataList;
                }else if(this.selectedPacket.activities[0].documentationEventDescription.documents !== undefined){
                    documents = this.selectedPacket.activities[0].documentationEventDescription.documents;
                }

                let assignees = [];
                if(type == "assignees"){
                    assignees = data;
                }else if(this.selectedPacket.assignees !== undefined){
                    assignees = this.selectedPacket.assignees;
                }

                packetdata = {
                    _id: profileId,
                    replacesAssignmentId: this.replaceId,// If edit then pass only this parameter
                    assignmentStableId: this.selectedPacket.assignmentStableId,
                    category: 'Documentation',
                    startDate: new Date(),
                    audienceInclusions: [{
                         roles: [
                                    "OADM",
                                    "OTRN",
                                ], // Ask to client
                        ofOrg: this.currentOrgData.data.org.orgId,
                        canEdit: true
                    }],
                    activities:[{
                        _id: profileId,
                        localOnly: true,
                        documentationEventDescription:{
                            coordinatorName: this.currentOrgData.data.org.name,
                            eventName: this.packetName,
                            documents: documents,
                            summaryFields : []
                        },
                        orgId : this.currentOrgData.data.org.orgId,
                        type : "Documentation"
                    }],
                    assignees: assignees
                };

                this.packetformDataList = documents;
            }else{ // On Add

                packetdata = {
                    _id: profileId,
                    assignmentStableId: profileId,
                    category: 'Documentation',
                    startDate: new Date(),
                    audienceInclusions: [{
                        roles: [
                                    "OADM",
                                    "OTRN",
                                ], // Ask to client
                        ofOrg: this.currentOrgData.data.org.orgId,
                        canEdit: true
                    }],
                    activities:[{
                        _id: profileId,
                        localOnly: true,
                        documentationEventDescription:{
                            coordinatorName: this.currentOrgData.data.org.name,
                            eventName: this.packetName,
                            documents: [],
                            summaryFields : []
                        },
                        orgId : this.currentOrgData.data.org.orgId,
                        type : "Documentation"
                    }],
                    assignees: []
                };
                this.packetformDataList = [];
            }

            this.unsavedPacket = new PacketForm(packetdata);
        }else{
            if(type == "packet"){
                this.unsavedPacket.activities[0].documentationEventDescription.eventName = data;
            }else if(type == "form"){
                this.packetformDataList = data;
            }else if(type == "assignees"){
                this.unsavedPacket.assignees = data;
            }else if(type == "form-modify"){
                this.unsavedPacket.activities[0].documentationEventDescription.documents = this.packetformDataList;
            }
        }

        this.unsavedPacket.activities[0].documentationEventDescription.documents = this.packetformDataList;
        this.selectedPacket = this.unsavedPacket;
        // this.unsavedData.emit(this.unsavedPacket);

        // console.log(this.selectedPacket);
        // console.log(this.documentationAssignments);

        this.displayAssignees();
        this.checkAssigneesPrompt();
    }

    checkAssigneesPrompt(){
        this.isAssigneesChange = false;
        this.isAssigneesAvailable = false;
        if(this.unsavedPacket !== null){
            let selectedPack = _.find(this.documentationAssignments, (o:any)=>{
                return this.assignmentId === o._id;
            });
            if(selectedPack !== null && selectedPack !== undefined){
                if(
                    (selectedPack.assignees !== undefined && selectedPack.assignees.length > 0)
                    &&
                    (this.unsavedPacket.assignees !== undefined && this.unsavedPacket.assignees.length ==0)
                ){
                    this.isAssigneesChange = true;
                }
            }

            if(this.unsavedPacket.assignees !== undefined && this.unsavedPacket.assignees.length > 0){
                this.isAssigneesAvailable = true;
            }
        }
    }

    // Chage form order using drag
    dragSuccess(){
        this.manageUnsavedPacket(this.packetformDataList, "form-modify");
    }

    // If you change any packet then lost unsaved packet data
    lostDataPrompt():Promise<any>{
        return new Promise((resolve, reject) => {
            if(this.unsavedPacket == null){
                resolve(true);
            }else{
                this._modal.confirm()
                .size('lg').isBlocking(true).showClose(false).keyboard(27)
                .body(`You have unsaved changes to ${this.unsavedPacket.activities[0].documentationEventDescription.eventName}.  Do you want to save these changes before you move on?<br><br>If you don't save your changes, they will be lost.`)
                .addButton('btn btn-primary', 'Save changes', function (dialogFooter) {
                    dialogFooter.dialog.dismiss();
                    resolve("save");
                })
                .headerClass("hide")
                .okBtn("Discard Changes").okBtnClass("btn btn-danger")
                .cancelBtnClass("btn btn-danger")
                .open().then((dialog : any ) => {
                    return dialog.result;
                }).then(result =>{
                    if(result === true){
                        resolve(true);
                    }else{
                        resolve(false);
                    }
                }).catch((e:any)=>{
                    reject(e);
                }).catch((e:any)=>{
                    reject(e);
                });
            }
        });
    }

    // Change packet details then call this function
    onClickFormsAssignment(assignment:PacketForm=null)
    {
        if(assignment !==null && assignment !==undefined)
        sessionStorage['currentPacket'] = assignment._id;

        if(this.unsavedPacket !== null){
            this.lostDataPrompt().then((res:any)=>{
                if(res == "save"){
                    this.checkBeforeSave().then((res:boolean)=>{
                        if(res == true){
                            this.savedata();
                            this.changePacket(assignment);
                        }
                    });
                }else{
                    this.resetChanges();
                    this.refresh();
                    this.changePacket(assignment);
                }
            }).catch(e=>{
                // this.onCancel();
            });
        }else{
            this.changePacket(assignment);
        }
    }

    resetChanges(){
        this.selectedRow = null;
        this.arrowupactive = true;
        this.arrowdownactive = true;
        this.unsavedPacket = null;
        this.assignmentId = null;
        this.selectedPacket = null;
        this.assignedToString = "None";
        this.selectedPacket=null;
        // this.unsavedData.emit(this.unsavedPacket);
    }

    changePacket(assignment:PacketForm=null){
        if(assignment !== null){
            this.resetChanges();
            this.selectedPacket = assignment;
        }

        if(assignment === null){ // Add new packet
            this.addPacket(null);

        }else{ // Edit current packet
            this.assignmentId=this.selectedPacket._id;
            if(this.selectedPacket.activities[0].documentationEventDescription.documents){
                this.packetformDataList = Array.apply(this, this.selectedPacket.activities[0].documentationEventDescription.documents);
            }
            this.packetName = this.selectedPacket.activities[0].documentationEventDescription.eventName;
        }
        this.displayAssignees();
    }

    // Use for assignment add OR edit
    checkBeforeSave():Promise<boolean>{
        return new Promise((resolve, reject) => {
            if(this.isAssigneesChange){
                this.checkAssigneeAvailableOrNot().then((data:boolean)=>{
                    resolve(data);
                }).catch(e=>{
                    reject(e);
                });
            }

            if(this.isAssigneesAvailable){
                this.checkAssigneeIfAvailable().then((data:boolean)=>{
                    resolve(data);
                }).catch(e=>{
                    // console.log(e);
                    reject(e);
                });
            }

            if(this.isAssigneesChange === false &&  this.isAssigneesAvailable === false){
                resolve(true);
            }
        });
    }

    onSaveData(is_get_list:boolean=true){
        if(is_get_list==false){ // Save on route redirect
            this.savedata(false);
        }else{ // Save in current component
            this.checkBeforeSave().then((res)=>{
                if(res){
                    this.savedata();
                }
            }).catch((e)=>{
                //   console.log(e);
            });
        }
    }

    // Change route then ask unsaved popup
    lostCurrentRoute():Promise<boolean>{
        return new Promise((resolve, reject) => {
            if(this.unsavedPacket !== null){
                this.lostDataPrompt().then((res:any)=>{
                    if(res == "save"){
                        this.checkBeforeSave().then((res:boolean)=>{
                            if(res == true){
                                this.onSaveData(false);
                                resolve(true);
                            }
                        });
                    }else{
                        resolve(true);
                    }
                }).catch(e=>{
                    // this.onCancel();
                    resolve(false);
                    // throw e;
                });
            }else{
                resolve(true);
            }
        });
    }

    savedata(is_get_list:boolean=true){
        this.isSavingData = true;
        this._assignmentsSvc.createPacket(this.unsavedPacket).single().toPromise().then((d:any)=>{

            if(is_get_list){
                this.refresh();
            }

            if(d._id !== undefined){
                sessionStorage['currentPacket'] = d._id;
            }else{
                sessionStorage['currentPacket'] ="";
            }

            // this.unsavedPacket = null;
            // this.unsavedData.emit(this.unsavedPacket);
            this.resetChanges();
            this.isSavingData = false;
        }).catch(e=>{
            this.isSavingData = false;

            (<any>this._modal.alert()).message(`Some error has been occur while saving the data.`).open();
            console.log(e);
            throw e;
        });
    }

    // Befaore save packet availabe and on save packet is not availabe then show this popup
    areYouSure():Promise<boolean>{
        return new Promise((resolve, reject) => {
            this._modal.confirm()
            .size('sm').isBlocking(true).showClose(false).keyboard(27)
            .body(`Are you sure you want to cancel?`)
            .headerClass("hide")
            .okBtn("Discard Changes").okBtnClass("btn btn-danger")
            .cancelBtn("No").cancelBtnClass("btn btn-primary")
            .open().then((dialog : any ) => {
                return dialog.result;
            }).then(result =>{
                if(result === true){
                    resolve(true);
                }else{
                    resolve(false);
                }
            }).catch((e:any)=>{
                resolve(e);
            }).catch((e:any)=>{
                resolve(e);
            });
        });
    }

    // Befaore save packet availabe and on save packet is not availabe then show this popup
    checkAssigneeAvailableOrNot():Promise<boolean>{
        return new Promise((resolve, reject) => {
            this._modal.confirm()
            .size('lg').isBlocking(true).showClose(false).keyboard(27)
            .body(`You have removed everyone from this forms packet.  If you continue, these forms will no longer be assigned to anyone, but any forms that have already been filled out will still be in those athlete's records.<br><br>Are you sure you want to unassign this packet?`)
            .headerClass("hide")
            .okBtnClass("btn btn-primary")
            .cancelBtnClass("btn btn-danger")
            .open().then((dialog : any ) => {
                return dialog.result;
            }).then(result =>{
                if(result === true){
                    resolve(true);
                }else{
                    resolve(false);
                }
            }).catch((e:any)=>{
                resolve(e);
            }).catch((e:any)=>{
                resolve(e);
            });
        });
    }

    // Befaore save packet availabe and on save packet is not availabe then show this popup
    checkAssigneeIfAvailable():Promise<boolean>{
        return new Promise((resolve, reject) => {
            this._modal.confirm()
            .size('lg').isBlocking(true).showClose(false).keyboard(27)
            .body(`If you continue, these forms will immediately be assigned to the people and sports you selected.  Are you ready to assign these forms now?<br><br>If you want to save your work but aren't ready to assign it yet, click Cancel, then go clear all the checkboxes in the 'Assigned to' box and click Save again.  You can go pick who to assign the forms to when you're ready to assign it.`)
            .headerClass("hide")
            .okBtn("Assign These Forms Now").okBtnClass("btn btn-primary")
            .cancelBtnClass("btn btn-primary")
            .open().then((dialog : any ) => {
                return dialog.result;
            }).then(result =>{
                if(result === true){
                    resolve(true);
                }else{
                    resolve(false);
                }
            }).catch((e:any)=>{
                resolve(e);
            }).catch((e:any)=>{
                resolve(e);
            });
        });
    }

    //use for Add OR Update packet popup list data
    addPacket(assignment:PacketForm=null)
    {
        let packetName = "";
        if(assignment !== null && assignment !== undefined && assignment.activities[0].documentationEventDescription.eventName !== undefined){
            packetName = assignment.activities[0].documentationEventDescription.eventName;

            if(assignment._id !== this.assignmentId){
                this.lostDataPrompt().then((res:any)=>{
                    if(res == "save"){
                        this.checkBeforeSave().then((res:boolean)=>{
                            if(res == true){
                                this.savedata();
                                this.changePacket(assignment);
                            }
                        });
                    }else{
                        this.resetChanges();
                        this.changePacket(assignment);
                        this.openPacketPopup(packetName);
                    }
                }).catch(e=>{
                    // throw e;
                    // this.onCancel();
                });
            }else{
                this.openPacketPopup(packetName);
            }
        }else{
            this.openPacketPopup(packetName);
        }
    }

    openPacketPopup(packetName:String=null){
        // this.assignedToString = "None";
        let packetId = (new DfObjectId()).toString();
        let context = new BSModalContext();
        let adminFormPrintModalData = new AssignmentModalContext(packetName);
        let config = overlayConfigFactory(adminFormPrintModalData, BSModalContext);
        this._modal.open(TeamPacketCreationModalPrompt, config)
        .then(result => result.result)
        .then(result => {  }).then(result =>
        {
            if (result){
                this.refresh();
            }
        })
        .catch(e => console.log(e));
    }

    requiredForms()
    {
        if (!this.documentDescriptions)
            return [];

        return this.documentDescriptions.filter(dd => dd.required);
    }

    //use for generate packet pdf data
    onPrint(activityId,selectedarray)
    {
         if(selectedarray.managedByDF==true){
           
     }else{
        this.printing = true;
        this.errorMessage = '';
        if (activityId.length < 1)
        {
            this.printing = false;
            this.errorMessage = 'The selected Form(s) have not filled out any of the selected forms.';
            return;
        }
        this._docLoader.openpacketformsPdf(activityId, window).then(() =>
        {
            this.printing = false;
        }).catch(error =>
        {
            this.printing = false;
            console.error(error);
            this.errorMessage = 'We encountered an error printing.  Please try again.';
        });
     }
    }

    onCancel(){
        this.areYouSure().then(res=>{
            if(res){
                let selectedPack = _.find(this.documentationAssignments, (o:any)=>{
                    return this.assignmentId === o._id;
                });

                if(selectedPack !== undefined && selectedPack !== null){
                    this.changePacket(selectedPack);
                }else{
                    this.resetChanges();

                    if(this.documentationAssignments !== undefined && this.documentationAssignments !== null){
                        this.changePacket(this.documentationAssignments[0]);
                    }
                }
            }else{
            }
        }).catch(e=>{
            console.log(e);
        });
    }

   //use for Assignment delete  data
    onRemoveForm(i:number,name:string)
    {
        (<any>this._modal.confirm())
        .size('lg')
        .isBlocking(true)
        .showClose(false)
        .headerClass("hide")
        .cancelBtnClass("btn btn-primary")
        .keyboard(27)
        .body(`Do you want to remove ${name} from ${this.packetName}?`)
        .bodyClass('modal-body text-left')
        .okBtn(`Remove ${name}`).okBtnClass("btn btn-danger okbutton")
        .open()
        .then(res =>
        {
            res.result.then(r =>
            {
                if (r === true)
                {
                    if(this.packetformDataList.length > 0){
                        var filtered2 = _.reject(this.packetformDataList, function(arrItem:any){
                            return arrItem.name === name;
                        });

                        this.packetformDataList = filtered2;
                        //this.packetformDataList.splice(i, 1);
                    }
                    this.manageUnsavedPacket(this.packetformDataList, "form-modify");
                }
            })
            .catch(e =>
            {
                if (e)
                    throw e;
            });
        });
    }

    onRemoveOnlyDisplayMessage() {
        this.onremoveform=true;
        (<any>this._modal.alert()).message(`This form cannot be deleted.`).open().then(res =>
        {
            res.result.then(r =>
            {
                if (r === true)
                {
                    this.onremoveform=false;
                }
            })
        });
    }

    setClickedRow(index,managedByDF) {
       
         if(managedByDF==true && this.onremoveform==false){

            (<any>this._modal.alert()).message(`This form cannot be changed.`).open();
     }else{
        this.arrowdownactive = false;
        this.arrowupactive = false;
        this.selectedRow = index;

        if (this.selectedRow <= 0) {
            this.arrowupactive = true;
            this.arrowdownactive = false;
        }
        if (this.selectedRow == (Object.keys(this.packetformDataList).length) - 1) {
            this.arrowdownactive = true;
            this.arrowupactive = false;
        }
     }
    }

    // Move up form for using this function
    moveUp(num,managedByDF) {
     //  console.log(this.selectedRow);
     if(managedByDF==true){
            (<any>this._modal.alert()).message(`This form cannot be changed.`).open();
     }else{
          if (this.selectedRow == 1 || this.selectedRow <= 0) {

            this.arrowupactive = true;
            this.arrowdownactive = false;
        }
        if (num !== null && num > 0) {

            if (this.selectedRow == 1 || this.selectedRow <= 0) {
                this.arrowupactive = true;
            } else {

                this.arrowupactive = false;
                this.arrowdownactive = false;
            }
            var tmp = this.packetformDataList[num - 1];
            this.packetformDataList[num - 1] = this.packetformDataList[num];
            this.packetformDataList[num] = tmp;
            this.selectedRow--;
            this.manageUnsavedPacket(this.packetformDataList, "form-modify");
        }
     }
       
    }

    // Move down form for using this function
    moveDown(num,managedByDF) {
          if(managedByDF==true){
            (<any>this._modal.alert()).message(`This form cannot be changed.`).open();
     }else{
        if (num !== null && num < (Object.keys(this.packetformDataList).length) - 1) {
            var tmp = this.packetformDataList[num + 1];
            this.packetformDataList[num + 1] = this.packetformDataList[num];
            this.packetformDataList[num] = tmp;
            this.selectedRow++;
            this.arrowupactive = false;
            this.manageUnsavedPacket(this.packetformDataList, "form-modify");
        }
        if (this.selectedRow == (Object.keys(this.packetformDataList).length) - 1) {
            this.arrowdownactive = true;
        } else {
            this.arrowdownactive = false;
        }
     }
    }

    //
    droppedPerson(event) {
        this.droppedValue = event.dragData;
    }

    // Open popup for add form
    getActivities(managedByDF){
          if(managedByDF==true){
            (<any>this._modal.alert()).message(`This packet cannot be modified.`).open();
     }else{
        let adminFormPrintModalData = new CustomModalContext({data:this.selectedPacket.activities[0].documentationEventDescription.documents,org:this.currentOrgData});
        let config = overlayConfigFactory(adminFormPrintModalData, BSModalContext);
        this._modal.open(PacketFormModal, config).then(result =>{
        })
        .catch(e => console.log(e));
     }
    }

    // Open popup for add assignees
    formAssigns(){
        let customModalData = new AssignFormModalContext({currentOrgData:this.currentOrgData, selectedPacket:this.selectedPacket.assignees});
        let config = overlayConfigFactory(customModalData, BSModalContext);
        this._modal.open(AssignFormModal, config).then(result =>{
        })
        .catch(e => console.log(e));
    }

    // For remove package
    removeAssignment(assignmentId:string, name:string)
    {
        this.lostDataPrompt().then((res:any)=>{
            if(res === "save"){
                this.onSaveData();
            }else if(res === true){
                this._modal.confirm()
                .size('lg').isBlocking(true).showClose(false).keyboard(27)
                .body(`Do you want to delete ${name}?<br><br>Afterward, it will no longer be assigned to anyone, but any forms that have already been filled out will still be in MAX.`)
                .headerClass("hide")
                .okBtn("Remove").okBtnClass("btn btn-danger")
                .cancelBtnClass("btn btn-primary")
                .open().then((dialog : any ) => {
                    return dialog.result;
                }).then(result =>{
                    if(result === true){
                        // Delete code
                        this._assignmentsSvc.deleteAssigement(assignmentId).subscribe(() =>
                        {
                           this.refresh();
                        }, e =>{
                            this.errorMessage = 'We encountered an error deleting packet ';
                            throw e;
                        });
                    }
                }).catch((e:any)=>{
                }).catch((e:any)=>{
                });
            }
        }).catch(e=>{
            console.log(e);
        });
    }

    removeAssignmentOnlyDisplayMessage() {
        (<any>this._modal.alert()).message(`This packet cannot be deleted.`).open();
    }
    editAssignmentOnlyDisplayMessage() {
        (<any>this._modal.alert()).message(`This packet cannot be edited.`).open();
    }
     formAssignsdisable() {
        (<any>this._modal.alert()).message(`This packet cannot be Assign.`).open();
    }
    disableunAssignsEveryone() {
        (<any>this._modal.alert()).message(`This packet cannot be unassign for Everyone.`).open();
    }

    //use for crousal setting
    toggleType() {
        this.type = this.type == 'component' ? 'directive' : 'component';
    }
    onReachEnd(event: any) {
        // console.log('Swiper at the end!');
    }

    onIndexChange(index: number) {
        // console.log('Swiper index: ' + index);
    }

    unAssignsEveryone(){
        this.manageUnsavedPacket([], "assignees");
    }
}