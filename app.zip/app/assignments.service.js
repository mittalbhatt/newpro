System.register(["@angular/core", "@angular/http", "./pagedDataUtil.service", "./maxAppContext.service"], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, http_1, pagedDataUtil_service_1, maxAppContext_service_1;
    var Packet, Assignments;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (http_1_1) {
                http_1 = http_1_1;
            },
            function (pagedDataUtil_service_1_1) {
                pagedDataUtil_service_1 = pagedDataUtil_service_1_1;
            },
            function (maxAppContext_service_1_1) {
                maxAppContext_service_1 = maxAppContext_service_1_1;
            }],
        execute: function() {
            Packet = (function () {
                function Packet() {
                }
                return Packet;
            }());
            exports_1("Packet", Packet);
            Assignments = (function () {
                function Assignments(_http, ctx) {
                    this._http = _http;
                    this.ctx = ctx;
                    this.getPopupData = new core_1.EventEmitter();
                }
                Assignments.prototype.getUserAssignments = function (category, userProfileId) {
                    var _this = this;
                    return pagedDataUtil_service_1.PagedDataUtil.getAllPages(function (s, t) { return _this.getUserAssignmentPage(category, userProfileId, s, t); });
                };
                Assignments.prototype.getUserAssignmentPage = function (category, userProfileId, skip, take) {
                    return this._http.get("/training/api/assignments?skip=" + skip + "&limit=" + take + "&userProfileId=" + userProfileId + "&category=" + category)
                        .map(function (res) { return res.json(); });
                };
                Assignments.prototype.getUserPacketList = function (category, skip, take) {
                    return this._http.get("/training/api/assignments?skip=" + skip + "&limit=" + take + "&category=" + category + "&excludeReplaced=true&excludeEnded=true")
                        .map(function (res) { return res.json(); });
                };
                Assignments.prototype.getMine = function (packetDisposition) {
                    var _this = this;
                    if (packetDisposition === void 0) { packetDisposition = false; }
                    return pagedDataUtil_service_1.PagedDataUtil.getAllPages(function (s, t) { return _this.getMinePage(s, t, packetDisposition); });
                };
                Assignments.prototype.createPacket = function (packet) {
                    return this._http.put('/training/api/assignments', packet).map(function (res) { return res.json(); });
                };
                Assignments.prototype.createForm = function (packet) {
                    return this._http.put("/training/api/activities", packet).map(function (res) { return res.json(); });
                };
                Assignments.prototype.getMinePage = function (skip, take, packetDisposition) {
                    if (packetDisposition === void 0) { packetDisposition = false; }
                    var args = packetDisposition ? this.getDocPacketArgs() : new http_1.RequestOptions();
                    return this._http.get("/training/api/assignments/mine?skip=" + skip + "&limit=" + take, args)
                        .map(function (res) { return res.json(); });
                };
                Assignments.prototype.submit = function (assignmentId, profileId) {
                    if (profileId === void 0) { profileId = null; }
                    if (profileId === null) {
                        var profile = this.ctx.currentProfile;
                        profileId = profile._id;
                    }
                    return this._http.put("/training/api/assignments/" + assignmentId + "/" + profileId + "/submission", '')
                        .map(function (res) { return res.json(); });
                };
                Assignments.prototype.requestConfirmation = function (assignmentId, profileId, emailAddress) {
                    return this._http.post("/training/api/assignments/" + assignmentId + "/" + profileId + "/submission-confirmation?email=" + emailAddress, '');
                };
                Assignments.prototype.findOrCreate = function (activityId, profileId) {
                    return this._http.get("/training/api/activities/" + activityId + "/assignmentFactory/" + profileId)
                        .map(function (res) { return res.json(); });
                };
                Assignments.prototype.getActivities = function (type, skip, take) {
                    if (skip === void 0) { skip = 0; }
                    if (take === void 0) { take = 1000; }
                    var args = new http_1.RequestOptions();
                    args.search = new http_1.URLSearchParams();
                    args.search.append('skip', skip.toString());
                    args.search.append('limit', take.toString());
                    args.search.append('type', "" + type);
                    return this._http.get("/training/api/activities", args)
                        .map(function (res) { return res.json(); });
                };
                Assignments.prototype.delete = function (id) {
                    return this._http.delete("/training/api/assignments/" + id);
                };
                Assignments.prototype.deleteAssigement = function (id) {
                    return this._http.put("/training/api/assignments/" + id + "/end", '');
                };
                Assignments.prototype.getAllPackets = function (includeActivityResponses) {
                    if (includeActivityResponses === void 0) { includeActivityResponses = true; }
                    var args = this.getDocPacketArgs();
                    args.search.append('skip', '0');
                    args.search.append('limit', '1000');
                    if (includeActivityResponses) {
                        args.search.append('includeActivityResponses', 'true');
                        args.search.append('includeActivityResponsesAcrossReplacedAssignments', 'true');
                    }
                    return this._http.get("/training/api/assignments", args)
                        .map(function (res) { return res.json(); });
                };
                Assignments.prototype.getAssignments = function (activityId, skip, take) {
                    // var args = new RequestOptions();
                    // args.search = new URLSearchParams();
                    // args.search.append('skip', skip.toString());
                    // args.search.append('limit', take.toString());
                    if (skip === void 0) { skip = 0; }
                    if (take === void 0) { take = 1000; }
                    //return this._http.get(`/training/api/assignments/${activityId}`, args)
                    return this._http.get("/training/api/assignments/" + activityId)
                        .map(function (res) { return res.json(); });
                };
                Assignments.prototype.submitAdministratively = function (assignmentId, activityId, userProfileId) {
                    return this._http.post("/training/api/assignments/" + assignmentId + "/activities/" + activityId + "/responses?userProfileId=" + userProfileId, { completedDate: new Date(), responseData: { submitted: true, submittedAdministratively: true } });
                };
                Assignments.prototype.getDocPacketArgs = function () {
                    var args = new http_1.RequestOptions();
                    args.search = new http_1.URLSearchParams();
                    args.search.append('category', 'Documentation');
                    args.search.append('excludeReplaced', 'true');
                    args.search.append('excludeEnded', 'true');
                    return args;
                };
                Assignments = __decorate([
                    core_1.Injectable(), 
                    __metadata('design:paramtypes', [http_1.Http, maxAppContext_service_1.MaxAppContext])
                ], Assignments);
                return Assignments;
            }());
            exports_1("Assignments", Assignments);
        }
    }
});
//# sourceMappingURL=assignments.service.js.map